import TorusLifts
import Mathlib.Analysis.Calculus.MeanValue

namespace IsometricEmbeddingEndpoints

open ContinuousLinearMap

noncomputable section

variable {d E F G : Type*} [Fintype d]
  [NormedAddCommGroup E] [NormedSpace ℝ E]
  [NormedAddCommGroup F] [NormedSpace ℝ F]
  [NormedAddCommGroup G] [NormedSpace ℝ G]

/-- A Hölder estimate on the Euclidean lift of a continuous torus map. -/
def HasHolderLift (a : ℝ) (f : C(UnitAddTorus d, F)) : Prop :=
  ∃ C : ℝ, 0 ≤ C ∧ ∀ x y : Cover d,
    ‖f (flatProjection x) - f (flatProjection y)‖ ≤ C * ‖x - y‖ ^ a

theorem exists_norm_sub_le_for_contDiff_lift (f : C(UnitAddTorus d, F))
    (hf : ContDiff ℝ 1 (fun x => f (flatProjection x))) :
    ∃ L : ℝ, 0 ≤ L ∧ ∀ x y : Cover d,
      ‖f (flatProjection x) - f (flatProjection y)‖ ≤ L * ‖x - y‖ := by
  let D := torusDifferential f hf
  refine ⟨‖D‖, norm_nonneg D, fun x y => ?_⟩
  exact (convex_univ (𝕜 := ℝ) (E := Cover d)).norm_image_sub_le_of_norm_fderiv_le
    (fun z _ => hf.differentiable one_ne_zero z)
    (fun z _ => by
      rw [← torusDifferential_apply f hf]
      exact D.norm_coe_le_norm (flatProjection z))
    (Set.mem_univ y) (Set.mem_univ x)

theorem hasHolderLift_of_contDiff (f : C(UnitAddTorus d, F))
    (hf : ContDiff ℝ 1 (fun x => f (flatProjection x))) {a : ℝ}
    (ha : 0 ≤ a) (ha₁ : a ≤ 1) : HasHolderLift a f := by
  obtain ⟨L, hL, hfL⟩ := exists_norm_sub_le_for_contDiff_lift f hf
  refine ⟨2 * ‖f‖ + L, by positivity, fun x y => ?_⟩
  by_cases hxy : ‖x - y‖ ≤ 1
  · have hpow : ‖x - y‖ ≤ ‖x - y‖ ^ a := by
      simpa only [Real.rpow_one] using
        Real.rpow_le_rpow_of_exponent_ge' (norm_nonneg (x - y)) hxy ha ha₁
    exact (hfL x y).trans ((mul_le_mul_of_nonneg_left hpow hL).trans
      (mul_le_mul_of_nonneg_right (by linarith [norm_nonneg f]) (Real.rpow_nonneg (norm_nonneg _) _)))
  · calc
      _ ≤ ‖f (flatProjection x)‖ + ‖f (flatProjection y)‖ := norm_sub_le _ _
      _ ≤ 2 * ‖f‖ := by rw [two_mul]; exact add_le_add (f.norm_coe_le_norm _) (f.norm_coe_le_norm _)
      _ ≤ 2 * ‖f‖ + L := le_add_of_nonneg_right hL
      _ ≤ _ := le_mul_of_one_le_right (by positivity) (Real.one_le_rpow (le_of_not_ge hxy) ha)

/-- Hölder regularity is preserved by a bilinear operation on continuous torus maps.
Their bounds come from compactness of the torus. -/
theorem HasHolderLift.bilinear {a : ℝ}
    (B : E →L[ℝ] F →L[ℝ] G) {f : C(UnitAddTorus d, E)} {g : C(UnitAddTorus d, F)}
    (hf : HasHolderLift a f) (hg : HasHolderLift a g) :
    HasHolderLift a ⟨fun t => B (f t) (g t), (B.continuous.comp f.continuous).clm_apply g.continuous⟩ := by
  obtain ⟨C, hC, hf⟩ := hf
  obtain ⟨K, hK, hg⟩ := hg
  refine ⟨‖B‖ * (C * ‖g‖ + ‖f‖ * K), by positivity, fun x y => ?_⟩
  let s := flatProjection x
  let t := flatProjection y
  change ‖B (f s) (g s) - B (f t) (g t)‖ ≤ _
  have heq : B (f s) (g s) - B (f t) (g t) =
      B (f s - f t) (g s) + B (f t) (g s - g t) := by
    simp only [map_sub, sub_apply]
    abel
  rw [heq]
  calc
    _ ≤ ‖B (f s - f t) (g s)‖ + ‖B (f t) (g s - g t)‖ := norm_add_le _ _
    _ ≤ ‖B‖ * ‖f s - f t‖ * ‖g s‖ + ‖B‖ * ‖f t‖ * ‖g s - g t‖ :=
      add_le_add (B.le_opNorm₂ _ _) (B.le_opNorm₂ _ _)
    _ ≤ ‖B‖ * (C * ‖x - y‖ ^ a) * ‖g‖ + ‖B‖ * ‖f‖ * (K * ‖x - y‖ ^ a) := by
      gcongr
      · exact hf x y
      · exact g.norm_coe_le_norm s
      · exact f.norm_coe_le_norm t
      · exact hg x y
    _ = _ := by ring

theorem HasHolderLift.add {a : ℝ} {f g : C(UnitAddTorus d, F)}
    (hf : HasHolderLift a f) (hg : HasHolderLift a g) : HasHolderLift a (f + g) := by
  obtain ⟨C, hC, hf⟩ := hf
  obtain ⟨K, hK, hg⟩ := hg
  refine ⟨C + K, by positivity, fun x y => ?_⟩
  simp only [ContinuousMap.add_apply, add_sub_add_comm, add_mul]
  exact (norm_add_le _ _).trans (add_le_add (hf x y) (hg x y))

theorem HasHolderLift.postcomp {a : ℝ} {f : C(UnitAddTorus d, F)}
    (hf : HasHolderLift a f) (T : F →L[ℝ] G) :
    HasHolderLift a ⟨T ∘ f, T.continuous.comp f.continuous⟩ := by
  obtain ⟨C, hC, hf⟩ := hf
  refine ⟨‖T‖ * C, by positivity, fun x y => ?_⟩
  change ‖T (f (flatProjection x)) - T (f (flatProjection y))‖ ≤ _
  rw [← map_sub, mul_assoc]
  exact (T.le_opNorm _).trans (mul_le_mul_of_nonneg_left (hf x y) (norm_nonneg T))

/-- A Hölder field on a set pulls back under a smooth periodic map with image in that set. -/
theorem HasHolderLift.of_comp {a C : ℝ} {s : Set E} {f : E → F} (hf : ContinuousOn f s)
    (hC : 0 ≤ C) (ha : 0 ≤ a)
    (hholder : ∀ x ∈ s, ∀ y ∈ s, ‖f x - f y‖ ≤ C * ‖x - y‖ ^ a)
    (g : C(UnitAddTorus d, E)) (hg : ContDiff ℝ 1 (fun x => g (flatProjection x)))
    (hs : ∀ t, g t ∈ s) :
    HasHolderLift a ⟨f ∘ g, hf.comp_continuous g.continuous hs⟩ := by
  obtain ⟨L, hL, hG⟩ := exists_norm_sub_le_for_contDiff_lift g hg
  refine ⟨C * L ^ a, by positivity, fun x y => ?_⟩
  calc
    _ ≤ C * ‖g (flatProjection x) - g (flatProjection y)‖ ^ a :=
      hholder _ (hs _) _ (hs _)
    _ ≤ C * (L * ‖x - y‖) ^ a :=
      mul_le_mul_of_nonneg_left (Real.rpow_le_rpow (norm_nonneg _) (hG x y) ha) hC
    _ = _ := by rw [Real.mul_rpow hL (norm_nonneg _), mul_assoc]

end

end IsometricEmbeddingEndpoints

#print axioms IsometricEmbeddingEndpoints.hasHolderLift_of_contDiff
#print axioms IsometricEmbeddingEndpoints.HasHolderLift.bilinear
#print axioms IsometricEmbeddingEndpoints.HasHolderLift.of_comp
