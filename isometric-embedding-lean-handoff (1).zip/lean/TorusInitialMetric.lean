import MetricAmplitude
import TorusInitialApproximation
import TorusLatticeApproximation

namespace IsometricEmbeddingEndpoints

open ContinuousLinearMap

noncomputable section

variable {d : Type*} [Fintype d] [DecidableEq d]

local instance : NormedAddCommGroup (MetricForm d) := inferInstance
local instance : NormedSpace ℝ (MetricForm d) := inferInstance

/-- For a fixed positive metric, the same finite family of directions works for
all sufficiently small scalar deficits subtracted from it. -/
theorem TorusMetric.exists_shiftedLatticeMetric (g : TorusMetric d) :
    ∃ (n : ℕ) (δ₀ : ℝ) (ξ : (Fin n × Fin (Module.finrank ℝ (Cover d))) ⊕ TwistIndex d → d → ℤ),
      0 < δ₀ ∧ ∀ δ, 0 ≤ δ → δ ≤ δ₀ →
        ∃ a : ((Fin n × Fin (Module.finrank ℝ (Cover d))) ⊕ TwistIndex d) → C(UnitAddTorus d, ℝ),
          torusLatticeMetric ξ a = g.form - δ • flatMetric := by
  obtain ⟨m, hm, hlower⟩ := g.exists_lowerBound
  obtain ⟨ε, hε, hAmp⟩ := exists_continuous_metricAmplitudes (d := d)
  let ρ := m / 2
  have hρ : 0 < ρ := by dsimp only [ρ]; positivity
  let g₁ : TorusMetric d :=
    { form := g.form - ρ • flatMetric
      symmetric := fun t v w => by
        simp only [ContinuousMap.sub_apply, ContinuousMap.smul_apply, sub_apply, smul_apply,
          smul_eq_mul, flatMetric_apply, g.symmetric t v w, real_inner_comm v w]
      positive := fun t v hv => by
        simp only [ContinuousMap.sub_apply, ContinuousMap.smul_apply, sub_apply, smul_apply,
          smul_eq_mul, flatMetric_apply, real_inner_self_eq_norm_sq]
        have hnorm := norm_pos_iff.mpr hv
        have hgap : 0 < (m - ρ) * ‖v‖ ^ 2 := mul_pos (by dsimp only [ρ]; linarith) (by positivity)
        linarith [hlower t v] }
  obtain ⟨n, ξ₀, a₀, happrox⟩ := g₁.exists_latticeMetric_near (ε := (ρ / 2) * ε) (by positivity)
  let R := torusLatticeMetric ξ₀ a₀
  let ξ := Sum.elim ξ₀ (twistDirection (d := d))
  refine ⟨n, ρ / 2, ξ, by positivity, ?_⟩
  intro δ hδ hδsmall
  let μ := ρ - δ
  have hμ₁ : ρ / 2 ≤ μ := by dsimp only [μ]; linarith
  have hμ : 0 < μ := (by positivity : 0 < ρ / 2).trans_le hμ₁
  let E := μ⁻¹ • (g₁.form - R)
  have hE : ‖E‖ ≤ ε := by
    change ‖μ⁻¹ • (g₁.form - R)‖ ≤ ε
    rw [norm_smul μ⁻¹ (g₁.form - R), Real.norm_eq_abs, abs_of_nonneg (inv_nonneg.mpr hμ.le),
      norm_sub_rev g₁.form R, ← div_eq_inv_mul, div_le_iff₀ hμ]
    exact (happrox.le).trans (by rw [mul_comm ε μ]; exact mul_le_mul_of_nonneg_right hμ₁ hε.le)
  have hEsym (t : UnitAddTorus d) (v w : Cover d) : E t v w = E t w v := by
    change ((μ⁻¹ • (g₁.form - R)) : C(UnitAddTorus d, MetricForm d)) t v w = _
    simp only [E, ContinuousMap.smul_apply, ContinuousMap.sub_apply, smul_apply, sub_apply,
      smul_eq_mul, g₁.symmetric t v w, R, torusLatticeMetric_symmetric ξ₀ a₀ t v w]
  obtain ⟨a₁, ha₁⟩ := hAmp E hμ.le hE hEsym
  let a := Sum.elim a₀ a₁
  have hErel : μ • E = g₁.form - R := by
    simp only [E, smul_smul, mul_inv_cancel₀ hμ.ne', one_smul]
  refine ⟨a, ?_⟩
  ext t v w
  rw [torusLatticeMetric_apply, Fintype.sum_sum_type]
  simp only [ξ, a, Sum.elim_inl, Sum.elim_inr, ha₁, ContinuousMap.sub_apply,
    ContinuousMap.smul_apply, sub_apply, smul_apply, smul_eq_mul, flatMetric_apply]
  have he := congrArg (fun q : C(UnitAddTorus d, MetricForm d) => q t v w) hErel
  simp only [ContinuousMap.smul_apply, ContinuousMap.sub_apply, smul_apply, sub_apply, smul_eq_mul,
    g₁, flatMetric_apply, R, torusLatticeMetric_apply] at he
  rw [mul_add, he]
  dsimp only [μ]
  ring

/-- Choose the target dimension before choosing the initial scalar deficit and
the precision of its first approximation. -/
theorem TorusMetric.exists_fixed_target_initialMap (g : TorusMetric d) :
    ∃ (n : ℕ) (δ₀ : ℝ), 0 < δ₀ ∧
      ∀ δ ε : ℝ, 0 ≤ δ → δ ≤ δ₀ → 0 < ε →
        ∃ (s : ℝ)
          (u : C(UnitAddTorus d, PiLp 2 (fun _ : (Fin n × Fin (Module.finrank ℝ (Cover d))) ⊕
            TwistIndex d => CirclePair))) (hu : ContDiff ℝ 1 (fun x => u (flatProjection x))),
          0 < s ∧ HasFourierSupport (torusCutoffBand (d := d) s : Set (d → ℤ)) u ∧
          ‖torusGram (torusDifferential u hu) - (g.form - δ • flatMetric)‖ < ε := by
  obtain ⟨n, δ₀, ξ, hδ₀, hdecompose⟩ := g.exists_shiftedLatticeMetric
  refine ⟨n, δ₀, hδ₀, fun δ ε hδ hδsmall hε => ?_⟩
  obtain ⟨a, ha⟩ := hdecompose δ hδ hδsmall
  rw [← ha]
  exact exists_initialMap_of_latticeMetric ξ a hε

end

end IsometricEmbeddingEndpoints

#print axioms IsometricEmbeddingEndpoints.TorusMetric.exists_fixed_target_initialMap
