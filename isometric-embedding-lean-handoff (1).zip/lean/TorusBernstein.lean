import TorusCutoff
import Mathlib.Analysis.SpecialFunctions.ExpDeriv

namespace IsometricEmbeddingEndpoints

open MeasureTheory
open scoped FourierTransform

noncomputable section

variable {d : Type*} [Fintype d]

/-- The complex linear phase in the exponential on the real Euclidean cover. -/
def modeFrequency (ξ : Cover d) : Cover d →L[ℝ] ℂ :=
  (2 * Real.pi * Complex.I : ℂ) • (Complex.ofRealCLM.comp (innerSL ℝ ξ))

private theorem modeFrequency_apply (ξ v : Cover d) :
    modeFrequency ξ v = (2 * Real.pi * Complex.I : ℂ) * (inner ℝ ξ v : ℂ) := rfl

theorem mFourier_flatProjection_eq_exp (n : d → ℤ) (x : Cover d) :
    UnitAddTorus.mFourier n (flatProjection x) =
      Complex.exp (modeFrequency (latticeVector n) x) := by
  have hn : latticeVector (-n) = -latticeVector n := by
    ext i
    simp [latticeVector]
  have h := mFourier_neg_flatProjection (-n) x
  rw [neg_neg, hn, negativeCarrier, inner_neg_right, neg_neg, Real.fourierChar_apply] at h
  rw [h, modeFrequency_apply, real_inner_comm x, Complex.ofReal_mul, Complex.ofReal_mul]
  push_cast
  ring_nf

private def derivativeKernelSchwartz (v : Cover d) : SchwartzMap (Cover d) ℂ :=
  SchwartzMap.evalCLM ℂ (Cover d) ℂ v
    (SchwartzMap.fderivCLM ℂ (Cover d) ℂ (cutoffKernel unitCutoffSymbol))

private theorem fourier_derivativeKernelSchwartz (v ξ : Cover d) :
    (𝓕 (derivativeKernelSchwartz v) : SchwartzMap (Cover d) ℂ) ξ =
      modeFrequency ξ v * unitCutoffSymbol ξ := by
  simp only [derivativeKernelSchwartz, SchwartzMap.fourier_evalCLM_eq,
    SchwartzMap.fourier_fderivCLM_eq, fourier_cutoffKernel, SchwartzMap.evalCLM_apply_apply,
    smul_apply, SchwartzMap.smulRightCLM_apply_apply,
    ContinuousLinearMap.smulRight_apply, innerSL_apply_apply ℝ, Complex.real_smul,
    modeFrequency_apply, smul_eq_mul]
  ring

private def scaledDerivativeKernel (scale : ℝ) (v : Cover d) (y : Cover d) : ℂ :=
  scale • dilatedKernel scale (derivativeKernelSchwartz v) y

private theorem scaledDerivativeKernel_multiplier {scale : ℝ} (hs : 0 < scale)
    (v ξ : Cover d) :
    (∫ y, negativeCarrier ξ y * scaledDerivativeKernel scale v y) =
      modeFrequency ξ v * unitCutoffSymbol (scale⁻¹ • ξ) := by
  let χ := 𝓕 (derivativeKernelSchwartz v)
  have hK : cutoffKernel χ = derivativeKernelSchwartz v := by simp [χ, cutoffKernel]
  have hm := dilated_cutoffKernel_modulated_mass χ hs ξ
  rw [hK, fourier_derivativeKernelSchwartz] at hm
  calc
    _ = (scale : ℂ) * ∫ y, negativeCarrier ξ y * dilatedKernel scale (derivativeKernelSchwartz v) y := by
      rw [← integral_const_mul]
      apply integral_congr_ae
      exact Filter.Eventually.of_forall fun y => by
        simp only [scaledDerivativeKernel, Complex.real_smul]
        ring
    _ = _ := by
      rw [hm, modeFrequency_apply, modeFrequency_apply, real_inner_smul_left,
        Complex.ofReal_mul, Complex.ofReal_inv]
      field_simp [Complex.ofReal_ne_zero.mpr hs.ne']

private theorem integrable_scaledDerivativeKernel {scale : ℝ} (hs : 0 < scale) (v : Cover d) :
    Integrable (scaledDerivativeKernel scale v) := by
  have h := (derivativeKernelSchwartz v).integrable.comp_smul (μ := volume) hs.ne'
  exact ((h.smul (𝕜 := ℝ) (scale ^ Module.finrank ℝ (Cover d))).smul (𝕜 := ℝ) scale)

/-- The directional derivative of a reproduced band is convolution by the differentiated kernel. -/
def derivativeCutoff {scale : ℝ} (hs : 0 < scale) (v : Cover d) :
    C(UnitAddTorus d, ℂ) →L[ℂ] C(UnitAddTorus d, ℂ) :=
  weightedShiftOperator flatProjection (scaledDerivativeKernel scale v)
    (integrable_scaledDerivativeKernel hs v)

private theorem derivativeCutoff_on_modes {scale : ℝ} (hs : 0 < scale) (v : Cover d) (n : d → ℤ) :
    derivativeCutoff hs v (UnitAddTorus.mFourier n) =
      (modeFrequency (latticeVector n) v * unitCutoffSymbol (scale⁻¹ • latticeVector n)) •
        UnitAddTorus.mFourier n := by
  rw [derivativeCutoff, weightedShiftOperator_on_modes, scaledDerivativeKernel_multiplier hs]

theorem derivativeCutoff_mem_modeSpan {scale : ℝ} (hs : 0 < scale) (v : Cover d)
    {band : Set (d → ℤ)} {f : C(UnitAddTorus d, ℂ)}
    (hf : f ∈ Submodule.span ℂ (UnitAddTorus.mFourier '' band)) :
    derivativeCutoff hs v f ∈ Submodule.span ℂ (UnitAddTorus.mFourier '' band) := by
  let P := Submodule.span ℂ (UnitAddTorus.mFourier '' band)
  have hP : P ≤ P.comap (derivativeCutoff hs v).toLinearMap := by
    refine Submodule.span_le.2 ?_
    rintro _ ⟨n, hn, rfl⟩
    change derivativeCutoff hs v (UnitAddTorus.mFourier n) ∈ P
    rw [derivativeCutoff_on_modes]
    exact P.smul_mem _ (Submodule.subset_span ⟨n, hn, rfl⟩)
  exact hP hf

theorem contDiff_lift_of_modeSpan {band : Set (d → ℤ)} {f : C(UnitAddTorus d, ℂ)}
    (hf : f ∈ Submodule.span ℂ (UnitAddTorus.mFourier '' band)) {k : WithTop ℕ∞} :
    ContDiff ℝ k (fun x : Cover d => f (flatProjection x)) := by
  induction hf using Submodule.span_induction with
  | mem g hg =>
    obtain ⟨n, _, rfl⟩ := hg
    simp only [mFourier_flatProjection_eq_exp]
    exact (modeFrequency (latticeVector n)).contDiff.cexp
  | zero => exact contDiff_const
  | add g h _ _ hg hh => exact hg.add hh
  | smul c g _ hg => exact contDiff_const.smul hg

theorem exists_hasFDerivAt_of_modeSpan {scale : ℝ} (hs : 0 < scale)
    {band : Set (d → ℤ)} (hone : ∀ n ∈ band, ‖scale⁻¹ • latticeVector n‖ ≤ 1)
    {f : C(UnitAddTorus d, ℂ)}
    (hf : f ∈ Submodule.span ℂ (UnitAddTorus.mFourier '' band)) (x : Cover d) :
    ∃ D : Cover d →L[ℝ] ℂ, HasFDerivAt (fun z => f (flatProjection z)) D x ∧
      ∀ v, D v = derivativeCutoff hs v f (flatProjection x) := by
  induction hf using Submodule.span_induction with
  | mem g hg =>
    obtain ⟨n, hn, rfl⟩ := hg
    let L := modeFrequency (latticeVector n)
    refine ⟨Complex.exp (L x) • L, ?_, ?_⟩
    · simpa only [mFourier_flatProjection_eq_exp, L] using L.hasFDerivAt.cexp (x := x)
    · intro v
      rw [derivativeCutoff_on_modes, unitCutoffSymbol_one (hone n hn), mul_one]
      change Complex.exp (L x) * L v = L v * UnitAddTorus.mFourier n (flatProjection x)
      rw [mFourier_flatProjection_eq_exp, mul_comm]
  | zero =>
    refine ⟨0, hasFDerivAt_const (0 : ℂ) x, ?_⟩
    intro v
    rw [map_zero]
    rfl
  | add g h _ _ hg hh =>
    obtain ⟨Dg, hDg, hg⟩ := hg
    obtain ⟨Dh, hDh, hh⟩ := hh
    refine ⟨Dg + Dh, hDg.add hDh, fun v => ?_⟩
    rw [map_add]
    change Dg v + Dh v = _
    rw [hg, hh]
    rfl
  | smul c g _ hg =>
    obtain ⟨Dg, hDg, hg⟩ := hg
    refine ⟨c • Dg, hDg.const_smul c, fun v => ?_⟩
    rw [map_smul]
    change c * Dg v = _
    rw [hg]
    rfl

/-- The uniform Bernstein constant is the integral of the operator norm of the unit kernel's
gradient. It is independent of the polynomial and its frequency scale. -/
def bernsteinConstant (d : Type*) [Fintype d] : ℝ :=
  ∫ y, ‖SchwartzMap.fderivCLM ℂ (Cover d) ℂ
    (cutoffKernel unitCutoffSymbol) y‖

private theorem integral_norm_scaledDerivativeKernel_le {scale : ℝ} (hs : 0 < scale)
    (v : Cover d) :
    (∫ y, ‖scaledDerivativeKernel scale v y‖) ≤ scale * bernsteinConstant d * ‖v‖ := by
  have hscale :
      (∫ y, ‖dilatedKernel scale (derivativeKernelSchwartz v) y‖) =
        ∫ y, ‖derivativeKernelSchwartz v y‖ := by
    simpa only [neg_zero, Real.rpow_zero, mul_one, one_mul] using
      integral_dilatedKernel_norm_rpow (derivativeKernelSchwartz v) hs 0
  simp only [scaledDerivativeKernel, norm_smul, Real.norm_eq_abs, abs_of_pos hs,
    integral_const_mul, hscale]
  rw [mul_assoc, bernsteinConstant, ← integral_mul_const]
  apply mul_le_mul_of_nonneg_left _ hs.le
  exact integral_mono (derivativeKernelSchwartz v).integrable.norm
    ((SchwartzMap.fderivCLM ℂ (Cover d) ℂ
      (cutoffKernel unitCutoffSymbol)).integrable.norm.mul_const ‖v‖)
    (fun y => ContinuousLinearMap.le_opNorm _ _)

theorem norm_derivativeCutoff_le {scale : ℝ} (hs : 0 < scale) (v : Cover d)
    (f : C(UnitAddTorus d, ℂ)) :
    ‖derivativeCutoff hs v f‖ ≤ scale * bernsteinConstant d * ‖v‖ * ‖f‖ :=
  (norm_weightedShiftOperator_apply_le _ _ _ _).trans
    (mul_le_mul_of_nonneg_right (integral_norm_scaledDerivativeKernel_le hs v) (norm_nonneg _))

theorem norm_fderiv_lift_le_of_modeSpan {scale : ℝ} (hs : 0 < scale)
    {band : Set (d → ℤ)} (hone : ∀ n ∈ band, ‖scale⁻¹ • latticeVector n‖ ≤ 1)
    {f : C(UnitAddTorus d, ℂ)}
    (hf : f ∈ Submodule.span ℂ (UnitAddTorus.mFourier '' band)) (x : Cover d) :
    ‖fderiv ℝ (fun z => f (flatProjection z)) x‖ ≤ scale * bernsteinConstant d * ‖f‖ := by
  obtain ⟨D, hD, hDv⟩ := exists_hasFDerivAt_of_modeSpan hs hone hf x
  rw [hD.fderiv]
  have hC : 0 ≤ bernsteinConstant d := integral_nonneg fun _ => norm_nonneg _
  apply D.opNorm_le_bound (mul_nonneg (mul_nonneg hs.le hC) (norm_nonneg _))
  intro v
  rw [hDv]
  calc
    _ ≤ ‖derivativeCutoff hs v f‖ := (derivativeCutoff hs v f).norm_coe_le_norm _
    _ ≤ (scale * bernsteinConstant d * ‖v‖) * ‖f‖ := norm_derivativeCutoff_le hs v f
    _ = _ := mul_right_comm _ _ _

/-- Every extra derivative of a band-limited function costs one power of the frequency. -/
theorem norm_iteratedFDeriv_lift_le_of_modeSpan {scale : ℝ} (hs : 0 < scale)
    {band : Set (d → ℤ)} (hone : ∀ n ∈ band, ‖scale⁻¹ • latticeVector n‖ ≤ 1)
    {f : C(UnitAddTorus d, ℂ)}
    (hf : f ∈ Submodule.span ℂ (UnitAddTorus.mFourier '' band)) (x : Cover d) (j : ℕ) :
    ‖iteratedFDeriv ℝ j (fun z => f (flatProjection z)) x‖ ≤
      (scale * bernsteinConstant d) ^ j * ‖f‖ := by
  let C := scale * bernsteinConstant d
  have hC : 0 ≤ C := mul_nonneg hs.le (integral_nonneg fun _ => norm_nonneg _)
  change _ ≤ C ^ j * ‖f‖
  induction j generalizing f with
  | zero => simpa only [norm_iteratedFDeriv_zero, pow_zero, one_mul] using f.norm_coe_le_norm _
  | succ j ih =>
    apply ContinuousMultilinearMap.opNorm_le_bound
      (mul_nonneg (pow_nonneg hC _) (norm_nonneg _))
    intro m
    let v := m (Fin.last j)
    let G := derivativeCutoff hs v f
    have hG : ∀ z, fderiv ℝ (fun y => f (flatProjection y)) z v = G (flatProjection z) := by
      intro z
      obtain ⟨D, hD, hDv⟩ := exists_hasFDerivAt_of_modeSpan hs hone hf z
      rw [hD.fderiv]
      exact hDv v
    have hd := (contDiff_infty_iff_fderiv.mp (contDiff_lift_of_modeSpan hf)).2
    rw [iteratedFDeriv_succ_apply_right,
      ← iteratedFDeriv_clm_apply_const_apply hd (by simp) (u := v), funext hG]
    calc
      _ ≤ (C ^ j * ‖G‖) * ∏ i, ‖Fin.init m i‖ :=
        (iteratedFDeriv ℝ j (fun z => G (flatProjection z)) x).le_of_opNorm_le
          (ih (derivativeCutoff_mem_modeSpan hs v hf)) _
      _ ≤ (C ^ j * (C * ‖v‖ * ‖f‖)) * ∏ i, ‖Fin.init m i‖ :=
        mul_le_mul_of_nonneg_right
          (mul_le_mul_of_nonneg_left (norm_derivativeCutoff_le hs v f) (pow_nonneg hC _))
          (Finset.prod_nonneg fun _ _ => norm_nonneg _)
      _ = _ := by
        rw [Fin.prod_univ_castSucc, pow_succ]
        simp only [Fin.init, v]
        ring

end

end IsometricEmbeddingEndpoints

#print axioms IsometricEmbeddingEndpoints.norm_fderiv_lift_le_of_modeSpan
#print axioms IsometricEmbeddingEndpoints.norm_iteratedFDeriv_lift_le_of_modeSpan
