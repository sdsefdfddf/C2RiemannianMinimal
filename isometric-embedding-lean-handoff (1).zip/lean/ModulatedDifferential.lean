import RealTorusCutoff
import TorusBernstein

namespace IsometricEmbeddingEndpoints

open MeasureTheory

noncomputable section

variable {d H : Type*} [Fintype d] [NormedAddCommGroup H] [NormedSpace ℝ H] [CompleteSpace H]

/-- Differentiating the real carrier splits its differential into a sine and a cosine
with constant real-linear coefficients. -/
theorem hasFDerivAt_fourierCarrier_lift (n : d → ℤ) (c : ℂ) (x : Cover d) :
    let L := modeFrequency (latticeVector n)
    let t := flatProjection x
    HasFDerivAt (fun z => fourierCarrier n c (flatProjection z))
      (fourierCarrier n c t • Complex.reCLM.comp L +
        fourierCarrier n (Complex.I * c) t • Complex.imCLM.comp L) x := by
  dsimp only
  let L := modeFrequency (latticeVector n)
  have hc := (L.hasFDerivAt.cexp (x := x)).const_mul c
  have hd := Complex.reCLM.hasFDerivAt.comp x hc
  convert hd using 1
  · funext z
    change (c * UnitAddTorus.mFourier n (flatProjection z)).re = (c * Complex.exp (L z)).re
    rw [mFourier_flatProjection_eq_exp]
  · ext v
    simp only [fourierCarrier, ContinuousMap.coe_mk, ContinuousLinearMap.comp_apply, smul_apply,
      add_apply, smul_eq_mul, mFourier_flatProjection_eq_exp, L]
    change (c * Complex.exp (L x)).re * (L v).re +
      (Complex.I * c * Complex.exp (L x)).re * (L v).im =
      (c * (Complex.exp (L x) * L v)).re
    rw [mul_assoc Complex.I c, ← mul_assoc c]
    simp [Complex.mul_re]
    ring

omit [CompleteSpace H] in
/-- The product rule keeps the original carrier frequencies. It yields one amplitude
containing the derivative of the original amplitude and two containing only its value. -/
theorem hasFDerivAt_fourierCarrier_smul_lift (n : d → ℤ) (c : ℂ)
    (A : C(UnitAddTorus d, H)) {DA : Cover d →L[ℝ] H} {x : Cover d}
    (hA : HasFDerivAt (fun z => A (flatProjection z)) DA x) :
    let L := modeFrequency (latticeVector n)
    let t := flatProjection x
    HasFDerivAt (fun z => (fourierCarrier n c • A) (flatProjection z))
      (fourierCarrier n c t • DA +
        fourierCarrier n c t • (Complex.reCLM.comp L).smulRight (A t) +
        fourierCarrier n (Complex.I * c) t • (Complex.imCLM.comp L).smulRight (A t)) x := by
  dsimp only
  convert (hasFDerivAt_fourierCarrier_lift n c x).smul hA using 1
  ext v
  simp only [add_apply, smul_apply, ContinuousLinearMap.smulRight_apply, add_smul, smul_smul]
  abel

theorem realTorusCutoff_add {scale : ℝ} (hs : 0 < scale)
    (f g : C(UnitAddTorus d, H)) :
    realTorusCutoff scale (f + g) = realTorusCutoff scale f + realTorusCutoff scale g := by
  ext t
  simp only [realTorusCutoff_apply hs, ContinuousMap.add_apply, smul_add]
  exact integral_add (integrable_realTorusCutoff_eval hs f t)
    (integrable_realTorusCutoff_eval hs g t)

theorem realTorusCutoff_finset_sum {ι : Type*} {scale : ℝ} (hs : 0 < scale)
    (s : Finset ι) (f : ι → C(UnitAddTorus d, H)) :
    realTorusCutoff scale (∑ i ∈ s, f i) = ∑ i ∈ s, realTorusCutoff scale (f i) := by
  classical
  induction s using Finset.induction_on with
  | empty =>
    ext t
    simp [realTorusCutoff_apply hs]
  | insert i s hi ih =>
    rw [Finset.sum_insert hi, Finset.sum_insert hi, realTorusCutoff_add hs, ih]

/-- A differential that is a finite sum of modulated amplitudes can be filtered with an
error estimate for each amplitude. The powers may differ, as they do for an amplitude and its
first derivative. -/
theorem norm_fderiv_realTorusCutoff_sub_le_of_modulated_differential {ι : Type*}
    {scale : ℝ} (hs : 0 < scale) (s : Finset ι) (n : ι → d → ℤ) (c : ι → ℂ)
    (A : ι → C(UnitAddTorus d, Cover d →L[ℝ] H))
    (P : C(UnitAddTorus d, H)) (DP : C(UnitAddTorus d, Cover d →L[ℝ] H))
    (hP : ∀ x : Cover d, HasFDerivAt (fun z => P (flatProjection z)) (DP (flatProjection x)) x)
    (hDP : DP = ∑ i ∈ s, fourierCarrier (n i) (c i) • A i)
    (hband : ∀ i ∈ s, ‖scale⁻¹ • latticeVector (n i)‖ < 1)
    (x : Cover d) (r C : ι → ℝ) (hr : ∀ i ∈ s, 0 ≤ r i ∧ r i ≤ 2)
    (hC : ∀ i ∈ s, 0 ≤ C i) (B : ι → Cover d →L[ℝ] Cover d →L[ℝ] H)
    (hrem : ∀ i ∈ s, ∀ y : Cover d,
      ‖A i (flatProjection (x - y)) - A i (flatProjection x) + B i y‖ ≤ C i * ‖y‖ ^ r i) :
    ‖fderiv ℝ (fun z => realTorusCutoff scale P (flatProjection z)) x -
      fderiv ℝ (fun z => P (flatProjection z)) x‖ ≤
      ∑ i ∈ s, C i * (‖c i‖ * (scale ^ (-(r i)) *
        ∫ y : Cover d, ‖cutoffKernel unitCutoffSymbol y‖ * ‖y‖ ^ r i)) := by
  rw [(hasFDerivAt_realTorusCutoff_lift hs P DP hP x).fderiv, (hP x).fderiv]
  let t := flatProjection x
  let F := fun i => fourierCarrier (n i) (c i) • A i
  change ‖(realTorusCutoff scale DP - DP) t‖ ≤ _
  rw [show DP = ∑ i ∈ s, F i from hDP, realTorusCutoff_finset_sum hs, ← Finset.sum_sub_distrib]
  change ‖(ContinuousMap.evalCLM ℝ t) (∑ i ∈ s, (realTorusCutoff scale (F i) - F i))‖ ≤ _
  rw [map_sum]
  refine (norm_sum_le _ _).trans (Finset.sum_le_sum fun i hi => ?_)
  exact norm_realTorusCutoff_sub_le_of_modulated_remainder hs (hr i hi).1 (hr i hi).2
    (hC i hi) (n i) (hband i hi) (c i) (A i) (B i) x (hrem i hi)

end

end IsometricEmbeddingEndpoints

#print axioms IsometricEmbeddingEndpoints.norm_fderiv_realTorusCutoff_sub_le_of_modulated_differential
#print axioms IsometricEmbeddingEndpoints.hasFDerivAt_fourierCarrier_smul_lift
