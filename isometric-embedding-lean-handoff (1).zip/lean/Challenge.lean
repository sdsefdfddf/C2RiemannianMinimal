module

public import ClosedManifoldStatement

open scoped ContDiff Manifold NNReal

public section

namespace IsometricEmbeddingEndpoints

local notation "𝓔" d:arg => 𝓘(ℝ, Euclidean d)

variable {d N : ℕ} {M : Type*} [TopologicalSpace M] [ChartedSpace (Euclidean d) M]

local notation "T" M:arg => TangentSpace (𝓔 d) (M := M)

variable [T2Space M] [CompactSpace M] [IsManifold (𝓔 d) ∞ M]

/-- A `C^{0,a}` metric admits a `C^{1,a/2}` isometric embedding for `0 ≤ a ≤ 1`. -/
theorem exists_holder_isometricEmbedding
    (g : Bundle.ContinuousRiemannianMetric (Euclidean d) (T M)) {a : ℝ≥0} (ha : a ≤ 1)
    (hg : HolderInCharts a (metricInChart g.toRiemannianMetric)) :
    ∃ (N : ℕ) (u : M → Euclidean N), IsHolderIsometricEmbedding g.toRiemannianMetric (a / 2) u := by
  sorry

/-- A `C^{1,a}` metric admits a `C^{1,(1+a)/2}` isometric embedding for `0 ≤ a < 1`. -/
theorem exists_holderDifferential_isometricEmbedding
    (g : Bundle.ContMDiffRiemannianMetric (𝓔 d) 1 (Euclidean d) (T M)) {a : ℝ≥0} (ha : a < 1)
    (hg : HolderDifferentialInCharts a (metricInChart g.toRiemannianMetric)) :
    ∃ (N : ℕ) (u : M → Euclidean N),
      IsHolderIsometricEmbedding g.toRiemannianMetric ((1 + a) / 2) u := by
  sorry

end IsometricEmbeddingEndpoints
