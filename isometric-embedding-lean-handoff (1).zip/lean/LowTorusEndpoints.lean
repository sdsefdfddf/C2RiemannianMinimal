import LowIterationAssemble

namespace IsometricEmbeddingEndpoints

open ContinuousLinearMap

noncomputable section

variable {d H : Type*} [Fintype d] [DecidableEq d]
  [NormedAddCommGroup H] [NormedSpace ℝ H]

/-- A torus map whose periodic lift is continuously differentiable with Hölder differential. -/
def HasHolderDifferential (θ : ℝ) (u : C(UnitAddTorus d, H)) : Prop :=
  ContDiff ℝ 1 (fun x => u (flatProjection x)) ∧
    ∃ K : ℝ, 0 ≤ K ∧ ∀ x y : Cover d,
      ‖fderiv ℝ (fun z => u (flatProjection z)) x -
        fderiv ℝ (fun z => u (flatProjection z)) y‖ ≤ K * dist x y ^ θ

local instance : NormedAddCommGroup (MetricForm d) := inferInstance
local instance : NormedSpace ℝ (MetricForm d) := inferInstance
local instance : CompleteSpace (MetricForm d) := inferInstance

private theorem TorusMetric.to_euclideanHolder {E : Type*} [NormedAddCommGroup E]
    [InnerProductSpace ℝ E] [FiniteDimensional ℝ E] (g : TorusMetric d) {θ : ℝ}
    (w : C(UnitAddTorus d, E)) (hHolder : HasHolderDifferential θ w)
    (hIso : g.HasIsometricDifferential w) :
    ∃ (N : ℕ) (u : C(UnitAddTorus d, EuclideanSpace ℝ (Fin N))),
      HasHolderDifferential θ u ∧ g.HasIsometricDifferential u := by
  obtain ⟨hw, M, hM, hHolder⟩ := hHolder
  let N := Module.finrank ℝ E
  let I : E →ₗᵢ[ℝ] EuclideanSpace ℝ (Fin N) := (stdOrthonormalBasis ℝ E).repr.toLinearIsometry
  let f : TorusCorrection d E := ⟨w, hw⟩
  let u := f.postcomp I.toContinuousLinearMap
  refine ⟨N, u.value, ⟨u.contDiff, M, hM, ?_⟩, u.contDiff.differentiable one_ne_zero, ?_⟩
  · intro x y
    rw [← torusDifferential_apply u.value u.contDiff x, ← torusDifferential_apply u.value u.contDiff y]
    refine (f.norm_postcomp_differential_sub_le I.toContinuousLinearMap _ _).trans ?_
    simp only [TorusCorrection.differential, f, torusDifferential_apply]
    exact (mul_le_of_le_one_left (norm_nonneg _) I.norm_toContinuousLinearMap_le).trans (hHolder x y)
  · intro x a b
    have hD : fderiv ℝ (fun z => u.value (flatProjection z)) x =
        I.toContinuousLinearMap.comp (fderiv ℝ (fun z => w (flatProjection z)) x) := by
      have h := f.postcomp_differential I.toContinuousLinearMap (flatProjection x)
      simpa only [TorusCorrection.differential, torusDifferential_apply, u, f] using h
    rw [hD, comp_apply, comp_apply, LinearIsometry.coe_toContinuousLinearMap, I.inner_map_map]
    exact hIso.2 x a b

set_option maxHeartbeats 410000 in
/-- A cutoff error of order twice the desired exponent suffices for an
isometric immersion of that Hölder regularity into finite-dimensional Euclidean space. -/
theorem TorusMetric.exists_euclideanImmersion_of_cutoffRate (g : TorusMetric d) {θ C : ℝ}
    (hθ : 0 < θ) (hθ₁ : θ < 1) (hC : 0 ≤ C)
    (hcut : ∀ s : ℝ, 0 < s →
      ‖realTorusCutoff (H := MetricForm d) s g.form - g.form‖ ≤ C * s ^ (-(2 * θ))) :
    ∃ (N : ℕ) (u : C(UnitAddTorus d, EuclideanSpace ℝ (Fin N))),
      HasHolderDifferential θ u ∧ g.HasIsometricDifferential u := by
  have hRotation := g.exists_lowRotation hθ hθ₁ hC hcut
  rcases hRotation with ⟨B, n, hB, S, c, K, ε₀, u₀, v, hS, hc, hK, hε₀, hband, hv, hmetric⟩
  have hLimit := g.exists_holder_from_rotation (H := InitialBlockSpace d n) hB S hc hK hε₀ u₀ v hband hv hmetric
  rcases hLimit with ⟨w, hw, hHolder, hIso⟩
  rw [← hS]
  exact g.to_euclideanHolder w ⟨hw, hHolder⟩ hIso

/-- A Hölder metric on a torus, including a Lipschitz metric, admits an isometric
immersion whose differential has half the metric's Hölder exponent. -/
theorem TorusMetric.exists_euclideanImmersion_of_holder (g : TorusMetric d) {a C : ℝ}
    (ha : 0 < a) (ha₁ : a ≤ 1) (hC : 0 ≤ C)
    (hg : ∀ x z : Cover d,
      ‖g.form (flatProjection z) - g.form (flatProjection x)‖ ≤ C * ‖z - x‖ ^ a) :
    ∃ (N : ℕ) (u : C(UnitAddTorus d, EuclideanSpace ℝ (Fin N))),
      HasHolderDifferential (a / 2) u ∧ g.HasIsometricDifferential u := by
  obtain ⟨K, hK, hcut⟩ := g.exists_cutoffRate_of_holder ha.le ha₁ hC hg
  refine g.exists_euclideanImmersion_of_cutoffRate (θ := a / 2) (by positivity) (by linarith) hK
    (fun s hs => ?_)
  rw [show 2 * (a / 2) = a by ring]
  exact hcut s hs

/-- A metric with a Hölder first derivative has an isometric immersion at the
endpoint exponent `(1 + a) / 2` for the differential. -/
theorem TorusMetric.exists_euclideanImmersion_of_holderDifferential (g : TorusMetric d) {a C : ℝ}
    (ha : 0 ≤ a) (ha₁ : a < 1) (hC : 0 ≤ C)
    (hg : ContDiff ℝ 1 (fun z => g.form (flatProjection z)))
    (hDg : ∀ x z : Cover d,
      ‖fderiv ℝ (fun y => g.form (flatProjection y)) z -
        fderiv ℝ (fun y => g.form (flatProjection y)) x‖ ≤ C * ‖z - x‖ ^ a) :
    ∃ (N : ℕ) (u : C(UnitAddTorus d, EuclideanSpace ℝ (Fin N))),
      HasHolderDifferential ((1 + a) / 2) u ∧ g.HasIsometricDifferential u := by
  obtain ⟨K, hK, hcut⟩ := g.exists_cutoffRate_of_holderDifferential ha ha₁.le hC _
    (fun x => (hg.differentiable one_ne_zero x).hasFDerivAt) hDg
  refine g.exists_euclideanImmersion_of_cutoffRate (θ := (1 + a) / 2) (by linarith) (by linarith) hK
    (fun s hs => ?_)
  rw [show 2 * ((1 + a) / 2) = 1 + a by ring]
  exact hcut s hs

/-- The zero-exponent case for the metric's differential only requires a
continuously differentiable metric. -/
theorem TorusMetric.exists_euclideanImmersion_of_contDiff (g : TorusMetric d)
    (hg : ContDiff ℝ 1 (fun z => g.form (flatProjection z))) :
    ∃ (N : ℕ) (u : C(UnitAddTorus d, EuclideanSpace ℝ (Fin N))),
      HasHolderDifferential (1 / 2) u ∧ g.HasIsometricDifferential u := by
  let D := torusDifferential g.form hg
  have h := g.exists_euclideanImmersion_of_holderDifferential (a := 0) le_rfl zero_lt_one
    (C := 2 * ‖D‖) (by positivity) hg (fun x z => by
      rw [Real.rpow_zero, mul_one, ← torusDifferential_apply g.form hg,
        ← torusDifferential_apply g.form hg]
      calc
        ‖D (flatProjection z) - D (flatProjection x)‖ ≤
            ‖D (flatProjection z)‖ + ‖D (flatProjection x)‖ := norm_sub_le _ _
        _ ≤ 2 * ‖D‖ := by
          rw [two_mul]
          exact add_le_add (ContinuousMap.norm_coe_le_norm _ _) (ContinuousMap.norm_coe_le_norm _ _))
  simpa only [add_zero] using h

end

end IsometricEmbeddingEndpoints

#print axioms IsometricEmbeddingEndpoints.TorusMetric.exists_euclideanImmersion_of_holder
#print axioms IsometricEmbeddingEndpoints.TorusMetric.exists_euclideanImmersion_of_holderDifferential
#print axioms IsometricEmbeddingEndpoints.TorusMetric.exists_euclideanImmersion_of_contDiff
#check IsometricEmbeddingEndpoints.TorusMetric.exists_euclideanImmersion_of_holder
#check IsometricEmbeddingEndpoints.TorusMetric.exists_euclideanImmersion_of_holderDifferential
