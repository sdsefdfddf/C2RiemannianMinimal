import DirectSumUpdate
import LowIterationLimit
import LowIterationStart

namespace IsometricEmbeddingEndpoints

open Filter Finset ContinuousLinearMap
open scoped Topology

noncomputable section

variable {d H G : Type*} [Fintype d] [DecidableEq d]
  [NormedAddCommGroup H] [InnerProductSpace ℝ H] [CompleteSpace H] [FiniteDimensional ℝ H]
  [NormedAddCommGroup G] [InnerProductSpace ℝ G]

local instance : NormedAddCommGroup (MetricForm d) := inferInstance
local instance : NormedSpace ℝ (MetricForm d) := inferInstance
local instance : NormedAddCommGroup C(UnitAddTorus d, MetricForm d) := inferInstance

/-- Apply a fixed linear map to a correction. -/
def TorusCorrection.postcomp (u : TorusCorrection d H) (T : H →L[ℝ] G) : TorusCorrection d G :=
  ⟨ContinuousLinearMap.compLeftContinuous ℝ (UnitAddTorus d) T u.value,
    T.contDiff.comp u.contDiff⟩

theorem TorusCorrection.postcomp_differential (u : TorusCorrection d H) (T : H →L[ℝ] G)
    (t : UnitAddTorus d) :
    (u.postcomp T).differential t = T.comp (u.differential t) := by
  obtain ⟨x, rfl⟩ := flatProjection_surjective t
  simp only [TorusCorrection.differential, torusDifferential_apply]
  exact (T.hasFDerivAt.comp x (u.contDiff.differentiable one_ne_zero x).hasFDerivAt).fderiv

theorem TorusCorrection.norm_postcomp_differential_sub_le (u : TorusCorrection d H) (T : H →L[ℝ] G)
    (t t' : UnitAddTorus d) :
    ‖(u.postcomp T).differential t - (u.postcomp T).differential t'‖ ≤
      ‖T‖ * ‖u.differential t - u.differential t'‖ := by
  rw [u.postcomp_differential T t, u.postcomp_differential T t']
  have heq : T.comp (u.differential t - u.differential t') =
      T.comp (u.differential t) - T.comp (u.differential t') := by ext x; simp
  rw [← heq]
  exact opNorm_comp_le _ _

private def singleBlockIsometry {ι : Type*} [Fintype ι] [DecidableEq ι] (b : ι) :
    H →ₗᵢ[ℝ] PiLp 2 (fun _ : ι => H) where
  toLinearMap := (PiLp.continuousLinearEquiv 2 ℝ (fun _ : ι => H)).symm.toLinearEquiv.toLinearMap.comp
    (LinearMap.single ℝ (fun _ : ι => H) b)
  norm_map' x := PiLp.norm_single 2 (fun _ : ι => H) b x

private theorem directSumDifferential_update_add {ι : Type*} [Fintype ι] [DecidableEq ι]
    (F : ι → Cover d →L[ℝ] H) (b : ι) (D : Cover d →L[ℝ] H) :
    directSumDifferential (Function.update F b (F b + D)) =
      directSumDifferential F + (singleBlockIsometry b).toContinuousLinearMap.comp D := by
  ext x k
  simp only [add_apply, PiLp.add_apply, comp_apply, LinearIsometry.coe_toContinuousLinearMap]
  change Function.update F b (F b + D) k x = F k x + (Pi.single b (D x) : ι → H) k
  by_cases hk : k = b
  · subst k
    simp only [Function.update_self, add_apply, Pi.single_eq_same]
  · simp only [Function.update_of_ne hk, Pi.single_eq_of_ne hk, add_zero]

private theorem norm_fderiv_sub_le_of_bound
    (u : TorusCorrection d H) (hD : Differentiable ℝ (fun z => u.differential (flatProjection z)))
    {C : ℝ} (hC : ∀ x : Cover d, ‖fderiv ℝ (fun z => u.differential (flatProjection z)) x‖ ≤ C)
    (x y : Cover d) :
    ‖u.differential (flatProjection x) - u.differential (flatProjection y)‖ ≤ C * dist x y := by
  rw [dist_eq_norm]
  exact (convex_univ (𝕜 := ℝ) (E := Cover d)).norm_image_sub_le_of_norm_fderiv_le
    (fun z _ => hD z) (fun z _ => hC z) (Set.mem_univ y) (Set.mem_univ x)

private theorem holder_of_bounded_and_lipschitz {E W : Type*} [PseudoMetricSpace E]
    [NormedAddCommGroup W] (f : E → W) {θ M L : ℝ}
    (hθ : 0 ≤ θ) (hθ₁ : θ ≤ 1) (hM : 0 ≤ M) (hL : 0 ≤ L)
    (hbound : ∀ x, ‖f x‖ ≤ M) (hlip : ∀ x y, ‖f x - f y‖ ≤ L * dist x y) (x y : E) :
    ‖f x - f y‖ ≤ (2 * M + L) * dist x y ^ θ := by
  by_cases h : dist x y ≤ 1
  · have hpow : dist x y ≤ dist x y ^ θ := by
      simpa only [Real.rpow_one] using Real.rpow_le_rpow_of_exponent_ge' dist_nonneg h hθ hθ₁
    exact (hlip x y).trans ((mul_le_mul_of_nonneg_left hpow hL).trans
      (mul_le_mul_of_nonneg_right (by linarith) (Real.rpow_nonneg dist_nonneg _)))
  · calc
      _ ≤ 2 * M := (norm_sub_le _ _).trans ((add_le_add (hbound x) (hbound y)).trans_eq (by ring))
      _ ≤ 2 * M + L := le_add_of_nonneg_right hL
      _ ≤ _ := le_mul_of_one_le_right (by positivity) (Real.one_le_rpow (le_of_not_ge h) hθ)

omit [DecidableEq d] in
private theorem isometry_norm_le_one (I : H →ₗᵢ[ℝ] G) : ‖I.toContinuousLinearMap‖ ≤ 1 := by
  apply opNorm_le_bound _ zero_le_one
  intro x
  simp only [LinearIsometry.coe_toContinuousLinearMap, I.norm_map, one_mul, le_refl]

set_option maxHeartbeats 630000 in
/-- Put each correction in its assigned orthogonal block and pass to the critical
Hölder limit. All metric information is in the sum of the Gram forms of the blocks. -/
theorem TorusMetric.exists_holder_from_rotation (g : TorusMetric d)
    {B : ℕ} (hB : 0 < B) (S : LowGeometricScales) {c K ε₀ : ℝ} (hc : 1 ≤ c)
    (hK : 0 ≤ K) (hε₀ : 0 < ε₀)
    (u₀ : TorusCorrection d H) (v : ℕ → TorusCorrection d H)
    (hband : HasFourierSupport (latticeBall d (c * (S.frequency 0 : ℝ))) u₀.differential)
    (hv : ∀ j, (v j).HasIterationBounds S c K j)
    (hmetric : ∀ j, ‖torusBlockGram (fun b : Fin B =>
      iteratedBlock u₀.differential (fun i => (v i).differential) B j b) -
        (g.form - S.defect j • flatMetric)‖ ≤ ε₀ * S.defect j) :
    ∃ u : C(UnitAddTorus d, PiLp 2 (fun _ : Fin B => H)),
      ContDiff ℝ 1 (fun x => u (flatProjection x)) ∧
      (∃ M : ℝ, 0 ≤ M ∧ ∀ x y : Cover d,
        ‖fderiv ℝ (fun z => u (flatProjection z)) x -
          fderiv ℝ (fun z => u (flatProjection z)) y‖ ≤ M * dist x y ^ S.exponent) ∧
      g.HasIsometricDifferential u := by
  let F₀ := u₀.differential
  let Hsum := PiLp 2 (fun _ : Fin B => H)
  let rep : H →L[ℝ] Hsum := directSumDifferential (fun _ : Fin B => ContinuousLinearMap.id ℝ H)
  let I : ℕ → H →ₗᵢ[ℝ] Hsum := fun j => singleBlockIsometry (activeBlock hB j)
  let U₀ := u₀.postcomp rep
  let w := fun j => (v j).postcomp (I j).toContinuousLinearMap
  let D := fun j => (v j).differential
  let E := fun j => (w j).differential
  have hEdiff (j : ℕ) (t : UnitAddTorus d) : E j t = (I j).toContinuousLinearMap.comp (D j t) :=
    (v j).postcomp_differential _ t
  have hAll (j : ℕ) (t : UnitAddTorus d) : (U₀.differential + ∑ i ∈ range j, E i) t =
      directSumDifferential (fun b : Fin B => iteratedBlock F₀ D B j b t) := by
    induction j with
    | zero =>
      simp only [range_zero, sum_empty, add_zero, iteratedBlock, earlierBlockSteps, filter_empty]
      rw [u₀.postcomp_differential rep t]
      rfl
    | succ j ih =>
      rw [sum_range_succ, ← add_assoc, ContinuousMap.add_apply, ih, hEdiff]
      have hupdate := iteratedBlock_succ F₀ D hB j
      have hupdate' :
          (fun b : Fin B => iteratedBlock F₀ D B (j + 1) b t) =
            Function.update (fun b : Fin B => iteratedBlock F₀ D B j b t) (activeBlock hB j)
              (iteratedBlock F₀ D B j (activeBlock hB j) t + D j t) := by
        funext b
        have he := congrArg (fun F : Fin B → C(UnitAddTorus d, Cover d →L[ℝ] H) => F b t) hupdate
        by_cases hb : b = activeBlock hB j
        · subst b
          simpa only [Function.update_self, ContinuousMap.add_apply] using he
        · simpa only [Function.update_of_ne hb] using he
      rw [hupdate', directSumDifferential_update_add]
  have hgram (j : ℕ) : torusGram (U₀.differential + ∑ i ∈ range j, E i) =
      torusBlockGram (fun b : Fin B => iteratedBlock F₀ D B j b) := by
    ext t x y
    rw [torusGram_apply, hAll, inner_directSumDifferential, torusBlockGram_apply]
  have hmetric' : Tendsto (fun j => torusGram (U₀.differential + ∑ i ∈ range j, E i))
      atTop (𝓝 g.form) := by
    apply tendsto_iff_norm_sub_tendsto_zero.2
    apply squeeze_zero (fun _ => norm_nonneg _) (g := fun j => (ε₀ + 1) * S.defect j) ?_ ?_
    · intro j
      rw [hgram]
      let P := torusBlockGram (fun b : Fin B => iteratedBlock F₀ D B j b)
      calc
        ‖P - g.form‖ ≤ ‖P - (g.form - S.defect j • flatMetric)‖ +
            ‖(g.form - S.defect j • flatMetric) - g.form‖ := norm_sub_le_norm_sub_add_norm_sub _ _ _
        _ ≤ ε₀ * S.defect j + S.defect j := by
          apply add_le_add (hmetric j)
          have heq : (g.form - S.defect j • flatMetric) - g.form = -(S.defect j • flatMetric) := by
            abel
          rw [heq, norm_neg, norm_smul (S.defect j) (flatMetric (d := d)), Real.norm_eq_abs,
            abs_of_pos (S.defect_pos j)]
          exact mul_le_of_le_one_right (S.defect_pos j).le norm_flatMetric_le_one
        _ = _ := by ring
    · simpa only [mul_zero] using S.tendsto_defect.const_mul (ε₀ + 1)
  have hD₀diff : Differentiable ℝ (fun z => F₀ (flatProjection z)) :=
    (hband.contDiff_lift (k := 1)).differentiable one_ne_zero
  let L₀ := (c * (S.frequency 0 : ℝ) * bernsteinConstant d) * ‖F₀‖
  have hbern : 0 ≤ bernsteinConstant d := MeasureTheory.integral_nonneg fun _ => norm_nonneg _
  have hL₀ : 0 ≤ L₀ := by dsimp only [L₀]; positivity
  have hD₀bound (x : Cover d) : ‖fderiv ℝ (fun z => F₀ (flatProjection z)) x‖ ≤ L₀ := by
    have hr : 0 < c * (S.frequency 0 : ℝ) :=
      mul_pos (zero_lt_one.trans_le hc) (by exact_mod_cast S.frequency_pos 0)
    simpa only [norm_iteratedFDeriv_one, pow_one] using
      hband.norm_iteratedFDeriv_lift_le_of_radius hr (fun _ hk => hk) x 1
  let A₀ := ‖rep‖ * (2 * ‖F₀‖ + L₀)
  have hA₀ : 0 ≤ A₀ := by dsimp only [A₀]; positivity
  have hstart (x y : Cover d) :
      ‖fderiv ℝ (fun z => U₀.value (flatProjection z)) x -
        fderiv ℝ (fun z => U₀.value (flatProjection z)) y‖ ≤ A₀ * dist x y ^ S.exponent := by
    rw [← torusDifferential_apply U₀.value U₀.contDiff x, ← torusDifferential_apply U₀.value U₀.contDiff y]
    refine (u₀.norm_postcomp_differential_sub_le rep _ _).trans ?_
    have h := holder_of_bounded_and_lipschitz (fun z : Cover d => F₀ (flatProjection z))
      S.exponent_pos.le S.exponent_lt_one.le (norm_nonneg _) hL₀
      (fun z => F₀.norm_coe_le_norm _) (norm_fderiv_sub_le_of_bound u₀ hD₀diff hD₀bound) x y
    exact (mul_le_mul_of_nonneg_left h (norm_nonneg rep)).trans_eq (by dsimp only [A₀]; ring)
  let A := K * √S.initialDefect + K * ((S.frequency 1 : ℝ) * √S.initialDefect)
  have hA : 0 ≤ A := by dsimp only [A]; positivity
  have hA₁ : K * √S.initialDefect ≤ A := by dsimp only [A]; exact le_add_of_nonneg_right (by positivity)
  have hA₂ : K * ((S.frequency 1 : ℝ) * √S.initialDefect) ≤ A := by
    dsimp only [A]
    exact le_add_of_nonneg_left (by positivity)
  have hsmall (j : ℕ) : ‖(w j).value‖ ≤ A * S.decay ^ j := by
    have hnorm : ‖(w j).value‖ ≤ ‖(v j).value‖ := by
      apply (ContinuousMap.norm_le _ (norm_nonneg _)).2
      intro t
      change ‖I j ((v j).value t)‖ ≤ _
      rw [(I j).norm_map]
      exact (v j).value.norm_coe_le_norm t
    refine (hnorm.trans (hv j).2.1).trans ?_
    calc
      _ ≤ K * S.amplitude j := div_le_self (mul_nonneg hK (S.amplitude_pos j).le)
        (by exact_mod_cast S.frequency_pos (j + 1))
      _ = (K * √S.initialDefect) * S.decay ^ j := by rw [LowGeometricScales.amplitude, mul_assoc]
      _ ≤ _ := mul_le_mul_of_nonneg_right hA₁ (pow_nonneg S.decay_pos.le _)
  have hgrad (j : ℕ) : ‖E j‖ ≤ A * S.decay ^ j := by
    apply (ContinuousMap.norm_le _ (mul_nonneg hA (pow_nonneg S.decay_pos.le _))).2
    intro t
    rw [hEdiff]
    calc
      _ ≤ ‖(I j).toContinuousLinearMap‖ * ‖D j t‖ := opNorm_comp_le _ _
      _ ≤ 1 * ‖D j‖ := mul_le_mul (isometry_norm_le_one (I j)) ((D j).norm_coe_le_norm t)
        (norm_nonneg _) zero_le_one
      _ ≤ _ := by
        rw [one_mul]
        have hv' := (hv j).2.2.1
        rw [LowGeometricScales.amplitude, ← mul_assoc] at hv'
        exact hv'.trans (mul_le_mul_of_nonneg_right hA₁ (pow_nonneg S.decay_pos.le _))
  have hlip (j : ℕ) (x y : Cover d) :
      ‖fderiv ℝ (fun z => (w j).value (flatProjection z)) x -
        fderiv ℝ (fun z => (w j).value (flatProjection z)) y‖ ≤ A * S.growth ^ j * dist x y := by
    rw [← torusDifferential_apply (w j).value (w j).contDiff x,
      ← torusDifferential_apply (w j).value (w j).contDiff y]
    refine ((v j).norm_postcomp_differential_sub_le (I j).toContinuousLinearMap _ _).trans ?_
    have hd : Differentiable ℝ (fun z => D j (flatProjection z)) :=
      ((hv j).1.contDiff_lift (k := 1)).differentiable one_ne_zero
    have hraw := norm_fderiv_sub_le_of_bound (v j) hd (hv j).2.2.2 x y
    calc
      _ ≤ 1 * (K * (S.frequency (j + 1) : ℝ) * S.amplitude j * dist x y) :=
        mul_le_mul (isometry_norm_le_one (I j)) hraw (norm_nonneg _) zero_le_one
      _ = (K * ((S.frequency 1 : ℝ) * √S.initialDefect)) * S.growth ^ j * dist x y := by
        rw [one_mul, mul_assoc K, S.frequency_mul_amplitude]
        ring
      _ ≤ _ := mul_le_mul_of_nonneg_right
        (mul_le_mul_of_nonneg_right hA₂ (pow_nonneg (zero_lt_one.trans S.one_lt_growth).le _)) dist_nonneg
  exact exists_isometric_holder_limit_of_gram_approximations S.one_lt_ratio
    S.exponent_pos S.exponent_lt_one hA hA₀ U₀.value U₀.contDiff hstart
    (fun j => (w j).value) (fun j => (w j).contDiff) hsmall hgrad hlip g hmetric'

end

end IsometricEmbeddingEndpoints

#print axioms IsometricEmbeddingEndpoints.TorusMetric.exists_holder_from_rotation
