import ManifoldLowStatement
import Mathlib.Geometry.Manifold.MFDeriv.Atlas
import Mathlib.Geometry.Manifold.MFDeriv.NormedSpace

open scoped Manifold

namespace IsometricEmbeddingEndpoints

noncomputable section

variable {d M : Type*} [Fintype d] [TopologicalSpace M] [ChartedSpace (Cover d) M]

local notation "I" => 𝓘(ℝ, Cover d)

theorem RiemannianMetric.inChart_symmetric (g : RiemannianMetric d M)
    (e : OpenPartialHomeomorph M (Cover d)) (x v w : Cover d) :
    g.inChart e x v w = g.inChart e x w v :=
  g.symmetric _ _ _

theorem RiemannianMetric.inChart_positive (g : RiemannianMetric d M)
    {e : OpenPartialHomeomorph M (Cover d)} (he : e.MDifferentiable I I)
    {x : Cover d} (hx : x ∈ e.target) {v : Cover d} (hv : v ≠ 0) :
    0 < g.inChart e x v v := by
  let D := mfderiv I I e.symm x
  have hD : D v ≠ 0 := by
    intro hz
    apply hv
    exact he.symm.mfderiv_injective hx (hz.trans (map_zero D).symm)
  exact g.positive _ _ hD

theorem RiemannianMetric.inChart_pullback (g : RiemannianMetric d M)
    {e : OpenPartialHomeomorph M (Cover d)} (he : e.MDifferentiable I I)
    {p : M} (hp : p ∈ e.source) (v w : TangentSpace I p) :
    g.inChart e (e p) (mfderiv I I e p v) (mfderiv I I e p w) = g.form p v w := by
  have hD (z : TangentSpace I p) :
      mfderiv I I e.symm (e p) (mfderiv I I e p z) = z :=
    DFunLike.congr_fun (he.symm_comp_deriv hp) z
  change g.form (e.symm (e p))
    (mfderiv I I e.symm (e p) (mfderiv I I e p v))
    (mfderiv I I e.symm (e p) (mfderiv I I e p w)) = g.form p v w
  rw [hD, hD, e.left_inv hp]

/-- An isometric differential in coordinates gives the corresponding
manifold isometric differential at each point of the chart. -/
theorem RiemannianMetric.isometricDifferential_of_inChart (g : RiemannianMetric d M)
    {e : OpenPartialHomeomorph M (Cover d)} (he : e.MDifferentiable I I)
    {F : Type*} [NormedAddCommGroup F] [InnerProductSpace ℝ F] {u : Cover d → F}
    {p : M} (hp : p ∈ e.source) (hu : DifferentiableAt ℝ u (e p))
    (hiso : ∀ v w : Cover d, inner ℝ (fderiv ℝ u (e p) v) (fderiv ℝ u (e p) w) =
      g.inChart e (e p) v w) (v w : TangentSpace I p) :
    inner ℝ (mvfderiv I (u ∘ e) p v) (mvfderiv I (u ∘ e) p w) = g.form p v w := by
  have hm : mvfderiv I (u ∘ e) p = (fderiv ℝ u (e p)).comp (mfderiv I I e p) := by
    rw [mvfderiv_comp p hu.mdifferentiableAt (he.mdifferentiableAt hp), mvfderiv_eq_fderiv]
    rfl
  rw [hm]
  change inner ℝ (fderiv ℝ u (e p) (mfderiv I I e p v))
    (fderiv ℝ u (e p) (mfderiv I I e p w)) = g.form p v w
  exact (hiso (mfderiv I I e p v) (mfderiv I I e p w)).trans (g.inChart_pullback he hp v w)

end

end IsometricEmbeddingEndpoints

#print axioms IsometricEmbeddingEndpoints.RiemannianMetric.inChart_pullback
#print axioms IsometricEmbeddingEndpoints.RiemannianMetric.isometricDifferential_of_inChart
