import Mathlib.Analysis.SpecialFunctions.Pow.Asymptotics
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Ring

namespace IsometricEmbeddingEndpoints

open Filter
open scoped Topology

/-- With `θ = r/2`, the frequency cutoff and the block rotation both give errors of
strictly higher order than the next defect. The final term allows an initial gradient
drift squared of size at most `δ₀`. The number of blocks is fixed before choosing
the estimate constant, and the lower bound for the frequency ratio is arbitrary. -/
theorem exists_lowIteration_parameters {θ ε C δmax : ℝ} (hθ : 0 < θ) (hθ₁ : θ < 1)
    (hε : 0 < ε) (hC : 0 ≤ C) (hδmax : 0 < δmax)
    {B : ℕ} (hgap : 2 * θ < (B : ℝ) * (1 - θ)) (Lmin : ℕ) :
    ∃ L : ℕ, max 2 Lmin ≤ L ∧ ∃ δ₀ : ℝ, 0 < δ₀ ∧ δ₀ ≤ δmax ∧
      C * ((L : ℝ) ^ (-(1 + θ)) + (L : ℝ) ^ (-((B : ℝ) * (1 - θ))) + δ₀) ≤
        ε * (L : ℝ) ^ (-(2 * θ)) := by
  let r := 2 * θ
  let p := 1 + θ
  have hp : r < p := by dsimp [r, p]; linarith
  let q := (B : ℝ) * (1 - θ)
  have hdecay : Tendsto (fun t : ℝ => C * (t ^ (-(p - r)) + t ^ (-(q - r)))) atTop (𝓝 0) := by
    simpa only [add_zero, mul_zero] using
      ((tendsto_rpow_neg_atTop (sub_pos.mpr hp)).add
        (tendsto_rpow_neg_atTop (sub_pos.mpr hgap))).const_mul C
  have hevent : ∀ᶠ t : ℝ in atTop, C * (t ^ (-(p - r)) + t ^ (-(q - r))) < ε / 2 :=
    hdecay.eventually (gt_mem_nhds (by positivity))
  obtain ⟨M, hM⟩ := eventually_atTop.mp hevent
  obtain ⟨L, hL⟩ := exists_nat_gt (max M (max 2 Lmin : ℕ))
  have hLmin : max 2 Lmin ≤ L := by
    exact_mod_cast ((le_max_right M (max 2 Lmin : ℕ)).trans hL.le)
  have hL₁ : 1 < (L : ℝ) := by
    exact_mod_cast (show 1 < L from (le_max_left 2 Lmin).trans hLmin)
  have hL₀ : 0 < (L : ℝ) := zero_lt_one.trans hL₁
  let s := (L : ℝ) ^ (-r)
  have hs : 0 < s := Real.rpow_pos_of_pos hL₀ _
  have hfreq :
      C * ((L : ℝ) ^ (-p) + (L : ℝ) ^ (-q)) ≤ (ε / 2) * s := by
    calc
      _ = C * ((L : ℝ) ^ (-(p - r)) + (L : ℝ) ^ (-(q - r))) * s := by
        rw [mul_assoc, add_mul]
        dsimp only [s]
        rw [← Real.rpow_add hL₀, ← Real.rpow_add hL₀]
        ring_nf
      _ ≤ _ := mul_le_mul_of_nonneg_right
        (hM L ((le_max_left _ _).trans hL.le)).le hs.le
  let δ₀ := min δmax ((ε / 2) * s / (C + 1))
  have hδ₀ : 0 < δ₀ := lt_min hδmax (by positivity)
  have hdrift : C * δ₀ ≤ (ε / 2) * s := by
    calc
      C * δ₀ ≤ (C + 1) * δ₀ :=
        mul_le_mul_of_nonneg_right (by linarith) hδ₀.le
      _ ≤ (C + 1) * ((ε / 2) * s / (C + 1)) :=
        mul_le_mul_of_nonneg_left (min_le_right _ _) (by positivity)
      _ = _ := by field_simp [show C + 1 ≠ 0 by positivity]
  refine ⟨L, hLmin, δ₀, hδ₀, min_le_left _ _, ?_⟩
  change C * ((L : ℝ) ^ (-p) + (L : ℝ) ^ (-q) + δ₀) ≤ ε * s
  rw [mul_add]
  linarith

theorem exists_lowIteration_scales {θ ε C : ℝ} (hθ : 0 < θ) (hθ₁ : θ < 1)
    (hε : 0 < ε) (hC : 0 ≤ C) :
    ∃ B : ℕ, 0 < B ∧ 2 * θ < (B : ℝ) * (1 - θ) ∧
      ∃ L : ℕ, 2 ≤ L ∧ ∃ δ₀ : ℝ, 0 < δ₀ ∧ δ₀ ≤ 1 ∧
        C * ((L : ℝ) ^ (-(1 + θ)) + (L : ℝ) ^ (-((B : ℝ) * (1 - θ))) + δ₀) ≤
          ε * (L : ℝ) ^ (-(2 * θ)) := by
  obtain ⟨B, hB⟩ := exists_nat_gt (2 * θ / (1 - θ))
  have hB₀ : 0 < B := by
    exact_mod_cast (div_pos (by positivity : 0 < 2 * θ) (sub_pos.mpr hθ₁)).trans hB
  have hgap := (div_lt_iff₀ (sub_pos.mpr hθ₁)).mp hB
  obtain ⟨L, hL, δ₀, hδ₀, hδ₁, h⟩ :=
    exists_lowIteration_parameters hθ hθ₁ hε hC zero_lt_one hgap 2
  exact ⟨B, hB₀, hgap, L, (le_max_left _ _).trans hL, δ₀, hδ₀, hδ₁, h⟩

/-- At the critical exponent the smoothing error and the next defect have exactly the
same geometric decay. Increasing the initial frequency makes their ratio small. -/
theorem smoothingScale_rpow {freq₀ L r η : ℝ} (hfreq₀ : 0 < freq₀) (hL : 0 < L) (j : ℕ) :
    (freq₀ * L ^ (j + 1) * L ^ (-η)) ^ (-r) =
      (freq₀ ^ (-r) * L ^ (r * η)) * (L ^ (-r)) ^ (j + 1) := by
  have hpow : (L ^ (j + 1)) ^ (-r) = (L ^ (-r)) ^ (j + 1) := by
    calc
      _ = L ^ ((↑(j + 1) : ℝ) * (-r)) := by
        rw [Real.rpow_mul hL.le, Real.rpow_natCast]
      _ = _ := by rw [mul_comm, Real.rpow_mul hL.le, Real.rpow_natCast]
  rw [Real.mul_rpow (mul_nonneg hfreq₀.le (pow_nonneg hL.le _)) (Real.rpow_nonneg hL.le _),
    Real.mul_rpow hfreq₀.le (pow_nonneg hL.le _), hpow, ← Real.rpow_mul hL.le]
  rw [neg_mul_neg, mul_comm η r, mul_right_comm]

/-- At a sufficiently large frequency ratio the old Fourier band fits inside the
next smoothing scale, which in turn fits inside the carrier frequency after a
fixed change of scale. The relative size of the next metric defect also tends to zero. -/
theorem exists_lowIteration_scaleSeparation {θ η ε : ℝ} (hθ : 0 < θ)
    (hη : 0 < η) (hη₁ : η < 1) (hε : 0 < ε) (c A C : ℝ) :
    ∃ Lmin : ℕ, ∀ L : ℕ, Lmin ≤ L →
      c ≤ (L : ℝ) ^ (1 - η) ∧ A ≤ (L : ℝ) ^ η ∧ C * (L : ℝ) ^ (-(2 * θ)) ≤ ε := by
  have h₁ : Tendsto (fun L : ℕ => (L : ℝ) ^ (1 - η)) atTop atTop :=
    (tendsto_rpow_atTop (sub_pos.mpr hη₁)).comp tendsto_natCast_atTop_atTop
  have h₂ : Tendsto (fun L : ℕ => (L : ℝ) ^ η) atTop atTop :=
    (tendsto_rpow_atTop hη).comp tendsto_natCast_atTop_atTop
  have h₃ : Tendsto (fun L : ℕ => C * (L : ℝ) ^ (-(2 * θ))) atTop (𝓝 0) := by
    simpa only [mul_zero, Function.comp_def] using
      ((tendsto_rpow_neg_atTop (show 0 < 2 * θ by positivity)).comp
        (tendsto_natCast_atTop_atTop (R := ℝ))).const_mul C
  exact eventually_atTop.mp ((h₁.eventually_ge_atTop c).and
    ((h₂.eventually_ge_atTop A).and (h₃.eventually (ge_mem_nhds hε))))

theorem lowIteration_rotationFactor_le {L θ : ℝ} (hL : 2 ≤ L) (hθ : θ < 1) :
    L ^ (1 - θ) / (L ^ (1 - θ) - 1) ≤ (2 : ℝ) ^ (1 - θ) / ((2 : ℝ) ^ (1 - θ) - 1) := by
  let q := L ^ (1 - θ)
  let p := (2 : ℝ) ^ (1 - θ)
  have hp : 1 < p := Real.one_lt_rpow (by norm_num) (sub_pos.mpr hθ)
  have hpq : p ≤ q := Real.rpow_le_rpow (by norm_num) hL (sub_nonneg.mpr hθ.le)
  have h : (q - 1)⁻¹ ≤ (p - 1)⁻¹ := inv_anti₀ (sub_pos.mpr hp) (sub_le_sub_right hpq 1)
  change q / (q - 1) ≤ p / (p - 1)
  rw [show q / (q - 1) = 1 + (q - 1)⁻¹ by field_simp [(sub_pos.mpr (hp.trans_le hpq)).ne']; ring,
    show p / (p - 1) = 1 + (p - 1)⁻¹ by field_simp [(sub_pos.mpr hp).ne']; ring]
  exact add_le_add le_rfl h

theorem lowIteration_driftFactor_le {L θ : ℝ} (hL : 2 ≤ L) (hθ : 0 < θ) :
    (1 - L ^ (-θ))⁻¹ ≤ (1 - (2 : ℝ) ^ (-θ))⁻¹ :=
  inv_anti₀ (sub_pos.mpr (Real.rpow_lt_one_of_one_lt_of_neg (by norm_num) (neg_neg_of_pos hθ)))
    (sub_le_sub_left (Real.rpow_le_rpow_of_nonpos (by norm_num) hL (neg_nonpos.mpr hθ.le)) 1)

end IsometricEmbeddingEndpoints

#print axioms IsometricEmbeddingEndpoints.exists_lowIteration_scales
#print axioms IsometricEmbeddingEndpoints.exists_lowIteration_parameters
#print axioms IsometricEmbeddingEndpoints.smoothingScale_rpow
