import CoordinateTwists
import Spiral

namespace IsometricEmbeddingEndpoints

open ContinuousLinearMap

noncomputable section

variable {d : Type*} [Fintype d] [DecidableEq d]

abbrev TwistIndex (d : Type*) := d ⊕ (d × d × Bool)

/-- Fixed integer coordinate directions for the rank-one expansion near the identity. -/
def twistDirection : TwistIndex d → d → ℤ
  | .inl i => Pi.single i 1
  | .inr (i, j, true) => Pi.single i 1 + Pi.single j 1
  | .inr (i, j, false) => Pi.single i 1 - Pi.single j 1

def twistCoefficient (E : d → d → ℝ) (δ c : ℝ) : TwistIndex d → ℝ
  | .inl _ => δ * (1 - (Fintype.card d : ℝ) * c)
  | .inr (i, j, true) => (c * δ + E i j) / 4
  | .inr (i, j, false) => (c * δ - E i j) / 4

def twistLinearForm (i : TwistIndex d) : EuclideanSpace ℝ d →L[ℝ] ℝ :=
  innerSL ℝ (latticeVector (twistDirection i))

private theorem sum_single_mul (i : d) (v : EuclideanSpace ℝ d) :
    (∑ j, (((Pi.single i 1 : d → ℤ) j : ℤ) : ℝ) * v j) = v i := by
  rw [Finset.sum_eq_single i]
  · simp
  · intro j _ hji
    simp [Pi.single_eq_of_ne hji]
  · simp

theorem twistLinearForm_inl (i : d) (v : EuclideanSpace ℝ d) :
    twistLinearForm (.inl i) v = v i := by
  exact (inner_latticeVector (Pi.single i 1) v).trans (sum_single_mul i v)

theorem twistLinearForm_inr_true (i j : d) (v : EuclideanSpace ℝ d) :
    twistLinearForm (.inr (i, j, true)) v = v i + v j := by
  simp only [twistLinearForm, innerSL_apply_apply ℝ, inner_latticeVector, twistDirection,
    Pi.add_apply, Int.cast_add, add_mul, Finset.sum_add_distrib, sum_single_mul]

theorem twistLinearForm_inr_false (i j : d) (v : EuclideanSpace ℝ d) :
    twistLinearForm (.inr (i, j, false)) v = v i - v j := by
  simp only [twistLinearForm, innerSL_apply_apply ℝ, inner_latticeVector, twistDirection,
    Pi.sub_apply, Int.cast_sub, sub_mul, Finset.sum_sub_distrib, sum_single_mul]

omit [DecidableEq d] in
theorem twistCoefficient_pos {E : d → d → ℝ} {δ c : ℝ} (hδ : 0 < δ)
    (hc : (Fintype.card d : ℝ) * c < 1) (hE : ∀ i j, |E i j| < c * δ) :
    ∀ i, 0 < twistCoefficient E δ c i := by
  obtain ⟨h₀, h⟩ := shifted_coordinate_twist_coefficients_pos hδ hc hE
  rintro (i | ⟨i, j, b⟩)
  · exact h₀
  · cases b
    · exact (h i j).2
    · exact (h i j).1

theorem sum_twistCoefficient_mul (E : d → d → ℝ) (hsym : ∀ i j, E i j = E j i)
    (δ c : ℝ) (v w : EuclideanSpace ℝ d) :
    (∑ i, twistCoefficient E δ c i * (twistLinearForm i v * twistLinearForm i w)) =
      δ * inner ℝ v w + ∑ i, ∑ j, E i j * (v i * w j) := by
  classical
  simp only [Fintype.sum_sum_type, Fintype.sum_prod_type, Fintype.sum_bool,
    twistCoefficient, twistLinearForm_inl, twistLinearForm_inr_true, twistLinearForm_inr_false,
    ← Finset.mul_sum, PiLp.inner_apply, Real.inner_apply]
  simpa only [mul_comm (w _) (v _), add_comm
    ((c * δ - E _ _) / 4 * ((v _ - v _) * (w _ - w _)))] using
    (shifted_coordinate_twist_decomposition E hsym δ c (fun i => v i) (fun i => w i))

end

end IsometricEmbeddingEndpoints

#print axioms IsometricEmbeddingEndpoints.sum_twistCoefficient_mul
