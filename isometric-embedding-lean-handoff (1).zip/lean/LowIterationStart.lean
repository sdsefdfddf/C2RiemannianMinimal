import LowIterationRecurrence
import TorusInitialBlock

namespace IsometricEmbeddingEndpoints

open Filter
open scoped Topology

noncomputable section

variable {d : Type*} [Fintype d] [DecidableEq d]

local instance : NormedAddCommGroup (MetricForm d) := inferInstance
local instance : NormedSpace ℝ (MetricForm d) := inferInstance
local instance : NormedAddCommGroup C(UnitAddTorus d, MetricForm d) := inferInstance

set_option maxHeartbeats 670000 in
/-- Choose the scale ratio and initial frequency for the rotating corrections.
The required metric truncation rate is exactly twice the desired exponent. -/
theorem TorusMetric.exists_lowRotation (g : TorusMetric d) {θ C : ℝ}
    (hθ : 0 < θ) (hθ₁ : θ < 1) (hC : 0 ≤ C)
    (hcut : ∀ s : ℝ, 0 < s → ‖realTorusCutoff (H := MetricForm d) s g.form - g.form‖ ≤
      C * s ^ (-(2 * θ))) :
    ∃ (B n : ℕ) (hB : 0 < B) (S : LowGeometricScales) (c K ε₀ : ℝ)
      (u₀ : TorusCorrection d (InitialBlockSpace d n)) (v : ℕ → TorusCorrection d (InitialBlockSpace d n)),
      S.exponent = θ ∧ 1 ≤ c ∧ 0 ≤ K ∧ 0 < ε₀ ∧
      HasFourierSupport (latticeBall d (c * (S.frequency 0 : ℝ))) u₀.differential ∧
      (∀ j, (v j).HasIterationBounds S c K j) ∧
      ∀ j, ‖torusBlockGram (fun b : Fin B =>
        iteratedBlock u₀.differential (fun i => (v i).differential) B j b) -
          (g.form - S.defect j • flatMetric)‖ ≤ ε₀ * S.defect j := by
  obtain ⟨B, hBlarge⟩ := exists_nat_gt (2 * θ / (1 - θ))
  have hgap := (div_lt_iff₀ (sub_pos.mpr hθ₁)).mp hBlarge
  have hB : 0 < B := by
    exact_mod_cast (div_pos (by positivity : 0 < 2 * θ) (sub_pos.mpr hθ₁)).trans hBlarge
  obtain ⟨n, δstart, σ₀, M₀, J, hδstart, hσ₀, hM₀, hstart⟩ := g.exists_initialBlock hB
  obtain ⟨ε, δmax, c, A, K, hε, hδmax, hc, hA, hK, hrotate⟩ :=
    exists_rotatingCorrections (d := d) (H := InitialBlockSpace d n) hB
      (show 0 < σ₀ / 2 by positivity) (show 0 ≤ M₀ + 1 by positivity)
  let η := (1 + θ) / 2
  have hη : 0 < η := by dsimp only [η]; positivity
  have hη₁ : η < 1 := by dsimp only [η]; linarith
  let ε₀ := min 1 (ε / 2)
  have hε₀ : 0 < ε₀ := lt_min zero_lt_one (by positivity)
  have hε₁ : ε₀ ≤ 1 := min_le_left _ _
  have hε₂ : ε₀ ≤ ε / 2 := min_le_right _ _
  let q₀ := (2 : ℝ) ^ (-θ)
  let p₀ := (2 : ℝ) ^ (1 - θ)
  have hq₀ : q₀ < 1 := Real.rpow_lt_one_of_one_lt_of_neg (by norm_num) (neg_neg_of_pos hθ)
  have hp₀ : 1 < p₀ := Real.one_lt_rpow (by norm_num) (sub_pos.mpr hθ₁)
  let U := K * (1 - q₀)⁻¹
  let R := 1 + K * (p₀ / (p₀ - 1))
  have hU : 0 ≤ U := mul_nonneg hK (inv_nonneg.mpr (sub_nonneg.mpr hq₀.le))
  have hR : 0 < R := by
    dsimp only [R]
    exact zero_lt_one.trans_le (le_add_of_nonneg_right
      (mul_nonneg hK (div_nonneg (zero_lt_one.trans hp₀).le (sub_nonneg.mpr hp₀.le))))
  let C' := K * (1 + R + U ^ 2)
  have hC' : 0 ≤ C' := by dsimp only [C']; positivity
  let τ := min (σ₀ / 2) 1
  have hτ : 0 < τ := lt_min (by positivity) zero_lt_one
  let small := min (τ / (U + 1)) (1 / R)
  have hsmall : 0 < small := lt_min (by positivity) (by positivity)
  let upper := min δstart (min δmax (small ^ 2))
  have hupper : 0 < upper := lt_min hδstart (lt_min hδmax (by positivity))
  obtain ⟨Lmin, hLmin⟩ :=
    exists_lowIteration_scaleSeparation hθ hη hη₁ (show 0 < ε / 2 by positivity) c A (1 + ε₀ / 2)
  obtain ⟨L, hL, δ₀, hδ₀, hδupper, hbudget⟩ :=
    exists_lowIteration_parameters hθ hθ₁ (show 0 < ε₀ / 2 by positivity) hC' hupper hgap Lmin
  have hL₂ : 2 ≤ L := (le_max_left _ _).trans hL
  let ℓ : ℝ := L
  have hℓ₂ : (2 : ℝ) ≤ ℓ := by
    change (2 : ℝ) ≤ (L : ℝ)
    exact_mod_cast hL₂
  have hℓ : 0 < ℓ := (by norm_num : (0 : ℝ) < 2).trans_le hℓ₂
  obtain ⟨hsep, hfrac, hrelative⟩ := hLmin L ((le_max_right _ _).trans hL)
  have hδstart' : δ₀ ≤ δstart := hδupper.trans (min_le_left _ _)
  have hδmax' : δ₀ ≤ δmax := (hδupper.trans (min_le_right _ _)).trans (min_le_left _ _)
  have hsqrt : √δ₀ ≤ small := by
    have h := Real.sqrt_le_sqrt ((hδupper.trans (min_le_right _ _)).trans (min_le_right _ _))
    rwa [Real.sqrt_sq hsmall.le] at h
  have hinitε : 0 < ε₀ * δ₀ := mul_pos hε₀ hδ₀
  obtain ⟨s, u, hu, hs, _, hFband, hFNorm, hFpositive, hJ, hGram⟩ :=
    hstart δ₀ (ε₀ * δ₀) hδ₀.le hδstart' hinitε
      ((mul_le_of_le_one_left hδ₀.le hε₁).trans hδstart')
  let u₀ : TorusCorrection d (InitialBlockSpace d n) := ⟨u, hu⟩
  let F₀ := u₀.differential
  let H₀ := (2 * s * bernsteinConstant d) * M₀
  have hH₀ : 0 ≤ H₀ := by
    have hbern : 0 ≤ bernsteinConstant d := MeasureTheory.integral_nonneg fun _ => norm_nonneg _
    dsimp only [H₀]
    positivity
  have hF₀deriv (x : Cover d) : ‖fderiv ℝ (fun z => F₀ (flatProjection z)) x‖ ≤ H₀ := by
    have hband : HasFourierSupport (latticeBall d (2 * s)) F₀ :=
      hFband.mono (torusCutoffBand_subset_latticeBall _)
    have h := hband.norm_iteratedFDeriv_lift_le_of_radius (by positivity : 0 < 2 * s) (fun _ hk => hk) x 1
    rw [norm_iteratedFDeriv_one, pow_one] at h
    have hbern : 0 ≤ bernsteinConstant d := MeasureTheory.integral_nonneg fun _ => norm_nonneg _
    exact h.trans (mul_le_mul_of_nonneg_left hFNorm (by positivity))
  let p := ℓ ^ (1 - θ)
  have hp : 0 < p := Real.rpow_pos_of_pos hℓ _
  have hdecay : Tendsto (fun t : ℝ => C * (t ^ (-(2 * θ)) * ℓ ^ ((2 * θ) * η))) atTop (𝓝 0) := by
    simpa only [zero_mul, mul_zero] using
      ((tendsto_rpow_neg_atTop (by positivity : 0 < 2 * θ)).mul_const
        (ℓ ^ ((2 * θ) * η))).const_mul C
  obtain ⟨Nmin, hNmin⟩ := eventually_atTop.mp
    (hdecay.eventually (ge_mem_nhds (show 0 < (ε₀ / 2) * δ₀ by positivity)))
  obtain ⟨N₀, hN₀⟩ := exists_nat_gt (max Nmin (max 0 (max (2 * s / c)
    (H₀ * p ^ B / (ℓ * √δ₀)))))
  have hN₀' : 0 < (N₀ : ℝ) := ((le_max_left _ _).trans (le_max_right _ _)).trans_lt hN₀
  have hNmin' : Nmin ≤ (N₀ : ℝ) := (le_max_left _ _).trans hN₀.le
  have hNfreq : 2 * s / c ≤ (N₀ : ℝ) :=
    (((le_max_left _ _).trans (le_max_right _ _)).trans (le_max_right _ _)).trans hN₀.le
  have hNhess : H₀ * p ^ B / (ℓ * √δ₀) ≤ (N₀ : ℝ) :=
    (((le_max_right _ _).trans (le_max_right _ _)).trans (le_max_right _ _)).trans hN₀.le
  let S : LowGeometricScales :=
    ⟨L, N₀, θ, δ₀, ℓ ^ (-η), hL₂, by exact_mod_cast hN₀', hθ, hθ₁, hδ₀, Real.rpow_pos_of_pos hℓ _⟩
  have hc₀ : 0 < c := zero_lt_one.trans_le hc
  have hstartBand : HasFourierSupport (latticeBall d (c * (S.frequency 0 : ℝ))) F₀ := by
    refine hFband.mono ((torusCutoffBand_subset_latticeBall _).trans (latticeBall_mono ?_))
    rw [S.frequency_zero]
    rw [mul_comm c]
    exact (div_le_iff₀ hc₀).mp hNfreq
  have hstartD (x : Cover d) : ‖fderiv ℝ (fun z => F₀ (flatProjection z)) x‖ ≤
      ((S.frequency 1 : ℝ) * √S.initialDefect) / S.growth ^ B := by
    refine (hF₀deriv x).trans ?_
    change _ ≤ ((S.frequency 1 : ℝ) * √δ₀) / p ^ B
    apply (le_div_iff₀ (pow_pos hp _)).2
    have h := (div_le_iff₀ (show 0 < ℓ * √δ₀ by positivity)).mp hNhess
    convert h using 1
    simp only [LowGeometricScales.frequency, S, Nat.cast_mul, pow_one]
    dsimp only [ℓ]
    ring
  have hsmooth (j : ℕ) : ‖realTorusCutoff (H := MetricForm d) (S.smoothing j) g.form - g.form‖ ≤
      (ε₀ / 2) * S.defect (j + 1) := by
    refine (hcut _ (S.smoothing_pos j)).trans ?_
    rw [S.defect_eq]
    simp only [LowGeometricScales.smoothing, LowGeometricScales.frequency, S, Nat.cast_mul, Nat.cast_pow]
    rw [mul_comm (ℓ ^ (-η)), smoothingScale_rpow hN₀' hℓ]
    have hq : 0 ≤ (ℓ ^ (-(2 * θ))) ^ (j + 1) := by positivity
    convert mul_le_mul_of_nonneg_right (hNmin _ hNmin') hq using 1 <;> dsimp only [ℓ] <;> ring
  have hfrac' : A * S.smoothingFraction ≤ 1 := by
    change A * ℓ ^ (-η) ≤ 1
    rw [Real.rpow_neg hℓ.le, ← div_eq_mul_inv, div_le_one (Real.rpow_pos_of_pos hℓ _)]
    exact hfrac
  have hsep' : c ≤ (S.ratio : ℝ) * S.smoothingFraction := by
    change c ≤ ℓ * ℓ ^ (-η)
    calc
      _ ≤ ℓ ^ (1 - η) := hsep
      _ = _ := by rw [sub_eq_add_neg, Real.rpow_add hℓ, Real.rpow_one]
  have hrelative' : ε₀ + (1 + ε₀ / 2) * S.decay ^ 2 ≤ ε := by
    rw [S.decay_sq]
    exact (add_le_add hε₂ hrelative).trans_eq (by ring)
  have hrot : S.rotationConstant K ≤ R := by
    change 1 + K * (p / (p - 1)) ≤ 1 + K * (p₀ / (p₀ - 1))
    exact add_le_add le_rfl (mul_le_mul_of_nonneg_left (lowIteration_rotationFactor_le hℓ₂ hθ₁) hK)
  have hrotSmall : S.rotationConstant K * √S.initialDefect ≤ 1 := by
    have hsmall' := hsqrt.trans (min_le_right (τ / (U + 1)) (1 / R))
    calc
      _ ≤ R * √δ₀ := mul_le_mul_of_nonneg_right hrot (Real.sqrt_nonneg _)
      _ ≤ _ := by
        have h := (le_div_iff₀ hR).mp hsmall'
        rwa [mul_comm]
  have hDrift : S.driftBound K ≤ U * √δ₀ := by
    calc
      _ ≤ (K * √δ₀) * (1 - q₀)⁻¹ :=
        mul_le_mul_of_nonneg_left (lowIteration_driftFactor_le hℓ₂ hθ) (by positivity)
      _ = _ := by dsimp only [U]; ring
  have hDrift₀ : 0 ≤ S.driftBound K :=
    mul_nonneg (mul_nonneg hK (Real.sqrt_nonneg _)) (inv_nonneg.mpr (sub_nonneg.mpr S.decay_lt_one.le))
  have hDriftτ : S.driftBound K ≤ τ := by
    have hmul := (le_div_iff₀ (show 0 < U + 1 by positivity)).mp
      (hsqrt.trans (min_le_left (τ / (U + 1)) (1 / R)))
    refine hDrift.trans ?_
    linarith [Real.sqrt_nonneg δ₀]
  have hDriftM : ‖F₀‖ + S.driftBound K ≤ M₀ + 1 :=
    add_le_add hFNorm (hDriftτ.trans (min_le_right _ _))
  have hDriftσ (t : UnitAddTorus d) (v : Cover d) :
      (σ₀ / 2 + S.driftBound K) * ‖v‖ ≤ ‖F₀ t v‖ := by
    refine (mul_le_mul_of_nonneg_right ?_ (norm_nonneg v)).trans (hFpositive t v)
    linarith [hDriftτ.trans (min_le_left _ _)]
  have hbudget' : K * (S.smoothingFraction ^ 2 + S.rotationConstant K / S.growth ^ B +
      S.driftBound K ^ 2) ≤ (ε₀ / 2) * S.decay ^ 2 := by
    let x := ℓ ^ (-(1 + θ))
    let y := ℓ ^ (-((B : ℝ) * (1 - θ)))
    have hx : 0 ≤ x := Real.rpow_nonneg hℓ.le _
    have hy : 0 ≤ y := Real.rpow_nonneg hℓ.le _
    have hμsq : S.smoothingFraction ^ 2 = x := by
      change (ℓ ^ (-η)) ^ 2 = _
      rw [← Real.rpow_natCast _ 2, ← Real.rpow_mul hℓ.le]
      dsimp only [x, η]
      congr 1
      push_cast
      ring
    have hpinv : (S.growth ^ B)⁻¹ = y := by
      change (p ^ B)⁻¹ = _
      dsimp only [p]
      rw [← Real.rpow_natCast _ B, ← Real.rpow_mul hℓ.le, ← Real.rpow_neg hℓ.le]
      dsimp only [y]
      rw [mul_comm (B : ℝ)]
    have hroty : S.rotationConstant K / S.growth ^ B ≤ R * y := by
      rw [div_eq_mul_inv, hpinv]
      exact mul_le_mul_of_nonneg_right hrot hy
    have hDriftSq : S.driftBound K ^ 2 ≤ U ^ 2 * δ₀ := by
      refine (pow_le_pow_left₀ hDrift₀ hDrift 2).trans_eq ?_
      rw [mul_pow, Real.sq_sqrt hδ₀.le]
    have h1 : K ≤ C' := by
      dsimp only [C']
      exact le_mul_of_one_le_right hK (by linarith only [hR, sq_nonneg U])
    have h2 : K * R ≤ C' :=
      mul_le_mul_of_nonneg_left (by linarith only [sq_nonneg U]) hK
    have h3 : K * U ^ 2 ≤ C' :=
      mul_le_mul_of_nonneg_left (by linarith only [hR]) hK
    rw [hμsq, S.decay_sq]
    calc
      _ ≤ K * (x + R * y + U ^ 2 * δ₀) :=
        mul_le_mul_of_nonneg_left (add_le_add (add_le_add le_rfl hroty) hDriftSq) hK
      _ = K * x + (K * R) * y + (K * U ^ 2) * δ₀ := by ring
      _ ≤ C' * x + C' * y + C' * δ₀ :=
        add_le_add (add_le_add (mul_le_mul_of_nonneg_right h1 hx) (mul_le_mul_of_nonneg_right h2 hy))
          (mul_le_mul_of_nonneg_right h3 hδ₀.le)
      _ = C' * (x + y + δ₀) := by ring
      _ ≤ _ := hbudget
  obtain ⟨v, hv, hmetric⟩ := hrotate g F₀ J S ε₀ hε₀ hδmax' hfrac' hsep' hrelative' hrotSmall
    hbudget' hDriftM hDriftσ hJ hstartBand hstartD hsmooth hGram.le
  exact ⟨B, n, hB, S, c, K, ε₀, u₀, v, rfl, hc, hK, hε₀, hstartBand, hv, hmetric⟩

end

end IsometricEmbeddingEndpoints

#print axioms IsometricEmbeddingEndpoints.TorusMetric.exists_lowRotation
