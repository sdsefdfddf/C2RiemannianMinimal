import Mathlib.Analysis.Calculus.MeanValue
import Mathlib.Analysis.RCLike.Basic
import Mathlib.Analysis.SpecialFunctions.Pow.Real
import Mathlib.MeasureTheory.Integral.Bochner.ContinuousLinearMap
import Mathlib.Tactic.Ring

namespace IsometricEmbeddingEndpoints

open MeasureTheory

noncomputable section

variable {Ω : Type*} [MeasurableSpace Ω] {ν : Measure Ω}
variable {𝕜 : Type*} [RCLike 𝕜]
variable {H : Type*} [NormedAddCommGroup H] [NormedSpace ℝ H] [NormedSpace 𝕜 H]
  [CompleteSpace H]

/-- The mass determines the constant term, and the vanishing weighted linear term leaves exactly
the integral of the Taylor remainder. The weights may be complex. -/
theorem weighted_sub_mass_eq_remainder (k : Ω → 𝕜) (A T : Ω → H) (a : H) {m : 𝕜}
    (hk : Integrable k ν) (hA : Integrable (fun y => k y • A y) ν)
    (hT : Integrable (fun y => k y • T y) ν)
    (hmass : (∫ y, k y ∂ν) = m) (hzero : (∫ y, k y • T y ∂ν) = 0) :
    (∫ y, k y • A y ∂ν) - m • a = ∫ y, k y • (A y - a + T y) ∂ν := by
  have hconst : Integrable (fun y => k y • a) ν := hk.smul_const a
  calc
    _ = ((∫ y, k y • A y ∂ν) - ∫ y, k y • a ∂ν) + ∫ y, k y • T y ∂ν := by
      rw [integral_smul_const, hmass, hzero, add_zero]
    _ = ∫ y, (k y • A y - k y • a) + k y • T y ∂ν := by
      have hadd := integral_add (hA.sub hconst) hT
      rw [integral_sub' hA hconst] at hadd
      exact hadd.symm
    _ = _ := integral_congr_ae (Filter.Eventually.of_forall fun y => by
      rw [smul_add, smul_sub])

/-- A Taylor remainder controlled by a moment of the kernel gives the cutoff error. -/
theorem norm_weighted_sub_mass_le (k : Ω → 𝕜) (A T : Ω → H) (a : H) (d : Ω → ℝ)
    {m : 𝕜} {C : ℝ} (hk : Integrable k ν) (hA : Integrable (fun y => k y • A y) ν)
    (hT : Integrable (fun y => k y • T y) ν)
    (hmass : (∫ y, k y ∂ν) = m) (hzero : (∫ y, k y • T y ∂ν) = 0)
    (hmoment : Integrable (fun y => ‖k y‖ * d y) ν)
    (hrem : ∀ᵐ y ∂ν, ‖A y - a + T y‖ ≤ C * d y) :
    ‖(∫ y, k y • A y ∂ν) - m • a‖ ≤ C * (∫ y, ‖k y‖ * d y ∂ν) := by
  rw [weighted_sub_mass_eq_remainder k A T a hk hA hT hmass hzero, ← integral_const_mul]
  refine norm_integral_le_of_norm_le (hmoment.const_mul C) ?_
  filter_upwards [hrem] with y hy
  calc
    ‖k y • (A y - a + T y)‖ = ‖k y‖ * ‖A y - a + T y‖ := norm_smul _ _
    _ ≤ ‖k y‖ * (C * d y) := mul_le_mul_of_nonneg_left hy (norm_nonneg _)
    _ = C * (‖k y‖ * d y) := by ring

/-- A vanishing vector moment cancels every continuous linear Taylor term. -/
theorem integral_weighted_linear_eq_zero {E : Type*}
    [NormedAddCommGroup E] [NormedSpace ℝ E] [CompleteSpace E]
    (k : Ω → ℝ) (Y : Ω → E) (L : E →L[ℝ] H)
    (hkY : Integrable (fun y => k y • Y y) ν)
    (hzero : (∫ y, k y • Y y ∂ν) = 0) :
    (∫ y, k y • L (Y y) ∂ν) = 0 := by
  calc
    _ = ∫ y, L (k y • Y y) ∂ν :=
      integral_congr_ae (Filter.Eventually.of_forall fun y => (L.map_smul (k y) (Y y)).symm)
    _ = L (∫ y, k y • Y y ∂ν) := L.integral_comp_comm hkY
    _ = 0 := by rw [hzero, map_zero]

end

/-- Taylor's first-order remainder from a Hölder bound on the derivative.
The bound with exponent one on the derivative is the quadratic remainder used by a stage. -/
theorem norm_firstOrderRemainder_le_of_holderDifferential
    {E H : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E]
    [NormedAddCommGroup H] [NormedSpace ℝ H]
    (A : E → H) (D : E → E →L[ℝ] H)
    (hD : ∀ x, HasFDerivAt A (D x) x) {α C : ℝ} (hα : 0 ≤ α) (hC : 0 ≤ C)
    (hHolder : ∀ x z, ‖D z - D x‖ ≤ C * ‖z - x‖ ^ α) (x y : E) :
    ‖A (x - y) - A x + D x y‖ ≤ C * ‖y‖ ^ α * ‖y‖ := by
  let s := Metric.closedBall x ‖y‖
  let B := fun z => A z - D x z
  have hB : ∀ z ∈ s, HasFDerivWithinAt B (D z - D x) s z :=
    fun z _ => ((hD z).sub (D x).hasFDerivAt).hasFDerivWithinAt
  have hbound : ∀ z ∈ s, ‖D z - D x‖ ≤ C * ‖y‖ ^ α := by
    intro z hz
    have hzy : ‖z - x‖ ≤ ‖y‖ := by simpa [s, Metric.mem_closedBall, dist_eq_norm] using hz
    exact (hHolder x z).trans
      (mul_le_mul_of_nonneg_left (Real.rpow_le_rpow (norm_nonneg _) hzy hα) hC)
  have hx : x ∈ s := Metric.mem_closedBall_self (norm_nonneg _)
  have hyx : x - y - x = -y := by abel
  have hy : x - y ∈ s := by simp [s, Metric.mem_closedBall]
  have hb := (convex_closedBall x ‖y‖).norm_image_sub_le_of_norm_hasFDerivWithin_le
    hB hbound hx hy
  have heq : B (x - y) - B x = A (x - y) - A x + D x y := by
    dsimp only [B]
    rw [map_sub]
    abel
  simpa only [heq, hyx, norm_neg] using hb

end IsometricEmbeddingEndpoints

#print axioms IsometricEmbeddingEndpoints.norm_weighted_sub_mass_le
#print axioms IsometricEmbeddingEndpoints.norm_firstOrderRemainder_le_of_holderDifferential
