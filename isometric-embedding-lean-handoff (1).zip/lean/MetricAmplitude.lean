import AmplitudeRegularity
import IntegerDirections
import TorusMetric

namespace IsometricEmbeddingEndpoints

open ContinuousLinearMap

noncomputable section

variable {d : Type*} [Fintype d] [DecidableEq d]

local instance : NormedAddCommGroup (MetricForm d) := inferInstance
local instance : NormedSpace ℝ (MetricForm d) := inferInstance

private def basisVector (i : d) : Cover d := EuclideanSpace.basisFun d ℝ i

private theorem norm_basisVector (i : d) : ‖basisVector i‖ = 1 :=
  (EuclideanSpace.basisFun d ℝ).orthonormal.norm_eq_one i

private def coordinateEntry (i j : d) : MetricForm d →L[ℝ] ℝ :=
  (ContinuousLinearMap.apply ℝ ℝ (basisVector j)).comp
    (ContinuousLinearMap.apply ℝ (Cover d →L[ℝ] ℝ) (basisVector i))

private theorem norm_coordinateEntry_le (i j : d) : ‖coordinateEntry i j‖ ≤ 1 := by
  apply opNorm_le_bound _ zero_le_one
  intro E
  change ‖E (basisVector i) (basisVector j)‖ ≤ 1 * ‖E‖
  calc
    _ ≤ ‖E (basisVector i)‖ * ‖basisVector j‖ := le_opNorm _ _
    _ ≤ (‖E‖ * ‖basisVector i‖) * ‖basisVector j‖ :=
      mul_le_mul_of_nonneg_right (le_opNorm _ _) (norm_nonneg _)
    _ = _ := by simp only [norm_basisVector, mul_one, one_mul]

private theorem abs_coordinateEntry_le (E : MetricForm d) (i j : d) :
    |coordinateEntry i j E| ≤ ‖E‖ := by
  rw [← Real.norm_eq_abs]
  exact (le_opNorm (coordinateEntry i j) E).trans
    ((mul_le_mul_of_nonneg_right (norm_coordinateEntry_le i j) (norm_nonneg E)).trans_eq (one_mul _))

private theorem sum_coordinateEntry_mul (E : MetricForm d) (v w : Cover d) :
    ∑ i, ∑ j, coordinateEntry i j E * (v i * w j) = E v w := by
  have hrepr (z : Cover d) : ∑ i, z i • basisVector i = z :=
    (EuclideanSpace.basisFun d ℝ).sum_repr z
  calc
    _ = E (∑ i, v i • basisVector i) (∑ j, w j • basisVector j) := by
      simp only [map_sum, map_smul, sum_apply, smul_apply, smul_eq_mul, Finset.mul_sum]
      conv_rhs => rw [Finset.sum_comm]
      apply Finset.sum_congr rfl
      intro i _
      apply Finset.sum_congr rfl
      intro j _
      change E (basisVector i) (basisVector j) * (v i * w j) =
        w j * (v i * E (basisVector i) (basisVector j))
      ring
    _ = _ := by rw [hrepr, hrepr]

private def coefficientLinear : TwistIndex d → MetricForm d →L[ℝ] ℝ
  | .inl _ => 0
  | .inr (i, j, true) => (1 / 4 : ℝ) • coordinateEntry i j
  | .inr (i, j, false) => (-1 / 4 : ℝ) • coordinateEntry i j

private theorem norm_coefficientLinear_le (i : TwistIndex d) : ‖coefficientLinear i‖ ≤ 1 := by
  rcases i with i | ⟨i, j, b⟩
  · simp [coefficientLinear]
  · cases b <;> simp only [coefficientLinear, norm_smul, Real.norm_eq_abs] <;>
      norm_num only [abs_neg, abs_of_nonneg (show (0 : ℝ) ≤ 1 / 4 by norm_num)] <;>
      nlinarith [norm_coordinateEntry_le i j]

private theorem twistCoefficient_one (E : MetricForm d) (c : ℝ) (i : TwistIndex d) :
    twistCoefficient (fun j k => coordinateEntry j k E) 1 c i =
      twistCoefficient 0 1 c i + coefficientLinear i E := by
  rcases i with i | ⟨i, j, b⟩
  · simp [twistCoefficient, coefficientLinear]
  · cases b <;> simp [coefficientLinear, twistCoefficient] <;> ring

private theorem twistCoefficient_scale (E : d → d → ℝ) (δ c : ℝ) (i : TwistIndex d) :
    δ * twistCoefficient E 1 c i = twistCoefficient (fun j k => δ * E j k) δ c i := by
  rcases i with i | ⟨i, j, b⟩
  · simp [twistCoefficient]
  · cases b <;> simp [twistCoefficient] <;> ring

private def normalizedTwistFunction (E : C(UnitAddTorus d, MetricForm d)) (c : ℝ)
    (i : TwistIndex d) : C(UnitAddTorus d, ℝ) :=
  ⟨fun t => twistCoefficient 0 1 c i + coefficientLinear i (E t),
    continuous_const.add ((coefficientLinear i).continuous.comp E.continuous)⟩

private theorem normalizedTwistFunction_apply (E : C(UnitAddTorus d, MetricForm d)) (c : ℝ)
    (i : TwistIndex d) (t : UnitAddTorus d) :
    normalizedTwistFunction E c i t = twistCoefficient (fun j k => coordinateEntry j k (E t)) 1 c i :=
  (twistCoefficient_one _ _ _).symm

private theorem sum_twistAmplitudes (E : MetricForm d) (hsym : ∀ v w, E v w = E w v)
    (δ c : ℝ) (a : TwistIndex d → ℝ)
    (ha : ∀ i, a i ^ 2 = δ * twistCoefficient (fun j k => coordinateEntry j k E) 1 c i)
    (v w : Cover d) :
    (∑ i, a i ^ 2 * (inner ℝ (latticeVector (twistDirection i)) v *
      inner ℝ (latticeVector (twistDirection i)) w)) = δ * (inner ℝ v w + E v w) := by
  have hlin (i : TwistIndex d) (z : Cover d) :
      inner ℝ (latticeVector (twistDirection i)) z = twistLinearForm i z := rfl
  simp_rw [ha, twistCoefficient_scale, hlin]
  rw [sum_twistCoefficient_mul _ (fun i j => by
    change δ * E (basisVector i) (basisVector j) = δ * E (basisVector j) (basisVector i)
    rw [hsym]) δ c]
  simp_rw [mul_assoc, ← Finset.mul_sum, sum_coordinateEntry_mul]
  ring

/-- The decomposition near the flat form needs only continuity when derivative
bounds on the amplitudes are unnecessary. -/
theorem exists_continuous_metricAmplitudes :
    ∃ ε : ℝ, 0 < ε ∧ ∀ (E : C(UnitAddTorus d, MetricForm d)) {δ : ℝ},
      0 ≤ δ → ‖E‖ ≤ ε → (∀ t v w, E t v w = E t w v) →
      ∃ a : TwistIndex d → C(UnitAddTorus d, ℝ), ∀ t v w,
        (∑ i, a i t ^ 2 *
          (inner ℝ (latticeVector (twistDirection i)) v *
            inner ℝ (latticeVector (twistDirection i)) w)) =
          δ * (inner ℝ v w + E t v w) := by
  let m : ℝ := Fintype.card d
  let c : ℝ := 1 / (2 * (m + 1))
  have hm : 0 ≤ m := by positivity
  have hc : 0 < c := by dsimp only [c]; positivity
  have hmc : m * c < 1 := by
    dsimp only [c]
    rw [mul_one_div]
    exact (div_lt_one (by positivity)).2 (by linarith)
  refine ⟨c / 2, by positivity, ?_⟩
  intro E δ hδ hE hsym
  let f := normalizedTwistFunction E c
  let a := fun i : TwistIndex d =>
    (⟨fun t => √(δ * f i t), Real.continuous_sqrt.comp ((f i).continuous.const_mul δ)⟩ :
      C(UnitAddTorus d, ℝ))
  refine ⟨a, fun t v w => sum_twistAmplitudes (E t) (hsym t) δ c (fun i => a i t) ?_ v w⟩
  intro i
  have hpos : 0 < f i t := by
    rw [normalizedTwistFunction_apply]
    refine twistCoefficient_pos zero_lt_one hmc (fun j k => ?_) i
    rw [mul_one]
    exact ((abs_coordinateEntry_le (E t) j k).trans ((E.norm_coe_le_norm t).trans hE)).trans_lt
      (by linarith)
  change (√(δ * f i t)) ^ 2 = _
  rw [Real.sq_sqrt (mul_nonneg hδ hpos.le), normalizedTwistFunction_apply]

set_option maxHeartbeats 440000 in
/-- On a fixed ball about the identity, a metric increment admits amplitudes
in fixed lattice directions with uniformly bounded derivatives after normalization. -/
theorem exists_metricAmplitudes :
    ∃ ε A : ℝ, 0 < ε ∧ 0 ≤ A ∧
      ∀ (E : C(UnitAddTorus d, MetricForm d)) {δ Λ : ℝ}, 0 ≤ δ → 0 ≤ Λ →
        ‖E‖ ≤ ε → (∀ t v w, E t v w = E t w v) →
        ContDiff ℝ 2 (fun z => E (flatProjection z)) →
        (∀ z j, 1 ≤ j → j ≤ 2 →
          ‖iteratedFDeriv ℝ j (fun y => E (flatProjection y)) z‖ ≤ Λ ^ j) →
        ∃ a : TwistIndex d → C(UnitAddTorus d, ℝ),
          (∀ i, ContDiff ℝ 2 (fun z => a i (flatProjection z))) ∧
          (∀ i z j, j ≤ 2 →
            ‖iteratedFDeriv ℝ j (fun y => a i (flatProjection y)) z‖ ≤ (A * √δ) * Λ ^ j) ∧
          ∀ t v w,
            (∑ i, a i t ^ 2 *
              (inner ℝ (latticeVector (twistDirection i)) v *
                inner ℝ (latticeVector (twistDirection i)) w)) =
              δ * (inner ℝ v w + E t v w) := by
  let m : ℝ := Fintype.card d
  let c : ℝ := 1 / (2 * (m + 1))
  have hm : 0 ≤ m := by positivity
  have hc : 0 < c := by dsimp only [c]; positivity
  have hmc : m * c ≤ 1 / 2 := by
    dsimp only [c]
    rw [mul_one_div]
    apply (div_le_iff₀ (show 0 < 2 * (m + 1) by positivity)).2
    linarith
  let ℓ : ℝ := min (1 / 2) (c / 8)
  let u : ℝ := max 1 (c / 2)
  have hℓ : 0 < ℓ := lt_min (by norm_num) (div_pos hc (by norm_num))
  obtain ⟨B, hB, hAmp⟩ := exists_bound_iteratedFDeriv_amplitude (E := Cover d) (b := u) hℓ 2
  refine ⟨c / 2, 2 * B, by positivity, by positivity, ?_⟩
  intro E δ Λ hδ hΛ hE hsym hd hD
  let f := normalizedTwistFunction E c
  have hf (i : TwistIndex d) (t : UnitAddTorus d) :
      f i t = twistCoefficient (fun j k => coordinateEntry j k (E t)) 1 c i :=
    normalizedTwistFunction_apply E c i t
  have hentry (t : UnitAddTorus d) (i j : d) : |coordinateEntry i j (E t)| ≤ c / 2 :=
    (abs_coordinateEntry_le (E t) i j).trans ((E.norm_coe_le_norm t).trans hE)
  have hI (i : TwistIndex d) (t : UnitAddTorus d) : f i t ∈ Set.Icc ℓ u := by
    rw [hf]
    rcases i with i | ⟨i, j, b⟩
    · simp only [twistCoefficient, one_mul, Set.mem_Icc]
      exact ⟨(min_le_left _ _).trans (by linarith),
        (by linarith [mul_nonneg hm hc.le] : 1 - m * c ≤ 1).trans (le_max_left _ _)⟩
    · obtain ⟨hlo, hhi⟩ := abs_le.mp (hentry t i j)
      have hlo' := min_le_right (1 / 2 : ℝ) (c / 8)
      have hhi' := le_max_right (1 : ℝ) (c / 2)
      cases b <;> simp only [twistCoefficient, mul_one, Set.mem_Icc] <;>
        constructor <;> linarith
  have hfd (i : TwistIndex d) : ContDiff ℝ 2 (fun z => f i (flatProjection z)) :=
    contDiff_const.add ((coefficientLinear i).contDiff.comp hd)
  have hfd' (i : TwistIndex d) (z : Cover d) (j : ℕ) (hj : 1 ≤ j) (hjn : j ≤ 2) :
      ‖iteratedFDeriv ℝ j (fun y => f i (flatProjection y)) z‖ ≤ Λ ^ j := by
    have hj' : (j : WithTop ℕ∞) ≤ 2 := by exact_mod_cast hjn
    change ‖iteratedFDeriv ℝ j ((fun _ => twistCoefficient 0 1 c i) +
      (coefficientLinear i ∘ fun y => E (flatProjection y))) z‖ ≤ _
    rw [iteratedFDeriv_add contDiff_const ((coefficientLinear i).contDiff.comp (hd.of_le hj')),
      iteratedFDeriv_const_of_ne (by omega : j ≠ 0), zero_add]
    refine ((coefficientLinear i).norm_iteratedFDeriv_comp_left hd.contDiffAt hj').trans ?_
    exact ((mul_le_mul_of_nonneg_right (norm_coefficientLinear_le i) (norm_nonneg _)).trans_eq
      (one_mul _)).trans (hD z j hj hjn)
  let a := fun i : TwistIndex d =>
    (⟨fun t => √(δ * f i t), Real.continuous_sqrt.comp ((f i).continuous.const_mul δ)⟩ :
      C(UnitAddTorus d, ℝ))
  refine ⟨a, ?_, ?_, ?_⟩
  · intro i
    change ContDiff ℝ 2 (fun z => √(δ * f i (flatProjection z)))
    simp only [Real.sqrt_mul hδ]
    exact contDiff_const.mul ((hfd i).sqrt (fun x => (hℓ.trans_le (hI i (flatProjection x)).1).ne'))
  · intro i z j hj
    refine (hAmp (fun x => f i (flatProjection x)) Λ hδ (hfd i) (fun x => hI i (flatProjection x))
      z j hj (fun k hk hkj => hfd' i z k hk (hkj.trans hj))).trans ?_
    have hj2 : (j.factorial : ℝ) ≤ 2 := by interval_cases j <;> norm_num
    gcongr
  · intro t v w
    refine sum_twistAmplitudes (E t) (hsym t) δ c (fun i => a i t) (fun i => ?_) v w
    change (√(δ * f i t)) ^ 2 = _
    rw [Real.sq_sqrt (mul_nonneg hδ (hℓ.trans_le (hI i t).1).le), hf]

end

end IsometricEmbeddingEndpoints

#print axioms IsometricEmbeddingEndpoints.exists_metricAmplitudes
#print axioms IsometricEmbeddingEndpoints.exists_continuous_metricAmplitudes
