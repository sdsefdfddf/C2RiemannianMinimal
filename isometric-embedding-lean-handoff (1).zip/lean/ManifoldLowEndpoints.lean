import ManifoldLowAssembly

open scoped ContDiff Manifold

namespace IsometricEmbeddingEndpoints

noncomputable section

variable {d M : Type*} [Fintype d]
  [TopologicalSpace M] [ChartedSpace (Cover d) M]
  [IsManifold 𝓘(ℝ, Cover d) ∞ M] [T2Space M] [CompactSpace M]

local notation "K₀" r:arg => Metric.closedBall (0 : Cover d) r
local notation "B₀" r:arg => Metric.ball (0 : Cover d) r
local instance : NormedAddCommGroup (MetricForm d) := inferInstance
local instance : NormedSpace ℝ (MetricForm d) := inferInstance

private theorem holder_metric_sub {R a : ℝ} (ha : 0 ≤ a) (ha₁ : a ≤ 1)
    {h q : Cover d → MetricForm d} (hh : HolderMetricCoefficientsOn a (K₀ R) h)
    (hq : ∀ x ∈ K₀ R, ContDiffAt ℝ 2 q x) :
    HolderMetricCoefficientsOn a (K₀ R) (h - q) := by
  have hq₁ (x : Cover d) (hx : x ∈ K₀ R) : ContDiffAt ℝ 1 q x := (hq x hx).of_le (by norm_num)
  refine ⟨hh.1.sub (fun x hx => (hq₁ x hx).continuousAt.continuousWithinAt), ?_⟩
  rcases hh.2 with ha₀ | ⟨C, hC, hCest⟩
  · exact Or.inl ha₀
  · obtain ⟨L, hL, hLest⟩ := exists_holder_bound_on_of_contDiffAt_one
      (isCompact_closedBall _ _) (convex_closedBall _ _) hq₁ ha ha₁
    refine Or.inr ⟨C + L, add_nonneg hC hL, fun x hx y hy => ?_⟩
    simp only [Pi.sub_apply, sub_sub_sub_comm, add_mul]
    exact (norm_sub_le _ _).trans (add_le_add (hCest x hx y hy) (hLest x hx y hy))

private theorem holder_metric_local_solver {a : ℝ} (ha : 0 ≤ a) (ha₁ : a ≤ 1)
    (R : ℝ) (h : Cover d → MetricForm d) (hR : 0 < R)
    (hh : HolderMetricCoefficientsOn a (K₀ R) h)
    (hs : ∀ x ∈ B₀ R, ∀ v z, h x v z = h x z v)
    (hp : ∀ x ∈ B₀ R, ∀ v ≠ 0, 0 < h x v v) :
    ∃ (N : ℕ) (u : Cover d → EuclideanSpace ℝ (Fin N)),
      HasHolderDifferentialOn (a / 2) u (localImmersionBall d R) ∧
      ∀ x ∈ localImmersionBall d R, ∀ v z,
        inner ℝ (fderiv ℝ u x v) (fderiv ℝ u x z) = h x v z := by
  classical
  have hc := hh.1.mono Metric.ball_subset_closedBall
  by_cases ha₀ : a = 0
  · obtain ⟨N, u, hu, hiso⟩ := exists_localIsometricImmersion_contDiff hR h hc hs hp
    have hu₀ : HasHolderDifferentialOn 0 u (localImmersionBall d R) :=
      hasHolderDifferentialOn_zero_of_contDiffAt (isCompact_closedBall _ _) hu
    exact ⟨N, u, by simpa only [ha₀, zero_div] using hu₀, hiso⟩
  · rcases hh.2 with h | ⟨C, hC, hCest⟩
    · exact (ha₀ h).elim
    · exact exists_localIsometricImmersion_of_holder hR h hc hs hp
        (lt_of_le_of_ne ha (Ne.symm ha₀)) ha₁ hC
        (fun x hx y hy => hCest x (Metric.ball_subset_closedBall hx) y (Metric.ball_subset_closedBall hy))

/-- The first low-regularity endpoint on closed smooth manifolds. This includes
a continuous metric and a continuously differentiable isometric embedding at exponent zero. -/
theorem RiemannianMetric.exists_holder_isometricEmbedding
    (g : RiemannianMetric d M) {a : ℝ} (ha : 0 ≤ a) (ha₁ : a ≤ 1)
    (hg : g.holderInCharts a) :
    ∃ (N : ℕ) (u : M → EuclideanSpace ℝ (Fin N)),
      g.IsHolderIsometricEmbedding (a / 2) u := by
  classical
  exact g.exists_embedding_of_local_solver (a / 2) (by linarith) (by linarith)
    (HolderMetricCoefficientsOn a) hg (fun _ _ h => h.1)
    (holder_metric_sub ha ha₁) (holder_metric_local_solver ha ha₁)

/-- The continuously differentiable isometric embedding theorem for a
continuous metric on a closed smooth manifold. -/
theorem RiemannianMetric.exists_contDiff_isometricEmbedding
    (g : RiemannianMetric d M) (hg : g.continuousInCharts) :
    ∃ (N : ℕ) (u : M → EuclideanSpace ℝ (Fin N)),
      g.IsC1IsometricEmbedding u := by
  have hg₀ : g.holderInCharts 0 := fun p => by
    obtain ⟨R, hR, ht, h⟩ := hg p
    exact ⟨R, hR, ht, h, Or.inl rfl⟩
  obtain ⟨N, u, hu, _⟩ := g.exists_holder_isometricEmbedding le_rfl zero_le_one hg₀
  exact ⟨N, u, hu⟩

/-- The second low-regularity endpoint on closed smooth manifolds. -/
theorem RiemannianMetric.exists_holderDifferential_isometricEmbedding
    (g : RiemannianMetric d M) {a : ℝ} (ha : 0 ≤ a) (ha₁ : a < 1)
    (hg : g.holderDifferentialInCharts a) :
    ∃ (N : ℕ) (u : M → EuclideanSpace ℝ (Fin N)),
      g.IsHolderIsometricEmbedding ((1 + a) / 2) u := by
  classical
  refine g.exists_embedding_of_local_solver ((1 + a) / 2) (by linarith) (by linarith)
    (fun s h => HasHolderDifferentialOn a h s) hg ?_ ?_ ?_
  · intro s h hh x hx
    exact (hh.1 x hx).continuousAt.continuousWithinAt
  · intro R h q hh hq
    exact hh.sub (hasHolderDifferentialOn_of_contDiffAt_two (isCompact_closedBall _ _)
      (convex_closedBall _ _) hq ha ha₁.le)
  · intro R h hR hh hsym hpos
    obtain ⟨hF, C, hC, hEst⟩ := hh
    exact exists_localIsometricImmersion_of_holderDifferential hR h
      (fun x hx => (hF x (Metric.ball_subset_closedBall hx)).contDiffWithinAt)
      hsym hpos ha ha₁ hC (fun x hx y hy =>
        hEst x (Metric.ball_subset_closedBall hx) y (Metric.ball_subset_closedBall hy))

/-- Continuously differentiable metrics give the exponent one half. -/
theorem RiemannianMetric.exists_holder_half_isometricEmbedding
    (g : RiemannianMetric d M) (hg : g.contDiffInCharts) :
    ∃ (N : ℕ) (u : M → EuclideanSpace ℝ (Fin N)),
      g.IsHolderIsometricEmbedding (1 / 2) u := by
  have h₀ : g.holderDifferentialInCharts 0 := fun p => by
    obtain ⟨R, hR, ht, h⟩ := hg p
    exact ⟨R, hR, ht, hasHolderDifferentialOn_zero_of_contDiffAt (isCompact_closedBall _ _) h⟩
  simpa only [add_zero] using g.exists_holderDifferential_isometricEmbedding le_rfl zero_lt_one h₀

end

end IsometricEmbeddingEndpoints
