import ClosedManifoldCoordinates
import FiniteDimensionalImmersion
import ManifoldLowEndpoints

open scoped ContDiff Manifold NNReal

namespace IsometricEmbeddingEndpoints

noncomputable section

variable {d N : ℕ} {M : Type*} [TopologicalSpace M] [ChartedSpace (Euclidean d) M]

local notation "𝓔" d:arg => 𝓘(ℝ, Euclidean d)
local notation "T" M:arg => TangentSpace (𝓔 d) (M := M)

variable [T2Space M] [CompactSpace M] [IsManifold (𝓔 d) ∞ M]

omit [T2Space M] [CompactSpace M] in
private theorem isHolderIsometricEmbedding_of_metricField
    (g : Bundle.RiemannianMetric (T M)) {a : ℝ≥0} {u : M → Euclidean N}
    (hu : (metricField g).IsHolderIsometricEmbedding (a : ℝ) u) :
    IsHolderIsometricEmbedding g a u := by
  rcases hu with ⟨⟨hE, hC, hI⟩, hH⟩
  have hinj (p : M) : Function.Injective (mvfderiv (𝓔 d) u p) := by
    intro v w hvw
    by_contra hv
    have hpos := g.pos p (v - w) (sub_ne_zero.mpr hv)
    have hz : mvfderiv (𝓔 d) u p (v - w) = 0 := by
      rw [map_sub, hvw, sub_self]
    have h := hI p (v - w) (v - w)
    change inner ℝ (mvfderiv (𝓔 d) u p (v - w)) (mvfderiv (𝓔 d) u p (v - w)) =
      g.inner p (v - w) (v - w) at h
    rw [hz, inner_zero_left] at h
    exact (ne_of_gt hpos) h.symm
  exact ⟨⟨⟨isImmersion_of_injective_mvfderiv (d := d) (N := N) hC hinj, hE⟩, hI⟩,
    holderDifferentialInCharts_of_centered hH⟩

/-- A `C^{0,a}` metric admits a `C^{1,a/2}` isometric embedding for `0 ≤ a ≤ 1`. -/
theorem exists_holder_isometricEmbedding
    (g : Bundle.ContinuousRiemannianMetric (Euclidean d) (T M)) {a : ℝ≥0} (ha : a ≤ 1)
    (hg : HolderInCharts a (metricInChart g.toRiemannianMetric)) :
    ∃ (N : ℕ) (u : M → Euclidean N), IsHolderIsometricEmbedding g.toRiemannianMetric (a / 2) u := by
  obtain ⟨N, u, hu⟩ := (metricField g.toRiemannianMetric).exists_holder_isometricEmbedding
    a.coe_nonneg (by exact_mod_cast ha) (metricField_holderInCharts g hg)
  exact ⟨N, u, isHolderIsometricEmbedding_of_metricField g.toRiemannianMetric
    (by simpa only [NNReal.coe_div, NNReal.coe_two] using hu)⟩

/-- A `C^{1,a}` metric admits a `C^{1,(1+a)/2}` isometric embedding for `0 ≤ a < 1`. -/
theorem exists_holderDifferential_isometricEmbedding
    (g : Bundle.ContMDiffRiemannianMetric (𝓔 d) 1 (Euclidean d) (T M)) {a : ℝ≥0} (ha : a < 1)
    (hg : HolderDifferentialInCharts a (metricInChart g.toRiemannianMetric)) :
    ∃ (N : ℕ) (u : M → Euclidean N),
      IsHolderIsometricEmbedding g.toRiemannianMetric ((1 + a) / 2) u := by
  obtain ⟨N, u, hu⟩ :=
    (metricField g.toRiemannianMetric).exists_holderDifferential_isometricEmbedding
      a.coe_nonneg (by exact_mod_cast ha) (metricField_holderDifferentialInCharts g hg)
  exact ⟨N, u, isHolderIsometricEmbedding_of_metricField g.toRiemannianMetric
    (by simpa only [NNReal.coe_div, NNReal.coe_ofNat, NNReal.coe_add, NNReal.coe_one] using hu)⟩

end

end IsometricEmbeddingEndpoints
