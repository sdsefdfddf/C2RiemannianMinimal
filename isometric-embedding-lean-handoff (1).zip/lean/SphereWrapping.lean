import Spiral
import Mathlib.Analysis.Calculus.ContDiff.Operations

namespace IsometricEmbeddingEndpoints

open ContinuousLinearMap

noncomputable section

variable {ι : Type*} [Fintype ι]

/-- Wrap each Euclidean coordinate around a circle of radius `r`. -/
def circleWrapping (r : ℝ) : EuclideanSpace ℝ ι → PiLp 2 (fun _ : ι => CirclePair) :=
  circlePairs (fun _ _ => r) (fun i z => r⁻¹ * z i)

theorem contDiff_circleWrapping {k : WithTop ℕ∞} (r : ℝ) :
    ContDiff ℝ k (circleWrapping (ι := ι) r) := by
  let e := (PiLp.continuousLinearEquiv 2 ℝ (fun _ : ι => CirclePair)).symm.toContinuousLinearMap
  have h (i : ι) : ContDiff ℝ k (circlePair (fun _ : EuclideanSpace ℝ ι => r)
      (fun x => r⁻¹ * x i)) := by
    have hphase : ContDiff ℝ k (fun x : EuclideanSpace ℝ ι => r⁻¹ * x i) := by
      let L : EuclideanSpace ℝ ι →L[ℝ] ℝ := EuclideanSpace.proj i
      change ContDiff ℝ k (fun x => r⁻¹ * L x)
      exact contDiff_const.mul L.contDiff
    let e' := (WithLp.prodContinuousLinearEquiv 2 ℝ ℝ ℝ).symm.toContinuousLinearMap
    exact e'.contDiff.comp ((contDiff_const.mul hphase.sin).prodMk (contDiff_const.mul hphase.cos))
  exact e.contDiff.comp (contDiff_pi.mpr h)

theorem norm_circleWrapping_sq (r : ℝ) (x : EuclideanSpace ℝ ι) :
    ‖circleWrapping r x‖ ^ 2 = (Fintype.card ι : ℝ) * r ^ 2 := by
  rw [circleWrapping, norm_circlePairs_sq]
  simp only [Finset.sum_const, Finset.card_univ, nsmul_eq_mul]

theorem inner_fderiv_circleWrapping {r : ℝ} (hr : r ≠ 0) (x v w : EuclideanSpace ℝ ι) :
    inner ℝ (fderiv ℝ (circleWrapping r) x v) (fderiv ℝ (circleWrapping r) x w) = inner ℝ v w := by
  have h := inner_fderiv_scaledCirclePairs
    (a := fun _ : ι => fun _ : EuclideanSpace ℝ ι => (1 : ℝ)) (A := fun _ => 0)
    (fun _ => hasFDerivAt_const (1 : ℝ) x) (fun i => EuclideanSpace.proj i)
    (inv_ne_zero hr) v w
  simpa only [circleWrapping, inv_inv, mul_one, one_pow, zero_apply, mul_zero, zero_add, one_mul,
    EuclideanSpace.proj, PiLp.proj_apply, PiLp.inner_apply, Real.inner_apply, RCLike.conj_to_real] using h

theorem inner_circleWrapping_fderiv (r : ℝ) (x v : EuclideanSpace ℝ ι) :
    inner ℝ (circleWrapping r x) (fderiv ℝ (circleWrapping r) x v) = 0 := by
  have h := hasFDerivAt_circlePairs
    (a := fun _ : ι => fun _ : EuclideanSpace ℝ ι => r)
    (t := fun i z => r⁻¹ * z i) (A := fun _ => 0)
    (T := fun i => r⁻¹ • EuclideanSpace.proj i)
    (fun _ => hasFDerivAt_const r x)
    (fun i => by
      let L : EuclideanSpace ℝ ι →L[ℝ] ℝ := EuclideanSpace.proj i
      change HasFDerivAt (fun z => r⁻¹ * L z) (r⁻¹ • L) x
      exact L.hasFDerivAt.const_mul r⁻¹)
  rw [circleWrapping, h.fderiv, PiLp.inner_apply]
  apply Finset.sum_eq_zero
  intro i _
  change inner ℝ (circlePair (fun _ : EuclideanSpace ℝ ι => r) (fun z => r⁻¹ * z i) x)
    (circlePairDeriv r (r⁻¹ * x i) 0 (r⁻¹ • EuclideanSpace.proj i) v) = 0
  simp only [circlePair, circlePairDeriv, comp_apply, ContinuousLinearEquiv.coe_coe,
    ContinuousLinearMap.prod_apply, WithLp.prodContinuousLinearEquiv_symm_apply, WithLp.prod_inner_apply,
    Real.inner_apply, RCLike.conj_to_real, add_apply, smul_apply, smul_eq_mul, zero_apply, mul_zero, add_zero]
  ring

/-- An isometric immersion of a Euclidean space into a sphere of prescribed radius. -/
theorem exists_isometricSphereMap [Nonempty ι] {ρ : ℝ} (hρ : 0 < ρ) :
    ∃ f : EuclideanSpace ℝ ι → PiLp 2 (fun _ : ι => CirclePair),
      ContDiff ℝ ⊤ f ∧ (∀ x, ‖f x‖ ^ 2 = ρ ^ 2) ∧
      (∀ x v, inner ℝ (f x) (fderiv ℝ f x v) = 0) ∧
      ∀ x v w, inner ℝ (fderiv ℝ f x v) (fderiv ℝ f x w) = inner ℝ v w := by
  have hn : 0 < (Fintype.card ι : ℝ) := by exact_mod_cast Fintype.card_pos
  let r := ρ / √(Fintype.card ι : ℝ)
  have hr : 0 < r := div_pos hρ (Real.sqrt_pos.2 hn)
  refine ⟨circleWrapping r, contDiff_circleWrapping r, fun x => ?_,
    inner_circleWrapping_fderiv r, inner_fderiv_circleWrapping hr.ne'⟩
  rw [norm_circleWrapping_sq, show r ^ 2 = ρ ^ 2 / (Fintype.card ι : ℝ) by
    dsimp only [r]; rw [div_pow, Real.sq_sqrt hn.le]]
  field_simp

/-- Adding a constant coordinate gives an isometric sphere map also in dimension zero. -/
theorem exists_isometricSphereMap_withConstant {ρ : ℝ} (hρ : 0 < ρ) :
    ∃ f : EuclideanSpace ℝ ι → WithLp 2 (PiLp 2 (fun _ : ι => CirclePair) × ℝ),
      ContDiff ℝ ⊤ f ∧ (∀ x, ‖f x‖ ^ 2 = ρ ^ 2) ∧
      (∀ x v, inner ℝ (f x) (fderiv ℝ f x v) = 0) ∧
      ∀ x v w, inner ℝ (fderiv ℝ f x v) (fderiv ℝ f x w) = inner ℝ v w := by
  let H := PiLp 2 (fun _ : ι => CirclePair)
  let n : ℝ := Fintype.card ι + 1
  let r := ρ / √n
  have hn : 0 < n := by positivity
  have hr : 0 < r := div_pos hρ (Real.sqrt_pos.2 hn)
  let L := (WithLp.prodContinuousLinearEquiv 2 ℝ H ℝ).symm.toContinuousLinearMap
  let f := fun x : EuclideanSpace ℝ ι => L (circleWrapping r x, r)
  have hf : ContDiff ℝ ⊤ f :=
    L.contDiff.comp ((contDiff_circleWrapping r).prodMk contDiff_const)
  have hD (x v : EuclideanSpace ℝ ι) :
      fderiv ℝ f x v = WithLp.toLp 2 (fderiv ℝ (circleWrapping r) x v, 0) := by
    have hd := ((contDiff_circleWrapping (ι := ι) (k := 1) r).differentiable one_ne_zero x).hasFDerivAt
    have hpair := hd.prodMk (hasFDerivAt_const r x)
    exact DFunLike.congr_fun (L.hasFDerivAt.comp x hpair).fderiv v
  refine ⟨f, hf, fun x => ?_, fun x v => ?_, fun x v w => ?_⟩
  · rw [WithLp.prod_norm_sq_eq_of_L2]
    change ‖circleWrapping r x‖ ^ 2 + ‖r‖ ^ 2 = ρ ^ 2
    rw [norm_circleWrapping_sq, Real.norm_eq_abs, sq_abs]
    have h : n * r ^ 2 = ρ ^ 2 := by
      dsimp only [r]
      rw [div_pow, Real.sq_sqrt hn.le]
      field_simp [hn.ne']
    calc
      _ = n * r ^ 2 := by dsimp only [n]; ring
      _ = _ := h
  · rw [hD, WithLp.prod_inner_apply]
    change inner ℝ (circleWrapping r x) (fderiv ℝ (circleWrapping r) x v) +
      inner ℝ r 0 = 0
    simp only [inner_circleWrapping_fderiv, inner_zero_right, add_zero]
  · rw [hD, hD, WithLp.prod_inner_apply]
    change inner ℝ (fderiv ℝ (circleWrapping r) x v)
      (fderiv ℝ (circleWrapping r) x w) + inner ℝ (0 : ℝ) 0 = inner ℝ v w
    simp only [inner_fderiv_circleWrapping hr.ne', inner_zero_right, add_zero]

section Weighted

variable {E H : Type*} [AddCommMonoid E] [TopologicalSpace E] [Module ℝ E]
  [NormedAddCommGroup H] [InnerProductSpace ℝ H]

/-- Multiplying a constant-length map by a scalar weight adds exactly the
radius squared times the Gram form of the derivative of the weight. -/
theorem inner_weightedSphereDifferential {y : H} {ρ a : ℝ}
    (D : E →L[ℝ] H) (A : E →L[ℝ] ℝ)
    (hy : ‖y‖ ^ 2 = ρ ^ 2) (horth : ∀ v, inner ℝ y (D v) = 0) (v w : E) :
    let B := a • D + A.smulRight y
    inner ℝ (B v) (B w) =
      a ^ 2 * inner ℝ (D v) (D w) + ρ ^ 2 * (A v * A w) := by
  have hv : inner ℝ (D v) y = 0 := (real_inner_comm _ _).trans (horth v)
  simp only [add_apply, smul_apply, smulRight_apply, inner_add_left, inner_add_right,
    real_inner_smul_left, real_inner_smul_right, horth w, hv, real_inner_self_eq_norm_sq, hy]
  ring

end Weighted

end

end IsometricEmbeddingEndpoints

#print axioms IsometricEmbeddingEndpoints.exists_isometricSphereMap
#print axioms IsometricEmbeddingEndpoints.exists_isometricSphereMap_withConstant
#print axioms IsometricEmbeddingEndpoints.inner_weightedSphereDifferential
