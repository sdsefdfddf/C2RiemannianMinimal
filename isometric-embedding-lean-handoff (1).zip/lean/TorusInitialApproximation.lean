import LatticeMetric
import ProjectedCirclePairs
import TorusUniformApproximation

namespace IsometricEmbeddingEndpoints

open Filter ContinuousLinearMap
open scoped Topology

noncomputable section

variable {d ι : Type*} [Fintype d] [Fintype ι] [DecidableEq ι]

local instance : NormedAddCommGroup (MetricForm d) := inferInstance
local instance : NormedSpace ℝ (MetricForm d) := inferInstance

set_option maxHeartbeats 450000 in
/-- A continuous lattice-direction decomposition gives arbitrarily accurate initial
Gram approximations in a target of twice the number of directions. -/
theorem exists_initialMap_of_latticeMetric (ξ : ι → d → ℤ)
    (a : ι → C(UnitAddTorus d, ℝ)) {ε : ℝ} (hε : 0 < ε) :
    ∃ (s : ℝ) (u : C(UnitAddTorus d, PiLp 2 (fun _ : ι => CirclePair)))
      (hu : ContDiff ℝ 1 (fun x => u (flatProjection x))), 0 < s ∧
      HasFourierSupport (torusCutoffBand (d := d) s : Set (d → ℤ)) u ∧
      ‖torusGram (torusDifferential u hu) - torusLatticeMetric ξ a‖ < ε := by
  let η := ε / 3
  have hη : 0 < η := by dsimp only [η]; positivity
  have hamplitudes := tendsto_torusLatticeMetric ξ a (fun s i => realTorusCutoff s (a i))
    (fun i => tendsto_realTorusCutoff (a i))
  obtain ⟨s, hs, hclose⟩ := ((eventually_gt_atTop (0 : ℝ)).and
    (Metric.tendsto_nhds.1 hamplitudes η hη)).exists
  let b := fun i => realTorusCutoff s (a i)
  have hb₁ (i : ι) : ContDiff ℝ 1 (fun x => b i (flatProjection x)) :=
    (hasFourierSupport_realTorusCutoff hs (a i)).contDiff_lift
  let Db := fun i => torusDifferential (b i) (hb₁ i)
  let A := ∑ i, (‖b i‖ + ‖Db i‖)
  have hA : 0 ≤ A := Finset.sum_nonneg fun _ _ => by positivity
  have hsize (i : ι) : ‖b i‖ + ‖Db i‖ ≤ A :=
    Finset.single_le_sum (f := fun i => ‖b i‖ + ‖Db i‖)
      (fun _ _ => by positivity) (Finset.mem_univ i)
  have hb₀ (i : ι) (t : UnitAddTorus d) : ‖b i t‖ ≤ A :=
    ((b i).norm_coe_le_norm t).trans ((le_add_of_nonneg_right (norm_nonneg (Db i))).trans (hsize i))
  have hbD (i : ι) (x : Cover d) : ‖fderiv ℝ (fun z => b i (flatProjection z)) x‖ ≤ A * 1 := by
    rw [← torusDifferential_apply (b i) (hb₁ i), mul_one]
    exact ((Db i).norm_coe_le_norm _).trans ((le_add_of_nonneg_left (norm_nonneg (b i))).trans (hsize i))
  let H := PiLp 2 (fun _ : ι => CirclePair)
  obtain ⟨C, hC, hbounds⟩ := exists_torusBlockWave_bounds (H := H) ξ
  have hnat : Tendsto (fun n : ℕ => (n : ℝ)⁻¹) atTop (𝓝 0) :=
    tendsto_inv_atTop_zero.comp tendsto_natCast_atTop_atTop
  have hdecay : Tendsto (fun n : ℕ => C * A ^ 2 * (1 / (n : ℝ)) ^ 2) atTop (𝓝 0) := by
    simpa only [one_div, zero_pow (by decide : (2 : ℕ) ≠ 0), mul_zero] using
      (hnat.pow 2).const_mul (C * A ^ 2)
  obtain ⟨N, hN, hsmall⟩ := ((eventually_gt_atTop (0 : ℕ)).and
    (hdecay.eventually (gt_mem_nhds hη))).exists
  let J := LinearIsometry.id (R := ℝ) (E := H)
  let W := torusBlockWave J b N ξ
  have hN₁ : (1 : ℝ) ≤ (N : ℝ) := by exact_mod_cast hN
  have hW₁ : ContDiff ℝ 1 (fun z => W (flatProjection z)) :=
    contDiff_torusBlockWave_lift J b N ξ hb₁
  let DW := torusDifferential W hW₁
  obtain ⟨_, _, hGram⟩ := hbounds J b hN hA zero_le_one hN₁ hb₀
    (fun i x => (hb₁ i).differentiable one_ne_zero x) hbD
  have hGramW : ‖torusGram DW - torusLatticeMetric ξ b‖ ≤ C * A ^ 2 * (1 / (N : ℝ)) ^ 2 := by
    apply norm_torusGram_sub_le_of_pointwise _ _ (by positivity)
    intro t v w
    obtain ⟨x, rfl⟩ := flatProjection_surjective t
    rw [torusLatticeMetric_apply, torusDifferential_apply]
    exact hGram x v w
  have hfinal := (continuous_torusGram.continuousAt (x := DW)).tendsto.comp (tendsto_realTorusCutoff DW)
  obtain ⟨S, hS, hcloseW⟩ := ((eventually_gt_atTop (0 : ℝ)).and
    (Metric.tendsto_nhds.1 hfinal η hη)).exists
  let u := realTorusCutoff S W
  have hband := hasFourierSupport_realTorusCutoff hS W
  have hu : ContDiff ℝ 1 (fun z => u (flatProjection z)) := hband.contDiff_lift
  refine ⟨S, u, hu, hS, hband, ?_⟩
  have h₁ : ‖torusGram (torusDifferential u hu) - torusGram DW‖ < η := by
    rw [torusDifferential_realTorusCutoff hS W hW₁ hu]
    simpa only [dist_eq_norm, Function.comp_def] using hcloseW
  have h₂ : ‖torusGram DW - torusLatticeMetric ξ b‖ < η := hGramW.trans_lt hsmall
  have h₃ : ‖torusLatticeMetric ξ b - torusLatticeMetric ξ a‖ < η :=
    by simpa only [dist_eq_norm] using hclose
  refine (norm_sub_le_norm_sub_add_norm_sub _ (torusGram DW) _).trans_lt ?_
  have hrest := norm_sub_le_norm_sub_add_norm_sub (torusGram DW) (torusLatticeMetric ξ b)
    (torusLatticeMetric ξ a)
  dsimp only [η] at h₁ h₂ h₃
  linarith

end

end IsometricEmbeddingEndpoints

#print axioms IsometricEmbeddingEndpoints.exists_initialMap_of_latticeMetric
