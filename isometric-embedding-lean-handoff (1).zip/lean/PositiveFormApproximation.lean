import LatticeMetric
import Mathlib.Analysis.InnerProductSpace.Dual
import Mathlib.Topology.Algebra.Order.Archimedean
import Mathlib.Data.Rat.Lemmas

namespace IsometricEmbeddingEndpoints

open ContinuousLinearMap

noncomputable section

variable {d : Type*} [Fintype d]

local instance : NormedAddCommGroup (MetricForm d) := inferInstance
local instance : NormedSpace ℝ (MetricForm d) := inferInstance

/-- A separate copy of the cover so that its positive form can be used as an inner product. -/
private def CoverWithForm (d : Type*) := Cover d

private instance : AddCommGroup (CoverWithForm d) := inferInstanceAs (AddCommGroup (Cover d))
private instance : Module ℝ (CoverWithForm d) := inferInstanceAs (Module ℝ (Cover d))
private instance : FiniteDimensional ℝ (CoverWithForm d) :=
  inferInstanceAs (FiniteDimensional ℝ (Cover d))

@[instance_reducible]
private def innerProductCoreOfForm (G : MetricForm d)
    (hsym : ∀ v w, G v w = G w v) (hpos : ∀ v, v ≠ 0 → 0 < G v v) :
    InnerProductSpace.Core ℝ (CoverWithForm d) where
  inner v w := G v w
  conj_inner_symm v w := by simpa only [RCLike.conj_to_real] using hsym w v
  re_inner_nonneg v := by
    change 0 ≤ G v v
    by_cases hv : (v : Cover d) = 0
    · have h0 : G (0 : Cover d) (0 : Cover d) = 0 := DFunLike.congr_fun G.map_zero (0 : Cover d)
      exact (congrArg (fun z : Cover d => G z z) hv).trans h0 ▸ (le_rfl : (0 : ℝ) ≤ 0)
    · exact (hpos v hv).le
  add_left v w u := DFunLike.congr_fun (G.map_add (v : Cover d) (w : Cover d)) (u : Cover d)
  smul_left v w r := by
    change G ((r : ℝ) • (v : Cover d)) w = _ * G v w
    rw [RCLike.conj_to_real]
    exact DFunLike.congr_fun (G.map_smul r (v : Cover d)) (w : Cover d)
  definite v hv := by
    by_contra hne
    exact (hpos v hne).ne' hv

/-- Factor a positive form into the rank-one forms of the coordinate functionals
of an orthonormal basis for that form. -/
theorem exists_sum_rankOneForm (G : MetricForm d) (hsym : ∀ v w, G v w = G w v)
    (hpos : ∀ v, v ≠ 0 → 0 < G v v) :
    ∃ z : Fin (Module.finrank ℝ (Cover d)) → Cover d, (∑ i, rankOneForm (z i)) = G := by
  letI : InnerProductSpace.Core ℝ (CoverWithForm d) := innerProductCoreOfForm G hsym hpos
  letI : NormedAddCommGroup (CoverWithForm d) := InnerProductSpace.Core.toNormedAddCommGroup (𝕜 := ℝ)
  letI : InnerProductSpace ℝ (CoverWithForm d) := InnerProductSpace.ofCore _
  let e := stdOrthonormalBasis ℝ (CoverWithForm d)
  let z := fun i => (InnerProductSpace.toDual ℝ (Cover d)).symm (G (e i))
  refine ⟨z, ?_⟩
  ext v w
  rw [sum_apply, sum_apply]
  simp only [rankOneForm_apply, z, InnerProductSpace.toDual_symm_apply]
  have h := e.sum_inner_mul_inner (v : CoverWithForm d) (w : CoverWithForm d)
  change (∑ i, G v (e i) * G (e i) w) = G v w at h
  refine (Finset.sum_congr rfl fun i _ => ?_).trans h
  rw [hsym (e i) v]

private def rationalCoverVector (q : d → ℚ) : Cover d :=
  WithLp.toLp 2 (fun j => (q j : ℝ))

omit [Fintype d] in
private theorem denseRange_rationalCoverVector : DenseRange (rationalCoverVector (d := d)) := by
  let e := (PiLp.continuousLinearEquiv 2 ℝ (fun _ : d => ℝ)).symm
  exact e.surjective.denseRange.comp
    (DenseRange.piMap fun _ => (Rat.denseRange_cast (𝕜 := ℝ))) e.continuous

private theorem exists_rationalCoverVector_lattice (q : d → ℚ) :
    ∃ μ : ℝ, ∃ ξ : d → ℤ, rationalCoverVector q = μ • latticeVector ξ := by
  classical
  let D : ℕ := ∏ j, (q j).den
  let D' : d → ℕ := fun j => ∏ k ∈ Finset.univ.erase j, (q k).den
  have hD (j : d) : (q j).den * D' j = D :=
    Finset.mul_prod_erase Finset.univ (fun k => (q k).den) (Finset.mem_univ j)
  have hD' (j : d) : (0 : ℝ) < (D' j : ℝ) := by
    exact_mod_cast (Finset.prod_pos fun k _ => (q k).den_pos : 0 < D' j)
  let ξ := fun j => (q j).num * (D' j : ℤ)
  refine ⟨(D : ℝ)⁻¹, ξ, ?_⟩
  ext j
  change (q j : ℝ) = (D : ℝ)⁻¹ * ((ξ j : ℤ) : ℝ)
  have heq : (q j : ℝ) = ((q j).num : ℝ) / ((q j).den : ℝ) := by
    exact_mod_cast (Rat.num_div_den (q j)).symm
  have hdj : (0 : ℝ) < ((q j).den : ℝ) := by exact_mod_cast (q j).den_pos
  rw [heq, ← hD j]
  simp only [ξ, Nat.cast_mul, Int.cast_mul, Int.cast_natCast]
  field_simp [(hD' j).ne', hdj.ne']

/-- A positive form can be approximated by a positive sum of rank-one forms in
integer directions. The number of terms is the dimension of the domain. -/
theorem exists_latticeSum_near_positiveForm (G : MetricForm d)
    (hsym : ∀ v w, G v w = G w v) (hpos : ∀ v, v ≠ 0 → 0 < G v v) {ε : ℝ} (hε : 0 < ε) :
    ∃ (ξ : Fin (Module.finrank ℝ (Cover d)) → d → ℤ)
      (a : Fin (Module.finrank ℝ (Cover d)) → ℝ),
      ‖(∑ i, a i ^ 2 • rankOneForm (latticeVector (ξ i))) - G‖ < ε := by
  let ι := Fin (Module.finrank ℝ (Cover d))
  obtain ⟨z, hz⟩ := exists_sum_rankOneForm G hsym hpos
  let U := {v : ι → Cover d | ‖(∑ i, rankOneForm (v i)) - G‖ < ε}
  have hcont : Continuous (fun v : ι → Cover d => ∑ i, rankOneForm (v i)) :=
    continuous_finsetSum _ (fun i _ => continuous_rankOneForm.comp (continuous_apply i))
  have hU : IsOpen U := isOpen_lt (hcont.sub continuous_const).norm continuous_const
  have hzU : z ∈ U := by
    change ‖(∑ i, rankOneForm (z i)) - G‖ < ε
    rwa [hz, sub_self, norm_zero]
  obtain ⟨q, hq⟩ := (DenseRange.piMap (ι := ι) (fun _ => denseRange_rationalCoverVector (d := d))).exists_mem_open
    hU ⟨z, hzU⟩
  choose a ξ hξ using (fun i => exists_rationalCoverVector_lattice (q i))
  have hsum : (∑ i, rankOneForm (rationalCoverVector (q i))) =
      ∑ i, a i ^ 2 • rankOneForm (latticeVector (ξ i)) := by
    simp_rw [hξ, rankOneForm_smul]
  change ‖(∑ i, rankOneForm (rationalCoverVector (q i))) - G‖ < ε at hq
  exact ⟨ξ, a, hsum ▸ hq⟩

end

end IsometricEmbeddingEndpoints

#print axioms IsometricEmbeddingEndpoints.exists_latticeSum_near_positiveForm
