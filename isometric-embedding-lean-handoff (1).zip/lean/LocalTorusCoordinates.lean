import IntegerDirections
import TorusCirclePairs
import TorusLifts
import Mathlib.Analysis.Calculus.ContDiff.WithLp
import Mathlib.Analysis.SpecialFunctions.SmoothTransition
import Mathlib.Analysis.SpecialFunctions.Trigonometric.InverseDeriv

namespace IsometricEmbeddingEndpoints

open ContinuousLinearMap Filter
open scoped ContDiff Topology

noncomputable section

variable {d : Type*} [Fintype d] [DecidableEq d]

private def torusSin (i : d) : C(UnitAddTorus d, ℝ) :=
  fourierCarrier (Pi.single i 1) (-Complex.I)

private def torusCos (i : d) : C(UnitAddTorus d, ℝ) :=
  fourierCarrier (Pi.single i 1) 1

private theorem phase_coord (i : d) (x : Cover d) :
    integerPhase 1 (Pi.single i 1) x = 2 * Real.pi * x i := by
  rw [integerPhase_eq_linear, Nat.cast_one, mul_one]
  congr 1
  exact twistLinearForm_inl i x

@[simp] private theorem torusSin_lift (i : d) (x : Cover d) :
    torusSin i (flatProjection x) = Real.sin (2 * Real.pi * x i) := by
  simpa only [torusSin, Nat.cast_one, one_mul, phase_coord] using
    fourierCarrier_sin_lift 1 (Pi.single i 1) x

@[simp] private theorem torusCos_lift (i : d) (x : Cover d) :
    torusCos i (flatProjection x) = Real.cos (2 * Real.pi * x i) := by
  simpa only [torusCos, Nat.cast_one, one_mul, phase_coord] using
    fourierCarrier_cos_lift 1 (Pi.single i 1) x

/-- Bounded coordinate map on the flat torus with a smooth right inverse near zero. -/
def torusSineCoordinates (a : ℝ) : C(UnitAddTorus d, Cover d) :=
  ⟨fun t => WithLp.toLp 2 (fun i => a * torusSin i t),
    (PiLp.continuousLinearEquiv 2 ℝ (fun _ : d => ℝ)).symm.continuous.comp
      (continuous_pi fun i => continuous_const.mul (torusSin i).continuous)⟩

@[simp] theorem torusSineCoordinates_lift (a : ℝ) (x : Cover d) (i : d) :
    torusSineCoordinates a (flatProjection x) i = a * Real.sin (2 * Real.pi * x i) := by
  change a * torusSin i (flatProjection x) = _
  rw [torusSin_lift]

theorem contDiff_torusSineCoordinates_lift (a : ℝ) (n : ℕ∞ω) :
    ContDiff ℝ n (fun x : Cover d => torusSineCoordinates a (flatProjection x)) := by
  apply contDiff_piLp' 2
  intro i
  simp only [torusSineCoordinates_lift]
  let L : Cover d →L[ℝ] ℝ := EuclideanSpace.proj i
  have hL : ContDiff ℝ n (fun x : Cover d => x i) := L.contDiff
  exact contDiff_const.mul (contDiff_const.mul hL).sin

theorem torusSineCoordinates_mem_ball {R : ℝ} (hR : 0 < R) (t : UnitAddTorus d) :
    torusSineCoordinates (R / (2 * ((Fintype.card d : ℝ) + 1))) t ∈
      Metric.ball (0 : Cover d) R := by
  obtain ⟨x, rfl⟩ := flatProjection_surjective t
  let n : ℝ := Fintype.card d
  let a := R / (2 * (n + 1))
  have hn : 0 ≤ n := Nat.cast_nonneg _
  have ha : 0 < a := by positivity
  have hRa : R = 2 * (n + 1) * a := by dsimp [a]; field_simp
  rw [Metric.mem_ball, dist_zero_right]
  change ‖torusSineCoordinates a (flatProjection x)‖ < R
  have hsum : ‖torusSineCoordinates a (flatProjection x)‖ ^ 2 ≤ n * a ^ 2 := by
    rw [EuclideanSpace.real_norm_sq_eq]
    calc
      _ ≤ ∑ _ : d, a ^ 2 := by
        apply Finset.sum_le_sum
        intro i _
        rw [torusSineCoordinates_lift, mul_pow]
        have hs : Real.sin (2 * Real.pi * x i) ^ 2 ≤ 1 :=
          (sq_le_one_iff_abs_le_one _).mpr (Real.abs_sin_le_one _)
        simpa using mul_le_mul_of_nonneg_left hs (sq_nonneg a)
      _ = _ := by simp [n]
  have hstrict : n * a ^ 2 < R ^ 2 := by
    rw [hRa]
    have hq : n < (2 * (n + 1)) ^ 2 := by nlinarith [sq_nonneg n]
    nlinarith [mul_lt_mul_of_pos_right hq (sq_pos_of_pos ha)]
  exact (sq_lt_sq₀ (norm_nonneg _) hR.le).mp (hsum.trans_lt hstrict)

/-- Continuous linear dependence of a diagonal operator on its diagonal entries. -/
def diagonalOperator : Cover d →L[ℝ] (Cover d →L[ℝ] Cover d) :=
  ∑ i : d, (EuclideanSpace.proj i).smulRight
    ((EuclideanSpace.proj i).smulRight (EuclideanSpace.single i 1))

@[simp] theorem diagonalOperator_apply (b v : Cover d) (i : d) :
    diagonalOperator b v i = b i * v i := by
  change EuclideanSpace.proj i ((diagonalOperator b) v) = _
  simp only [diagonalOperator, sum_apply, map_sum]
  rw [Finset.sum_eq_single i]
  · simp [EuclideanSpace.single, PiLp.single_apply]
  · intro j _ hji
    simp [EuclideanSpace.single, PiLp.single_apply, hji, Ne.symm hji]
  · simp

private def multCos (a : ℝ) (c : ℝ → ℝ) (hc : Continuous c) :
    C(UnitAddTorus d, Cover d) :=
  ⟨fun t => WithLp.toLp 2 (fun i => a * c (torusCos i t)),
    (PiLp.continuousLinearEquiv 2 ℝ (fun _ : d => ℝ)).symm.continuous.comp
      (continuous_pi fun i => continuous_const.mul (hc.comp (torusCos i).continuous))⟩

@[simp] private theorem multCos_lift (a : ℝ) (c : ℝ → ℝ) (hc : Continuous c)
    (x : Cover d) (i : d) :
    multCos a c hc (flatProjection x) i = a * c (Real.cos (2 * Real.pi * x i)) := by
  change a * c (torusCos i (flatProjection x)) = _
  rw [torusCos_lift]

private theorem contDiff_multCos_lift (a : ℝ) {c : ℝ → ℝ} {n : ℕ∞ω}
    (hc : ContDiff ℝ n c) :
    ContDiff ℝ n (fun x : Cover d => multCos a c hc.continuous (flatProjection x)) := by
  apply contDiff_piLp' 2
  intro i
  simp only [multCos_lift]
  let L : Cover d →L[ℝ] ℝ := EuclideanSpace.proj i
  have hL : ContDiff ℝ n (fun x : Cover d => x i) := L.contDiff
  exact contDiff_const.mul (hc.comp (contDiff_const.mul hL).cos)

/-- The derivative in the flat covering coordinates. -/
def torusSineDifferential (a : ℝ) : C(UnitAddTorus d, Cover d →L[ℝ] Cover d) :=
  ⟨fun t => diagonalOperator (multCos (a * (2 * Real.pi)) id continuous_id t),
    diagonalOperator.continuous.comp (multCos _ _ continuous_id).continuous⟩

@[simp] theorem torusSineDifferential_lift (a : ℝ) (x v : Cover d) (i : d) :
    torusSineDifferential a (flatProjection x) v i =
      a * (2 * Real.pi) * Real.cos (2 * Real.pi * x i) * v i := by
  change diagonalOperator (multCos _ id continuous_id (flatProjection x)) v i = _
  rw [diagonalOperator_apply, multCos_lift, id_eq]

theorem contDiff_torusSineDifferential_lift (a : ℝ) (n : ℕ∞ω) :
    ContDiff ℝ n (fun x : Cover d => torusSineDifferential a (flatProjection x)) := by
  exact (diagonalOperator (d := d)).contDiff.comp
    (contDiff_multCos_lift (a * (2 * Real.pi)) (contDiff_id (n := n)))

set_option maxHeartbeats 450000 in
theorem hasFDerivAt_torusSineCoordinates_lift (a : ℝ) (x : Cover d) :
    HasFDerivAt (fun y => torusSineCoordinates a (flatProjection y))
      (torusSineDifferential a (flatProjection x)) x := by
  let e := PiLp.continuousLinearEquiv 2 ℝ (fun _ : d => ℝ)
  let D := torusSineDifferential a (flatProjection x)
  have h : HasFDerivAt (fun y => e (torusSineCoordinates a (flatProjection y)))
      (e.toContinuousLinearMap.comp D) x := by
    apply hasFDerivAt_pi'.mpr
    intro i
    change HasFDerivAt (fun y => torusSineCoordinates a (flatProjection y) i)
      ((EuclideanSpace.proj i).comp D) x
    have hD : (EuclideanSpace.proj i).comp D =
        a • (Real.cos (2 * Real.pi * x i) • ((2 * Real.pi) • EuclideanSpace.proj i)) := by
      ext v
      change (torusSineDifferential a (flatProjection x) v) i = _
      simp [mul_comm, mul_left_comm, mul_assoc]
    rw [hD]
    simp only [torusSineCoordinates_lift]
    let L : Cover d →L[ℝ] ℝ := EuclideanSpace.proj i
    have hL : HasFDerivAt (fun y : Cover d => y i) L x := L.hasFDerivAt
    exact ((hL.const_mul (2 * Real.pi)).sin.const_mul a)
  have h' := e.symm.toContinuousLinearMap.hasFDerivAt.comp x h
  have hcomp : e.symm.toContinuousLinearMap.comp (e.toContinuousLinearMap.comp D) = D := by
    apply ContinuousLinearMap.ext
    intro v
    exact e.symm_apply_apply (D v)
  simpa [hcomp, Function.comp_def, D] using h'

private def correction (c : ℝ) : ℝ := 1 - Real.smoothTransition (2 * c)

private theorem contDiff_correction (n : ℕ∞) : ContDiff ℝ n correction := by
  have h : ContDiff ℝ n (fun x : ℝ => 2 * x) := contDiff_const.mul contDiff_id
  exact contDiff_const.sub (Real.smoothTransition.contDiff.comp h)

/-- Covers the coordinate directions where the sine map is singular, and vanishes near zero. -/
def torusSineCorrection : C(UnitAddTorus d, Cover d →L[ℝ] Cover d) :=
  ⟨fun t => diagonalOperator (multCos 1 correction (contDiff_correction 0).continuous t),
    diagonalOperator.continuous.comp (multCos 1 correction _).continuous⟩

@[simp] theorem torusSineCorrection_lift (x v : Cover d) (i : d) :
    torusSineCorrection (flatProjection x) v i =
      (1 - Real.smoothTransition (2 * Real.cos (2 * Real.pi * x i))) * v i := by
  change diagonalOperator (multCos 1 correction _ (flatProjection x)) v i = _
  rw [diagonalOperator_apply, multCos_lift, one_mul, correction]

theorem contDiff_torusSineCorrection_lift (n : ℕ∞) :
    ContDiff ℝ n (fun x : Cover d => torusSineCorrection (flatProjection x)) := by
  exact (diagonalOperator (d := d)).contDiff.comp (contDiff_multCos_lift 1 (contDiff_correction n))

theorem eq_zero_of_torusSineDifferential_and_correction {a : ℝ} (ha : 0 < a)
    (t : UnitAddTorus d) {v : Cover d} (hA : torusSineDifferential a t v = 0)
    (hB : torusSineCorrection t v = 0) : v = 0 := by
  obtain ⟨x, rfl⟩ := flatProjection_surjective t
  apply WithLp.ofLp_injective 2
  funext i
  have hAi := congrArg (fun z : Cover d => z i) hA
  have hBi := congrArg (fun z : Cover d => z i) hB
  simp only [torusSineDifferential_lift, PiLp.zero_apply] at hAi
  simp only [torusSineCorrection_lift, PiLp.zero_apply] at hBi
  change v i = 0
  rcases mul_eq_zero.mp hAi with h | h
  · have hp : a * (2 * Real.pi) ≠ 0 := by positivity
    rw [(mul_eq_zero.mp h).resolve_left hp] at hBi
    simpa using hBi
  · exact h

/-- The local inverse in the covering coordinates, using the principal inverse sine. -/
def torusSineSection (a : ℝ) (x : Cover d) : Cover d :=
  WithLp.toLp 2 (fun i => Real.arcsin (x i / a) / (2 * Real.pi))

private theorem abs_coord_div_lt_half {a : ℝ} (ha : 0 < a) {x : Cover d}
    (hx : x ∈ Metric.ball (0 : Cover d) (a / 2)) (i : d) : |x i / a| < 1 / 2 := by
  rw [abs_div, abs_of_pos ha, div_lt_iff₀ ha]
  have h := (PiLp.norm_apply_le x i).trans_lt (by simpa [Metric.mem_ball, dist_zero_right] using hx)
  simpa [Real.norm_eq_abs, div_eq_mul_inv, mul_comm] using h

theorem contDiffAt_torusSineSection {a : ℝ} (ha : 0 < a) {x : Cover d}
    (hx : x ∈ Metric.ball (0 : Cover d) (a / 2)) (n : ℕ∞ω) :
    ContDiffAt ℝ n (torusSineSection a) x := by
  apply contDiffAt_piLp' 2
  intro i
  have h := abs_lt.mp (abs_coord_div_lt_half ha hx i)
  let L : Cover d →L[ℝ] ℝ := EuclideanSpace.proj i
  have hL : ContDiffAt ℝ n (fun y : Cover d => y i / a) x :=
    L.contDiff.contDiffAt.div_const a
  have hA : ContDiffAt ℝ n Real.arcsin (x i / a) :=
    Real.contDiffAt_arcsin (by linarith [h.1]) (by linarith [h.2])
  exact (hA.comp x hL).div_const _

theorem torusSineCoordinates_section {a : ℝ} (ha : 0 < a) {x : Cover d}
    (hx : x ∈ Metric.ball (0 : Cover d) (a / 2)) :
    torusSineCoordinates a (flatProjection (torusSineSection a x)) = x := by
  apply WithLp.ofLp_injective 2
  funext i
  change torusSineCoordinates a (flatProjection (torusSineSection a x)) i = x i
  rw [torusSineCoordinates_lift]
  change a * Real.sin (2 * Real.pi * (Real.arcsin (x i / a) / (2 * Real.pi))) = x i
  have hp : 2 * Real.pi ≠ 0 := by positivity
  rw [← mul_div_assoc, mul_div_cancel_left₀ _ hp]
  have h := abs_lt.mp (abs_coord_div_lt_half ha hx i)
  rw [Real.sin_arcsin (by linarith [h.1]) (by linarith [h.2])]
  rw [← mul_div_assoc, mul_div_cancel_left₀ _ ha.ne']

theorem torusSineCorrection_section {a : ℝ} (ha : 0 < a) {x : Cover d}
    (hx : x ∈ Metric.ball (0 : Cover d) (a / 2)) :
    torusSineCorrection (flatProjection (torusSineSection a x)) = 0 := by
  ext v i
  change torusSineCorrection (flatProjection (torusSineSection a x)) v i = 0
  rw [torusSineCorrection_lift]
  change (1 - Real.smoothTransition (2 * Real.cos
    (2 * Real.pi * (Real.arcsin (x i / a) / (2 * Real.pi))))) * v i = 0
  have hp : 2 * Real.pi ≠ 0 := by positivity
  rw [← mul_div_assoc, mul_div_cancel_left₀ _ hp, Real.cos_arcsin]
  have h := abs_lt.mp (abs_coord_div_lt_half ha hx i)
  have hsq : (1 / 2 : ℝ) ^ 2 ≤ 1 - (x i / a) ^ 2 := by
    nlinarith [mul_nonneg (sub_nonneg.mpr h.2.le) (sub_nonneg.mpr h.1.le)]
  have hs : (1 / 2 : ℝ) ≤ Real.sqrt (1 - (x i / a) ^ 2) := Real.le_sqrt_of_sq_le hsq
  rw [Real.smoothTransition.one_of_one_le (by linarith), sub_self, zero_mul]

theorem torusSineDifferential_section {a : ℝ} (ha : 0 < a) {x : Cover d}
    (hx : x ∈ Metric.ball (0 : Cover d) (a / 2)) :
    (torusSineDifferential a (flatProjection (torusSineSection a x))).comp
      (fderiv ℝ (torusSineSection a) x) = ContinuousLinearMap.id ℝ (Cover d) := by
  have hd := (contDiffAt_torusSineSection ha hx 1).differentiableAt one_ne_zero
  have h := (hasFDerivAt_torusSineCoordinates_lift a (torusSineSection a x)).comp x
    hd.hasFDerivAt
  have he : id =ᶠ[𝓝 x]
      (fun y => torusSineCoordinates a (flatProjection (torusSineSection a y))) := by
    filter_upwards [Metric.isOpen_ball.mem_nhds hx] with y hy
    exact (torusSineCoordinates_section ha hy).symm
  exact (h.congr_of_eventuallyEq he).unique (hasFDerivAt_id x)

end

end IsometricEmbeddingEndpoints

#print axioms IsometricEmbeddingEndpoints.torusSineCoordinates_mem_ball
#print axioms IsometricEmbeddingEndpoints.eq_zero_of_torusSineDifferential_and_correction
#print axioms IsometricEmbeddingEndpoints.torusSineCorrection_section
#print axioms IsometricEmbeddingEndpoints.torusSineDifferential_section
