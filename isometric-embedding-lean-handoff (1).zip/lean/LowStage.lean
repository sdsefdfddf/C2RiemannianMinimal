import ProjectedCirclePairs
import TorusNormalProjection
import RealTorusBernstein

namespace IsometricEmbeddingEndpoints

open ContinuousLinearMap

noncomputable section

variable {d ι H : Type*} [Fintype d] [Fintype ι] [DecidableEq ι]
  [NormedAddCommGroup H] [InnerProductSpace ℝ H] [CompleteSpace H] [FiniteDimensional ℝ H]

private def stageCutoffFactor (ξ : ι → d → ℤ) : ℝ :=
  1 + ∑ i, ‖latticeVector (ξ i)‖

omit [DecidableEq ι] in
private theorem one_le_stageCutoffFactor (ξ : ι → d → ℤ) :
    1 ≤ stageCutoffFactor ξ := by
  unfold stageCutoffFactor
  exact le_add_of_nonneg_right (Finset.sum_nonneg fun _ _ => norm_nonneg _)

omit [DecidableEq ι] in
private theorem stage_carrier_inside (ξ : ι → d → ℤ) {N : ℕ} (hN : 0 < N) (i : ι) :
    ‖(stageCutoffFactor ξ * (N : ℝ))⁻¹ • latticeVector (fun j => (N : ℤ) * ξ i j)‖ < 1 := by
  have hN' : 0 < (N : ℝ) := by exact_mod_cast hN
  have hc : 0 < stageCutoffFactor ξ := zero_lt_one.trans_le (one_le_stageCutoffFactor ξ)
  rw [latticeVector_mul_nat, norm_smul, norm_smul, Real.norm_eq_abs, Real.norm_eq_abs,
    abs_of_nonneg (inv_nonneg.mpr (mul_nonneg hc.le hN'.le)), abs_of_nonneg hN'.le]
  calc
    _ = ‖latticeVector (ξ i)‖ / stageCutoffFactor ξ := by field_simp
    _ < 1 := by
      apply (div_lt_one hc).2
      have h := Finset.single_le_sum (f := fun i => ‖latticeVector (ξ i)‖)
        (fun j _ => norm_nonneg _) (Finset.mem_univ i)
      unfold stageCutoffFactor
      linarith

set_option maxHeartbeats 550000 in
/-- One Fourier-bounded normal correction for a metric increment given in fixed lattice
directions. The initially unused target planes control the quadratic angle error. -/
theorem exists_lowStage (ξ : ι → d → ℤ) {σ M : ℝ} (hσ : 0 < σ) (hM : 0 ≤ M) :
    ∃ c K : ℝ, 1 ≤ c ∧ 0 ≤ K ∧
      ∀ (F F₀ : C(UnitAddTorus d, Cover d →L[ℝ] H))
        (J : PiLp 2 (fun _ : ι => CirclePair) →ₗᵢ[ℝ] H)
        (a : ι → C(UnitAddTorus d, ℝ)) {N : ℕ} {amp Λ L : ℝ},
        0 < N → 0 ≤ amp → amp ≤ 1 → 0 ≤ Λ → Λ ≤ (N : ℝ) →
        0 ≤ L → L ≤ (N : ℝ) →
        ‖F‖ ≤ M → (∀ t v, σ * ‖v‖ ≤ ‖F t v‖) →
        (∀ t z, (F₀ t).adjoint (J z) = 0) →
        ContDiff ℝ 2 (fun z => F (flatProjection z)) →
        (∀ z, ‖fderiv ℝ (fun y => F (flatProjection y)) z‖ ≤ L) →
        (∀ z j, 1 ≤ j → j ≤ 2 →
          ‖iteratedFDeriv ℝ j (fun y => F (flatProjection y)) z‖ ≤ Λ ^ j) →
        (∀ i, ContDiff ℝ 2 (fun z => a i (flatProjection z))) →
        (∀ i z j, j ≤ 2 →
          ‖iteratedFDeriv ℝ j (fun y => a i (flatProjection y)) z‖ ≤ amp * Λ ^ j) →
        ∃ V : C(UnitAddTorus d, H),
          HasFourierSupport (torusCutoffBand (d := d) (c * (N : ℝ)) : Set (d → ℤ)) V ∧
          ‖V‖ ≤ K * amp / (N : ℝ) ∧
          (∀ x, ‖fderiv ℝ (fun z => V (flatProjection z)) x‖ ≤ K * amp) ∧
          ∀ x v w,
            let D := fderiv ℝ (fun z => V (flatProjection z)) x
            let G := F (flatProjection x)
            |inner ℝ ((G + D) v) ((G + D) w) - inner ℝ (G v) (G w) -
              ∑ i, a i (flatProjection x) ^ 2 *
                (inner ℝ (latticeVector (ξ i)) v * inner ℝ (latticeVector (ξ i)) w)| ≤
              (K * (amp ^ 2 * (Λ / (N : ℝ)) ^ 2 + amp * L / (N : ℝ) +
                amp ^ 2 * ‖F - F₀‖ ^ 2)) * (‖v‖ * ‖w‖) := by
  obtain ⟨CW, hCW, hCW'⟩ := exists_torusBlockWave_bounds (H := H) ξ
  obtain ⟨CQ, hCQ, hCQ'⟩ := exists_torusProjection_derivative_bounds (d := d) (H := H) hσ M
  let CF := 4 * CQ * (Fintype.card (ι × Bool) : ℝ) / (2 * Real.pi) *
    (torusCutoffMoment d 1 + (4 * Real.pi) * torusCutoffMoment d 2)
  have hCQ₀ : 0 ≤ CQ := zero_le_one.trans hCQ
  have hCF : 0 ≤ CF := by
    dsimp only [CF]
    have := torusCutoffMoment_nonneg (d := d) 1
    have := torusCutoffMoment_nonneg (d := d) 2
    positivity
  let CA := M * (σ ^ 2)⁻¹ * CW
  have hCA : 0 ≤ CA := by dsimp only [CA]; positivity
  let C := 1 + CW + CQ + CF + CA
  have hC : 1 ≤ C := by dsimp only [C]; linarith
  have hC₀ : 0 ≤ C := zero_le_one.trans hC
  have hC_W : CW ≤ C := by dsimp only [C]; linarith
  have hC_Q : CQ ≤ C := by dsimp only [C]; linarith
  have hC_F : CF ≤ C := by dsimp only [C]; linarith
  have hC_A : CA ≤ C := by dsimp only [C]; linarith
  obtain ⟨K, hK, hstage⟩ := exists_bound_gram_filtered_projection_stage (d := d) (H := H) hC₀
  refine ⟨stageCutoffFactor ξ, K, one_le_stageCutoffFactor ξ, hK, ?_⟩
  intro F F₀ J a N amp Λ L hN hamp hamp₁ hΛ hΛN hL hLN hFN hF hJ hFdiff hDF hFscale hA hAscale
  let s := stageCutoffFactor ξ * (N : ℝ)
  let b := (Λ / (N : ℝ)) ^ 2
  have hN' : 0 < (N : ℝ) := by exact_mod_cast hN
  have hNs : (N : ℝ) ≤ s := by
    dsimp only [s]
    simpa only [one_mul] using mul_le_mul_of_nonneg_right (one_le_stageCutoffFactor ξ) hN'.le
  have hb : 0 ≤ b := sq_nonneg _
  have hb₁ : b ≤ 1 := by
    dsimp only [b]
    have hΛ₁ := (div_le_one hN').2 hΛN
    simpa only [one_pow] using pow_le_pow_left₀ (div_nonneg hΛ hN'.le) hΛ₁ 2
  have hLC : L ≤ C * (N : ℝ) := hLN.trans (by
    simpa only [one_mul] using mul_le_mul_of_nonneg_right hC hN'.le)
  let Q := torusTangentProjection F hσ hF
  let W := torusBlockWave J a N ξ
  obtain ⟨hQderiv, hQscale⟩ := hCQ' F hF Λ hΛ hFN hFdiff hFscale
  have hQdiff : ContDiff ℝ 2 (fun z => Q (flatProjection z)) :=
    contDiff_torusTangentProjection_lift F hσ hF hFdiff
  have hQnormal : ContDiff ℝ 2 (fun z => normalPart (Q (flatProjection z))) :=
    contDiff_const.sub hQdiff
  have hproperties (t : UnitAddTorus d) := tangentProjection_properties (F t) hσ (hF t)
  have ha₀ (i : ι) (t : UnitAddTorus d) : ‖a i t‖ ≤ amp := by
    obtain ⟨z, rfl⟩ := flatProjection_surjective t
    simpa only [norm_iteratedFDeriv_zero, pow_zero, mul_one] using hAscale i z 0 (by norm_num)
  have ha₁ (i : ι) (x : Cover d) :
      ‖fderiv ℝ (fun z => a i (flatProjection z)) x‖ ≤ amp * Λ := by
    simpa only [norm_iteratedFDeriv_one, pow_one] using hAscale i x 1 (by norm_num)
  have hadiff (i : ι) (z : Cover d) := (hA i).differentiable (by norm_num) z
  obtain ⟨hW₀, hDW, hWgram⟩ := hCW' J a hN hamp hΛ hΛN ha₀ hadiff ha₁
  have hangle (x : Cover d) :
      ‖(Q (flatProjection x)).comp (fderiv ℝ (fun z => W (flatProjection z)) x)‖ ≤
        C * amp * ‖F - F₀‖ := by
    let D := fderiv ℝ (fun z => W (flatProjection z)) x
    have horth (v : Cover d) : (F₀ (flatProjection x)).adjoint (D v) = 0 := by
      dsimp only [D, W]
      rw [fderiv_torusBlockWave_lift J a N ξ (fun i => hadiff i x)]
      exact hJ _ _
    calc
      _ ≤ ‖F‖ * (σ ^ 2)⁻¹ * ‖F - F₀‖ * ‖D‖ :=
        norm_torusTangentProjection_comp_le F F₀ hσ hF _ D horth
      _ ≤ M * (σ ^ 2)⁻¹ * ‖F - F₀‖ * (CW * amp) := by
        gcongr
        exact hDW x
      _ = CA * amp * ‖F - F₀‖ := by dsimp only [CA]; ring
      _ ≤ _ := by gcongr
  have hcut (x : Cover d) :=
    norm_fderiv_cutoff_projectedBlockWave_sub_le J a hN ξ Q hNs hΛ hCQ₀ hamp
      (stage_carrier_inside ξ hN) hQnormal hA hQscale hAscale x
  obtain ⟨hV₀, hDV, hgram⟩ := hstage F Q W hN' hNs hamp hamp₁ hb hb₁ hL hLC
    (norm_nonneg (F - F₀)) (hFdiff.of_le (by norm_num)) (hQdiff.of_le (by norm_num))
    (contDiff_torusBlockWave_lift J a N ξ (fun i => (hA i).of_le (by norm_num)))
    (fun t => (hproperties t).1) (fun t => (hproperties t).2.1) (fun t => (hproperties t).2.2)
    hDF (fun x => (hQderiv x).trans (by gcongr; exact hDF x))
    (hW₀.trans (by gcongr)) (fun x => (hDW x).trans (mul_le_mul_of_nonneg_right hC_W hamp))
    hangle (fun x => (hcut x).trans (by change CF * amp * b ≤ _; gcongr))
  refine ⟨realTorusCutoff s (projectedWave Q W), hasFourierSupport_realTorusCutoff (hN'.trans_le hNs) _,
    hV₀, hDV, fun x v w => hgram x _ (fun u y => (hWgram x u y).trans (by gcongr)) v w⟩

end

end IsometricEmbeddingEndpoints

#print axioms IsometricEmbeddingEndpoints.exists_lowStage
