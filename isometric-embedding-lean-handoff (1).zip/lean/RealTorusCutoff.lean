import ConvolutionStage
import ModulatedCutoff
import TorusCutoff

namespace IsometricEmbeddingEndpoints

open MeasureTheory

noncomputable section

variable {d H : Type*} [Fintype d] [NormedAddCommGroup H] [NormedSpace ℝ H] [CompleteSpace H]

/-- Cutoff on real vector-valued torus functions. Integrating translations in the uniform norm
gives a continuous torus function directly. -/
def realTorusCutoff (scale : ℝ) (f : C(UnitAddTorus d, H)) : C(UnitAddTorus d, H) :=
  ∫ y, realCutoffKernel scale y • shiftMap f (flatProjection y)

omit [CompleteSpace H] in
theorem integrable_realTorusCutoff_eval {scale : ℝ} (hs : 0 < scale)
    (f : C(UnitAddTorus d, H)) (x : UnitAddTorus d) :
    Integrable (fun y : Cover d => realCutoffKernel scale y • f (x - flatProjection y)) := by
  simpa only [ContinuousMap.evalCLM_apply, ContinuousMap.smul_apply, shiftMap, ContinuousMap.coe_mk]
    using (ContinuousMap.evalCLM ℝ x).integrable_comp
      (integrable_weighted_shiftMap flatProjection _ (integrable_realCutoffKernel hs) f)

theorem realTorusCutoff_apply {scale : ℝ} (hs : 0 < scale) (f : C(UnitAddTorus d, H))
    (x : UnitAddTorus d) :
    realTorusCutoff scale f x = ∫ y : Cover d, realCutoffKernel scale y • f (x - flatProjection y) := by
  change (ContinuousMap.evalCLM ℝ x) (∫ y, realCutoffKernel scale y • shiftMap f (flatProjection y)) = _
  rw [← (ContinuousMap.evalCLM ℝ x).integral_comp_comm
    (integrable_weighted_shiftMap flatProjection _ (integrable_realCutoffKernel hs) f)]
  rfl

theorem realTorusCutoff_lift_apply {scale : ℝ} (hs : 0 < scale) (f : C(UnitAddTorus d, H))
    (x : Cover d) :
    realTorusCutoff scale f (flatProjection x) =
      ∫ y : Cover d, realCutoffKernel scale y • f (flatProjection (x - y)) := by
  simp only [realTorusCutoff_apply hs, flatProjection_sub]

/-- The cutoff commutes with differentiation of a differentiable torus lift whose
differential also descends to a continuous torus function. -/
theorem hasFDerivAt_realTorusCutoff_lift {scale : ℝ} (hs : 0 < scale)
    (f : C(UnitAddTorus d, H)) (Df : C(UnitAddTorus d, Cover d →L[ℝ] H))
    (hDf : ∀ x : Cover d, HasFDerivAt (fun z => f (flatProjection z)) (Df (flatProjection x)) x)
    (x : Cover d) :
    HasFDerivAt (fun z => realTorusCutoff scale f (flatProjection z))
      (realTorusCutoff scale Df (flatProjection x)) x := by
  have hF := hasFDerivAt_weighted_translate (realCutoffKernel scale)
    (fun z => f (flatProjection z)) (fun z => Df (flatProjection z))
    (M := ‖Df‖) (integrable_realCutoffKernel hs)
    (fun z => by simpa only [flatProjection_sub] using integrable_realTorusCutoff_eval hs f (flatProjection z))
    (fun z => by
      simpa only [flatProjection_sub] using
        (integrable_realTorusCutoff_eval hs Df (flatProjection z)).aestronglyMeasurable)
    hDf (fun z => Df.norm_coe_le_norm (flatProjection z)) x
  simpa only [realTorusCutoff_lift_apply hs] using hF

omit [CompleteSpace H] in
theorem norm_realTorusCutoff_le {scale : ℝ} (hs : 0 < scale) (f : C(UnitAddTorus d, H)) :
    ‖realTorusCutoff scale f‖ ≤ ‖f‖ * ∫ y : Cover d, ‖cutoffKernel unitCutoffSymbol y‖ := by
  calc
    ‖realTorusCutoff scale f‖ ≤ (∫ y : Cover d, ‖realCutoffKernel scale y‖) * ‖f‖ :=
      norm_integral_weighted_shiftMap_le _ _ (integrable_realCutoffKernel hs) _
    _ = _ := by
      have hm := integral_dilatedKernel_norm_rpow (cutoffKernel (unitCutoffSymbol (V := Cover d))) hs 0
      simpa only [norm_realCutoffKernel, neg_zero, Real.rpow_zero, one_mul, mul_one,
        mul_comm _ ‖f‖] using congrArg (· * ‖f‖) hm

/-- Evaluate a real coordinate and regard it as a complex torus function for Fourier analysis. -/
def complexCoordinate (L : H →L[ℝ] ℝ) (f : C(UnitAddTorus d, H)) : C(UnitAddTorus d, ℂ) :=
  ⟨fun x => (L (f x) : ℂ), Complex.continuous_ofReal.comp (L.continuous.comp f.continuous)⟩

theorem complexCoordinate_realTorusCutoff {scale : ℝ} (hs : 0 < scale)
    (L : H →L[ℝ] ℝ) (f : C(UnitAddTorus d, H)) :
    complexCoordinate L (realTorusCutoff scale f) =
      weightedShiftOperator flatProjection (dilatedKernel scale (cutoffKernel unitCutoffSymbol))
        (integrable_dilated_cutoffKernel unitCutoffSymbol hs) (complexCoordinate L f) := by
  ext x
  rw [weightedShiftOperator_apply]
  let Lc := Complex.ofRealCLM.comp L
  change Lc (realTorusCutoff scale f x) = _
  rw [realTorusCutoff_apply hs, ← Lc.integral_comp_comm (integrable_realTorusCutoff_eval hs f x)]
  apply integral_congr_ae
  exact Filter.Eventually.of_forall fun y => by
    dsimp only
    rw [Lc.map_smul, Complex.real_smul, ofReal_realCutoffKernel]
    rfl

theorem complexCoordinate_realTorusCutoff_mem_band {scale : ℝ} (hs : 0 < scale)
    (L : H →L[ℝ] ℝ) (f : C(UnitAddTorus d, H)) :
    complexCoordinate L (realTorusCutoff scale f) ∈
      Submodule.span ℂ (UnitAddTorus.mFourier '' (torusCutoffBand (d := d) scale : Set (d → ℤ))) := by
  rw [complexCoordinate_realTorusCutoff hs]
  exact unitCutoff_mem_band hs _

/-- The uniform error for a Hölder input, including exponent one. -/
theorem norm_realTorusCutoff_sub_le_of_holder {scale α C : ℝ} (hs : 0 < scale)
    (hα : 0 ≤ α) (hα₁ : α ≤ 1) (f : C(UnitAddTorus d, H))
    (hf : ∀ x z : Cover d, ‖f (flatProjection z) - f (flatProjection x)‖ ≤ C * ‖z - x‖ ^ α)
    (x : Cover d) :
    ‖(realTorusCutoff scale f - f) (flatProjection x)‖ ≤
      C * (scale ^ (-α) * ∫ y : Cover d, ‖cutoffKernel unitCutoffSymbol y‖ * ‖y‖ ^ α) := by
  rw [ContinuousMap.sub_apply, realTorusCutoff_lift_apply hs]
  apply norm_realCutoff_error_of_remainder hs hα (hα₁.trans (by norm_num))
    (fun z => f (flatProjection z)) 0 x
  · simpa only [flatProjection_sub] using integrable_realTorusCutoff_eval hs f (flatProjection x)
  · intro y
    have hsub : x - y - x = -y := by abel
    simpa only [hsub, norm_neg, zero_apply, add_zero] using hf x (x - y)

/-- The uniform error for a differentiable input with Hölder gradient. -/
theorem norm_realTorusCutoff_sub_le_of_holderDifferential {scale α C : ℝ} (hs : 0 < scale)
    (hα : 0 ≤ α) (hα₁ : α ≤ 1) (hC : 0 ≤ C) (f : C(UnitAddTorus d, H))
    (Df : Cover d → Cover d →L[ℝ] H)
    (hf : ∀ x, HasFDerivAt (fun z => f (flatProjection z)) (Df x) x)
    (hDf : ∀ x z, ‖Df z - Df x‖ ≤ C * ‖z - x‖ ^ α) (x : Cover d) :
    ‖(realTorusCutoff scale f - f) (flatProjection x)‖ ≤
      C * (scale ^ (-(1 + α)) * ∫ y : Cover d,
        ‖cutoffKernel unitCutoffSymbol y‖ * ‖y‖ ^ (1 + α)) := by
  rw [ContinuousMap.sub_apply, realTorusCutoff_lift_apply hs]
  apply norm_realCutoff_error_of_remainder hs (by linarith) (by linarith)
    (fun z => f (flatProjection z)) (Df x) x
  · simpa only [flatProjection_sub] using integrable_realTorusCutoff_eval hs f (flatProjection x)
  · intro y
    by_cases hy : y = 0
    · subst y
      simp only [sub_zero, sub_self, map_zero, add_zero, norm_zero]
      exact mul_nonneg hC (Real.rpow_nonneg le_rfl _)
    · rw [Real.rpow_add (norm_pos_iff.mpr hy), Real.rpow_one, mul_comm ‖y‖, ← mul_assoc]
      exact
        norm_firstOrderRemainder_le_of_holderDifferential _ Df hf hα hC hDf x y

/-- A real sine or cosine carrier, with any complex phase and magnitude. -/
def fourierCarrier (n : d → ℤ) (c : ℂ) : C(UnitAddTorus d, ℝ) :=
  ⟨fun t => (c * UnitAddTorus.mFourier n t).re,
    Complex.continuous_re.comp (continuous_const.mul (UnitAddTorus.mFourier n).continuous)⟩

/-- The cutoff error for a single carrier times a real amplitude depends on the amplitude's
Taylor remainder, provided the carrier lies inside the plateau. -/
theorem norm_realTorusCutoff_sub_le_of_modulated_remainder
    {scale r C : ℝ} (hs : 0 < scale) (hr : 0 ≤ r) (hr₂ : r ≤ 2) (hC : 0 ≤ C)
    (n : d → ℤ) (hn : ‖scale⁻¹ • latticeVector n‖ < 1) (c : ℂ)
    (A : C(UnitAddTorus d, H)) (B : Cover d →L[ℝ] H) (x : Cover d)
    (hrem : ∀ y, ‖A (flatProjection (x - y)) - A (flatProjection x) + B y‖ ≤ C * ‖y‖ ^ r) :
    let carrier := fourierCarrier n c
    ‖(realTorusCutoff scale (carrier • A) - carrier • A) (flatProjection x)‖ ≤
      C * (‖c‖ * (scale ^ (-r) * ∫ y : Cover d, ‖cutoffKernel unitCutoffSymbol y‖ * ‖y‖ ^ r)) := by
  dsimp only
  let t := flatProjection x
  let phase := c * UnitAddTorus.mFourier n t
  let carrier := fourierCarrier n c
  change ‖(realTorusCutoff scale (carrier • A) - carrier • A) t‖ ≤ _
  have hk (y : Cover d) :
      realCutoffKernel scale y • (carrier • A) (t - flatProjection y) =
        realModulatedKernel scale (latticeVector n) phase y • A (flatProjection (x - y)) := by
    change realCutoffKernel scale y •
      ((c * UnitAddTorus.mFourier n (t - flatProjection y)).re • A (t - flatProjection y)) = _
    rw [smul_smul, flatProjection_sub, realModulatedKernel_apply, mFourier_sub,
      mFourier_neg_flatProjection, ← mul_assoc c]
  have hi : Integrable (fun y => realModulatedKernel scale (latticeVector n) phase y •
      A (flatProjection (x - y))) := by
    simpa only [hk] using integrable_realTorusCutoff_eval hs (carrier • A) t
  rw [ContinuousMap.sub_apply, realTorusCutoff_apply hs]
  simp_rw [hk]
  change ‖(∫ y, realModulatedKernel scale (latticeVector n) phase y • A (flatProjection (x - y))) -
    phase.re • A t‖ ≤ _
  refine (norm_realModulatedCutoff_error_of_remainder hs hr hr₂ hC hn phase
    (fun z => A (flatProjection z)) B x hi hrem).trans ?_
  have hphase : ‖phase‖ ≤ ‖c‖ := by
    rw [show phase = c * UnitAddTorus.mFourier n t from rfl, norm_mul]
    calc
      _ ≤ ‖c‖ * ‖UnitAddTorus.mFourier n‖ :=
        mul_le_mul_of_nonneg_left ((UnitAddTorus.mFourier n).norm_coe_le_norm t) (norm_nonneg _)
      _ = _ := by rw [UnitAddTorus.mFourier_norm, mul_one]
  exact mul_le_mul_of_nonneg_left
    (mul_le_mul_of_nonneg_right hphase (mul_nonneg (Real.rpow_nonneg hs.le _)
      (integral_nonneg fun _ => mul_nonneg (norm_nonneg _) (Real.rpow_nonneg (norm_nonneg _) _)))) hC

end

end IsometricEmbeddingEndpoints

#print axioms IsometricEmbeddingEndpoints.complexCoordinate_realTorusCutoff_mem_band
#print axioms IsometricEmbeddingEndpoints.norm_realTorusCutoff_sub_le_of_holder
#print axioms IsometricEmbeddingEndpoints.norm_realTorusCutoff_sub_le_of_holderDifferential
#print axioms IsometricEmbeddingEndpoints.hasFDerivAt_realTorusCutoff_lift
#print axioms IsometricEmbeddingEndpoints.norm_realTorusCutoff_sub_le_of_modulated_remainder
