import LowStage
import MetricAmplitude
import TorusGram

namespace IsometricEmbeddingEndpoints

open ContinuousLinearMap

noncomputable section

variable {d H : Type*} [Fintype d] [DecidableEq d]
  [NormedAddCommGroup H] [InnerProductSpace ℝ H] [CompleteSpace H] [FiniteDimensional ℝ H]

local instance : NormedAddCommGroup (MetricForm d) := inferInstance
local instance : NormedSpace ℝ (MetricForm d) := inferInstance

set_option maxHeartbeats 500000 in
/-- Correct a metric increment near a positive scalar multiple of the flat metric
in a single target block. The error uses the uniform norm of bilinear forms. -/
theorem exists_metricStage {σ M : ℝ} (hσ : 0 < σ) (hM : 0 ≤ M) :
    ∃ ε δ₀ c K : ℝ, 0 < ε ∧ 0 < δ₀ ∧ 1 ≤ c ∧ 0 ≤ K ∧
      ∀ (F F₀ : C(UnitAddTorus d, Cover d →L[ℝ] H))
        (J : PiLp 2 (fun _ : TwistIndex d => CirclePair) →ₗᵢ[ℝ] H)
        (E : C(UnitAddTorus d, MetricForm d)) {N : ℕ} {δ Λ L : ℝ},
        0 < N → 0 ≤ δ → δ ≤ δ₀ → 0 ≤ Λ → Λ ≤ (N : ℝ) →
        0 ≤ L → L ≤ (N : ℝ) →
        ‖F‖ ≤ M → (∀ t v, σ * ‖v‖ ≤ ‖F t v‖) →
        (∀ t z, (F₀ t).adjoint (J z) = 0) →
        ContDiff ℝ 2 (fun z => F (flatProjection z)) →
        (∀ z, ‖fderiv ℝ (fun y => F (flatProjection y)) z‖ ≤ L) →
        (∀ z j, 1 ≤ j → j ≤ 2 →
          ‖iteratedFDeriv ℝ j (fun y => F (flatProjection y)) z‖ ≤ Λ ^ j) →
        ‖E‖ ≤ ε → (∀ t v w, E t v w = E t w v) →
        ContDiff ℝ 2 (fun z => E (flatProjection z)) →
        (∀ z j, 1 ≤ j → j ≤ 2 →
          ‖iteratedFDeriv ℝ j (fun y => E (flatProjection y)) z‖ ≤ Λ ^ j) →
        ∃ (V : C(UnitAddTorus d, H)) (hV : ContDiff ℝ 1 (fun z => V (flatProjection z))),
          HasFourierSupport (torusCutoffBand (d := d) (c * (N : ℝ)) : Set (d → ℤ)) V ∧
          ‖V‖ ≤ K * √δ / (N : ℝ) ∧
          ‖torusDifferential V hV‖ ≤ K * √δ ∧
          ‖torusGram (F + torusDifferential V hV) - (torusGram F + δ • (flatMetric + E))‖ ≤
            K * (δ * (Λ / (N : ℝ)) ^ 2 + √δ * L / (N : ℝ) + δ * ‖F - F₀‖ ^ 2) := by
  obtain ⟨ε, A, hε, hA, hAmplitude⟩ := exists_metricAmplitudes (d := d)
  obtain ⟨c, K, hc, hK, hstage⟩ := exists_lowStage (H := H) (twistDirection (d := d)) hσ hM
  let δ₀ := ((A + 1)⁻¹) ^ 2
  have hA₁ : 0 < A + 1 := by linarith
  have hδ₀ : 0 < δ₀ := by dsimp only [δ₀]; positivity
  let C := K * (A ^ 2 + A)
  have hC : 0 ≤ C := by dsimp only [C]; positivity
  have hKA : K * A ≤ C := by
    dsimp only [C]
    gcongr
    linarith [sq_nonneg A]
  have hKAA : K * A ^ 2 ≤ C := by
    dsimp only [C]
    gcongr
    linarith
  refine ⟨ε, δ₀, c, C, hε, hδ₀, hc, hC, ?_⟩
  intro F F₀ J E N δ Λ L hN hδ hδsmall hΛ hΛN hL hLN hFN hF hJ hFdiff hDF hFscale
    hE hEsym hEdiff hEscale
  have hN' : 0 < (N : ℝ) := by exact_mod_cast hN
  have hamp : 0 ≤ A * √δ := mul_nonneg hA (Real.sqrt_nonneg _)
  have hamp₁ : A * √δ ≤ 1 := by
    have hsqrt := Real.sqrt_le_sqrt hδsmall
    rw [show √δ₀ = (A + 1)⁻¹ from Real.sqrt_sq (inv_nonneg.mpr hA₁.le)] at hsqrt
    calc
      _ ≤ A * (A + 1)⁻¹ := mul_le_mul_of_nonneg_left hsqrt hA
      _ ≤ 1 := by rw [← div_eq_mul_inv, div_le_one hA₁]; linarith
  obtain ⟨a, ha, hascale, heq⟩ := hAmplitude E hδ hΛ hE hEsym hEdiff hEscale
  obtain ⟨V, hVband, hV₀, hDV, hgram⟩ := hstage F F₀ J a hN hamp hamp₁ hΛ hΛN hL hLN
    hFN hF hJ hFdiff hDF hFscale ha hascale
  let hV := hVband.contDiff_lift (k := 1)
  let D := torusDifferential V hV
  refine ⟨V, hV, hVband, ?_, ?_, ?_⟩
  · exact hV₀.trans (by rw [← mul_assoc]; gcongr)
  · apply (ContinuousMap.norm_le _ (by positivity)).2
    intro t
    obtain ⟨x, rfl⟩ := flatProjection_surjective t
    rw [torusDifferential_apply]
    exact (hDV x).trans (by rw [← mul_assoc]; gcongr)
  · apply norm_torusGram_sub_le_of_pointwise _ _ (by positivity)
    intro t v w
    obtain ⟨x, rfl⟩ := flatProjection_surjective t
    have h := hgram x v w
    dsimp only at h
    rw [heq] at h
    have htarget : ((torusGram F + δ • (flatMetric + E)) : C(UnitAddTorus d, MetricForm d))
        (flatProjection x) v w =
        inner ℝ (F (flatProjection x) v) (F (flatProjection x) w) +
          δ * (inner ℝ v w + E (flatProjection x) v w) := by
      simp only [ContinuousMap.add_apply, ContinuousMap.smul_apply, add_apply, smul_apply,
        smul_eq_mul, torusGram_apply, flatMetric, ContinuousMap.const_apply, innerSL_apply_apply ℝ]
    rw [htarget, ← sub_sub]
    change |inner ℝ ((F (flatProjection x) + D (flatProjection x)) v)
      ((F (flatProjection x) + D (flatProjection x)) w) -
      inner ℝ (F (flatProjection x) v) (F (flatProjection x) w) -
      δ * (inner ℝ v w + E (flatProjection x) v w)| ≤ _
    rw [torusDifferential_apply]
    refine h.trans (mul_le_mul_of_nonneg_right ?_ (by positivity))
    rw [mul_pow, Real.sq_sqrt hδ]
    calc
      _ = (K * A ^ 2) * (δ * (Λ / (N : ℝ)) ^ 2) +
          (K * A) * (√δ * L / (N : ℝ)) + (K * A ^ 2) * (δ * ‖F - F₀‖ ^ 2) := by ring
      _ ≤ C * (δ * (Λ / (N : ℝ)) ^ 2) +
          C * (√δ * L / (N : ℝ)) + C * (δ * ‖F - F₀‖ ^ 2) := by
        gcongr
      _ = _ := by ring

end

end IsometricEmbeddingEndpoints

#print axioms IsometricEmbeddingEndpoints.exists_metricStage
