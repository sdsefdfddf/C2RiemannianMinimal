import MetricStage
import LowIterationMetric

namespace IsometricEmbeddingEndpoints

open ContinuousLinearMap
open scoped Pointwise

noncomputable section

variable {d ι H : Type*} [Fintype d] [DecidableEq d] [Fintype ι] [DecidableEq ι]
  [NormedAddCommGroup H] [InnerProductSpace ℝ H] [CompleteSpace H] [FiniteDimensional ℝ H]

local instance : NormedAddCommGroup (MetricForm d) := inferInstance
local instance : NormedSpace ℝ (MetricForm d) := inferInstance
local instance : FiniteDimensional ℝ (MetricForm d) := inferInstance
local instance : FiniteDimensional ℝ (Cover d →L[ℝ] H) := inferInstance
local instance : NormedAddCommGroup C(UnitAddTorus d, MetricForm d) := inferInstance
local instance : NormedSpace ℝ C(UnitAddTorus d, MetricForm d) := inferInstance

/-- The lattice frequencies within a Euclidean radius. -/
def latticeBall (d : Type*) [Fintype d] (R : ℝ) : Set (d → ℤ) :=
  {k | ‖latticeVector k‖ ≤ R}

theorem latticeBall_mono {R S : ℝ} (h : R ≤ S) : latticeBall d R ⊆ latticeBall d S :=
  fun _ hk => hk.trans h

theorem zero_mem_latticeBall {R : ℝ} (hR : 0 ≤ R) : 0 ∈ latticeBall d R := by
  have h : latticeVector (0 : d → ℤ) = 0 := by ext k; simp [latticeVector]
  change ‖latticeVector (0 : d → ℤ)‖ ≤ R
  simpa only [h, norm_zero] using hR

theorem latticeBall_add_subset (R S : ℝ) :
    latticeBall d R + latticeBall d S ⊆ latticeBall d (R + S) := by
  intro k hk
  obtain ⟨l, hl, m, hm, rfl⟩ := Set.mem_add.1 hk
  have h : latticeVector (l + m) = latticeVector l + latticeVector m := by
    ext i
    simp [latticeVector]
  change ‖latticeVector (l + m)‖ ≤ R + S
  rw [h]
  exact (norm_add_le _ _).trans (add_le_add hl hm)

theorem torusCutoffBand_subset_latticeBall (s : ℝ) :
    (torusCutoffBand (d := d) s : Set (d → ℤ)) ⊆ latticeBall d (2 * s) :=
  fun _ hk => norm_le_of_mem_torusCutoffBand hk

set_option maxHeartbeats 550000 in
/-- Advance the metric defect by one block correction. Frequency bounds alone
give the required coarse derivative bounds, while (L) retains the smaller
first derivative bound for the active block. -/
theorem exists_lowIterationStep {σ M : ℝ} (hσ : 0 < σ) (hM : 0 ≤ M) :
    ∃ ε δmax c A K : ℝ, 0 < ε ∧ 0 < δmax ∧ 1 ≤ c ∧ 1 ≤ A ∧ 0 ≤ K ∧
      ∀ (g G : C(UnitAddTorus d, MetricForm d))
        (F : ι → C(UnitAddTorus d, Cover d →L[ℝ] H))
        (F₀ : C(UnitAddTorus d, Cover d →L[ℝ] H)) (b : ι)
        (J : PiLp 2 (fun _ : TwistIndex d => CirclePair) →ₗᵢ[ℝ] H)
        {N : ℕ} {δ δ' Λ L : ℝ}, 0 < N → 0 < δ → δ ≤ δmax →
        0 < Λ → A * Λ ≤ (N : ℝ) → 0 ≤ L → L ≤ (N : ℝ) →
        ‖F b‖ ≤ M → (∀ t v, σ * ‖v‖ ≤ ‖F b t v‖) →
        (∀ t z, (F₀ t).adjoint (J z) = 0) →
        (∀ k, HasFourierSupport (latticeBall d Λ) (F k)) →
        (∀ z, ‖fderiv ℝ (fun y => F b (flatProjection y)) z‖ ≤ L) →
        HasFourierSupport (latticeBall d (2 * Λ)) G →
        (∀ t v w, G t v w = G t w v) →
        ‖normalizedDefect G (torusBlockGram F) δ δ'‖ ≤ ε →
        ∃ (V : C(UnitAddTorus d, H)) (hV : ContDiff ℝ 1 (fun z => V (flatProjection z))),
          let D := torusDifferential V hV
          HasFourierSupport (latticeBall d (c * (N : ℝ))) V ∧
          HasFourierSupport (latticeBall d (c * (N : ℝ))) D ∧
          ‖V‖ ≤ K * √δ / (N : ℝ) ∧ ‖D‖ ≤ K * √δ ∧
          (∀ z, ‖fderiv ℝ (fun y => D (flatProjection y)) z‖ ≤ K * (N : ℝ) * √δ) ∧
          ‖torusBlockGram (Function.update F b (F b + D)) - (g - δ' • flatMetric)‖ ≤
            K * (δ * (Λ / (N : ℝ)) ^ 2 + √δ * L / (N : ℝ) + δ * ‖F b - F₀‖ ^ 2) + ‖G - g‖ := by
  obtain ⟨ε, δmax, c₀, K₀, hε, hδmax, hc₀, hK₀, hstep⟩ :=
    exists_metricStage (d := d) (H := H) hσ hM
  let C := bernsteinConstant d
  have hC : 0 ≤ C := MeasureTheory.integral_nonneg fun _ => norm_nonneg _
  let c := 2 * c₀
  let A := 1 + 2 * C * (1 + ε + M)
  have hc : 1 ≤ c := by dsimp only [c]; linarith
  have hA : 1 ≤ A := by
    dsimp only [A]
    exact le_add_of_nonneg_right (by positivity)
  let K := K₀ * (1 + A ^ 2 + c * C)
  have hK : 0 ≤ K := by dsimp only [K]; positivity
  have hK₁ : K₀ ≤ K := by
    dsimp only [K]
    calc
      _ = K₀ * 1 := (mul_one _).symm
      _ ≤ _ := mul_le_mul_of_nonneg_left (by linarith [sq_nonneg A, mul_nonneg (zero_le_one.trans hc) hC]) hK₀
  have hK₂ : K₀ * A ^ 2 ≤ K := by
    dsimp only [K]
    exact mul_le_mul_of_nonneg_left (by linarith [mul_nonneg (zero_le_one.trans hc) hC]) hK₀
  have hK₃ : K₀ * (c * C) ≤ K := by
    dsimp only [K]
    exact mul_le_mul_of_nonneg_left (by linarith [sq_nonneg A]) hK₀
  refine ⟨ε, δmax, c, A, K, hε, hδmax, hc, hA, hK, ?_⟩
  intro g G F F₀ b J N δ δ' Λ L hN hδ hδmax' hΛ hΛN hL hLN hFN hF hJ hFband hDF hGband hGsym hE
  let P := torusBlockGram F
  let E := normalizedDefect G P δ δ'
  have hN' : 0 < (N : ℝ) := by exact_mod_cast hN
  have hΛ' : 0 < 2 * Λ := by positivity
  have hAΛ : 0 ≤ A * Λ := by positivity
  have hPband : HasFourierSupport (latticeBall d (2 * Λ)) P :=
    (hasFourierSupport_torusBlockGram F hFband).mono
      (by rw [two_mul]; exact latticeBall_add_subset Λ Λ)
  have hEband : HasFourierSupport (latticeBall d (2 * Λ)) E :=
    hasFourierSupport_normalizedDefect (zero_mem_latticeBall hΛ'.le) G P hGband hPband δ δ'
  have hEsym := normalizedDefect_symmetric G P hGsym (torusBlockGram_symmetric F) δ δ'
  have hFscale (x : Cover d) (j : ℕ) (hj : 1 ≤ j) (_ : j ≤ 2) :
      ‖iteratedFDeriv ℝ j (fun z => F b (flatProjection z)) x‖ ≤ (A * Λ) ^ j := by
    refine ((hFband b).norm_iteratedFDeriv_le_pow hΛ (fun _ hk => hk) hFN x hj).trans ?_
    apply pow_le_pow_left₀ (by positivity)
    calc
      _ = (C * (1 + M)) * Λ := by dsimp only [C]; ring
      _ ≤ _ := by
        apply mul_le_mul_of_nonneg_right _ hΛ.le
        dsimp only [A]
        linarith [mul_nonneg hC hM, mul_nonneg hC hε.le]
  have hEscale (x : Cover d) (j : ℕ) (hj : 1 ≤ j) (_ : j ≤ 2) :
      ‖iteratedFDeriv ℝ j (fun z => E (flatProjection z)) x‖ ≤ (A * Λ) ^ j := by
    refine (hEband.norm_iteratedFDeriv_le_pow hΛ' (fun _ hk => hk) hE x hj).trans ?_
    apply pow_le_pow_left₀ (by positivity)
    calc
      _ = (2 * C * (1 + ε)) * Λ := by dsimp only [C]; ring
      _ ≤ _ := by
        apply mul_le_mul_of_nonneg_right _ hΛ.le
        dsimp only [A]
        linarith [mul_nonneg hC hM]
  obtain ⟨V, hV, hVband, hV₀, hDV, hgram⟩ :=
    hstep (F b) F₀ J E hN hδ.le hδmax' hAΛ hΛN hL hLN hFN hF hJ
      ((hFband b).contDiff_lift) hDF hFscale hE hEsym hEband.contDiff_lift hEscale
  let D := torusDifferential V hV
  let R := c * (N : ℝ)
  have hR : 0 < R := mul_pos (zero_lt_one.trans_le hc) hN'
  have hVband' : HasFourierSupport (latticeBall d R) V :=
    hVband.mono (by
      change _ ⊆ latticeBall d (2 * c₀ * (N : ℝ))
      rw [mul_assoc]
      exact torusCutoffBand_subset_latticeBall _)
  have hDband : HasFourierSupport (latticeBall d R) D := by
    refine hVband'.differential hR (fun k hk => ?_) D (fun x => ?_)
    · rw [norm_smul, Real.norm_eq_abs, abs_of_nonneg (inv_nonneg.mpr hR.le)]
      exact (mul_le_mul_of_nonneg_left hk (inv_nonneg.mpr hR.le)).trans_eq (inv_mul_cancel₀ hR.ne')
    · dsimp only [D]
      rw [torusDifferential_apply]
      exact (hV.differentiable one_ne_zero x).hasFDerivAt
  have hDD (z : Cover d) : ‖fderiv ℝ (fun y => D (flatProjection y)) z‖ ≤ K * (N : ℝ) * √δ := by
    have h := hDband.norm_iteratedFDeriv_lift_le_of_radius hR (fun _ hk => hk) z 1
    rw [norm_iteratedFDeriv_one, pow_one] at h
    calc
      _ ≤ (R * C) * ‖D‖ := h
      _ ≤ (R * C) * (K₀ * √δ) := mul_le_mul_of_nonneg_left hDV (mul_nonneg hR.le hC)
      _ = (K₀ * (c * C)) * (N : ℝ) * √δ := by dsimp only [R]; ring
      _ ≤ _ := by gcongr
  refine ⟨V, hV, hVband', hDband, hV₀.trans (by gcongr),
    hDV.trans (mul_le_mul_of_nonneg_right hK₁ (Real.sqrt_nonneg _)), hDD, ?_⟩
  let error := torusGram (F b + D) - (torusGram (F b) + δ • (flatMetric + E))
  have hlocal : ‖error‖ ≤
      K * (δ * (Λ / (N : ℝ)) ^ 2 + √δ * L / (N : ℝ) + δ * ‖F b - F₀‖ ^ 2) := by
    refine hgram.trans ?_
    calc
      _ = (K₀ * A ^ 2) * (δ * (Λ / (N : ℝ)) ^ 2) +
        K₀ * (√δ * L / (N : ℝ)) + K₀ * (δ * ‖F b - F₀‖ ^ 2) := by ring
      _ ≤ K * (δ * (Λ / (N : ℝ)) ^ 2) +
        K * (√δ * L / (N : ℝ)) + K * (δ * ‖F b - F₀‖ ^ 2) := by gcongr
      _ = _ := by ring
  have heq : torusBlockGram (Function.update F b (F b + D)) - (g - δ' • flatMetric) =
      error + (G - g) := torusBlockGram_next_defect g G F b D hδ.ne'
  calc
    _ = ‖error + (G - g)‖ := congrArg (fun P : C(UnitAddTorus d, MetricForm d) => ‖P‖) heq
    _ ≤ ‖error‖ + ‖G - g‖ := norm_add_le error (G - g)
    _ ≤ _ := add_le_add hlocal le_rfl

end

end IsometricEmbeddingEndpoints

#print axioms IsometricEmbeddingEndpoints.exists_lowIterationStep
