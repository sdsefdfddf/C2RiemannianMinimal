import EmbeddingCoordinates
import Mathlib.Geometry.Manifold.ContMDiff.Defs
import Mathlib.Geometry.Manifold.MFDeriv.NormedSpace
import Mathlib.Topology.Algebra.Group.ContinuousDiv

open scoped ContDiff Manifold

namespace IsometricEmbeddingEndpoints

noncomputable section

variable {d M : Type*} [Fintype d] [TopologicalSpace M] [ChartedSpace (Cover d) M]

local notation "𝕀" => 𝓘(ℝ, Cover d)
local notation "K₀" r:arg => Metric.closedBall (0 : Cover d) r

/-- A positive symmetric field of bilinear forms on an ordinary smooth manifold.
Its regularity is a condition on the coordinate expressions. -/
structure RiemannianMetric (d M : Type*) [Fintype d] [TopologicalSpace M] [ChartedSpace (Cover d) M] where
  form : ∀ p : M, TangentSpace 𝓘(ℝ, Cover d) p →L[ℝ] TangentSpace 𝓘(ℝ, Cover d) p →L[ℝ] ℝ
  symmetric : ∀ p v w, form p v w = form p w v
  positive : ∀ p v, v ≠ 0 → 0 < form p v v

/-- The coordinate expression of the metric is its pullback by the inverse chart. -/
def RiemannianMetric.inChart (g : RiemannianMetric d M)
    (e : OpenPartialHomeomorph M (Cover d)) (x : Cover d) : MetricForm d :=
  pullbackMetricForm (g.form (e.symm x)) (mfderiv 𝕀 𝕀 e.symm x)

/-- A chart translated so that its center maps to zero. -/
def centeredChart (p : M) : OpenPartialHomeomorph M (Cover d) :=
  (chartAt (Cover d) p).transHomeomorph (Homeomorph.subRight (chartAt (Cover d) p p))

section

variable {F : Type*} [NormedAddCommGroup F] [NormedSpace ℝ F]

/-- Hölder regularity of the differential in a neighbourhood of a point of a manifold. -/
def HasLocalHolderDifferentialAt (a : ℝ) (f : M → F) (p : M) : Prop :=
  ∃ r : ℝ, 0 < r ∧ K₀ r ⊆ (centeredChart (d := d) p).target ∧
    HasHolderDifferentialOn a (f ∘ (centeredChart (d := d) p).symm) (K₀ r)

end

/-- A regularity condition on the metric coefficients in a neighbourhood of each
chart center. The closed coordinate ball lies in the chart domain. -/
def RiemannianMetric.locallyInCharts (g : RiemannianMetric d M)
    (P : Set (Cover d) → (Cover d → MetricForm d) → Prop) : Prop :=
  ∀ p, ∃ R : ℝ, 0 < R ∧ K₀ R ⊆ (centeredChart (d := d) p).target ∧
    P (K₀ R) (g.inChart (centeredChart (d := d) p))

/-- At exponent zero we require continuity. At positive exponent we also require
the corresponding Hölder estimate. -/
def HolderMetricCoefficientsOn (a : ℝ) (s : Set (Cover d)) (h : Cover d → MetricForm d) : Prop :=
  ContinuousOn h s ∧ (a = 0 ∨ ∃ C : ℝ, 0 ≤ C ∧ ∀ x ∈ s, ∀ y ∈ s,
    ‖h x - h y‖ ≤ C * ‖x - y‖ ^ a)

abbrev RiemannianMetric.continuousInCharts (g : RiemannianMetric d M) : Prop :=
  g.locallyInCharts (fun s h => ContinuousOn h s)

abbrev RiemannianMetric.holderInCharts (g : RiemannianMetric d M) (a : ℝ) : Prop :=
  g.locallyInCharts (HolderMetricCoefficientsOn a)

abbrev RiemannianMetric.holderDifferentialInCharts (g : RiemannianMetric d M) (a : ℝ) : Prop :=
  g.locallyInCharts (fun s h => HasHolderDifferentialOn a h s)

abbrev RiemannianMetric.contDiffInCharts (g : RiemannianMetric d M) : Prop :=
  g.locallyInCharts (fun s h => ∀ x ∈ s, ContDiffAt ℝ 1 h x)

/-- The pullback of the Euclidean inner product is the given metric. -/
def RiemannianMetric.HasIsometricDifferential {N : ℕ}
    (g : RiemannianMetric d M) (u : M → EuclideanSpace ℝ (Fin N)) : Prop :=
  ∀ p v z, inner ℝ (mvfderiv 𝕀 u p v) (mvfderiv 𝕀 u p z) = g.form p v z

/-- A continuously differentiable embedding with isometric differential. -/
def RiemannianMetric.IsC1IsometricEmbedding {N : ℕ}
    (g : RiemannianMetric d M) (u : M → EuclideanSpace ℝ (Fin N)) : Prop :=
  Topology.IsEmbedding u ∧ ContMDiff 𝕀 𝓘(ℝ, EuclideanSpace ℝ (Fin N)) 1 u ∧
    g.HasIsometricDifferential u

/-- A continuously differentiable isometric embedding with locally Hölder differential. -/
def RiemannianMetric.IsHolderIsometricEmbedding {N : ℕ}
    (g : RiemannianMetric d M) (a : ℝ) (u : M → EuclideanSpace ℝ (Fin N)) : Prop :=
  g.IsC1IsometricEmbedding u ∧ ∀ p, HasLocalHolderDifferentialAt (d := d) a u p

end

end IsometricEmbeddingEndpoints
