import Mathlib.Analysis.Normed.Group.Bounded
import Mathlib.Analysis.Normed.Module.FiniteDimension
import Mathlib.Analysis.Normed.Operator.Bilinear
import Mathlib.Analysis.Normed.Operator.BoundedLinearMaps
import Mathlib.Data.Fintype.Lattice
import Mathlib.Topology.Order.Compact

namespace IsometricEmbeddingEndpoints

noncomputable section

/-- A finite family of positive real numbers has a common positive lower bound. -/
theorem exists_pos_le_of_finite {ι : Type*} [Finite ι] {r : ι → ℝ}
    (hr : ∀ i, 0 < r i) : ∃ R : ℝ, 0 < R ∧ ∀ i, R ≤ r i := by
  cases isEmpty_or_nonempty ι with
  | inl h => exact ⟨1, zero_lt_one, fun i => isEmptyElim i⟩
  | inr h =>
    obtain ⟨i, hi⟩ := Finite.exists_min r
    exact ⟨r i, hr i, hi⟩

variable {X E : Type*} [TopologicalSpace X]
  [NormedAddCommGroup E] [NormedSpace ℝ E] [FiniteDimensional ℝ E]

/-- A positive metric on a compact set remains positive after subtracting a
sufficiently small multiple of a continuous bilinear form. -/
theorem exists_pos_metric_subtraction_on_compact {s : Set X} (hs : IsCompact s)
    (g q : X → E →L[ℝ] E →L[ℝ] ℝ) (hg : ContinuousOn g s) (hq : ContinuousOn q s)
    (hpos : ∀ x ∈ s, ∀ v ≠ 0, 0 < g x v v) :
    ∃ ε : ℝ, 0 < ε ∧ ∀ t : ℝ, 0 ≤ t → t ≤ ε →
      ∀ x ∈ s, ∀ v ≠ 0, 0 < g x v v - t * q x v v := by
  let S := s ×ˢ Metric.sphere (0 : E) 1
  let G := fun p : X × E => g p.1 p.2 p.2
  let Q := fun p : X × E => q p.1 p.2 p.2
  have hS : IsCompact S := hs.prod (isCompact_sphere _ _)
  have hmaps : Set.MapsTo (Prod.fst : X × E → X) S s := fun _ hp => hp.1
  have hEval (m : X → E →L[ℝ] E →L[ℝ] ℝ) (hm : ContinuousOn m s) :
      ContinuousOn (fun p : X × E => m p.1 p.2 p.2) S :=
    ((hm.comp continuous_fst.continuousOn hmaps).clm_apply
      continuous_snd.continuousOn).clm_apply continuous_snd.continuousOn
  have hunit (x : X) (hx : x ∈ s) {v : E} (hv : v ≠ 0) :
      (x, ‖v‖⁻¹ • v) ∈ S := by
    refine ⟨hx, ?_⟩
    rw [Metric.mem_sphere, dist_zero_right, norm_smul, Real.norm_eq_abs,
      abs_of_pos (inv_pos.mpr (norm_pos_iff.mpr hv)), inv_mul_cancel₀ (norm_ne_zero_iff.mpr hv)]
  by_cases hnonempty : S.Nonempty
  · obtain ⟨p, hp, hmin⟩ := hS.exists_isMinOn hnonempty (hEval _ hg)
    have hpNorm : ‖p.2‖ = 1 := by simpa only [Metric.mem_sphere, dist_zero_right] using hp.2
    have hpNe : p.2 ≠ 0 := by intro h; simp [h] at hpNorm
    have hm : 0 < G p := hpos p.1 hp.1 p.2 hpNe
    obtain ⟨B, hB⟩ := hS.exists_bound_of_continuousOn (hEval _ hq)
    let C := max B 0
    have hC : 0 ≤ C := le_max_right _ _
    let ε := G p / (2 * (C + 1))
    have hε : 0 < ε := by dsimp only [ε]; positivity
    have hmargin : ε * C < G p := by
      dsimp only [ε]
      rw [div_mul_eq_mul_div, div_lt_iff₀ (by positivity : 0 < 2 * (C + 1))]
      nlinarith [mul_nonneg hm.le hC]
    refine ⟨ε, hε, fun t ht htε x hx v hv => ?_⟩
    let u := (x, ‖v‖⁻¹ • v)
    have hu : u ∈ S := hunit x hx hv
    have hQu : Q u ≤ C := (le_abs_self _).trans
      (((Real.norm_eq_abs (Q u)) ▸ hB u hu).trans (le_max_left _ _))
    have htu : t * Q u ≤ ε * C :=
      (mul_le_mul_of_nonneg_left hQu ht).trans (mul_le_mul_of_nonneg_right htε hC)
    have hdiff : 0 < G u - t * Q u :=
      sub_pos.mpr (htu.trans_lt (hmargin.trans_le (hmin hu)))
    have heq : G u - t * Q u = (‖v‖⁻¹) ^ 2 * (g x v v - t * q x v v) := by
      simp only [G, Q, u, map_smul, ContinuousLinearMap.smul_apply, smul_eq_mul]
      ring
    rw [heq] at hdiff
    exact pos_of_mul_pos_right hdiff (sq_nonneg _)
  · exact ⟨1, zero_lt_one, fun _ _ _ x hx v hv => (hnonempty ⟨_, hunit x hx hv⟩).elim⟩

end

end IsometricEmbeddingEndpoints

#print axioms IsometricEmbeddingEndpoints.exists_pos_metric_subtraction_on_compact
