import LowStageGeometry
import LocalComposition
import Mathlib.Analysis.Calculus.ContDiff.Comp
import Mathlib.Analysis.Calculus.ContDiff.Operations
import Mathlib.Analysis.Normed.Group.Bounded

namespace IsometricEmbeddingEndpoints

open ContinuousLinearMap
open scoped ContDiff

noncomputable section

variable {X H : Type*} [NormedAddCommGroup X] [InnerProductSpace ℝ X] [CompleteSpace X]
  [NormedAddCommGroup H] [InnerProductSpace ℝ H] [CompleteSpace H] [FiniteDimensional ℝ X]

/-- The tangent projection as a smooth function of the full-rank differential. -/
def tangentProjection (F : X →L[ℝ] H) : H →L[ℝ] H :=
  rangeProjection F (F.adjoint.comp F).inverse

private theorem gram_isInvertible (F : X →L[ℝ] H) {σ : ℝ} (hσ : 0 < σ)
    (hF : ∀ x, σ * ‖x‖ ≤ ‖F x‖) : (F.adjoint.comp F).IsInvertible := by
  obtain ⟨B, hB, _, _⟩ := exists_gramInverse F hσ hF
  let G := F.adjoint.comp F
  have hleft : Function.LeftInverse B G := hB
  exact ⟨(LinearEquiv.ofInjectiveEndo G.toLinearMap hleft.injective).toContinuousLinearEquiv, rfl⟩

theorem contDiffAt_tangentProjection {n : WithTop ℕ∞} {F : X →L[ℝ] H}
    {σ : ℝ} (hσ : 0 < σ) (hF : ∀ x, σ * ‖x‖ ≤ ‖F x‖) :
    ContDiffAt ℝ n tangentProjection F := by
  let A := (ContinuousLinearMap.adjoint (𝕜 := ℝ) (E := X) (F := H)).toContinuousLinearEquiv
  have hA : ContDiff ℝ n (fun G : X →L[ℝ] H => G.adjoint) :=
    A.toContinuousLinearMap.contDiff
  have hG : ContDiff ℝ n (fun G : X →L[ℝ] H => G.adjoint.comp G) :=
    hA.clm_comp contDiff_id
  have hI : ContDiffAt ℝ n (fun B : X →L[ℝ] X => B.inverse) (F.adjoint.comp F) :=
    (gram_isInvertible F hσ hF).contDiffAt_map_inverse
  have hIG : ContDiffAt ℝ n (fun G : X →L[ℝ] H => (G.adjoint.comp G).inverse) F :=
    hI.comp (f := fun G : X →L[ℝ] H => G.adjoint.comp G) F hG.contDiffAt
  exact contDiffAt_id.clm_comp (hIG.clm_comp hA.contDiffAt)

theorem gramInverse_properties (F : X →L[ℝ] H) {σ : ℝ} (hσ : 0 < σ)
    (hF : ∀ x, σ * ‖x‖ ≤ ‖F x‖) :
    let B := (F.adjoint.comp F).inverse
    (∀ x, B (F.adjoint (F x)) = x) ∧
      (∀ x y, inner ℝ (B x) y = inner ℝ x (B y)) ∧
      ‖B‖ ≤ (σ ^ 2)⁻¹ := by
  obtain ⟨B, hleft, hsym, hnorm⟩ := exists_gramInverse F hσ hF
  obtain ⟨e, he⟩ := gram_isInvertible F hσ hF
  have hB : e.symm.toContinuousLinearMap = B := by
    ext x
    change e.symm x = B x
    calc
      _ = B ((F.adjoint.comp F) (e.symm x)) := (hleft (e.symm x)).symm
      _ = _ := by rw [← he, ContinuousLinearEquiv.coe_coe, e.apply_symm_apply]
  have heq : (F.adjoint.comp F).inverse = B := by
    rw [← he, ContinuousLinearMap.inverse_equiv, hB]
  simpa only [heq] using And.intro hleft (And.intro hsym hnorm)

private def fullRankBall (σ M : ℝ) : Set (X →L[ℝ] H) :=
  Metric.closedBall 0 M ∩ ⋂ x : X, {F | σ * ‖x‖ ≤ ‖F x‖}

omit [CompleteSpace X] [CompleteSpace H] [FiniteDimensional ℝ X] in
private theorem mem_fullRankBall {σ M : ℝ} {F : X →L[ℝ] H} :
    F ∈ fullRankBall σ M ↔ ‖F‖ ≤ M ∧ ∀ x, σ * ‖x‖ ≤ ‖F x‖ := by
  simp only [fullRankBall, Set.mem_inter_iff, Set.mem_iInter, Metric.mem_closedBall,
    dist_zero_right, Set.mem_ofPred_eq]

omit [CompleteSpace X] [CompleteSpace H] in
private theorem isCompact_fullRankBall [FiniteDimensional ℝ H] (σ M : ℝ) :
    IsCompact (fullRankBall (X := X) (H := H) σ M) := by
  have hSclosed : IsClosed (fullRankBall (X := X) (H := H) σ M) := by
    exact Metric.isClosed_closedBall.inter (isClosed_iInter fun x =>
      isClosed_le continuous_const (ContinuousLinearMap.apply ℝ H x).continuous.norm)
  exact (isCompact_closedBall (0 : X →L[ℝ] H) M).of_isClosed_subset hSclosed Set.inter_subset_left

/-- On a bounded set with a uniform lower singular-value bound, every fixed derivative
of the tangent projection is uniformly bounded. -/
theorem exists_bound_iteratedFDeriv_tangentProjection [FiniteDimensional ℝ H]
    {σ : ℝ} (hσ : 0 < σ) (M : ℝ) (j : ℕ) :
    ∃ C : ℝ, 0 ≤ C ∧ ∀ F : X →L[ℝ] H, ‖F‖ ≤ M →
      (∀ x, σ * ‖x‖ ≤ ‖F x‖) →
      ‖iteratedFDeriv ℝ j (tangentProjection (X := X) (H := H)) F‖ ≤ C := by
  let S := fullRankBall (X := X) (H := H) σ M
  have hD : ContinuousOn (iteratedFDeriv ℝ j (tangentProjection (X := X) (H := H))) S := by
    intro F hF
    have hl := (mem_fullRankBall.mp hF).2
    exact ((contDiffAt_tangentProjection (n := ∞) hσ hl).continuousAt_iteratedFDeriv
      (by simp)).continuousWithinAt
  obtain ⟨C, hC⟩ := (isCompact_fullRankBall σ M).exists_bound_of_continuousOn hD
  refine ⟨max C 0, le_max_right _ _, fun F hnorm hl => (hC F ?_).trans (le_max_left _ _)⟩
  exact mem_fullRankBall.mpr ⟨hnorm, hl⟩

theorem exists_bound_iteratedFDeriv_tangentProjection_comp {E : Type*}
    [NormedAddCommGroup E] [NormedSpace ℝ E] [FiniteDimensional ℝ H]
    {σ : ℝ} (hσ : 0 < σ) (M : ℝ) (n : ℕ) :
    ∃ C : ℝ, 0 ≤ C ∧ ∀ (F : E → X →L[ℝ] H) (D : ℝ), ContDiff ℝ n F →
      (∀ x, ‖F x‖ ≤ M) → (∀ x v, σ * ‖v‖ ≤ ‖F x v‖) →
      ∀ (x : E) (j : ℕ), j ≤ n →
        (∀ i, 1 ≤ i → i ≤ j → ‖iteratedFDeriv ℝ i F x‖ ≤ D ^ i) →
        ‖iteratedFDeriv ℝ j (fun y => tangentProjection (F y)) x‖ ≤ j.factorial * C * D ^ j := by
  obtain ⟨C, hC, hbound⟩ := exists_uniform_iteratedFDeriv_comp_le (E := E)
    (g := tangentProjection (X := X) (H := H)) (isCompact_fullRankBall σ M) n
    (fun F hF => contDiffAt_tangentProjection hσ (mem_fullRankBall.mp hF).2)
  refine ⟨C, hC, fun F D hF hn hl x j hj hD => hbound F D hF ?_ x j hj hD⟩
  rintro _ ⟨y, rfl⟩
  exact mem_fullRankBall.mpr ⟨hn y, hl y⟩

theorem tangentProjection_properties (F : X →L[ℝ] H) {σ : ℝ} (hσ : 0 < σ)
    (hF : ∀ v, σ * ‖v‖ ≤ ‖F v‖) :
    (∀ v w, inner ℝ (tangentProjection F v) w = inner ℝ v (tangentProjection F w)) ∧
    (∀ v, tangentProjection F (tangentProjection F v) = tangentProjection F v) ∧
    (∀ v, tangentProjection F (F v) = F v) := by
  obtain ⟨hleft, hsym, _⟩ := gramInverse_properties F hσ hF
  exact ⟨rangeProjection_symmetric F _ hsym, rangeProjection_idempotent F _ hleft,
    rangeProjection_apply_range F _ hleft⟩

theorem inner_tangent_normalPart (F : X →L[ℝ] H) {σ : ℝ} (hσ : 0 < σ)
    (hF : ∀ v, σ * ‖v‖ ≤ ‖F v‖) (v : X) (w : H) :
    inner ℝ (F v) (normalPart (tangentProjection F) w) = 0 := by
  obtain ⟨hsym, _, hfix⟩ := tangentProjection_properties F hσ hF
  simp only [normalPart, sub_apply, id_apply, inner_sub_right, ← hsym (F v) w,
    hfix, sub_self]

theorem exists_bound_fderiv_tangentProjection_comp {E : Type*}
    [NormedAddCommGroup E] [NormedSpace ℝ E] [FiniteDimensional ℝ H]
    {σ : ℝ} (hσ : 0 < σ) (M : ℝ) :
    ∃ C : ℝ, 0 ≤ C ∧ ∀ (F : E → X →L[ℝ] H), Differentiable ℝ F →
      (∀ x, ‖F x‖ ≤ M) → (∀ x v, σ * ‖v‖ ≤ ‖F x v‖) → ∀ x,
      ‖fderiv ℝ (fun y => tangentProjection (F y)) x‖ ≤ C * ‖fderiv ℝ F x‖ := by
  obtain ⟨C, hC, hb⟩ := exists_bound_iteratedFDeriv_tangentProjection (X := X) (H := H) hσ M 1
  refine ⟨C, hC, fun F hdiff hnorm hl x => ?_⟩
  have ht : DifferentiableAt ℝ tangentProjection (F x) :=
    (contDiffAt_tangentProjection (n := 1) hσ (hl x)).differentiableAt one_ne_zero
  change ‖fderiv ℝ (tangentProjection ∘ F) x‖ ≤ _
  rw [fderiv_comp x ht (hdiff x)]
  refine (opNorm_comp_le _ _).trans (mul_le_mul_of_nonneg_right ?_ (norm_nonneg _))
  simpa only [norm_iteratedFDeriv_one] using hb (F x) (hnorm x) (hl x)

end

end IsometricEmbeddingEndpoints

#print axioms IsometricEmbeddingEndpoints.gramInverse_properties
#print axioms IsometricEmbeddingEndpoints.exists_bound_iteratedFDeriv_tangentProjection
#print axioms IsometricEmbeddingEndpoints.exists_bound_iteratedFDeriv_tangentProjection_comp
#print axioms IsometricEmbeddingEndpoints.exists_bound_fderiv_tangentProjection_comp
