import LowStageGeometry
import RealTorusCutoff

namespace IsometricEmbeddingEndpoints

open MeasureTheory

noncomputable section

variable {d H : Type*} [Fintype d] [NormedAddCommGroup H] [InnerProductSpace ℝ H] [CompleteSpace H]

/-- The linear metric error of a filtered normal wave is controlled by the derivative
of the old differential. The bound uses the mass norm and first absolute moment
of the unit kernel. -/
theorem abs_inner_fderiv_realTorusCutoff_of_normal {scale L : ℝ} (hs : 0 < scale)
    (F : C(UnitAddTorus d, Cover d →L[ℝ] H)) (DF : Cover d → Cover d →L[ℝ] Cover d →L[ℝ] H)
    (hF : ∀ x, HasFDerivAt (fun z => F (flatProjection z)) (DF x) x)
    (hDF : ∀ x, ‖DF x‖ ≤ L)
    (P : C(UnitAddTorus d, H)) (DP : C(UnitAddTorus d, Cover d →L[ℝ] H))
    (hP : ∀ x, HasFDerivAt (fun z => P (flatProjection z)) (DP (flatProjection x)) x)
    (hn : ∀ t v, inner ℝ (F t v) (P t) = 0) (x v w : Cover d) :
    |inner ℝ (F (flatProjection x) v)
      (fderiv ℝ (fun z => realTorusCutoff scale P (flatProjection z)) x w)| ≤
      ((L * ‖DP‖) * (scale⁻¹ * ∫ y : Cover d, ‖cutoffKernel unitCutoffSymbol y‖ * ‖y‖) +
        (L * ‖P‖) * (∫ y : Cover d, ‖cutoffKernel unitCutoffSymbol y‖)) * (‖v‖ * ‖w‖) := by
  let k := realCutoffKernel (V := Cover d) scale
  let t := flatProjection x
  let u := fun y : Cover d => flatProjection (x - y)
  let D := fderiv ℝ (fun z => realTorusCutoff scale P (flatProjection z)) x
  have hint (Q : C(UnitAddTorus d, Cover d →L[ℝ] H)) :
      Integrable (fun y => k y • Q (u y)) := by
    simpa only [u, flatProjection_sub] using integrable_realTorusCutoff_eval hs Q t
  have hdint (w' : Cover d) : Integrable (fun y => k y • DP (u y) w') := by
    simpa only [ContinuousLinearMap.apply_apply, map_smul, smul_apply] using
      (ContinuousLinearMap.apply ℝ H w').integrable_comp (hint DP)
  have hD (w' : Cover d) : D w' = ∫ y, k y • DP (u y) w' := by
    dsimp only [D]
    rw [(hasFDerivAt_realTorusCutoff_lift hs P DP hP x).fderiv, realTorusCutoff_lift_apply hs,
      ContinuousLinearMap.integral_apply (hint DP)]
    rfl
  have hpair (v' w' : Cover d) :
      Integrable (fun y => k y * inner ℝ (F (u y) v') (DP (u y) w')) := by
    let A : C(UnitAddTorus d, ℝ) :=
      ⟨fun z => inner ℝ (F z v') (DP z w'),
        ((ContinuousLinearMap.apply ℝ H v').continuous.comp F.continuous).inner
          ((ContinuousLinearMap.apply ℝ H w').continuous.comp DP.continuous)⟩
    have h := integrable_realTorusCutoff_eval hs A t
    change Integrable (fun y => k y • A (u y))
    simpa only [u, flatProjection_sub] using h
  have hmass : Integrable (fun y => |k y|) := by
    simpa only [Real.norm_eq_abs] using (integrable_realCutoffKernel (V := Cover d) hs).norm
  have hmoment : Integrable (fun y => |k y| * ‖y‖) := by
    simpa only [Real.norm_eq_abs, Real.rpow_one] using
      integrable_norm_rpow_mul_realCutoffKernel (V := Cover d) hs (r := 1) (by norm_num) (by norm_num)
  have hLip (y : Cover d) : ‖F t - F (u y)‖ ≤ L * ‖y‖ := by
    have hb := (convex_univ (𝕜 := ℝ) (E := Cover d)).norm_image_sub_le_of_norm_hasFDerivWithin_le
      (fun z _ => (hF z).hasFDerivWithinAt) (fun z _ => hDF z)
      (Set.mem_univ (x - y)) (Set.mem_univ x)
    have heq : x - (x - y) = y := by abel
    simpa only [heq, t, u] using hb
  have hpairBound (v' w' y : Cover d) :
      |inner ℝ (F (u y) v') (DP (u y) w')| ≤ (L * ‖P‖) * (‖v'‖ * ‖w'‖) := by
    have hp := (ContinuousLinearMap.apply ℝ H v').hasFDerivAt.comp (x - y) (hF (x - y))
    have heq := inner_deriv_of_normal hp (hP (x - y)) (fun z => hn (flatProjection z) v') w'
    change inner ℝ (F (u y) v') (DP (u y) w') = -inner ℝ (DF (x - y) w' v') (P (u y)) at heq
    rw [heq, abs_neg]
    have hbound : ‖DF (x - y) w' v'‖ ≤ (L * ‖w'‖) * ‖v'‖ := by
      refine (ContinuousLinearMap.le_opNorm _ _).trans (mul_le_mul_of_nonneg_right ?_ (norm_nonneg _))
      exact (ContinuousLinearMap.le_opNorm _ _).trans (mul_le_mul_of_nonneg_right (hDF _) (norm_nonneg _))
    calc
      _ ≤ ‖DF (x - y) w' v'‖ * ‖P (u y)‖ := abs_real_inner_le_norm _ _
      _ ≤ ((L * ‖w'‖) * ‖v'‖) * ‖P‖ :=
        mul_le_mul hbound (P.norm_coe_le_norm _) (norm_nonneg _) ((norm_nonneg _).trans hbound)
      _ = _ := by ring
  have h := abs_weighted_differential_le k norm (F t) D (fun y => F (u y)) (fun y => DP (u y))
    hD hdint hpair hmass hmoment (Filter.Eventually.of_forall hLip)
    (Filter.Eventually.of_forall fun y => DP.norm_coe_le_norm (u y))
    (fun v' w' => Filter.Eventually.of_forall (hpairBound v' w')) v w
  have h₀ : (∫ y : Cover d, |k y|) = ∫ y : Cover d, ‖cutoffKernel unitCutoffSymbol y‖ := by
    simpa only [← Real.norm_eq_abs, k, norm_realCutoffKernel, neg_zero, Real.rpow_zero,
      mul_one, one_mul] using integral_dilatedKernel_norm_rpow
        (cutoffKernel (unitCutoffSymbol (V := Cover d))) hs 0
  have h₁ : (∫ y : Cover d, |k y| * ‖y‖) =
      scale⁻¹ * ∫ y : Cover d, ‖cutoffKernel unitCutoffSymbol y‖ * ‖y‖ := by
    simpa only [← Real.norm_eq_abs, k, norm_realCutoffKernel, Real.rpow_one, Real.rpow_neg_one] using
      integral_dilatedKernel_norm_rpow (cutoffKernel (unitCutoffSymbol (V := Cover d))) hs 1
  rw [h₀, h₁] at h
  exact h

end

end IsometricEmbeddingEndpoints

#print axioms IsometricEmbeddingEndpoints.abs_inner_fderiv_realTorusCutoff_of_normal
