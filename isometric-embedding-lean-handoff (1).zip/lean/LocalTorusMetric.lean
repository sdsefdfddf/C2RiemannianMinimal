import LocalTorusCoordinates
import TorusGram

namespace IsometricEmbeddingEndpoints

open ContinuousLinearMap
open scoped ContDiff

noncomputable section

variable {d : Type*} [Fintype d] [DecidableEq d]

local instance : NormedAddCommGroup (MetricForm d) := inferInstance
local instance : NormedSpace ℝ (MetricForm d) := inferInstance

set_option synthInstance.maxHeartbeats 80000

private theorem Continuous.pullbackForm {X : Type*} [TopologicalSpace X]
    {h : X → MetricForm d} {A : X → Cover d →L[ℝ] Cover d}
    (hh : Continuous h) (hA : Continuous A) :
    Continuous (fun x => pullbackMetricForm (h x) (A x)) :=
  (((compL ℝ (Cover d) (Cover d) ℝ).flip.continuous.comp hA).clm_comp (hh.clm_comp hA))

set_option maxHeartbeats 500000 in
private theorem ContDiff.pullbackForm {X : Type*} [NormedAddCommGroup X] [NormedSpace ℝ X]
    {h : X → MetricForm d} {A : X → Cover d →L[ℝ] Cover d} {n : ℕ∞ω}
    (hh : ContDiff ℝ n h) (hA : ContDiff ℝ n A) :
    ContDiff ℝ n (fun x => pullbackMetricForm (h x) (A x)) := by
  let T := (compL ℝ (Cover d) (Cover d) ℝ).flip
  have hTD := ContinuousLinearMap.contDiff (𝕜 := ℝ) (n := n)
    (E := Cover d →L[ℝ] Cover d) (F := (Cover d →L[ℝ] ℝ) →L[ℝ] Cover d →L[ℝ] ℝ) T
  have hT : ContDiff ℝ n (fun x => T (A x)) := hTD.comp hA
  have hC : ContDiff ℝ n (fun x => (h x).comp (A x)) := hh.clm_comp hA
  exact hT.clm_comp hC

private def chartScale (d : Type*) [Fintype d] (R : ℝ) : ℝ :=
  R / (2 * ((Fintype.card d : ℝ) + 1))

/-- The torus extension of a continuous metric on a coordinate ball. Near the origin,
the sine chart pulls this extension back to the original metric. -/
def localTorusMetric {R : ℝ} (hR : 0 < R) (h : Cover d → MetricForm d)
    (hc : ContinuousOn h (Metric.ball 0 R))
    (hs : ∀ x ∈ Metric.ball 0 R, ∀ v w, h x v w = h x w v)
    (hp : ∀ x ∈ Metric.ball 0 R, ∀ v ≠ 0, 0 < h x v v) : TorusMetric d where
  form :=
    let X := torusSineCoordinates (d := d) (chartScale d R)
    let A := torusSineDifferential (d := d) (chartScale d R)
    let G := torusGram (torusSineCorrection (d := d))
    ⟨fun t => pullbackMetricForm (h (X t)) (A t) + G t,
      ((Continuous.pullbackForm
        (hc.comp_continuous X.continuous (torusSineCoordinates_mem_ball hR)) A.continuous).add
        G.continuous)⟩
  symmetric := by
    intro t v w
    let a := chartScale d R
    have hmem : torusSineCoordinates a t ∈ Metric.ball (0 : Cover d) R :=
      torusSineCoordinates_mem_ball hR t
    simp only [ContinuousMap.coe_mk, add_apply, pullbackMetricForm_apply, torusGram_apply]
    rw [hs _ hmem, real_inner_comm (torusSineCorrection t v)]
  positive := by
    intro t v hv
    let a := chartScale d R
    let X := torusSineCoordinates a t
    let A := torusSineDifferential a t v
    let B := torusSineCorrection t v
    have ha : 0 < a := by dsimp only [a, chartScale]; positivity
    change 0 < h X A A + torusGram (torusSineCorrection (d := d)) t v v
    rw [torusGram_apply]
    change 0 < h X A A + inner ℝ B B
    by_cases hA : A = 0
    · have hB : B ≠ 0 := fun hz => hv (eq_zero_of_torusSineDifferential_and_correction ha t hA hz)
      simpa [hA] using real_inner_self_pos.mpr hB
    · exact add_pos_of_pos_of_nonneg (hp _ (torusSineCoordinates_mem_ball hR t) _ hA)
        real_inner_self_nonneg

/-- The radius of the smaller ball on which the local extension can be pulled back. -/
def localTorusRadius (d : Type*) [Fintype d] (R : ℝ) : ℝ := chartScale d R / 2

theorem localTorusRadius_pos {R : ℝ} (hR : 0 < R) : 0 < localTorusRadius d R := by
  unfold localTorusRadius chartScale
  positivity

/-- The map of covering coordinates used to pull the torus metric back to the original ball. -/
def localTorusChart (R : ℝ) : Cover d → Cover d := torusSineSection (chartScale d R)

theorem contDiffAt_localTorusChart {R : ℝ} (hR : 0 < R) {x : Cover d}
    (hx : x ∈ Metric.ball 0 (localTorusRadius d R)) (n : ℕ∞ω) :
    ContDiffAt ℝ n (localTorusChart R) x :=
  contDiffAt_torusSineSection (by unfold chartScale; positivity) hx n

theorem localTorusMetric_pullback {R : ℝ} (hR : 0 < R) (h : Cover d → MetricForm d)
    (hc : ContinuousOn h (Metric.ball 0 R))
    (hs : ∀ x ∈ Metric.ball 0 R, ∀ v w, h x v w = h x w v)
    (hp : ∀ x ∈ Metric.ball 0 R, ∀ v ≠ 0, 0 < h x v v) {x : Cover d}
    (hx : x ∈ Metric.ball 0 (localTorusRadius d R)) (v w : Cover d) :
    pullbackMetricForm ((localTorusMetric hR h hc hs hp).form
      (flatProjection (localTorusChart R x))) (fderiv ℝ (localTorusChart R) x) v w = h x v w := by
  let a := chartScale d R
  let J := fderiv ℝ (localTorusChart R) x
  let t := flatProjection (localTorusChart R x)
  have ha : 0 < a := by dsimp only [a, chartScale]; positivity
  have hX : torusSineCoordinates a t = x := torusSineCoordinates_section ha hx
  have hB : torusSineCorrection t = 0 := torusSineCorrection_section ha hx
  have hA : (torusSineDifferential a t).comp J = ContinuousLinearMap.id ℝ (Cover d) :=
    torusSineDifferential_section ha hx
  have hAv (z : Cover d) : torusSineDifferential a t (J z) = z := DFunLike.congr_fun hA z
  change (pullbackMetricForm (h (torusSineCoordinates a t)) (torusSineDifferential a t) +
    torusGram (torusSineCorrection (d := d)) t) (J v) (J w) = _
  simp only [add_apply, pullbackMetricForm_apply, torusGram_apply, hX, hB, zero_apply,
    inner_zero_left, add_zero, hAv]

set_option maxHeartbeats 650000 in
theorem contDiff_localTorusMetric_lift {R : ℝ} (hR : 0 < R) (h : Cover d → MetricForm d)
    {n : ℕ∞} (hc : ContDiffOn ℝ n h (Metric.ball 0 R))
    (hs : ∀ x ∈ Metric.ball 0 R, ∀ v w, h x v w = h x w v)
    (hp : ∀ x ∈ Metric.ball 0 R, ∀ v ≠ 0, 0 < h x v v) :
    ContDiff ℝ n (fun x => (localTorusMetric hR h hc.continuousOn hs hp).form (flatProjection x)) := by
  let a := chartScale d R
  have hX : ContDiff ℝ n (fun x : Cover d => h (torusSineCoordinates a (flatProjection x))) := by
    rw [contDiff_iff_contDiffAt]
    intro x
    have hmem := torusSineCoordinates_mem_ball hR (flatProjection x)
    exact (hc.contDiffAt (Metric.isOpen_ball.mem_nhds hmem)).comp x
      (contDiff_torusSineCoordinates_lift a n).contDiffAt
  have hA := contDiff_torusSineDifferential_lift (d := d) a n
  have hB := contDiff_torusSineCorrection_lift (d := d) n
  let P := differentialPairing (d := d) (H := Cover d)
  have hP := ContinuousLinearMap.contDiff (𝕜 := ℝ) (n := n)
    (E := Cover d →L[ℝ] Cover d) (F := (Cover d →L[ℝ] Cover d) →L[ℝ] MetricForm d) P
  have hPB : ContDiff ℝ n (fun x : Cover d => P (torusSineCorrection (flatProjection x))) :=
    hP.comp hB
  have hG : ContDiff ℝ n
      (fun x : Cover d => torusGram (torusSineCorrection (d := d)) (flatProjection x)) :=
    hPB.clm_apply hB
  exact (ContDiff.pullbackForm hX hA).add hG

set_option maxHeartbeats 500000 in
/-- An isometric differential for the torus extension pulls back to an
isometric differential on the smaller ball. -/
theorem localTorusMetric_isometricDifferential {H : Type*}
    [NormedAddCommGroup H] [InnerProductSpace ℝ H]
    {R : ℝ} (hR : 0 < R) (h : Cover d → MetricForm d)
    (hc : ContinuousOn h (Metric.ball 0 R))
    (hs : ∀ x ∈ Metric.ball 0 R, ∀ v w, h x v w = h x w v)
    (hp : ∀ x ∈ Metric.ball 0 R, ∀ v ≠ 0, 0 < h x v v)
    {u : C(UnitAddTorus d, H)} (hu : (localTorusMetric hR h hc hs hp).HasIsometricDifferential u)
    {x : Cover d} (hx : x ∈ Metric.ball 0 (localTorusRadius d R)) (v w : Cover d) :
    inner ℝ (fderiv ℝ (fun y => u (flatProjection (localTorusChart R y))) x v)
      (fderiv ℝ (fun y => u (flatProjection (localTorusChart R y))) x w) = h x v w := by
  have hD := ((hu.1 (localTorusChart R x)).hasFDerivAt.comp x
    ((contDiffAt_localTorusChart hR hx 1).differentiableAt one_ne_zero).hasFDerivAt).fderiv
  rw [Function.comp_def] at hD
  rw [hD, comp_apply, comp_apply, hu.2]
  exact localTorusMetric_pullback hR h hc hs hp hx v w

end

end IsometricEmbeddingEndpoints

#print axioms IsometricEmbeddingEndpoints.localTorusMetric_pullback
#print axioms IsometricEmbeddingEndpoints.contDiff_localTorusMetric_lift
#print axioms IsometricEmbeddingEndpoints.localTorusMetric_isometricDifferential
