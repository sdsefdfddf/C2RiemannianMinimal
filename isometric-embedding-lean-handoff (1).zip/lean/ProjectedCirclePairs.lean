import ProjectedAmplitudes
import TorusCirclePairs

namespace IsometricEmbeddingEndpoints

open ContinuousLinearMap

noncomputable section

variable {d ι H : Type*} [Fintype d] [Fintype ι] [DecidableEq ι]
  [NormedAddCommGroup H] [InnerProductSpace ℝ H] [CompleteSpace H]

/-- The circle-pair correction in a fixed orthogonal family of target planes. -/
def torusBlockWave (J : PiLp 2 (fun _ : ι => CirclePair) →ₗᵢ[ℝ] H)
    (a : ι → C(UnitAddTorus d, ℝ)) (N : ℕ) (ξ : ι → d → ℤ) :
    C(UnitAddTorus d, H) :=
  ⟨fun t => J (scaledTorusCirclePairs a N ξ t),
    J.continuous.comp (scaledTorusCirclePairs a N ξ).continuous⟩

omit [CompleteSpace H] in
theorem fderiv_torusBlockWave_lift (J : PiLp 2 (fun _ : ι => CirclePair) →ₗᵢ[ℝ] H)
    (a : ι → C(UnitAddTorus d, ℝ)) (N : ℕ) (ξ : ι → d → ℤ) {x : Cover d}
    (ha : ∀ i, DifferentiableAt ℝ (fun z => a i (flatProjection z)) x) :
    fderiv ℝ (fun z => torusBlockWave J a N ξ (flatProjection z)) x =
      J.toContinuousLinearMap.comp
        (fderiv ℝ (fun z => scaledTorusCirclePairs a N ξ (flatProjection z)) x) := by
  have hW : DifferentiableAt ℝ (fun z => scaledTorusCirclePairs a N ξ (flatProjection z)) x := by
    rw [scaledTorusCirclePairs_lift]
    let μ := 2 * Real.pi * (N : ℝ)
    simpa only [innerSL_apply_apply ℝ] using
      (hasFDerivAt_circlePairs (fun i => (ha i).hasFDerivAt.const_mul μ⁻¹)
        (fun i => ((innerSL ℝ (latticeVector (ξ i))).hasFDerivAt (x := x)).const_mul μ)).differentiableAt
  exact (J.toContinuousLinearMap.hasFDerivAt.comp x hW.hasFDerivAt).fderiv

private def circleAmplitudeMap (J : PiLp 2 (fun _ : ι => CirclePair) →ₗᵢ[ℝ] H)
    (N : ℕ) (k : ι × Bool) : ℝ →L[ℝ] H :=
  (2 * Real.pi * (N : ℝ))⁻¹ • (ContinuousLinearMap.id ℝ ℝ).smulRight (J (circleCoordinate k))

omit [CompleteSpace H] in
private theorem norm_circleAmplitudeMap (J : PiLp 2 (fun _ : ι => CirclePair) →ₗᵢ[ℝ] H)
    {N : ℕ} (hN : 0 < N) (k : ι × Bool) :
    ‖circleAmplitudeMap J N k‖ = (2 * Real.pi * (N : ℝ))⁻¹ := by
  have hp : 0 ≤ (2 * Real.pi * (N : ℝ))⁻¹ := by positivity
  rw [circleAmplitudeMap, norm_smul, Real.norm_eq_abs, abs_of_nonneg hp, norm_smulRight_apply,
    norm_id, J.norm_map, norm_circleCoordinate, one_mul, mul_one]

private def blockAmplitude (J : PiLp 2 (fun _ : ι => CirclePair) →ₗᵢ[ℝ] H)
    (a : ι → C(UnitAddTorus d, ℝ)) (N : ℕ) (k : ι × Bool) : C(UnitAddTorus d, H) :=
  ⟨circleAmplitudeMap J N k ∘ a k.1, (circleAmplitudeMap J N k).continuous.comp (a k.1).continuous⟩

omit [CompleteSpace H] in
theorem torusBlockWave_eq_sum (J : PiLp 2 (fun _ : ι => CirclePair) →ₗᵢ[ℝ] H)
    (a : ι → C(UnitAddTorus d, ℝ)) (N : ℕ) (ξ : ι → d → ℤ) :
    torusBlockWave J a N ξ =
      ∑ k : ι × Bool, fourierCarrier (fun i => (N : ℤ) * ξ k.1 i)
        (if k.2 then -Complex.I else 1) • blockAmplitude J a N k := by
  ext t
  let μ := (2 * Real.pi * (N : ℝ))
  let carrier := fun k : ι × Bool => fourierCarrier (fun i => (N : ℤ) * ξ k.1 i)
    (if k.2 then -Complex.I else 1)
  change J (ContinuousMap.evalCLM ℝ t (∑ k, carrier k • torusCircleAmplitude (fun i => μ⁻¹ • a i) k)) =
    ContinuousMap.evalCLM ℝ t (∑ k, carrier k • blockAmplitude J a N k)
  rw [map_sum, map_sum, map_sum]
  apply Finset.sum_congr rfl
  intro k _
  change J (carrier k t • ((μ⁻¹ * a k.1 t) • circleCoordinate k)) =
    carrier k t • (μ⁻¹ • (a k.1 t • J (circleCoordinate k)))
  simp only [map_smul J, smul_smul]

omit [CompleteSpace H] in
theorem contDiff_torusBlockWave_lift (J : PiLp 2 (fun _ : ι => CirclePair) →ₗᵢ[ℝ] H)
    (a : ι → C(UnitAddTorus d, ℝ)) (N : ℕ) (ξ : ι → d → ℤ) {k : WithTop ℕ∞}
    (ha : ∀ i, ContDiff ℝ k (fun z => a i (flatProjection z))) :
    ContDiff ℝ k (fun z => torusBlockWave J a N ξ (flatProjection z)) := by
  rw [torusBlockWave_eq_sum]
  have hc := ContDiff.sum (s := (Finset.univ : Finset (ι × Bool))) (fun i _ =>
      (contDiff_fourierCarrier_lift (fun j => (N : ℤ) * ξ i.1 j) (if i.2 then -Complex.I else 1) k).smul
        ((circleAmplitudeMap J N i).contDiff.comp (ha i.1)))
  convert hc using 1
  funext z
  simp only [ContinuousMap.coe_sum, Finset.sum_apply]
  rfl

omit [CompleteSpace H] in
/-- The size, first derivative and Gram error of a circle-pair correction before projection. -/
theorem exists_torusBlockWave_bounds (ξ : ι → d → ℤ) :
    ∃ C : ℝ, 0 ≤ C ∧
      ∀ (J : PiLp 2 (fun _ : ι => CirclePair) →ₗᵢ[ℝ] H)
        (a : ι → C(UnitAddTorus d, ℝ)) {N : ℕ} {amp Λ : ℝ},
        0 < N → 0 ≤ amp → 0 ≤ Λ → Λ ≤ (N : ℝ) →
        (∀ i t, ‖a i t‖ ≤ amp) →
        (∀ i x, DifferentiableAt ℝ (fun z => a i (flatProjection z)) x) →
        (∀ i x, ‖fderiv ℝ (fun z => a i (flatProjection z)) x‖ ≤ amp * Λ) →
        let W := torusBlockWave J a N ξ
        ‖W‖ ≤ C * amp / (N : ℝ) ∧
        (∀ x, ‖fderiv ℝ (fun z => W (flatProjection z)) x‖ ≤ C * amp) ∧
        ∀ x v w,
          let D := fderiv ℝ (fun z => W (flatProjection z)) x
          |inner ℝ (D v) (D w) - ∑ i, a i (flatProjection x) ^ 2 *
            (inner ℝ (latticeVector (ξ i)) v * inner ℝ (latticeVector (ξ i)) w)| ≤
            (C * amp ^ 2 * (Λ / (N : ℝ)) ^ 2) * (‖v‖ * ‖w‖) := by
  let m : ℝ := Fintype.card ι
  let b : ℝ := (2 * Real.pi)⁻¹
  let q := ∑ i, (b ^ 2 + ‖latticeVector (ξ i)‖ ^ 2)
  have hm : 0 ≤ m := by positivity
  have hb : 0 ≤ b := by dsimp [b]; positivity
  let C := √m * b + √q + m * b ^ 2
  have h₀ : 0 ≤ √m * b := mul_nonneg (Real.sqrt_nonneg _) hb
  have h₁ : 0 ≤ √q := Real.sqrt_nonneg _
  have h₂ : 0 ≤ m * b ^ 2 := mul_nonneg hm (sq_nonneg _)
  have hC₀ : √m * b ≤ C := by dsimp [C]; linarith
  have hC₁ : √q ≤ C := by dsimp [C]; linarith
  have hC₂ : m * b ^ 2 ≤ C := by dsimp [C]; linarith
  refine ⟨C, (mul_nonneg (Real.sqrt_nonneg _) hb).trans hC₀, ?_⟩
  intro J a N amp Λ hN hamp hΛ hΛN ha hdiff hA
  let A := fun (i : ι) (x : Cover d) => fderiv ℝ (fun z => a i (flatProjection z)) x
  have hN' : 0 < (N : ℝ) := by exact_mod_cast hN
  have hμ : (2 * Real.pi * (N : ℝ))⁻¹ = b / (N : ℝ) := by rw [mul_inv, div_eq_mul_inv]
  have hbN : 0 ≤ b / (N : ℝ) := div_nonneg hb hN'.le
  have hscaled (i : ι) (x : Cover d) :
      (b / (N : ℝ)) * ‖A i x‖ ≤ b * amp := by
    calc
      _ ≤ (b / (N : ℝ)) * (amp * Λ) := mul_le_mul_of_nonneg_left (hA i x) hbN
      _ ≤ (b / (N : ℝ)) * (amp * (N : ℝ)) := by gcongr
      _ = _ := by field_simp
  have hpoint (x : Cover d) :
      ‖torusBlockWave J a N ξ (flatProjection x)‖ ≤ √m * (b * amp / (N : ℝ)) := by
    rw [← Real.sqrt_sq (div_nonneg (mul_nonneg hb hamp) hN'.le), ← Real.sqrt_mul hm]
    apply Real.le_sqrt_of_sq_le
    change ‖J (scaledTorusCirclePairs a N ξ (flatProjection x))‖ ^ 2 ≤ _
    rw [J.norm_map, norm_scaledTorusCirclePairs_sq, hμ]
    calc
      _ ≤ ∑ _i : ι, (b * amp / (N : ℝ)) ^ 2 := by
        apply Finset.sum_le_sum
        intro i _
        rw [← sq_abs, abs_mul, abs_of_nonneg hbN]
        exact pow_le_pow_left₀ (by positivity) (by
          rw [mul_comm b amp, mul_div_assoc, mul_comm amp]
          exact mul_le_mul_of_nonneg_left (ha i _) hbN) 2
      _ = _ := by simp [m]
  refine ⟨(ContinuousMap.norm_le _ (by positivity)).2 (fun t => ?_), fun x => ?_, fun x v w => ?_⟩
  · obtain ⟨x, rfl⟩ := flatProjection_surjective t
    exact (hpoint x).trans (by rw [← mul_div_assoc, ← mul_assoc]; gcongr)
  · rw [fderiv_torusBlockWave_lift J a N ξ (fun i => hdiff i x)]
    refine (opNorm_le_bound _ (by positivity) (fun v => ?_))
    rw [comp_apply, LinearIsometry.coe_toContinuousLinearMap, J.norm_map]
    refine (le_opNorm _ _).trans (mul_le_mul_of_nonneg_right ?_ (norm_nonneg v))
    refine (norm_fderiv_scaledTorusCirclePairs_le a hN ξ
      (fun i => (hdiff i x).hasFDerivAt)).trans ?_
    rw [hμ]
    calc
      _ ≤ √(q * amp ^ 2) := by
        apply Real.sqrt_le_sqrt
        rw [Finset.sum_mul]
        apply Finset.sum_le_sum
        intro i _
        have hscaledSq := pow_le_pow_left₀ (mul_nonneg hbN (norm_nonneg (A i x))) (hscaled i x) 2
        have haSq := pow_le_pow_left₀ (norm_nonneg (a i (flatProjection x))) (ha i _) 2
        rw [mul_pow, mul_pow] at hscaledSq
        rw [Real.norm_eq_abs, sq_abs] at haSq
        rw [add_mul, mul_comm (‖latticeVector (ξ i)‖ ^ 2)]
        exact add_le_add hscaledSq (mul_le_mul_of_nonneg_right haSq (sq_nonneg _))
      _ = √q * amp := by rw [Real.sqrt_mul' _ (sq_nonneg _), Real.sqrt_sq hamp]
      _ ≤ C * amp := mul_le_mul_of_nonneg_right hC₁ hamp
  · dsimp only
    rw [fderiv_torusBlockWave_lift J a N ξ (fun i => hdiff i x)]
    simp only [comp_apply, LinearIsometry.coe_toContinuousLinearMap, J.inner_map_map]
    refine (abs_gram_scaledTorusCirclePairs_error_le a hN ξ
      (fun i => (hdiff i x).hasFDerivAt) v w).trans ?_
    have hsum : ∑ i, ‖A i x‖ ^ 2 ≤ m * (amp * Λ) ^ 2 := by
      simpa [m] using
        (Finset.sum_le_sum fun i (_ : i ∈ (Finset.univ : Finset ι)) =>
          pow_le_pow_left₀ (norm_nonneg (A i x)) (hA i x) 2)
    rw [hμ]
    calc
      _ ≤ ((b / (N : ℝ)) ^ 2 * (m * (amp * Λ) ^ 2)) * (‖v‖ * ‖w‖) := by gcongr
      _ = (m * b ^ 2 * amp ^ 2 * (Λ / (N : ℝ)) ^ 2) * (‖v‖ * ‖w‖) := by ring
      _ ≤ _ := by gcongr

/-- For the projected circle-pair wave, the differentiated cutoff changes the
differential by the common amplitude size times the squared ratio of the spatial
and carrier frequencies. -/
theorem norm_fderiv_cutoff_projectedBlockWave_sub_le
    (J : PiLp 2 (fun _ : ι => CirclePair) →ₗᵢ[ℝ] H)
    (a : ι → C(UnitAddTorus d, ℝ)) {N : ℕ} (hN : 0 < N) (ξ : ι → d → ℤ)
    (Q : C(UnitAddTorus d, H →L[ℝ] H)) {scale Λ M amp : ℝ}
    (hscale : (N : ℝ) ≤ scale) (hΛ : 0 ≤ Λ) (hM : 0 ≤ M) (hamp : 0 ≤ amp)
    (hband : ∀ i, ‖scale⁻¹ • latticeVector (fun j => (N : ℤ) * ξ i j)‖ < 1)
    (hQ : ContDiff ℝ 2 (fun z => normalPart (Q (flatProjection z))))
    (hA : ∀ i, ContDiff ℝ 2 (fun z => a i (flatProjection z)))
    (hQ' : ∀ x j, j ≤ 2 →
      ‖iteratedFDeriv ℝ j (fun z => normalPart (Q (flatProjection z))) x‖ ≤ M * Λ ^ j)
    (hA' : ∀ i x j, j ≤ 2 → ‖iteratedFDeriv ℝ j (fun z => a i (flatProjection z)) x‖ ≤ amp * Λ ^ j)
    (x : Cover d) :
    let V := projectedWave Q (torusBlockWave J a N ξ)
    ‖fderiv ℝ (fun z => realTorusCutoff scale V (flatProjection z)) x -
      fderiv ℝ (fun z => V (flatProjection z)) x‖ ≤
        (4 * M * (Fintype.card (ι × Bool) : ℝ) / (2 * Real.pi) *
          (torusCutoffMoment d 1 + (4 * Real.pi) * torusCutoffMoment d 2)) *
          amp * (Λ / (N : ℝ)) ^ 2 := by
  dsimp only
  rw [torusBlockWave_eq_sum]
  let μ := 2 * Real.pi * (N : ℝ)
  let p := fun k : ι × Bool => if k.2 then -Complex.I else 1
  have hN' : 0 < (N : ℝ) := by exact_mod_cast hN
  have hs := hN'.trans_le hscale
  have hμ : 0 < μ := by dsimp [μ]; positivity
  have hnorm (k : ι × Bool) : ‖p k‖ = 1 := by
    obtain ⟨i, b⟩ := k
    cases b <;> simp [p]
  have hAderiv (k : ι × Bool) (y : Cover d) (j : ℕ) (hj : j ≤ 2) :
      ‖iteratedFDeriv ℝ j (fun z => blockAmplitude J a N k (flatProjection z)) y‖ ≤
        (μ⁻¹ * amp) * Λ ^ j := by
    have hj' : (j : WithTop ℕ∞) ≤ 2 := by exact_mod_cast hj
    change ‖iteratedFDeriv ℝ j
      (circleAmplitudeMap J N k ∘ fun z => a k.1 (flatProjection z)) y‖ ≤ _
    refine ((circleAmplitudeMap J N k).norm_iteratedFDeriv_comp_left (hA k.1).contDiffAt hj').trans ?_
    rw [norm_circleAmplitudeMap J hN k]
    change μ⁻¹ * ‖iteratedFDeriv ℝ j (fun z => a k.1 (flatProjection z)) y‖ ≤
      (μ⁻¹ * amp) * Λ ^ j
    rw [mul_assoc μ⁻¹ amp]
    exact mul_le_mul_of_nonneg_left (hA' k.1 y j hj) (inv_nonneg.mpr hμ.le)
  refine (norm_fderiv_cutoff_projectedWave_sub_le_of_carriers hs hΛ hM Finset.univ
    (fun k : ι × Bool => fun j => (N : ℤ) * ξ k.1 j) p (fun _ => μ⁻¹ * amp) Q
    (blockAmplitude J a N) (fun k _ => hband k.1) (fun _ _ => mul_nonneg (inv_nonneg.mpr hμ.le) hamp)
    hQ (fun k _ => (circleAmplitudeMap J N k).contDiff.comp (hA k.1))
    hQ' (fun k _ => hAderiv k) x).trans ?_
  have hmoment : 0 ≤ torusCutoffMoment d 1 + (4 * Real.pi) * torusCutoffMoment d 2 :=
    add_nonneg (torusCutoffMoment_nonneg 1)
      (mul_nonneg (by positivity) (torusCutoffMoment_nonneg 2))
  calc
    _ = 4 * M * ((Fintype.card (ι × Bool) : ℝ) * (μ⁻¹ * amp)) * Λ ^ 2 * scale⁻¹ *
        (torusCutoffMoment d 1 + (4 * Real.pi) * torusCutoffMoment d 2) := by
      simp only [hnorm, mul_one, Finset.sum_const, Finset.card_univ, nsmul_eq_mul]
    _ ≤ 4 * M * ((Fintype.card (ι × Bool) : ℝ) * (μ⁻¹ * amp)) * Λ ^ 2 * (N : ℝ)⁻¹ *
        (torusCutoffMoment d 1 + (4 * Real.pi) * torusCutoffMoment d 2) :=
      mul_le_mul_of_nonneg_right (mul_le_mul_of_nonneg_left (inv_anti₀ hN' hscale) (by positivity)) hmoment
    _ = _ := by dsimp only [μ]; ring

end

end IsometricEmbeddingEndpoints

#print axioms IsometricEmbeddingEndpoints.norm_fderiv_cutoff_projectedBlockWave_sub_le
#print axioms IsometricEmbeddingEndpoints.exists_torusBlockWave_bounds
