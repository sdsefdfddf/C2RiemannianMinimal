import RealTorusBernstein
import TorusLifts

namespace IsometricEmbeddingEndpoints

open Filter MeasureTheory
open scoped Topology

noncomputable section

variable {d H : Type*} [Fintype d] [NormedAddCommGroup H] [NormedSpace ℝ H] [CompleteSpace H]

omit [NormedSpace ℝ H] [CompleteSpace H] in
private theorem exists_shiftMap_bound (f : C(UnitAddTorus d, H)) {ε : ℝ} (hε : 0 < ε) :
    ∃ B : ℝ, 0 ≤ B ∧ ∀ y : Cover d, ‖shiftMap f (flatProjection y) - f‖ ≤ ε + B * ‖y‖ := by
  have hzero : flatProjection (0 : Cover d) = 0 := by
    simpa only [sub_self] using flatProjection_sub (0 : Cover d) 0
  have hshift : shiftMap f (flatProjection (0 : Cover d)) = f := by
    rw [hzero]
    ext x
    exact congrArg f (sub_zero x)
  obtain ⟨ρ, hρ, hclose⟩ := Metric.continuousAt_iff.mp
    (continuous_shiftMap flatProjection f).continuousAt ε hε
  let B := 2 * ‖f‖ / ρ
  have hB : 0 ≤ B := by dsimp only [B]; positivity
  refine ⟨B, hB, fun y => ?_⟩
  by_cases hy : ‖y‖ < ρ
  · have h := hclose (show dist y 0 < ρ by rwa [dist_zero_right])
    rw [hshift, dist_eq_norm] at h
    exact h.le.trans (le_add_of_nonneg_right (mul_nonneg hB (norm_nonneg _)))
  · calc
      _ ≤ ‖shiftMap f (flatProjection y)‖ + ‖f‖ := norm_sub_le _ _
      _ ≤ ‖f‖ + ‖f‖ := add_le_add (norm_shiftMap_le f (flatProjection y)) le_rfl
      _ = B * ρ := by dsimp only [B]; field_simp; ring
      _ ≤ B * ‖y‖ := mul_le_mul_of_nonneg_left (le_of_not_gt hy) hB
      _ ≤ _ := le_add_of_nonneg_left hε.le

/-- Fourier truncation converges uniformly even when the function is only continuous. -/
theorem tendsto_realTorusCutoff (f : C(UnitAddTorus d, H)) :
    Tendsto (fun s : ℝ => realTorusCutoff s f) atTop (𝓝 f) := by
  let K := cutoffKernel (unitCutoffSymbol (V := Cover d))
  let M₀ : ℝ := ∫ y : Cover d, ‖K y‖
  let M₁ : ℝ := ∫ y : Cover d, ‖K y‖ * ‖y‖
  have hM₀ : 0 ≤ M₀ := integral_nonneg fun _ => norm_nonneg _
  have hM₁ : 0 ≤ M₁ := integral_nonneg fun _ => mul_nonneg (norm_nonneg _) (norm_nonneg _)
  apply Metric.tendsto_nhds.2
  intro ε hε
  let ε₀ := ε / (2 * (M₀ + 1))
  have hε₀ : 0 < ε₀ := by dsimp only [ε₀]; positivity
  obtain ⟨B, hB, hshift⟩ := exists_shiftMap_bound f hε₀
  let R := 1 + 2 * B * M₁ / ε
  have hR : 0 < R := by dsimp only [R]; positivity
  filter_upwards [eventually_ge_atTop R] with s hs
  have hs₀ : 0 < s := hR.trans_le hs
  let k := realCutoffKernel (V := Cover d) s
  have hk : Integrable k := integrable_realCutoffKernel hs₀
  have hmoment : Integrable (fun y : Cover d => ‖k y‖ * ‖y‖) := by
    simpa only [Real.rpow_one, k] using
      integrable_norm_rpow_mul_realCutoffKernel (V := Cover d) hs₀ (r := 1) (by norm_num) (by norm_num)
  have hint₀ : (∫ y : Cover d, ‖k y‖) = M₀ := by
    simpa only [K, M₀, k, norm_realCutoffKernel, Real.rpow_zero, neg_zero, one_mul, mul_one] using
      integral_dilatedKernel_norm_rpow (cutoffKernel (unitCutoffSymbol (V := Cover d))) hs₀ 0
  have hint₁ : (∫ y : Cover d, ‖k y‖ * ‖y‖) = s⁻¹ * M₁ := by
    simpa only [K, M₁, k, norm_realCutoffKernel, Real.rpow_one, Real.rpow_neg hs₀.le, inv_pow, pow_one] using
      integral_dilatedKernel_norm_rpow (cutoffKernel (unitCutoffSymbol (V := Cover d))) hs₀ 1
  have hsum : Integrable (fun y : Cover d => (ε₀ + B * ‖y‖) * ‖k y‖) := by
    convert (hk.norm.const_mul ε₀).add (hmoment.const_mul B) using 1
    funext y
    change _ = ε₀ * ‖k y‖ + B * (‖k y‖ * ‖y‖)
    ring
  rw [dist_eq_norm, realTorusCutoff]
  have heq : (∫ y : Cover d, k y • shiftMap f (flatProjection y)) - f =
      ∫ y : Cover d, k y • (shiftMap f (flatProjection y) - f) := by
    simpa only [smul_zero, integral_zero, one_smul, add_zero] using
      weighted_sub_mass_eq_remainder k (fun y => shiftMap f (flatProjection y)) (fun _ => 0) f
        hk (integrable_weighted_shiftMap flatProjection k hk f) (by simp)
        (realCutoffKernel_mass hs₀) (by simp)
  change ‖(∫ y : Cover d, k y • shiftMap f (flatProjection y)) - f‖ < ε
  rw [heq]
  calc
    _ ≤ ∫ y : Cover d, (ε₀ + B * ‖y‖) * ‖k y‖ := by
      apply norm_integral_le_of_norm_le hsum
      filter_upwards with y
      rw [norm_smul, mul_comm]
      exact mul_le_mul_of_nonneg_right (hshift y) (norm_nonneg _)
    _ = ε₀ * M₀ + B * (s⁻¹ * M₁) := by
      calc
        _ = ∫ y : Cover d, ε₀ * ‖k y‖ + B * (‖k y‖ * ‖y‖) :=
          integral_congr_ae (Eventually.of_forall fun _ => by ring)
        _ = _ := by
          rw [integral_add (hk.norm.const_mul ε₀) (hmoment.const_mul B),
            integral_const_mul, integral_const_mul, hint₀, hint₁]
    _ < ε := by
      have hfirst : ε₀ * M₀ < ε / 2 := by
        dsimp only [ε₀]
        rw [div_mul_eq_mul_div, div_lt_iff₀ (show 0 < 2 * (M₀ + 1) by positivity)]
        linarith
      have hsecond : B * (s⁻¹ * M₁) ≤ ε / 2 := by
        have hle : 2 * B * M₁ / ε ≤ s := (le_add_of_nonneg_left zero_le_one).trans hs
        have hle' := (div_le_iff₀ hε).1 hle
        rw [show B * (s⁻¹ * M₁) = (B * M₁) / s by ring, div_le_iff₀ hs₀]
        linarith
      linarith

theorem torusDifferential_realTorusCutoff {s : ℝ} (hs : 0 < s)
    (f : C(UnitAddTorus d, H)) (hf : ContDiff ℝ 1 (fun x => f (flatProjection x)))
    (hS : ContDiff ℝ 1 (fun x => realTorusCutoff s f (flatProjection x))) :
    torusDifferential (realTorusCutoff s f) hS = realTorusCutoff s (torusDifferential f hf) := by
  ext t v
  obtain ⟨x, rfl⟩ := flatProjection_surjective t
  rw [torusDifferential_apply]
  have hderiv (y : Cover d) :
      HasFDerivAt (fun z => f (flatProjection z)) (torusDifferential f hf (flatProjection y)) y := by
    rw [torusDifferential_apply]
    exact (hf.differentiable one_ne_zero y).hasFDerivAt
  rw [(hasFDerivAt_realTorusCutoff_lift hs f (torusDifferential f hf) hderiv x).fderiv]

end

end IsometricEmbeddingEndpoints

#print axioms IsometricEmbeddingEndpoints.tendsto_realTorusCutoff
