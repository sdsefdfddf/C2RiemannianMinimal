import TorusGram

namespace IsometricEmbeddingEndpoints

open Filter ContinuousLinearMap
open scoped Topology

noncomputable section

variable {d ι : Type*} [Fintype d] [Fintype ι]

local instance : NormedAddCommGroup (MetricForm d) := inferInstance
local instance : NormedSpace ℝ (MetricForm d) := inferInstance

/-- The rank-one quadratic form defined by pairing with a vector. -/
def rankOneForm (z : Cover d) : MetricForm d :=
  (innerSL ℝ z).smulRight (innerSL ℝ z)

@[simp] theorem rankOneForm_apply (z u v : Cover d) :
    rankOneForm z u v = inner ℝ z u * inner ℝ z v := rfl

theorem rankOneForm_smul (r : ℝ) (z : Cover d) :
    rankOneForm (r • z) = r ^ 2 • rankOneForm z := by
  ext u v
  simp only [rankOneForm_apply, real_inner_smul_left, smul_apply, smul_eq_mul]
  ring

theorem continuous_rankOneForm : Continuous (rankOneForm (d := d)) := by
  let A := innerSL ℝ (E := Cover d)
  change Continuous (fun z => (smulRightL ℝ (Cover d) (Cover d →L[ℝ] ℝ) (A z)) (A z))
  exact ((smulRightL ℝ _ _).continuous.comp A.continuous).clm_apply A.continuous

private def rankOneTerm (z : Cover d) : C(UnitAddTorus d, ℝ) →L[ℝ] C(UnitAddTorus d, MetricForm d) :=
  ContinuousLinearMap.compLeftContinuous ℝ (UnitAddTorus d)
    ((ContinuousLinearMap.id ℝ ℝ).smulRight (rankOneForm z))

/-- A metric written as squared amplitudes in fixed integer directions. -/
def torusLatticeMetric (ξ : ι → d → ℤ) (a : ι → C(UnitAddTorus d, ℝ)) :
    C(UnitAddTorus d, MetricForm d) :=
  ∑ i, rankOneTerm (latticeVector (ξ i)) ((a i) ^ 2)

@[simp] theorem torusLatticeMetric_apply (ξ : ι → d → ℤ) (a : ι → C(UnitAddTorus d, ℝ))
    (t : UnitAddTorus d) (u v : Cover d) :
    torusLatticeMetric ξ a t u v =
      ∑ i, a i t ^ 2 * (inner ℝ (latticeVector (ξ i)) u * inner ℝ (latticeVector (ξ i)) v) := by
  simp only [torusLatticeMetric, ContinuousMap.coe_sum, Finset.sum_apply, sum_apply]
  exact Finset.sum_congr rfl fun i _ => rfl

theorem torusLatticeMetric_symmetric (ξ : ι → d → ℤ) (a : ι → C(UnitAddTorus d, ℝ))
    (t : UnitAddTorus d) (v w : Cover d) :
    torusLatticeMetric ξ a t v w = torusLatticeMetric ξ a t w v := by
  rw [torusLatticeMetric_apply, torusLatticeMetric_apply]
  exact Finset.sum_congr rfl fun _ _ => congrArg (_ * ·) (mul_comm _ _)

theorem tendsto_torusLatticeMetric {S : Type*} {l : Filter S} (ξ : ι → d → ℤ)
    (a : ι → C(UnitAddTorus d, ℝ)) (b : S → ι → C(UnitAddTorus d, ℝ))
    (hb : ∀ i, Tendsto (fun s => b s i) l (𝓝 (a i))) :
    Tendsto (fun s => torusLatticeMetric ξ (b s)) l (𝓝 (torusLatticeMetric ξ a)) := by
  unfold torusLatticeMetric
  exact tendsto_finsetSum Finset.univ (fun i _ =>
    ((rankOneTerm (latticeVector (ξ i))).continuous.tendsto _).comp ((hb i).pow 2))

end

end IsometricEmbeddingEndpoints

#print axioms IsometricEmbeddingEndpoints.torusLatticeMetric_apply
