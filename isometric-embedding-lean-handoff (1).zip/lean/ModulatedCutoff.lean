import RealCutoff
import Mathlib.Tactic.Ring

namespace IsometricEmbeddingEndpoints

open MeasureTheory

noncomputable section

variable {V : Type*} [NormedAddCommGroup V] [InnerProductSpace ℝ V] [FiniteDimensional ℝ V]
  [MeasurableSpace V] [BorelSpace V]

private def modulatedKernel (scale : ℝ) (ξ : V) (phase : ℂ) (y : V) : ℂ :=
  phase * (negativeCarrier ξ y * (realCutoffKernel scale y : ℂ))

/-- The real-part kernel handles both sine and cosine carriers by varying the phase. -/
def realModulatedKernel (scale : ℝ) (ξ : V) (phase : ℂ) (y : V) : ℝ :=
  (modulatedKernel scale ξ phase y).re

theorem realModulatedKernel_apply (scale : ℝ) (ξ : V) (phase : ℂ) (y : V) :
    realModulatedKernel scale ξ phase y =
      realCutoffKernel scale y * (phase * negativeCarrier ξ y).re := by
  rw [realModulatedKernel, modulatedKernel, ← mul_assoc]
  simp only [Complex.mul_re, Complex.ofReal_re, Complex.ofReal_im, mul_zero, sub_zero]
  ring

private theorem continuous_modulatedKernel (scale : ℝ) (ξ : V) (phase : ℂ) :
    Continuous (modulatedKernel scale ξ phase) := by
  have hc : Continuous (negativeCarrier ξ) := by
    exact continuous_subtype_val.comp
      (Real.continuous_fourierChar.comp ((innerSLFlip ℝ ξ).continuous.neg))
  exact continuous_const.mul (hc.mul (Complex.continuous_ofReal.comp
    (continuous_realCutoffKernel scale)))

private theorem norm_modulatedKernel (scale : ℝ) (ξ : V) (phase : ℂ) (y : V) :
    ‖modulatedKernel scale ξ phase y‖ = ‖phase‖ * ‖realCutoffKernel scale y‖ := by
  simp [modulatedKernel, negativeCarrier]

private theorem norm_realModulatedKernel_le (scale : ℝ) (ξ : V) (phase : ℂ) (y : V) :
    ‖realModulatedKernel scale ξ phase y‖ ≤ ‖phase‖ * ‖realCutoffKernel scale y‖ :=
  (Complex.abs_re_le_norm _).trans_eq (norm_modulatedKernel scale ξ phase y)

private theorem integrable_modulatedKernel {scale : ℝ} (hs : 0 < scale) (ξ : V) (phase : ℂ) :
    Integrable (modulatedKernel scale ξ phase) := by
  apply ((integrable_realCutoffKernel (V := V) hs).norm.const_mul ‖phase‖).mono'
    (continuous_modulatedKernel scale ξ phase).aestronglyMeasurable
  exact Filter.Eventually.of_forall fun y => (norm_modulatedKernel scale ξ phase y).le

theorem realModulatedKernel_mass {scale : ℝ} (hs : 0 < scale) {ξ : V}
    (hξ : ‖scale⁻¹ • ξ‖ < 1) (phase : ℂ) :
    (∫ y, realModulatedKernel scale ξ phase y) = phase.re := by
  change (∫ y, RCLike.re (modulatedKernel scale ξ phase y)) = phase.re
  rw [integral_re (integrable_modulatedKernel hs ξ phase)]
  have hm : (∫ y, modulatedKernel scale ξ phase y) = phase := by
    simp only [modulatedKernel, ofReal_realCutoffKernel, integral_const_mul,
      dilated_cutoffKernel_modulated_mass _ hs, unitCutoffSymbol_one hξ.le, mul_one]
  rw [hm]
  rfl

private theorem integrable_realModulatedKernel_moment {scale r : ℝ} (hs : 0 < scale)
    (hr : 0 ≤ r) (hr₂ : r ≤ 2) (ξ : V) (phase : ℂ) :
    Integrable (fun y => ‖realModulatedKernel scale ξ phase y‖ * ‖y‖ ^ r) := by
  have hb := (integrable_norm_rpow_mul_realCutoffKernel (V := V) hs hr hr₂).const_mul ‖phase‖
  have hc := (Complex.continuous_re.comp (continuous_modulatedKernel scale ξ phase)).norm.mul
    ((Real.continuous_rpow_const hr).comp continuous_norm)
  refine hb.mono' hc.aestronglyMeasurable (Filter.Eventually.of_forall fun y => ?_)
  rw [Real.norm_of_nonneg (mul_nonneg (norm_nonneg _) (Real.rpow_nonneg (norm_nonneg _) _)),
    ← mul_assoc]
  exact mul_le_mul_of_nonneg_right (norm_realModulatedKernel_le scale ξ phase y)
    (Real.rpow_nonneg (norm_nonneg _) _)

private theorem integrable_realModulatedKernel {scale : ℝ} (hs : 0 < scale) (ξ : V) (phase : ℂ) :
    Integrable (realModulatedKernel scale ξ phase) := by
  have hf : AEStronglyMeasurable (realModulatedKernel scale ξ phase) volume :=
    (Complex.continuous_re.comp (continuous_modulatedKernel scale ξ phase)).aestronglyMeasurable
  exact (integrable_norm_iff hf).mp (by
    simpa only [Real.rpow_zero, mul_one] using
      integrable_realModulatedKernel_moment hs le_rfl (by norm_num) ξ phase)

private theorem integrable_realModulatedKernel_linear {scale : ℝ} (hs : 0 < scale)
    (ξ : V) (phase : ℂ) : Integrable (fun y => realModulatedKernel scale ξ phase y • y) := by
  have hf : AEStronglyMeasurable (fun y => realModulatedKernel scale ξ phase y • y) volume :=
    ((Complex.continuous_re.comp
      (continuous_modulatedKernel scale ξ phase)).smul continuous_id).aestronglyMeasurable
  exact (integrable_norm_iff hf).mp (by
    simpa only [Real.rpow_one, norm_smul] using
      integrable_realModulatedKernel_moment hs (r := 1) (by norm_num) (by norm_num) ξ phase)

theorem realModulatedKernel_firstMoment {scale : ℝ} (hs : 0 < scale) {ξ : V}
    (hξ : ‖scale⁻¹ • ξ‖ < 1) (phase : ℂ) :
    (∫ y, realModulatedKernel scale ξ phase y • y) = 0 := by
  refine ext_inner_right ℝ fun w => ?_
  change (innerSLFlip ℝ w) (∫ y, realModulatedKernel scale ξ phase y • y) = inner ℝ (0 : V) w
  rw [← (innerSLFlip ℝ w).integral_comp_comm (integrable_realModulatedKernel_linear hs ξ phase),
    inner_zero_left]
  simp only [innerSLFlip_apply_apply ℝ, real_inner_smul_left]
  let f : V → ℂ := fun y => modulatedKernel scale ξ phase y * (inner ℝ y w : ℂ)
  have hfi : Integrable f := by
    have hb := (integrable_norm_rpow_mul_realCutoffKernel (V := V) hs
      (r := 1) (by norm_num) (by norm_num)).const_mul (‖phase‖ * ‖w‖)
    have hc := (continuous_modulatedKernel scale ξ phase).mul
      (Complex.continuous_ofReal.comp (innerSLFlip ℝ w).continuous)
    refine hb.mono' hc.aestronglyMeasurable (Filter.Eventually.of_forall fun y => ?_)
    simp only [f, norm_mul, norm_modulatedKernel, Complex.norm_real, Real.rpow_one]
    calc
      _ ≤ (‖phase‖ * ‖realCutoffKernel scale y‖) * (‖y‖ * ‖w‖) :=
        mul_le_mul_of_nonneg_left (abs_real_inner_le_norm y w) (mul_nonneg (norm_nonneg _) (norm_nonneg _))
      _ = _ := by ring
  have hfp (y : V) : RCLike.re (f y) = realModulatedKernel scale ξ phase y * inner ℝ y w := by
    change (modulatedKernel scale ξ phase y * (inner ℝ y w : ℂ)).re = _
    simp [realModulatedKernel, Complex.mul_re]
  simp_rw [← hfp]
  rw [integral_re hfi]
  have hz : (∫ y, f y) = 0 := by
    have hm := dilated_cutoffKernel_modulated_firstMoment
      (unitCutoffSymbol (V := V)) hs (unitCutoffSymbol_eventually_one hξ) w
    calc
      _ = phase * ∫ y, negativeCarrier ξ y *
          ((inner ℝ y w : ℂ) * dilatedKernel scale (cutoffKernel unitCutoffSymbol) y) := by
        rw [← integral_const_mul]
        apply integral_congr_ae
        exact Filter.Eventually.of_forall fun y => by
          simp only [f, modulatedKernel, ofReal_realCutoffKernel]
          ring
      _ = 0 := by rw [hm, mul_zero]
  rw [hz, map_zero]

/-- Removing the carrier from the integrand lets one estimate the cutoff error using
only derivatives of the amplitude. The phase may depend on the evaluation point. -/
theorem norm_realModulatedCutoff_error_of_remainder {H : Type*}
    [NormedAddCommGroup H] [NormedSpace ℝ H] [CompleteSpace H]
    {scale r C : ℝ} (hs : 0 < scale) (hr : 0 ≤ r) (hr₂ : r ≤ 2) (hC : 0 ≤ C)
    {ξ : V} (hξ : ‖scale⁻¹ • ξ‖ < 1) (phase : ℂ)
    (A : V → H) (B : V →L[ℝ] H) (x : V)
    (hA : Integrable (fun y => realModulatedKernel scale ξ phase y • A (x - y)))
    (hrem : ∀ y, ‖A (x - y) - A x + B y‖ ≤ C * ‖y‖ ^ r) :
    ‖(∫ y, realModulatedKernel scale ξ phase y • A (x - y)) - phase.re • A x‖ ≤
      C * (‖phase‖ * (scale ^ (-r) * ∫ y : V, ‖cutoffKernel unitCutoffSymbol y‖ * ‖y‖ ^ r)) := by
  let k := realModulatedKernel scale ξ phase
  have hkY := integrable_realModulatedKernel_linear hs ξ phase
  have hkB : Integrable (fun y => k y • B y) := by
    simpa only [B.map_smul] using B.integrable_comp hkY
  have hz := integral_weighted_linear_eq_zero k id B hkY
    (realModulatedKernel_firstMoment hs hξ phase)
  have hk := integrable_realModulatedKernel_moment hs hr hr₂ ξ phase
  refine (norm_weighted_sub_mass_le k (fun y => A (x - y)) B (A x)
    (fun y => ‖y‖ ^ r) (integrable_realModulatedKernel hs ξ phase) hA hkB
    (realModulatedKernel_mass hs hξ phase) hz hk (Filter.Eventually.of_forall hrem)).trans ?_
  apply mul_le_mul_of_nonneg_left _ hC
  rw [← integral_dilatedKernel_norm_rpow _ hs, ← integral_const_mul]
  have hb := (integrable_norm_rpow_mul_realCutoffKernel (V := V) hs hr hr₂).const_mul ‖phase‖
  simp only [norm_realCutoffKernel] at hb
  refine integral_mono hk hb fun y => ?_
  rw [← mul_assoc, ← norm_realCutoffKernel]
  exact mul_le_mul_of_nonneg_right (norm_realModulatedKernel_le scale ξ phase y)
    (Real.rpow_nonneg (norm_nonneg _) _)

end

end IsometricEmbeddingEndpoints

#print axioms IsometricEmbeddingEndpoints.norm_realModulatedCutoff_error_of_remainder
