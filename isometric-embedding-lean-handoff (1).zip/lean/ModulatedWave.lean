import ModulatedDifferential
import TorusLifts
import Mathlib.Analysis.Complex.OperatorNorm

namespace IsometricEmbeddingEndpoints

open MeasureTheory
open ContinuousLinearMap

noncomputable section

theorem norm_fderiv_sub_le_of_secondDerivative {E H : Type*}
    [NormedAddCommGroup E] [NormedSpace ℝ E] [NormedAddCommGroup H] [NormedSpace ℝ H]
    {f : E → H} (hf : ContDiff ℝ 2 f) {M : ℝ}
    (hM : ∀ x, ‖iteratedFDeriv ℝ 2 f x‖ ≤ M) (x y : E) :
    ‖fderiv ℝ f y - fderiv ℝ f x‖ ≤ M * ‖y - x‖ := by
  have hD : Differentiable ℝ (fderiv ℝ f) :=
    (hf.fderiv_right (m := 1) (by norm_num)).differentiable one_ne_zero
  have hb (z : E) : ‖fderiv ℝ (fderiv ℝ f) z‖ ≤ M := by
    rw [← norm_iteratedFDeriv_one, norm_iteratedFDeriv_fderiv]
    exact hM z
  exact (convex_univ (𝕜 := ℝ) (E := E)).norm_image_sub_le_of_norm_fderiv_le
    (fun z _ => hD z) (fun z _ => hb z) (Set.mem_univ x) (Set.mem_univ y)

variable {d : Type*} [Fintype d]

/-- The absolute moments of the unscaled torus cutoff kernel, computed on the cover. -/
def torusCutoffMoment (d : Type*) [Fintype d] (r : ℝ) : ℝ :=
  ∫ y : Cover d, ‖cutoffKernel unitCutoffSymbol y‖ * ‖y‖ ^ r

theorem torusCutoffMoment_nonneg (r : ℝ) : 0 ≤ torusCutoffMoment d r :=
  integral_nonneg fun _ => mul_nonneg (norm_nonneg _) (Real.rpow_nonneg (norm_nonneg _) _)

theorem norm_modeFrequency_le (ξ : Cover d) :
    ‖modeFrequency ξ‖ ≤ (2 * Real.pi) * ‖ξ‖ := by
  rw [modeFrequency, norm_smul, norm_mul, norm_mul, Complex.norm_I, mul_one,
    Complex.norm_real, Real.norm_eq_abs, abs_of_nonneg Real.pi_pos.le]
  norm_num only [Complex.norm_ofNat]
  apply mul_le_mul_of_nonneg_left _ (by positivity)
  refine (Complex.ofRealCLM.opNorm_comp_le (innerSL ℝ ξ)).trans ?_
  rw [Complex.ofRealCLM_norm, one_mul, innerSL_apply_norm]

theorem contDiff_fourierCarrier_lift (n : d → ℤ) (c : ℂ) (k : WithTop ℕ∞) :
    ContDiff ℝ k (fun z => fourierCarrier n c (flatProjection z)) := by
  have h := ((modeFrequency (latticeVector n)).contDiff (n := k)).cexp
  have hm : ContDiff ℝ k (fun z => c * Complex.exp (modeFrequency (latticeVector n) z)) :=
    contDiff_const.mul h
  simpa only [fourierCarrier, ContinuousMap.coe_mk, mFourier_flatProjection_eq_exp,
    Function.comp_def, Complex.reCLM_apply] using Complex.reCLM.contDiff.comp hm

variable {H : Type*} [NormedAddCommGroup H] [NormedSpace ℝ H] [CompleteSpace H]

omit [CompleteSpace H] in
private theorem norm_smulRightL_at_le (l : Cover d →L[ℝ] ℝ) :
    ‖smulRightL ℝ (Cover d) H l‖ ≤ ‖l‖ := by
  refine opNorm_le_bound _ (norm_nonneg _) fun y => ?_
  change ‖l.smulRight y‖ ≤ ‖l‖ * ‖y‖
  exact (norm_smulRight_apply l y).le

set_option maxHeartbeats 450000 in
/-- The cutoff changes the differential of one modulated amplitude by at most a constant
times the amplitude's second derivative bound divided by the cutoff frequency. -/
theorem norm_fderiv_realTorusCutoff_sub_le_of_carrier {scale M : ℝ}
    (hs : 0 < scale) (hM : 0 ≤ M) (n : d → ℤ) (hn : ‖scale⁻¹ • latticeVector n‖ < 1)
    (c : ℂ) (A : C(UnitAddTorus d, H))
    (hA : ContDiff ℝ 2 (fun z => A (flatProjection z)))
    (hA₂ : ∀ z, ‖iteratedFDeriv ℝ 2 (fun y => A (flatProjection y)) z‖ ≤ M)
    (x : Cover d) :
    ‖fderiv ℝ (fun z => realTorusCutoff scale (fourierCarrier n c • A) (flatProjection z)) x -
      fderiv ℝ (fun z => (fourierCarrier n c • A) (flatProjection z)) x‖ ≤
        M * ‖c‖ * scale⁻¹ * (torusCutoffMoment d 1 + (4 * Real.pi) * torusCutoffMoment d 2) := by
  let T := flatProjection x
  let a := fun z : Cover d => A (flatProjection z)
  let V := fourierCarrier n c • A
  let DA := torusDifferential A (hA.of_le (by norm_num))
  let L := modeFrequency (latticeVector n)
  let R := smulRightL ℝ (Cover d) H (Complex.reCLM.comp L)
  let I := smulRightL ℝ (Cover d) H (Complex.imCLM.comp L)
  let R₁ : C(UnitAddTorus d, Cover d →L[ℝ] H) := ⟨R ∘ A, R.continuous.comp A.continuous⟩
  let I₁ : C(UnitAddTorus d, Cover d →L[ℝ] H) := ⟨I ∘ A, I.continuous.comp A.continuous⟩
  let D₀ := fourierCarrier n c • DA
  let D₁ := fourierCarrier n c • R₁
  let D₂ := fourierCarrier n (Complex.I * c) • I₁
  have hD (y : Cover d) :
      HasFDerivAt (fun z => V (flatProjection z)) ((D₀ + D₁ + D₂) (flatProjection y)) y := by
    have h' := hasFDerivAt_fourierCarrier_smul_lift n c A ((hA.differentiable (by norm_num) y).hasFDerivAt)
    convert h' using 1
    ext v
    simp only [D₀, D₁, D₂, ContinuousMap.add_apply, ContinuousMap.smul_apply', add_apply,
      smul_apply, DA, torusDifferential_apply, R₁, I₁, ContinuousMap.coe_mk, Function.comp_apply,
      R, I, smulRightL_apply_apply, smulRight_apply, L]
  have hLip (y z : Cover d) : ‖fderiv ℝ a z - fderiv ℝ a y‖ ≤ M * ‖z - y‖ :=
    norm_fderiv_sub_le_of_secondDerivative hA hA₂ y z
  have hTaylor (y : Cover d) : ‖a (x - y) - a x + fderiv ℝ a x y‖ ≤ M * ‖y‖ ^ (2 : ℝ) := by
    simpa only [Real.rpow_one, Real.rpow_two, pow_two, mul_assoc] using
      norm_firstOrderRemainder_le_of_holderDifferential a (fderiv ℝ a)
        (fun z => (hA.differentiable (by norm_num) z).hasFDerivAt)
        (show (0 : ℝ) ≤ 1 by norm_num) hM
        (fun y z => by simpa only [Real.rpow_one] using hLip y z) x y
  have h₀ : ‖(realTorusCutoff scale D₀ - D₀) T‖ ≤
      M * (‖c‖ * (scale⁻¹ * torusCutoffMoment d 1)) := by
    have hb (y : Cover d) : ‖DA (flatProjection (x - y)) - DA T +
        (0 : Cover d →L[ℝ] Cover d →L[ℝ] H) y‖ ≤ M * ‖y‖ ^ (1 : ℝ) := by
      have he : x - y - x = -y := by abel
      simpa only [T, DA, torusDifferential_apply, zero_apply, add_zero, Real.rpow_one,
        he, norm_neg, a] using hLip x (x - y)
    simpa only [D₀, T, torusCutoffMoment, Real.rpow_neg_one] using
      norm_realTorusCutoff_sub_le_of_modulated_remainder hs (by norm_num : (0 : ℝ) ≤ 1)
        (by norm_num : (1 : ℝ) ≤ 2) hM n hn c DA 0 x hb
  have hpart (Q : H →L[ℝ] Cover d →L[ℝ] H) (c' : ℂ) :
      let U : C(UnitAddTorus d, Cover d →L[ℝ] H) := ⟨Q ∘ A, Q.continuous.comp A.continuous⟩
      let W := fourierCarrier n c' • U
      ‖(realTorusCutoff scale W - W) T‖ ≤
        (‖Q‖ * M) * (‖c'‖ * (scale ^ (-(2 : ℝ)) * torusCutoffMoment d 2)) := by
    dsimp only
    let U : C(UnitAddTorus d, Cover d →L[ℝ] H) := ⟨Q ∘ A, Q.continuous.comp A.continuous⟩
    refine norm_realTorusCutoff_sub_le_of_modulated_remainder (r := 2) hs (by norm_num) le_rfl
      (mul_nonneg (norm_nonneg Q) hM) n hn c' U (Q.comp (fderiv ℝ a x)) x ?_
    intro y
    change ‖Q (a (x - y)) - Q (a x) + Q (fderiv ℝ a x y)‖ ≤ _
    rw [← map_sub, ← map_add]
    refine (Q.le_opNorm _).trans ?_
    rw [mul_assoc]
    exact mul_le_mul_of_nonneg_left (hTaylor y) (norm_nonneg _)
  have hball : ‖latticeVector n‖ ≤ scale := by
    rw [norm_smul, Real.norm_eq_abs, abs_of_pos (inv_pos.mpr hs), ← div_eq_inv_mul] at hn
    exact (div_lt_one₀ hs).mp hn |>.le
  have hR : ‖R‖ ≤ (2 * Real.pi) * scale := by
    refine (norm_smulRightL_at_le (H := H) (Complex.reCLM.comp L)).trans ?_
    refine (Complex.reCLM.opNorm_comp_le L).trans ?_
    rw [Complex.reCLM_norm, one_mul]
    exact (norm_modeFrequency_le _).trans (mul_le_mul_of_nonneg_left hball (by positivity))
  have hI : ‖I‖ ≤ (2 * Real.pi) * scale := by
    refine (norm_smulRightL_at_le (H := H) (Complex.imCLM.comp L)).trans ?_
    refine (Complex.imCLM.opNorm_comp_le L).trans ?_
    rw [Complex.imCLM_norm, one_mul]
    exact (norm_modeFrequency_le _).trans (mul_le_mul_of_nonneg_left hball (by positivity))
  have hp₁ := hpart R c
  have hp₂ : ‖(realTorusCutoff scale D₂ - D₂) T‖ ≤
      (‖I‖ * M) * (‖c‖ * (scale ^ (-(2 : ℝ)) * torusCutoffMoment d 2)) := by
    simpa only [D₂, I₁, norm_mul, Complex.norm_I, one_mul] using hpart I (Complex.I * c)
  rw [(hasFDerivAt_realTorusCutoff_lift hs V _ hD x).fderiv, (hD x).fderiv]
  rw [realTorusCutoff_add hs, realTorusCutoff_add hs]
  have heq :
      (realTorusCutoff scale D₀ + realTorusCutoff scale D₁ + realTorusCutoff scale D₂)
        T - (D₀ + D₁ + D₂) T =
        (realTorusCutoff scale D₀ - D₀) T + (realTorusCutoff scale D₁ - D₁) T +
          (realTorusCutoff scale D₂ - D₂) T := by
    simp only [ContinuousMap.add_apply, ContinuousMap.sub_apply]
    abel
  rw [heq]
  have htwo : scale * scale ^ (-(2 : ℝ)) = scale⁻¹ := by
    calc
      _ = scale ^ (1 : ℝ) * scale ^ (-(2 : ℝ)) := by rw [Real.rpow_one]
      _ = _ := by rw [← Real.rpow_add hs]; norm_num [Real.rpow_neg_one]
  have hcoef (Q : ℝ) (hQ : Q ≤ (2 * Real.pi) * scale) :
      (Q * M) * (‖c‖ * (scale ^ (-(2 : ℝ)) * torusCutoffMoment d 2)) ≤
        M * ‖c‖ * scale⁻¹ * ((2 * Real.pi) * torusCutoffMoment d 2) := by
    calc
      _ ≤ (((2 * Real.pi) * scale) * M) * (‖c‖ * (scale ^ (-(2 : ℝ)) * torusCutoffMoment d 2)) :=
        mul_le_mul_of_nonneg_right (mul_le_mul_of_nonneg_right hQ hM)
          (mul_nonneg (norm_nonneg _) (mul_nonneg (Real.rpow_nonneg hs.le _) (torusCutoffMoment_nonneg 2)))
      _ = _ := by rw [← htwo]; ring
  calc
    _ ≤ ‖(realTorusCutoff scale D₀ - D₀) T‖ + ‖(realTorusCutoff scale D₁ - D₁) T‖ +
          ‖(realTorusCutoff scale D₂ - D₂) T‖ :=
      (norm_add_le _ _).trans (add_le_add (norm_add_le _ _) le_rfl)
    _ ≤ _ := (add_le_add (add_le_add h₀ (hp₁.trans (hcoef _ hR)))
      (hp₂.trans (hcoef _ hI))).trans_eq (by ring)

/-- The differentiated cutoff bound adds over finitely many modulated amplitudes. -/
theorem norm_fderiv_realTorusCutoff_sub_le_of_carriers {ι : Type*} {scale : ℝ}
    (hs : 0 < scale) (s : Finset ι) (n : ι → d → ℤ) (c : ι → ℂ)
    (A : ι → C(UnitAddTorus d, H)) (M : ι → ℝ)
    (hn : ∀ i ∈ s, ‖scale⁻¹ • latticeVector (n i)‖ < 1)
    (hM : ∀ i ∈ s, 0 ≤ M i)
    (hA : ∀ i ∈ s, ContDiff ℝ 2 (fun z => A i (flatProjection z)))
    (hA₂ : ∀ i ∈ s, ∀ z, ‖iteratedFDeriv ℝ 2 (fun y => A i (flatProjection y)) z‖ ≤ M i)
    (x : Cover d) :
    let V := ∑ i ∈ s, fourierCarrier (n i) (c i) • A i
    ‖fderiv ℝ (fun z => realTorusCutoff scale V (flatProjection z)) x -
      fderiv ℝ (fun z => V (flatProjection z)) x‖ ≤
        (∑ i ∈ s, M i * ‖c i‖) * scale⁻¹ *
          (torusCutoffMoment d 1 + (4 * Real.pi) * torusCutoffMoment d 2) := by
  let V := fun i => fourierCarrier (n i) (c i) • A i
  have hV (i) (hi : i ∈ s) : ContDiff ℝ 1 (fun z => V i (flatProjection z)) := by
    change ContDiff ℝ 1 ((fun z => fourierCarrier (n i) (c i) (flatProjection z)) •
      (fun z => A i (flatProjection z)))
    exact (contDiff_fourierCarrier_lift (n i) (c i) 1).smul
      ((hA i hi).of_le (show (1 : WithTop ℕ∞) ≤ 2 by norm_num))
  have hsum (u : ι → C(UnitAddTorus d, H)) :
      (fun z : Cover d => (∑ i ∈ s, u i) (flatProjection z)) =
        (fun z => ∑ i ∈ s, u i (flatProjection z)) := by
    funext z
    exact map_sum (ContinuousMap.evalCLM ℝ (flatProjection z)) u s
  have hf (i) (hi : i ∈ s) :
      DifferentiableAt ℝ (fun z => realTorusCutoff scale (V i) (flatProjection z)) x := by
    refine (hasFDerivAt_realTorusCutoff_lift hs (V i) (torusDifferential (V i) (hV i hi))
      (fun z => ?_) x).differentiableAt
    rw [torusDifferential_apply]
    exact ((hV i hi).differentiable one_ne_zero z).hasFDerivAt
  change ‖fderiv ℝ (fun z => realTorusCutoff scale (∑ i ∈ s, V i) (flatProjection z)) x -
    fderiv ℝ (fun z => (∑ i ∈ s, V i) (flatProjection z)) x‖ ≤ _
  rw [realTorusCutoff_finset_sum hs, hsum, hsum, fderiv_fun_sum hf,
    fderiv_fun_sum (fun i hi => (hV i hi).differentiable one_ne_zero x), ← Finset.sum_sub_distrib]
  let e : ι → Cover d →L[ℝ] H := fun i =>
    fderiv ℝ (fun z => realTorusCutoff scale (V i) (flatProjection z)) x -
      fderiv ℝ (fun z => V i (flatProjection z)) x
  change ‖∑ i ∈ s, e i‖ ≤ _
  calc
    _ ≤ ∑ i ∈ s, ‖e i‖ := norm_sum_le _ _
    _ ≤ ∑ i ∈ s, M i * ‖c i‖ * scale⁻¹ *
        (torusCutoffMoment d 1 + (4 * Real.pi) * torusCutoffMoment d 2) :=
      Finset.sum_le_sum fun i hi =>
        norm_fderiv_realTorusCutoff_sub_le_of_carrier hs (hM i hi) (n i) (hn i hi)
          (c i) (A i) (hA i hi) (hA₂ i hi) x
    _ = _ := by simp only [Finset.sum_mul]

end

end IsometricEmbeddingEndpoints

#print axioms IsometricEmbeddingEndpoints.norm_fderiv_realTorusCutoff_sub_le_of_carrier
#print axioms IsometricEmbeddingEndpoints.norm_fderiv_realTorusCutoff_sub_le_of_carriers
