import IsometricEmbeddingEndpoints
import TorusCutoff

namespace IsometricEmbeddingEndpoints

open Filter Finset
open scoped NNReal Topology

noncomputable section

variable {d H : Type*} [Fintype d] [NormedAddCommGroup H] [InnerProductSpace ℝ H] [CompleteSpace H]

/-- Passage from the low-regularity approximants to an isometric torus map.
The two geometric bounds on the differentials give the endpoint exponent itself. -/
theorem exists_isometric_holder_limit_of_torus_series
    {L θ A A₀ : ℝ} (hL : 1 < L) (hθ : 0 < θ) (hθ₁ : θ < 1) (hA : 0 ≤ A) (hA₀ : 0 ≤ A₀)
    (u₀ : C(UnitAddTorus d, H)) (D₀ : Cover d → Cover d →L[ℝ] H)
    (hD₀ : ∀ x, HasFDerivAt (fun z => u₀ (flatProjection z)) (D₀ x) x)
    (hD₀c : Continuous D₀)
    (hD₀h : ∀ x y, ‖D₀ x - D₀ y‖ ≤ A₀ * dist x y ^ θ)
    (v : ℕ → C(UnitAddTorus d, H)) (Dv : ℕ → Cover d → Cover d →L[ℝ] H)
    (hDv : ∀ j x, HasFDerivAt (fun z => v j (flatProjection z)) (Dv j x) x)
    (hsmall : ∀ j, ‖v j‖ ≤ A * (L ^ (-θ)) ^ j)
    (hgradient : ∀ j x, ‖Dv j x‖ ≤ A * (L ^ (-θ)) ^ j)
    (hlip : ∀ j x y, ‖Dv j x - Dv j y‖ ≤ A * (L ^ (1 - θ)) ^ j * dist x y)
    (g : Cover d → Cover d → Cover d → ℝ)
    (hmetric : ∀ x a b, Tendsto (fun n : ℕ =>
      inner ℝ ((D₀ x + ∑ j ∈ range n, Dv j x) a) ((D₀ x + ∑ j ∈ range n, Dv j x) b))
      atTop (𝓝 (g x a b))) :
    ∃ u : C(UnitAddTorus d, H), ContDiff ℝ 1 (fun x : Cover d => u (flatProjection x)) ∧
      (∃ K : ℝ, 0 ≤ K ∧ ∀ x y : Cover d,
        ‖fderiv ℝ (fun z => u (flatProjection z)) x -
          fderiv ℝ (fun z => u (flatProjection z)) y‖ ≤ K * dist x y ^ θ) ∧
      ∀ x a b : Cover d, inner ℝ (fderiv ℝ (fun z => u (flatProjection z)) x a)
        (fderiv ℝ (fun z => u (flatProjection z)) x b) = g x a b := by
  let q := L ^ (-θ)
  have hL₀ : 0 < L := zero_lt_one.trans hL
  have hq₀ : 0 ≤ q := Real.rpow_nonneg hL₀.le _
  have hq₁ : q < 1 := Real.rpow_lt_one_of_one_lt_of_neg hL (neg_neg_of_pos hθ)
  have hsum : Summable (fun j : ℕ => A * q ^ j) :=
    (summable_geometric_of_lt_one hq₀ hq₁).mul_left A
  have hvs : Summable v := Summable.of_norm_bounded hsum hsmall
  have hDvs (x : Cover d) : Summable (fun j => Dv j x) :=
    Summable.of_norm_bounded hsum (fun j => hgradient j x)
  let u := u₀ + ∑' j, v j
  let D := fun x => D₀ x + ∑' j, Dv j x
  have hu (x : Cover d) : u (flatProjection x) = u₀ (flatProjection x) + ∑' j, v j (flatProjection x) := by
    change u₀ (flatProjection x) + (ContinuousMap.evalCLM ℝ (flatProjection x)) (∑' j, v j) = _
    rw [ContinuousLinearMap.map_tsum _ hvs]
    rfl
  have hdu (x : Cover d) : HasFDerivAt (fun z => u (flatProjection z)) (D x) x := by
    let ev : C(UnitAddTorus d, H) →L[ℝ] H := ContinuousMap.evalCLM ℝ (flatProjection (0 : Cover d))
    have hpoint : Summable (fun j => v j (flatProjection (0 : Cover d))) :=
      hvs.map ev ev.continuous
    rw [funext hu]
    exact (hD₀ x).add (hasFDerivAt_tsum hsum hDv hgradient hpoint x)
  have hD : fderiv ℝ (fun z => u (flatProjection z)) = D := funext fun x => (hdu x).fderiv
  obtain ⟨K, hK, hkh⟩ := holder_tsum_of_geometric hL hθ hθ₁ hA Dv hgradient hlip
  have hK₀ := add_nonneg hA₀ hK
  have hDh (x y : Cover d) : ‖D x - D y‖ ≤ (A₀ + K) * dist x y ^ θ := by
    change ‖(D₀ x + ∑' j, Dv j x) - (D₀ y + ∑' j, Dv j y)‖ ≤ _
    rw [add_sub_add_comm]
    refine (norm_add_le _ _).trans ?_
    rw [add_mul]
    exact add_le_add (hD₀h x y) (hkh x y)
  have hDc : Continuous D := by
    apply hD₀c.add (continuous_tsum _ hsum hgradient)
    intro j
    let C : ℝ≥0 := ⟨A * (L ^ (1 - θ)) ^ j, mul_nonneg hA (pow_nonneg (Real.rpow_nonneg hL₀.le _) _)⟩
    exact (LipschitzWith.of_dist_le_mul (K := C) fun x y => by
      rw [dist_eq_norm]
      exact hlip j x y).continuous
  refine ⟨u, contDiff_one_iff_fderiv.2 ⟨fun x => (hdu x).differentiableAt, hD ▸ hDc⟩,
    ⟨A₀ + K, hK₀, hD.symm ▸ hDh⟩, ?_⟩
  intro x a b
  rw [hD]
  apply inner_of_tendsto_differentials _ a b (hmetric x a b)
  exact (tendsto_const_nhds (x := D₀ x)).add (hDvs x).hasSum.tendsto_sum_nat

end

end IsometricEmbeddingEndpoints

#print axioms IsometricEmbeddingEndpoints.exists_isometric_holder_limit_of_torus_series
