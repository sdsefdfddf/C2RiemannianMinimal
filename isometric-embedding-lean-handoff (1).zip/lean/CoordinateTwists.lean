import Mathlib.Algebra.BigOperators.Group.Finset.Sigma
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Basic.Real.Basic
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.Ring

namespace IsometricEmbeddingEndpoints

open scoped BigOperators

variable {ι : Type*} [Fintype ι]

/-- The sum over all ordered pairs is convenient in Lean: it uses no order on the coordinate
index and the symmetric terms are exchanged by `Finset.sum_comm`. -/
theorem sum_ordered_coordinate_twists (H : ι → ι → ℝ)
    (hsym : ∀ i j, H i j = H j i) (c : ℝ) (v w : ι → ℝ) :
    (∑ i, ∑ j, (((c + H i j) / 4) * ((v i + v j) * (w i + w j)) +
      ((c - H i j) / 4) * ((v i - v j) * (w i - w j)))) =
      (Fintype.card ι : ℝ) * c * (∑ i, v i * w i) +
        ∑ i, ∑ j, H i j * (v i * w j) := by
  let b := fun i => (c / 2) * (v i * w i)
  let h := fun i j => (H i j / 2) * (v i * w j)
  have hb : (∑ i, ∑ _j : ι, b i) = (Fintype.card ι : ℝ) * ∑ i, b i := by
    simp only [Finset.sum_const, Finset.card_univ, nsmul_eq_mul, Finset.mul_sum]
  have hb' : (∑ _i : ι, ∑ j, b j) = (Fintype.card ι : ℝ) * ∑ i, b i := by
    simp [nsmul_eq_mul]
  have hh : (∑ i, ∑ j, h j i) = ∑ i, ∑ j, h i j := Finset.sum_comm
  have hpiece (i j : ι) :
      ((c + H i j) / 4) * ((v i + v j) * (w i + w j)) +
        ((c - H i j) / 4) * ((v i - v j) * (w i - w j)) =
      b i + b j + h i j + h j i := by
    dsimp only [b, h]
    rw [← hsym i j]
    ring
  have hs : (∑ i, ∑ j, h i j) = (1 / 2 : ℝ) * ∑ i, ∑ j, H i j * (v i * w j) := by
    simp only [h, Finset.mul_sum]
    apply Finset.sum_congr rfl
    intro i _
    apply Finset.sum_congr rfl
    intro j _
    ring
  calc
    _ = ∑ i, ∑ j, (b i + b j + h i j + h j i) :=
      Finset.sum_congr rfl (fun i _ => Finset.sum_congr rfl (fun j _ => hpiece i j))
    _ = _ := by
      simp only [Finset.sum_add_distrib]
      rw [hb, hb', hh, hs]
      change ↑(Fintype.card ι) * (∑ i, (c / 2) * (v i * w i)) +
        ↑(Fintype.card ι) * (∑ i, (c / 2) * (v i * w i)) + _ + _ = _
      rw [← Finset.mul_sum]
      ring

/-- A matrix written as a scalar identity plus a small symmetric error has a fixed set of
integer directions. Ordered pairs, including diagonal pairs, are allowed. -/
theorem shifted_coordinate_twist_decomposition (H : ι → ι → ℝ)
    (hsym : ∀ i j, H i j = H j i) (δ c : ℝ) (v w : ι → ℝ) :
    δ * (1 - (Fintype.card ι : ℝ) * c) * (∑ i, v i * w i) +
      (∑ i, ∑ j, (((c * δ + H i j) / 4) * ((v i + v j) * (w i + w j)) +
        ((c * δ - H i j) / 4) * ((v i - v j) * (w i - w j)))) =
      δ * (∑ i, v i * w i) + ∑ i, ∑ j, H i j * (v i * w j) := by
  rw [sum_ordered_coordinate_twists H hsym]
  ring

theorem shifted_coordinate_twist_coefficients_pos {H : ι → ι → ℝ} {δ c : ℝ}
    (hδ : 0 < δ) (hc : (Fintype.card ι : ℝ) * c < 1)
    (hH : ∀ i j, |H i j| < c * δ) :
    0 < δ * (1 - (Fintype.card ι : ℝ) * c) ∧
      ∀ i j, 0 < (c * δ + H i j) / 4 ∧ 0 < (c * δ - H i j) / 4 := by
  refine ⟨mul_pos hδ (sub_pos.mpr hc), ?_⟩
  intro i j
  obtain ⟨h₁, h₂⟩ := abs_lt.mp (hH i j)
  exact ⟨by linarith, by linarith⟩

end IsometricEmbeddingEndpoints

#print axioms IsometricEmbeddingEndpoints.shifted_coordinate_twist_decomposition
#print axioms IsometricEmbeddingEndpoints.shifted_coordinate_twist_coefficients_pos
