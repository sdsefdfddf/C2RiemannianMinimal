import EmbeddingCoordinates
import CutoffOperator
import FourierKernelScaling
import Spiral
import Mathlib.Analysis.Fourier.AddCircleMulti
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Ring

namespace IsometricEmbeddingEndpoints

open MeasureTheory
open scoped FourierTransform

noncomputable section

variable {d : Type*} [Fintype d]

/-- Period-one covering coordinates, with the same convention as the flat torus in
`C2RiemannianMinimal`. -/
def flatProjection : C(Cover d, UnitAddTorus d) where
  toFun y i := (y i : AddCircle (1 : ℝ))
  continuous_toFun := continuous_pi
    (fun i => (AddCircle.continuous_mk' 1).comp (PiLp.continuous_apply 2 (fun _ : d => ℝ) i))

omit [Fintype d] in
theorem flatProjection_sub (x y : Cover d) :
    flatProjection (x - y) = flatProjection x - flatProjection y := by
  ext i
  exact AddCircle.coe_sub (p := (1 : ℝ)) (x i) (y i)

omit [Fintype d] in
theorem flatProjection_surjective : Function.Surjective (flatProjection (d := d)) := by
  intro x
  have h (i : d) : ∃ y : ℝ, (y : AddCircle (1 : ℝ)) = x i :=
    QuotientAddGroup.mk_surjective (x i)
  choose y hy using h
  exact ⟨WithLp.toLp 2 y, funext hy⟩

/-- A character at a translated point factors as the character times an inverse mode. -/
theorem mFourier_sub (n : d → ℤ) (x y : UnitAddTorus d) :
    UnitAddTorus.mFourier n (x - y) =
      UnitAddTorus.mFourier n x * UnitAddTorus.mFourier (-n) y := by
  classical
  simp only [UnitAddTorus.mFourier, ContinuousMap.coe_mk, Pi.sub_apply, Pi.neg_apply,
    ← Finset.prod_mul_distrib]
  apply Finset.prod_congr rfl
  intro i _
  rw [fourier_apply, fourier_apply, fourier_apply, zsmul_sub, sub_eq_add_neg,
    AddCircle.toCircle_add, Circle.coe_mul, neg_smul]

/-- The inverse mode on the torus agrees with the Euclidean carrier on its cover. -/
theorem mFourier_neg_flatProjection (n : d → ℤ) (y : Cover d) :
    UnitAddTorus.mFourier (-n) (flatProjection y) = negativeCarrier (latticeVector n) y := by
  classical
  simp only [UnitAddTorus.mFourier, flatProjection, ContinuousMap.coe_mk, Pi.neg_apply,
    fourier_coe_apply, Complex.ofReal_one, div_one, Int.cast_neg, ← Complex.exp_sum,
    negativeCarrier, Real.fourierChar_apply, PiLp.inner_apply, Real.inner_apply,
    latticeVector, Complex.ofReal_neg, Complex.ofReal_mul, Complex.ofReal_sum, Complex.ofReal_intCast]
  apply congrArg Complex.exp
  rw [← Finset.sum_neg_distrib]
  simp only [Finset.mul_sum, Finset.sum_mul]
  apply Finset.sum_congr rfl
  intro i _
  push_cast
  ring

/-- The positive-scale Schwartz cutoff kernel is integrable on the Euclidean cover. -/
theorem integrable_dilated_cutoffKernel (χ : SchwartzMap (Cover d) ℂ) {scale : ℝ}
    (hscale : 0 < scale) : Integrable (dilatedKernel scale (cutoffKernel χ)) := by
  have hk : Integrable (cutoffKernel χ : Cover d → ℂ) := (cutoffKernel χ).integrable
  have hscaled : Integrable (fun y : Cover d => cutoffKernel χ (scale • y)) :=
    hk.comp_smul hscale.ne'
  exact Integrable.smul (𝕜 := ℝ) (scale ^ Module.finrank ℝ (Cover d)) hscaled

theorem weightedShiftOperator_on_modes (k : Cover d → ℂ) (hk : Integrable k) (n : d → ℤ) :
    weightedShiftOperator flatProjection k hk (UnitAddTorus.mFourier n) =
      (∫ y, negativeCarrier (latticeVector n) y * k y) • UnitAddTorus.mFourier n := by
  ext x
  rw [weightedShiftOperator_apply]
  simp only [mFourier_sub, mFourier_neg_flatProjection, ContinuousMap.smul_apply, smul_eq_mul]
  calc
    _ = UnitAddTorus.mFourier n x *
        (∫ y, negativeCarrier (latticeVector n) y * k y) := by
      rw [← integral_const_mul]
      exact integral_congr_ae (Filter.Eventually.of_forall fun y => by ring)
    _ = _ := mul_comm _ _

/-- The cutoff acts on a torus mode by multiplying by the symbol at its scaled frequency. -/
theorem weightedCutoff_on_modes (χ : SchwartzMap (Cover d) ℂ) {scale : ℝ}
    (hscale : 0 < scale) (n : d → ℤ) :
    weightedShiftOperator flatProjection (dilatedKernel scale (cutoffKernel χ))
        (integrable_dilated_cutoffKernel χ hscale) (UnitAddTorus.mFourier n) =
      χ (scale⁻¹ • latticeVector n) • UnitAddTorus.mFourier n := by
  rw [weightedShiftOperator_on_modes, dilated_cutoffKernel_modulated_mass _ hscale]

/-- Once a finite band contains the nonzero lattice values of the symbol, the convolution of
every continuous input is a trigonometric polynomial in that band. -/
theorem weightedCutoff_mem_band (χ : SchwartzMap (Cover d) ℂ) {scale : ℝ} (hscale : 0 < scale)
    (band : Finset (d → ℤ)) (hband : ∀ n, n ∉ band → χ (scale⁻¹ • latticeVector n) = 0)
    (f : C(UnitAddTorus d, ℂ)) :
    weightedShiftOperator flatProjection (dilatedKernel scale (cutoffKernel χ))
        (integrable_dilated_cutoffKernel χ hscale) f ∈
      Submodule.span ℂ (UnitAddTorus.mFourier '' (band : Set (d → ℤ))) := by
  apply mem_finite_span_of_dense_modes _ _ _ UnitAddTorus.span_mFourier_closure_eq_top _ f
  intro n
  rw [weightedCutoff_on_modes χ hscale]
  by_cases hn : n ∈ band
  · exact (Submodule.span ℂ _).smul_mem _ (Submodule.subset_span ⟨n, hn, rfl⟩)
  · have hz : (0 : ℂ) • UnitAddTorus.mFourier n = 0 := by
      ext x
      change (0 : ℂ) * UnitAddTorus.mFourier n x = 0
      exact zero_mul _
    rw [hband n hn, hz]
    exact Submodule.zero_mem _

/-- A cutoff whose symbol is one on a band reproduces every polynomial in that band. -/
theorem weightedCutoff_eq_of_mem_band (χ : SchwartzMap (Cover d) ℂ) {scale : ℝ}
    (hscale : 0 < scale) (band : Finset (d → ℤ))
    (hone : ∀ n ∈ band, χ (scale⁻¹ • latticeVector n) = 1)
    {f : C(UnitAddTorus d, ℂ)}
    (hf : f ∈ Submodule.span ℂ (UnitAddTorus.mFourier '' (band : Set (d → ℤ)))) :
    weightedShiftOperator flatProjection (dilatedKernel scale (cutoffKernel χ))
        (integrable_dilated_cutoffKernel χ hscale) f = f := by
  let S := weightedShiftOperator flatProjection (dilatedKernel scale (cutoffKernel χ))
    (integrable_dilated_cutoffKernel χ hscale)
  let T := S.toLinearMap - LinearMap.id
  have hsub : Submodule.span ℂ (UnitAddTorus.mFourier '' (band : Set (d → ℤ))) ≤ T.ker := by
    refine Submodule.span_le.2 ?_
    rintro _ ⟨n, hn, rfl⟩
    change S (UnitAddTorus.mFourier n) - UnitAddTorus.mFourier n = 0
    have hm := weightedCutoff_on_modes χ hscale n
    change S (UnitAddTorus.mFourier n) = _ at hm
    have h₁ : (1 : ℂ) • UnitAddTorus.mFourier n = UnitAddTorus.mFourier n := by
      ext x
      change (1 : ℂ) * UnitAddTorus.mFourier n x = UnitAddTorus.mFourier n x
      exact one_mul _
    rw [hm, hone n hn, h₁, sub_self]
  have hz : T f = 0 := hsub hf
  exact sub_eq_zero.mp hz

/-- The lattice frequencies of norm at most twice the cutoff scale. The coordinate box
gives a finite set to filter. -/
def torusCutoffBand (scale : ℝ) : Finset (d → ℤ) := by
  classical
  exact (Fintype.piFinset (fun _ : d => Finset.Icc (-⌈2 * scale⌉) ⌈2 * scale⌉)).filter
    (fun n => ‖latticeVector n‖ ≤ 2 * scale)

theorem norm_le_of_mem_torusCutoffBand {scale : ℝ} {n : d → ℤ}
    (hn : n ∈ torusCutoffBand scale) : ‖latticeVector n‖ ≤ 2 * scale :=
  (Finset.mem_filter.mp hn).2

theorem unitCutoffSymbol_zero_off_torusBand {scale : ℝ} (hscale : 0 < scale) (n : d → ℤ)
    (hn : n ∉ torusCutoffBand scale) :
    unitCutoffSymbol (scale⁻¹ • latticeVector n) = 0 := by
  classical
  apply unitCutoffSymbol_zero
  apply le_of_not_gt
  intro hsmall
  have hs : scale⁻¹ * ‖latticeVector n‖ < 2 := by
    simpa only [norm_smul, Real.norm_eq_abs, abs_inv, abs_of_pos hscale] using hsmall
  have hnorm : ‖latticeVector n‖ < 2 * scale := by
    calc
      ‖latticeVector n‖ = scale * (scale⁻¹ * ‖latticeVector n‖) := by
        rw [← mul_assoc, mul_inv_cancel₀ hscale.ne', one_mul]
      _ < scale * 2 := mul_lt_mul_of_pos_left hs hscale
      _ = 2 * scale := mul_comm _ _
  apply hn
  unfold torusCutoffBand
  refine Finset.mem_filter.mpr ⟨?_, hnorm.le⟩
  apply Fintype.mem_piFinset.mpr
  intro i
  rw [Finset.mem_Icc]
  have hi : |(n i : ℝ)| ≤ ‖latticeVector n‖ := by
    simpa [latticeVector, Real.norm_eq_abs] using PiLp.norm_apply_le (latticeVector n) i
  have hceil : |(n i : ℝ)| ≤ (⌈2 * scale⌉ : ℝ) :=
    hi.trans (hnorm.le.trans (Int.le_ceil _))
  exact_mod_cast abs_le.mp hceil

/-- The concrete Schwartz cutoff has a finite spectral image on the flat torus. -/
theorem unitCutoff_mem_band {scale : ℝ} (hscale : 0 < scale) (f : C(UnitAddTorus d, ℂ)) :
    weightedShiftOperator flatProjection (dilatedKernel scale (cutoffKernel unitCutoffSymbol))
        (integrable_dilated_cutoffKernel unitCutoffSymbol hscale) f ∈
      Submodule.span ℂ (UnitAddTorus.mFourier '' (torusCutoffBand (d := d) scale : Set (d → ℤ))) :=
  weightedCutoff_mem_band unitCutoffSymbol hscale _ (unitCutoffSymbol_zero_off_torusBand hscale) f

end

end IsometricEmbeddingEndpoints

#print axioms IsometricEmbeddingEndpoints.weightedCutoff_mem_band
#print axioms IsometricEmbeddingEndpoints.unitCutoff_mem_band
#print axioms IsometricEmbeddingEndpoints.weightedCutoff_eq_of_mem_band
