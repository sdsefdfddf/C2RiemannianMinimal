import RealTorusBernstein
import TorusMetric
import Mathlib.Analysis.SpecialFunctions.Pow.Asymptotics

namespace IsometricEmbeddingEndpoints

open Filter MeasureTheory
open scoped Topology

noncomputable section

variable {d : Type*} [Fintype d]

local instance : NormedAddCommGroup (MetricForm d) := inferInstance
local instance : NormedSpace ℝ (MetricForm d) := inferInstance
local instance : CompleteSpace (MetricForm d) := inferInstance

private theorem abs_metricForm_apply_le (G : MetricForm d) (v w : Cover d) :
    |G v w| ≤ (‖G‖ * ‖v‖) * ‖w‖ := by
  rw [← Real.norm_eq_abs]
  exact (ContinuousLinearMap.le_opNorm _ _).trans
    (mul_le_mul_of_nonneg_right (G.le_opNorm v) (norm_nonneg _))

theorem TorusMetric.positive_of_close_form (g : TorusMetric d) {m : ℝ} (hm : 0 < m)
    (hg : ∀ x v, m * ‖v‖ ^ 2 ≤ g.form x v v)
    (G : C(UnitAddTorus d, MetricForm d)) (hG : ‖G - g.form‖ ≤ m / 2) :
    ∀ x v, v ≠ 0 → 0 < G x v v := by
  intro x v hv
  have hx : ‖G x - g.form x‖ ≤ m / 2 := by
    simpa only [ContinuousMap.sub_apply] using ((G - g.form).norm_coe_le_norm x).trans hG
  have hv' : 0 < ‖v‖ ^ 2 := sq_pos_of_pos (norm_pos_iff.mpr hv)
  have hest := abs_metricForm_apply_le (G x - g.form x) v v
  have hlow : -(m / 2 * ‖v‖ ^ 2) ≤ G x v v - g.form x v v := by
    apply (abs_le.mp ?_).1
    calc
      _ ≤ (‖G x - g.form x‖ * ‖v‖) * ‖v‖ := hest
      _ ≤ (m / 2 * ‖v‖) * ‖v‖ :=
        mul_le_mul_of_nonneg_right (mul_le_mul_of_nonneg_right hx (norm_nonneg _)) (norm_nonneg _)
      _ = _ := by ring
  linarith [hg x v, mul_pos hm hv']

private theorem realTorusCutoff_metricForm_apply {scale : ℝ} (hs : 0 < scale)
    (f : C(UnitAddTorus d, MetricForm d)) (x : UnitAddTorus d) (v w : Cover d) :
    realTorusCutoff (H := MetricForm d) scale f x v w =
      ∫ y : Cover d, realCutoffKernel scale y * f (x - flatProjection y) v w := by
  let L : MetricForm d →L[ℝ] ℝ := (ContinuousLinearMap.apply ℝ ℝ w).comp
    (ContinuousLinearMap.apply ℝ (Cover d →L[ℝ] ℝ) v)
  let q : Cover d → MetricForm d := fun y => realCutoffKernel scale y • f (x - flatProjection y)
  have hq : Integrable q := integrable_realTorusCutoff_eval (H := MetricForm d) hs f x
  calc
    _ = L (∫ y, q y) := congrArg L (realTorusCutoff_apply (H := MetricForm d) hs f x)
    _ = ∫ y, L (q y) := (L.integral_comp_comm hq).symm
    _ = _ := integral_congr_ae (Filter.Eventually.of_forall fun y => by
      change L (realCutoffKernel scale y • f (x - flatProjection y)) = _
      rw [L.map_smul]
      rfl)

theorem TorusMetric.realTorusCutoff_symmetric (g : TorusMetric d) {scale : ℝ} (hs : 0 < scale)
    (t : UnitAddTorus d) (v w : Cover d) :
    realTorusCutoff (H := MetricForm d) scale g.form t v w =
      realTorusCutoff (H := MetricForm d) scale g.form t w v := by
  simp only [realTorusCutoff_metricForm_apply hs, g.symmetric _ v w]

theorem TorusMetric.exists_cutoffRate_of_holder (g : TorusMetric d) {α C : ℝ}
    (hα : 0 ≤ α) (hα₁ : α ≤ 1) (hC : 0 ≤ C)
    (hg : ∀ x z : Cover d, ‖g.form (flatProjection z) - g.form (flatProjection x)‖ ≤ C * ‖z - x‖ ^ α) :
    ∃ K : ℝ, 0 ≤ K ∧ ∀ s : ℝ, 0 < s →
      ‖realTorusCutoff (H := MetricForm d) s g.form - g.form‖ ≤ K * s ^ (-α) := by
  let M := ∫ y : Cover d, ‖cutoffKernel unitCutoffSymbol y‖ * ‖y‖ ^ α
  have hM : 0 ≤ M := integral_nonneg fun _ => by positivity
  refine ⟨C * M, mul_nonneg hC hM, fun s hs => ?_⟩
  apply (ContinuousMap.norm_le _ (by positivity)).2
  intro t
  obtain ⟨x, rfl⟩ := flatProjection_surjective t
  calc
    _ ≤ C * (s ^ (-α) * M) := norm_realTorusCutoff_sub_le_of_holder hs hα hα₁ g.form hg x
    _ = _ := by ring

theorem TorusMetric.exists_cutoffRate_of_holderDifferential (g : TorusMetric d) {α C : ℝ}
    (hα : 0 ≤ α) (hα₁ : α ≤ 1) (hC : 0 ≤ C) (Dg : Cover d → Cover d →L[ℝ] MetricForm d)
    (hg : ∀ x, HasFDerivAt (fun z => g.form (flatProjection z)) (Dg x) x)
    (hDg : ∀ x z, ‖Dg z - Dg x‖ ≤ C * ‖z - x‖ ^ α) :
    ∃ K : ℝ, 0 ≤ K ∧ ∀ s : ℝ, 0 < s →
      ‖realTorusCutoff (H := MetricForm d) s g.form - g.form‖ ≤ K * s ^ (-(1 + α)) := by
  let M := ∫ y : Cover d, ‖cutoffKernel unitCutoffSymbol y‖ * ‖y‖ ^ (1 + α)
  have hM : 0 ≤ M := integral_nonneg fun _ => by positivity
  refine ⟨C * M, mul_nonneg hC hM, fun s hs => ?_⟩
  apply (ContinuousMap.norm_le _ (by positivity)).2
  intro t
  obtain ⟨x, rfl⟩ := flatProjection_surjective t
  calc
    _ ≤ C * (s ^ (-(1 + α)) * M) :=
      norm_realTorusCutoff_sub_le_of_holderDifferential hs hα hα₁ hC g.form Dg hg hDg x
    _ = _ := by ring

/-- A uniform Taylor remainder bound gives arbitrarily close smooth positive metrics
whose coefficients have finite Fourier support. The real cutoff preserves symmetry. -/
theorem TorusMetric.exists_smoothApproximation_of_remainder (g : TorusMetric d)
    {r C ε : ℝ} (hr : 0 < r) (hr₂ : r ≤ 2) (hε : 0 < ε)
    (hrem : ∀ x : Cover d, ∃ B : Cover d →L[ℝ] MetricForm d, ∀ y : Cover d,
      ‖g.form (flatProjection (x - y)) - g.form (flatProjection x) + B y‖ ≤ C * ‖y‖ ^ r) :
    ∃ scale : ℝ, 0 < scale ∧ ∃ G : TorusMetric d, ‖G.form - g.form‖ ≤ ε ∧
      HasFourierSupport (torusCutoffBand (d := d) scale : Set (d → ℤ)) G.form := by
  obtain ⟨m, hm, hmG⟩ := g.exists_lowerBound
  let K := ∫ y : Cover d, ‖cutoffKernel unitCutoffSymbol y‖ * ‖y‖ ^ r
  have hsmall : Tendsto (fun s : ℝ => C * (s ^ (-r) * K)) atTop (𝓝 0) := by
    simpa only [zero_mul, mul_zero] using ((tendsto_rpow_neg_atTop hr).mul_const K).const_mul C
  have hlimit := hsmall.eventually (gt_mem_nhds (lt_min hε (half_pos hm)))
  have hevent := hlimit.and (eventually_gt_atTop (0 : ℝ))
  obtain ⟨scale, hscale, hs⟩ := hevent.exists
  let f : C(UnitAddTorus d, MetricForm d) := realTorusCutoff (H := MetricForm d) scale g.form
  have hclose : ‖f - g.form‖ ≤ min ε (m / 2) := by
    apply (ContinuousMap.norm_le _ (le_min hε.le (half_pos hm).le)).2
    intro t
    obtain ⟨x, rfl⟩ := flatProjection_surjective t
    obtain ⟨B, hB⟩ := hrem x
    change ‖(realTorusCutoff scale g.form - g.form) (flatProjection x)‖ ≤ _
    rw [ContinuousMap.sub_apply, realTorusCutoff_lift_apply (H := MetricForm d) hs]
    have hI := integrable_realTorusCutoff_eval (H := MetricForm d) hs g.form (flatProjection x)
    simp only [← flatProjection_sub] at hI
    exact (norm_realCutoff_error_of_remainder (H := MetricForm d) (C := C) hs hr.le hr₂
      (fun z => g.form (flatProjection z)) B x hI hB).trans hscale.le
  let G : TorusMetric d :=
    { form := f
      symmetric := g.realTorusCutoff_symmetric hs
      positive := g.positive_of_close_form hm hmG f (hclose.trans (min_le_right _ _)) }
  exact ⟨scale, hs, G, hclose.trans (min_le_left _ _),
    hasFourierSupport_realTorusCutoff (H := MetricForm d) hs g.form⟩

end

end IsometricEmbeddingEndpoints

#print axioms IsometricEmbeddingEndpoints.TorusMetric.exists_smoothApproximation_of_remainder
#print axioms IsometricEmbeddingEndpoints.TorusMetric.exists_cutoffRate_of_holder
#print axioms IsometricEmbeddingEndpoints.TorusMetric.exists_cutoffRate_of_holderDifferential
