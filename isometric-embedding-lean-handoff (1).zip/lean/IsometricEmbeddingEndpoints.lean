import Mathlib.Analysis.Calculus.SmoothSeries
import Mathlib.Analysis.InnerProductSpace.Continuous
import Mathlib.Analysis.Normed.Operator.Bilinear
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Analysis.SpecialFunctions.Pow.Real
import Mathlib.Tactic.GCongr
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.Module.ContinuousLinearMap.Basic

open Filter Finset Topology

namespace IsometricEmbeddingEndpoints

private theorem geometricDecay {L θ : ℝ} (hL : 1 < L) (hθ : 0 < θ) :
    0 < L ^ (-θ) ∧ L ^ (-θ) < 1 := by
  have hpos : 0 < L := zero_lt_one.trans hL
  exact ⟨Real.rpow_pos_of_pos hpos _, Real.rpow_lt_one_of_one_lt_of_neg hL (neg_neg_of_pos hθ)⟩

/-- The cutoff sum used for the exact Hölder exponent, with no exponent loss. -/
theorem cutoffSum_le {L θ d : ℝ} (hL : 1 < L) (hθ : 0 < θ) (hθ₁ : θ < 1)
    (hd : 0 ≤ d) :
    (∑' j : ℕ, (L ^ (-θ)) ^ j * min 1 (d * L ^ j)) ≤
      ((L ^ (1 - θ) - 1)⁻¹ + L ^ θ * (1 - L ^ (-θ))⁻¹) * d ^ θ := by
  let q := L ^ (-θ)
  let p := L ^ (1 - θ)
  let f : ℕ → ℝ := fun j => q ^ j * min 1 (d * L ^ j)
  change (∑' j, f j) ≤ ((p - 1)⁻¹ + L ^ θ * (1 - q)⁻¹) * d ^ θ
  have hL0 : 0 < L := zero_lt_one.trans hL
  obtain ⟨hq0, hq1⟩ := geometricDecay hL hθ
  have hp1 : 1 < p := Real.one_lt_rpow hL (sub_pos.mpr hθ₁)
  have hpq : q * L = p := by
    calc
      q * L = L ^ (-θ) * L ^ (1 : ℝ) := by simp [q]
      _ = L ^ (-θ + 1) := (Real.rpow_add hL0 _ _).symm
      _ = p := by congr 1; ring
  have hf0 (j : ℕ) : 0 ≤ f j := by
    exact mul_nonneg (pow_nonneg hq0.le _) (le_min one_pos.le (mul_nonneg hd (pow_nonneg hL0.le _)))
  have hfb (j : ℕ) : f j ≤ q ^ j := by
    exact mul_le_of_le_one_right (pow_nonneg hq0.le _) (min_le_left _ _)
  have hqsum : Summable fun j : ℕ => q ^ j := summable_geometric_of_lt_one hq0.le hq1
  have hfsum : Summable f := Summable.of_nonneg_of_le hf0 hfb hqsum
  have hinv0 : 0 ≤ (1 - q)⁻¹ := inv_nonneg.mpr (sub_pos.mpr hq1).le
  by_cases hd0 : d = 0
  · simp [f, hd0, Real.zero_rpow hθ.ne']
  have hdpos : 0 < d := lt_of_le_of_ne hd (Ne.symm hd0)
  by_cases hlarge : 1 ≤ d
  · calc
      (∑' j, f j) ≤ ∑' j : ℕ, q ^ j := hfsum.tsum_le_tsum hfb hqsum
      _ = (1 - q)⁻¹ := tsum_geometric_of_lt_one hq0.le hq1
      _ ≤ ((p - 1)⁻¹ + L ^ θ * (1 - q)⁻¹) * d ^ θ := by
        have hLθ : 1 ≤ L ^ θ := Real.one_le_rpow hL.le hθ.le
        have hdθ : 1 ≤ d ^ θ := Real.one_le_rpow hlarge hθ.le
        have hp0 : 0 ≤ (p - 1)⁻¹ := inv_nonneg.mpr (sub_pos.mpr hp1).le
        calc
          (1 - q)⁻¹ ≤ L ^ θ * (1 - q)⁻¹ := le_mul_of_one_le_left hinv0 hLθ
          _ ≤ (p - 1)⁻¹ + L ^ θ * (1 - q)⁻¹ := le_add_of_nonneg_left hp0
          _ ≤ ((p - 1)⁻¹ + L ^ θ * (1 - q)⁻¹) * d ^ θ :=
            le_mul_of_one_le_right (add_nonneg hp0 (mul_nonneg (zero_le_one.trans hLθ) hinv0)) hdθ
  · have hdlt : d < 1 := lt_of_not_ge hlarge
    obtain ⟨m, hm, hm'⟩ := exists_nat_pow_near ((one_le_inv₀ hdpos).mpr hdlt.le) hL
    have hp_pow : p ^ m = (L ^ m) ^ (1 - θ) := by
      dsimp [p]
      rw [← Real.rpow_natCast_mul hL0.le, mul_comm (m : ℝ), Real.rpow_mul_natCast hL0.le]
    have hq_pow : q ^ m = ((L ^ m)⁻¹) ^ θ := by
      dsimp [q]
      rw [← Real.rpow_mul_natCast hL0.le, mul_comm (-θ) (m : ℝ),
        Real.rpow_natCast_mul hL0.le, Real.rpow_neg (pow_nonneg hL0.le _),
        Real.inv_rpow (pow_nonneg hL0.le _)]
    have hfront : d * p ^ m ≤ d ^ θ := by
      calc
        d * p ^ m = d * (L ^ m) ^ (1 - θ) := by rw [hp_pow]
        _ ≤ d * (d⁻¹) ^ (1 - θ) :=
          mul_le_mul_of_nonneg_left (Real.rpow_le_rpow (pow_nonneg hL0.le _) hm (sub_nonneg.mpr hθ₁.le)) hd
        _ = d ^ θ := by
          calc
            d * (d⁻¹) ^ (1 - θ) = d ^ (1 : ℝ) * d ^ (-(1 - θ)) := by
              rw [Real.rpow_one, Real.inv_rpow hd, Real.rpow_neg hd]
            _ = d ^ ((1 : ℝ) + -(1 - θ)) := (Real.rpow_add hdpos _ _).symm
            _ = d ^ θ := by congr 1; ring
    have htail : q ^ m ≤ L ^ θ * d ^ θ := by
      have hPow : 0 < L ^ m := pow_pos hL0 _
      have hone : 1 ≤ L ^ (m + 1) * d := (inv_le_iff_one_le_mul₀ hdpos).mp hm'.le
      have hscale : (L ^ m)⁻¹ ≤ L * d := by
        apply (inv_le_iff_one_le_mul₀ hPow).mpr
        simpa [pow_succ, mul_comm, mul_left_comm, mul_assoc] using hone
      rw [hq_pow, ← Real.mul_rpow hL0.le hd]
      exact Real.rpow_le_rpow (inv_nonneg.mpr hPow.le) hscale hθ.le
    have hprefix : (∑ j ∈ range m, f j) ≤ (p - 1)⁻¹ * d ^ θ := by
      calc
        (∑ j ∈ range m, f j) ≤ ∑ j ∈ range m, d * p ^ j := by
          apply sum_le_sum
          intro j _
          calc
            f j ≤ q ^ j * (d * L ^ j) :=
              mul_le_mul_of_nonneg_left (min_le_right _ _) (pow_nonneg hq0.le _)
            _ = d * p ^ j := by rw [mul_left_comm, ← mul_pow, hpq]
        _ = d * ((p ^ m - 1) / (p - 1)) := by
          rw [← mul_sum, geom_sum_eq hp1.ne']
        _ ≤ d * (p ^ m / (p - 1)) :=
          mul_le_mul_of_nonneg_left (div_le_div_of_nonneg_right (sub_le_self _ zero_le_one) (sub_pos.mpr hp1).le) hd
        _ = (p - 1)⁻¹ * (d * p ^ m) := by ring
        _ ≤ (p - 1)⁻¹ * d ^ θ :=
          mul_le_mul_of_nonneg_left hfront (inv_nonneg.mpr (sub_pos.mpr hp1).le)
    have hrest : (∑' j : ℕ, f (j + m)) ≤ (L ^ θ * (1 - q)⁻¹) * d ^ θ := by
      have hshift : Summable fun j : ℕ => q ^ (j + m) := by
        simp only [pow_add]
        exact hqsum.mul_right _
      calc
        (∑' j : ℕ, f (j + m)) ≤ ∑' j : ℕ, q ^ (j + m) :=
          (hfsum.comp_injective (add_left_injective m)).tsum_le_tsum (fun j => hfb (j + m)) hshift
        _ = (1 - q)⁻¹ * q ^ m := by
          simp only [pow_add, tsum_mul_right]
          rw [tsum_geometric_of_lt_one hq0.le hq1]
        _ ≤ (1 - q)⁻¹ * (L ^ θ * d ^ θ) := mul_le_mul_of_nonneg_left htail hinv0
        _ = (L ^ θ * (1 - q)⁻¹) * d ^ θ := by ring
    rw [← hfsum.sum_add_tsum_nat_add m, add_mul]
    exact add_le_add hprefix hrest

/-- Summing geometrically decaying increments preserves the critical exponent. -/
theorem holder_tsum_of_geometric {X F : Type*} [PseudoMetricSpace X]
    [NormedAddCommGroup F] [CompleteSpace F]
    {L θ A : ℝ} (hL : 1 < L) (hθ : 0 < θ) (hθ₁ : θ < 1) (hA : 0 ≤ A)
    (v : ℕ → X → F)
    (hsmall : ∀ j x, ‖v j x‖ ≤ A * (L ^ (-θ)) ^ j)
    (hlip : ∀ j x y, ‖v j x - v j y‖ ≤ A * (L ^ (1 - θ)) ^ j * dist x y) :
    ∃ K : ℝ, 0 ≤ K ∧ ∀ x y,
      ‖(∑' j, v j x) - (∑' j, v j y)‖ ≤ K * dist x y ^ θ := by
  let q := L ^ (-θ)
  let p := L ^ (1 - θ)
  have hL0 : 0 < L := zero_lt_one.trans hL
  obtain ⟨hq0, hq1⟩ := geometricDecay hL hθ
  have hp1 : 1 < p := Real.one_lt_rpow hL (sub_pos.mpr hθ₁)
  have hpq : p = q * L := by
    calc
      p = L ^ (-θ + 1) := by
        dsimp [p]
        congr 1
        ring
      _ = L ^ (-θ) * L ^ (1 : ℝ) := Real.rpow_add hL0 _ _
      _ = q * L := by simp [q]
  have hqsum : Summable fun j : ℕ => q ^ j := summable_geometric_of_lt_one hq0.le hq1
  have hvsum (x : X) : Summable fun j => v j x :=
    Summable.of_norm_bounded (hqsum.mul_left A) (fun j => hsmall j x)
  let C := (p - 1)⁻¹ + L ^ θ * (1 - q)⁻¹
  have hC : 0 ≤ C := by
    exact add_nonneg (inv_nonneg.mpr (sub_nonneg.mpr hp1.le))
      (mul_nonneg (Real.rpow_nonneg hL0.le _) (inv_nonneg.mpr (sub_nonneg.mpr hq1.le)))
  refine ⟨2 * A * C, mul_nonneg (mul_nonneg (by norm_num) hA) hC, ?_⟩
  intro x y
  let d := dist x y
  let b : ℕ → ℝ := fun j => q ^ j * min 1 (d * L ^ j)
  have hbsum : Summable b :=
    Summable.of_nonneg_of_le
      (fun j => mul_nonneg (pow_nonneg hq0.le _) (le_min zero_le_one (by positivity)))
      (fun j => mul_le_of_le_one_right (pow_nonneg hq0.le _) (min_le_left _ _)) hqsum
  have hbound (j : ℕ) : ‖v j x - v j y‖ ≤ (2 * A) * b j := by
    have hfirst : ‖v j x - v j y‖ ≤ (2 * A * q ^ j) * 1 := by
      calc
        ‖v j x - v j y‖ ≤ ‖v j x‖ + ‖v j y‖ := norm_sub_le _ _
        _ ≤ A * q ^ j + A * q ^ j := add_le_add (hsmall j x) (hsmall j y)
        _ = (2 * A * q ^ j) * 1 := by ring
    have hsecond : ‖v j x - v j y‖ ≤ (2 * A * q ^ j) * (d * L ^ j) := by
      calc
        ‖v j x - v j y‖ ≤ A * p ^ j * d := hlip j x y
        _ ≤ (2 * A) * p ^ j * d := by
          gcongr
          linarith
        _ = (2 * A * q ^ j) * (d * L ^ j) := by rw [hpq, mul_pow]; ring
    dsimp [b]
    rw [← mul_assoc, mul_min_of_nonneg _ _ (by positivity : 0 ≤ 2 * A * q ^ j)]
    exact le_min hfirst hsecond
  calc
    ‖(∑' j, v j x) - (∑' j, v j y)‖ = ‖∑' j, (v j x - v j y)‖ := by
      rw [Summable.tsum_sub (hvsum x) (hvsum y)]
    _ ≤ (2 * A) * (∑' j, b j) := tsum_of_norm_bounded (hbsum.hasSum.mul_left _) hbound
    _ ≤ (2 * A) * (C * d ^ θ) :=
      mul_le_mul_of_nonneg_left (cutoffSum_le hL hθ hθ₁ (show 0 ≤ d from dist_nonneg))
        (show 0 ≤ 2 * A by positivity)
    _ = (2 * A * C) * d ^ θ := (mul_assoc _ _ _).symm

/-- Pointwise limits of differentials preserve the induced metric when the metrics converge. -/
theorem inner_of_tendsto_differentials {E F : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E]
    [NormedAddCommGroup F] [InnerProductSpace ℝ F]
    {D : ℕ → ContinuousLinearMap (RingHom.id ℝ) E F}
    {limit : ContinuousLinearMap (RingHom.id ℝ) E F}
    (hD : Tendsto D atTop (𝓝 limit)) (a b : E) {g : ℝ}
    (hg : Tendsto (fun n => inner ℝ (D n a) (D n b)) atTop (𝓝 g)) :
    inner ℝ (limit a) (limit b) = g := by
  have happly (z : E) : Tendsto (fun n => D n z) atTop (𝓝 (limit z)) :=
    ((ContinuousLinearMap.apply ℝ F z).continuous.tendsto limit).comp hD
  exact tendsto_nhds_unique ((happly a).inner (happly b)) hg

end IsometricEmbeddingEndpoints

#print axioms IsometricEmbeddingEndpoints.cutoffSum_le
#print axioms IsometricEmbeddingEndpoints.holder_tsum_of_geometric
#print axioms IsometricEmbeddingEndpoints.inner_of_tendsto_differentials
