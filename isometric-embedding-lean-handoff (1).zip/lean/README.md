# 闭流形上的 Hölder 等距嵌入

设 $M$ 是任意有限维的紧致无边界光滑流形，$g$ 是其上的正定 Riemann 度量。下面的定理给出到某个有限维欧氏空间的全局嵌入 $u$，满足 $u^*e=g$。

| 度量 $g$ | 嵌入 $u$ | Lean 定理（`IsometricEmbeddingEndpoints` 命名空间） |
| --- | --- | --- |
| $C^{0,a}$，$0\le a\le1$ | $C^{1,a/2}$ | `exists_holder_isometricEmbedding` |
| $C^{1,a}$，$0\le a<1$ | $C^{1,(1+a)/2}$ | `exists_holderDifferential_isometricEmbedding` |

以 `import ClosedManifoldEndpoints` 使用两条定理。维数写成 `d : ℕ`。度量采用 Mathlib 的 Riemann 度量，坐标中的度量由逆图的微分拉回。$a=0$ 分别给出连续度量的 $C^1$ 等距嵌入和 $C^1$ 度量的 $C^{1,1/2}$ 等距嵌入。[公开定义](ClosedManifoldStatement.lean) · [数学审核](REVIEW.md)

闭流形拼接、环面迭代和共用引理见 [证明拆分](PROOF-TREE.md)。证明正文另附于 [中文证明稿](../isometric-embedding-endpoints-proof-cn.pdf)。

## 构建与审计

使用 `lean-toolchain` 固定的 Lean 4.36.0 和 `lake-manifest.json` 固定的 Mathlib。在本目录运行以下命令。

```sh
lake exe cache get
lake build IsometricEmbeddingEndpoints Challenge
lake env lean Audit.lean
```

[Audit.lean](Audit.lean) 检查闭曲面上两族的 $a=0$ 和第一族的 $a=1$，并打印两条定理依赖的公理。

## Comparator 与独立内核

[Challenge.lean](Challenge.lean) 只导入公开定义，单独声明两条待证明的命题。[comparator.json](comparator.json) 比对两条定理及其依赖的定义，并确认两条证明仅使用许可公理。Linux 上安装 Bubblewrap 后运行以下命令。

```sh
lake comparator --paranoid
```

`--paranoid` 使用本工具链所带的 Nanoda、Lean4Lean、leanchecker-paranoid、con-leche 和 con-ron 复核导出的证明，再用 Lean 内核复核。在 macOS 上复核这份本地源码，使用 `lake comparator --paranoid --inadvisably-no-sandbox`。这个开关关闭进程隔离。[Lean 的验证文档](https://lean-lang.org/doc/reference/latest/ValidatingProofs/) · [OpenAI 陈述与证明的分离方式](https://github.com/openai/math/blob/main/lean/ComparatorChallenges/README.md)

本机的构建与检查结果见 [验收记录](VERIFICATION.log)。
