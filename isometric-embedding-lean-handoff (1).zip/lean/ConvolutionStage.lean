import Mathlib.Analysis.Calculus.ParametricIntegral
import Mathlib.Analysis.InnerProductSpace.Dual
import Mathlib.MeasureTheory.Integral.Bochner.ContinuousLinearMap
import Mathlib.Tactic.Ring

namespace IsometricEmbeddingEndpoints

open MeasureTheory

noncomputable section

variable {Ω H : Type*} [MeasurableSpace Ω] [NormedAddCommGroup H] [InnerProductSpace ℝ H]
  [CompleteSpace H] {ν : Measure Ω}

/-- The scalar commutator with a convolution at a fixed evaluation point. -/
theorem inner_integral_sub_weighted_inner (k : Ω → ℝ) (p₀ : H) (p A : Ω → H)
    (hA : Integrable (fun y => k y • A y) ν)
    (hpA : Integrable (fun y => k y * inner ℝ (p y) (A y)) ν) :
    inner ℝ p₀ (∫ y, k y • A y ∂ν) - (∫ y, k y * inner ℝ (p y) (A y) ∂ν) =
      ∫ y, k y * inner ℝ (p₀ - p y) (A y) ∂ν := by
  have h₁ : Integrable (fun y => k y * inner ℝ p₀ (A y)) ν := by
    simpa only [innerSL_apply_apply, inner_smul_right, smul_eq_mul] using
      (innerSL ℝ p₀).integrable_comp hA
  have heq : (∫ y, k y * inner ℝ p₀ (A y) ∂ν) = inner ℝ p₀ (∫ y, k y • A y ∂ν) := by
    simpa only [innerSL_apply_apply, inner_smul_right, smul_eq_mul] using
      (innerSL ℝ p₀).integral_comp_comm hA
  rw [← heq, ← integral_sub h₁ hpA]
  apply integral_congr_ae
  exact Filter.Eventually.of_forall (fun y => by simp only [inner_sub_left, mul_sub])

/-- The commutator bound only needs the first absolute moment of the kernel. -/
theorem abs_weighted_commutator_le (k ρ : Ω → ℝ) (p₀ : H) (p A : Ω → H) {L M : ℝ}
    (hA : Integrable (fun y => k y • A y) ν)
    (hpA : Integrable (fun y => k y * inner ℝ (p y) (A y)) ν)
    (hmoment : Integrable (fun y => |k y| * ρ y) ν)
    (hp : ∀ᵐ y ∂ν, ‖p₀ - p y‖ ≤ L * ρ y)
    (hbound : ∀ᵐ y ∂ν, ‖A y‖ ≤ M) :
    |inner ℝ p₀ (∫ y, k y • A y ∂ν) - (∫ y, k y * inner ℝ (p y) (A y) ∂ν)| ≤
      (L * M) * ∫ y, |k y| * ρ y ∂ν := by
  rw [inner_integral_sub_weighted_inner k p₀ p A hA hpA, ← Real.norm_eq_abs,
    ← integral_const_mul]
  refine norm_integral_le_of_norm_le (hmoment.const_mul (L * M)) ?_
  filter_upwards [hp, hbound] with y hpy hAy
  rw [Real.norm_eq_abs, abs_mul]
  calc
    |k y| * |inner ℝ (p₀ - p y) (A y)| ≤ |k y| * (‖p₀ - p y‖ * ‖A y‖) :=
      mul_le_mul_of_nonneg_left (abs_real_inner_le_norm _ _) (abs_nonneg _)
    _ ≤ |k y| * ((L * ρ y) * M) :=
      mul_le_mul_of_nonneg_left
        (mul_le_mul hpy hAy (norm_nonneg _) ((norm_nonneg _).trans hpy)) (abs_nonneg _)
    _ = (L * M) * (|k y| * ρ y) := by ring

/-- The filtered tangent term, controlling the local pairing separately from the commutator. -/
theorem abs_weighted_tangent_le (k ρ : Ω → ℝ) (p₀ : H) (p A : Ω → H) {L M R : ℝ}
    (hA : Integrable (fun y => k y • A y) ν)
    (hpA : Integrable (fun y => k y * inner ℝ (p y) (A y)) ν)
    (hmass : Integrable (fun y => |k y|) ν)
    (hmoment : Integrable (fun y => |k y| * ρ y) ν)
    (hp : ∀ᵐ y ∂ν, ‖p₀ - p y‖ ≤ L * ρ y)
    (hbound : ∀ᵐ y ∂ν, ‖A y‖ ≤ M)
    (htangent : ∀ᵐ y ∂ν, |inner ℝ (p y) (A y)| ≤ R) :
    |inner ℝ p₀ (∫ y, k y • A y ∂ν)| ≤
      (L * M) * (∫ y, |k y| * ρ y ∂ν) + R * (∫ y, |k y| ∂ν) := by
  let a := inner ℝ p₀ (∫ y, k y • A y ∂ν)
  let b := ∫ y, k y * inner ℝ (p y) (A y) ∂ν
  have hb : |b| ≤ R * (∫ y, |k y| ∂ν) := by
    dsimp only [b]
    rw [← Real.norm_eq_abs, ← integral_const_mul]
    refine norm_integral_le_of_norm_le (hmass.const_mul R) ?_
    filter_upwards [htangent] with y hy
    rw [Real.norm_eq_abs, abs_mul, mul_comm R]
    exact mul_le_mul_of_nonneg_left hy (abs_nonneg _)
  calc
    |a| = |(a - b) + b| := by rw [sub_add_cancel]
    _ ≤ |a - b| + |b| := abs_add_le _ _
    _ ≤ _ := add_le_add (abs_weighted_commutator_le k ρ p₀ p A hA hpA hmoment hp hbound) hb

/-- The operator-norm estimates give the cross term consumed by the pointwise Gram estimate. -/
theorem abs_weighted_differential_le {E : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E]
    (k ρ : Ω → ℝ) (F₀ D : E →L[ℝ] H) (F A : Ω → E →L[ℝ] H) {L M R : ℝ}
    (hD : ∀ w, D w = ∫ y, k y • A y w ∂ν)
    (hA : ∀ w, Integrable (fun y => k y • A y w) ν)
    (hFA : ∀ v w, Integrable (fun y => k y * inner ℝ (F y v) (A y w)) ν)
    (hmass : Integrable (fun y => |k y|) ν)
    (hmoment : Integrable (fun y => |k y| * ρ y) ν)
    (hp : ∀ᵐ y ∂ν, ‖F₀ - F y‖ ≤ L * ρ y)
    (hbound : ∀ᵐ y ∂ν, ‖A y‖ ≤ M)
    (htangent : ∀ v w, ∀ᵐ y ∂ν, |inner ℝ (F y v) (A y w)| ≤ R * (‖v‖ * ‖w‖))
    (v w : E) :
    |inner ℝ (F₀ v) (D w)| ≤
      ((L * M) * (∫ y, |k y| * ρ y ∂ν) + R * (∫ y, |k y| ∂ν)) * (‖v‖ * ‖w‖) := by
  have hpv : ∀ᵐ y ∂ν, ‖F₀ v - F y v‖ ≤ (L * ‖v‖) * ρ y := by
    filter_upwards [hp] with y hy
    calc
      ‖F₀ v - F y v‖ ≤ ‖F₀ - F y‖ * ‖v‖ := ContinuousLinearMap.le_opNorm _ _
      _ ≤ (L * ρ y) * ‖v‖ := mul_le_mul_of_nonneg_right hy (norm_nonneg _)
      _ = _ := by ring
  have hAw : ∀ᵐ y ∂ν, ‖A y w‖ ≤ M * ‖w‖ := by
    filter_upwards [hbound] with y hy
    exact (ContinuousLinearMap.le_opNorm _ _).trans (mul_le_mul_of_nonneg_right hy (norm_nonneg _))
  rw [hD]
  refine (abs_weighted_tangent_le k ρ (F₀ v) (fun y => F y v) (fun y => A y w)
    (hA w) (hFA v w) hmass hmoment hpv hAw (htangent v w)).trans_eq ?_
  ring

/-- For an integrable kernel, a uniformly bounded differential can be passed under translation
and integration. No compact support of the kernel is required. -/
theorem hasFDerivAt_weighted_translate {E Y : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E]
    [NormedAddCommGroup Y] [NormedSpace ℝ Y]
    [MeasurableSpace E] {μ : Measure E}
    (k : E → ℝ) (V : E → Y) (DV : E → E →L[ℝ] Y) {M : ℝ}
    (hk : Integrable k μ)
    (hV : ∀ x, Integrable (fun y => k y • V (x - y)) μ)
    (hDVmeas : ∀ x, AEStronglyMeasurable (fun y => k y • DV (x - y)) μ)
    (hDV : ∀ x, HasFDerivAt V (DV x) x)
    (hbound : ∀ x, ‖DV x‖ ≤ M) (x : E) :
    HasFDerivAt (fun z => ∫ y, k y • V (z - y) ∂μ) (∫ y, k y • DV (x - y) ∂μ) x := by
  refine hasFDerivAt_integral_of_dominated_of_fderiv_le
    (F := fun z y => k y • V (z - y)) (F' := fun z y => k y • DV (z - y))
    (s := Set.univ) (bound := fun y => ‖k y‖ * M) Filter.univ_mem
    (Filter.Eventually.of_forall fun z => (hV z).aestronglyMeasurable)
    (hV x) (hDVmeas x) ?_ (hk.norm.mul_const M) ?_
  · filter_upwards with y z _
    simpa only [norm_smul] using mul_le_mul_of_nonneg_left (hbound (z - y)) (norm_nonneg (k y))
  · filter_upwards with y z _
    have hshift := hasFDerivAt_sub_const (𝕜 := ℝ) (x := z) y
    change HasFDerivAt (k y • (V ∘ fun q => q - y)) (k y • DV (z - y)) z
    simpa only [ContinuousLinearMap.comp_id] using
      ((hDV (z - y)).comp z hshift).const_smul (k y)

/-- The pointwise derivative form used as input to `abs_weighted_differential_le`. -/
theorem fderiv_weighted_translate_apply {E Y : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E]
    [NormedAddCommGroup Y] [NormedSpace ℝ Y]
    [MeasurableSpace E] {μ : Measure E}
    (k : E → ℝ) (V : E → Y) (DV : E → E →L[ℝ] Y) {M : ℝ}
    (hk : Integrable k μ)
    (hV : ∀ x, Integrable (fun y => k y • V (x - y)) μ)
    (hDVmeas : ∀ x, AEStronglyMeasurable (fun y => k y • DV (x - y)) μ)
    (hDV : ∀ x, HasFDerivAt V (DV x) x)
    (hbound : ∀ x, ‖DV x‖ ≤ M) (x w : E) :
    fderiv ℝ (fun z => ∫ y, k y • V (z - y) ∂μ) x w =
      ∫ y, k y • (DV (x - y) w) ∂μ := by
  rw [(hasFDerivAt_weighted_translate k V DV hk hV hDVmeas hDV hbound x).fderiv]
  have hi : Integrable (fun y => k y • DV (x - y)) μ := by
    refine (hk.norm.mul_const M).mono' (hDVmeas x) ?_
    filter_upwards with y
    rw [norm_smul]
    exact mul_le_mul_of_nonneg_left (hbound (x - y)) (norm_nonneg _)
  rw [ContinuousLinearMap.integral_apply hi]
  rfl

end

end IsometricEmbeddingEndpoints

#print axioms IsometricEmbeddingEndpoints.abs_weighted_commutator_le
#print axioms IsometricEmbeddingEndpoints.abs_weighted_tangent_le
#print axioms IsometricEmbeddingEndpoints.abs_weighted_differential_le
#print axioms IsometricEmbeddingEndpoints.fderiv_weighted_translate_apply
