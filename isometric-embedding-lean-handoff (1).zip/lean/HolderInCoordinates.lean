import EmbeddingCoordinates
import Mathlib.Analysis.Calculus.ContDiff.Comp
import Mathlib.Analysis.Calculus.MeanValue
import Mathlib.Analysis.Normed.Group.Bounded
import Mathlib.Analysis.SpecialFunctions.Pow.Real

namespace IsometricEmbeddingEndpoints

noncomputable section

variable {E F G : Type*}
  [NormedAddCommGroup E] [NormedSpace ℝ E]
  [NormedAddCommGroup F] [NormedSpace ℝ F]
  [NormedAddCommGroup G] [NormedSpace ℝ G]

theorem exists_lipschitz_bound_on (f : E → F) {s : Set E} (hs : IsCompact s)
    (hconv : Convex ℝ s) (hf : ∀ x ∈ s, ContDiffAt ℝ 1 f x) :
    ∃ L : ℝ, 0 ≤ L ∧ ∀ x ∈ s, ∀ y ∈ s, ‖f x - f y‖ ≤ L * ‖x - y‖ := by
  obtain ⟨M, hM⟩ := hs.exists_bound_of_continuousOn (f := fderiv ℝ f)
    (fun x hx => ((hf x hx).continuousAt_fderiv one_ne_zero).continuousWithinAt)
  refine ⟨max M 0, le_max_right _ _, fun x hx y hy => ?_⟩
  exact hconv.norm_image_sub_le_of_norm_fderiv_le
    (fun z hz => (hf z hz).differentiableAt one_ne_zero)
    (fun z hz => (hM z hz).trans (le_max_left _ _)) hy hx

theorem exists_holder_bound_on_of_contDiffAt_one {s : Set E} {f : E → F}
    (hs : IsCompact s) (hconv : Convex ℝ s) (hf : ∀ x ∈ s, ContDiffAt ℝ 1 f x)
    {a : ℝ} (ha : 0 ≤ a) (ha₁ : a ≤ 1) :
    ∃ C : ℝ, 0 ≤ C ∧ ∀ x ∈ s, ∀ y ∈ s, ‖f x - f y‖ ≤ C * ‖x - y‖ ^ a := by
  obtain ⟨L, hL, hLip⟩ := exists_lipschitz_bound_on f hs hconv hf
  obtain ⟨B, hB⟩ := hs.exists_bound_of_continuousOn (f := f)
    (fun x hx => (hf x hx).continuousAt.continuousWithinAt)
  let M := max B 0
  have hM : 0 ≤ M := le_max_right _ _
  refine ⟨2 * M + L, by positivity, fun x hx y hy => ?_⟩
  by_cases hxy : ‖x - y‖ ≤ 1
  · have hpow : ‖x - y‖ ≤ ‖x - y‖ ^ a := by
      simpa only [Real.rpow_one] using
        Real.rpow_le_rpow_of_exponent_ge' (norm_nonneg (x - y)) hxy ha ha₁
    exact (hLip x hx y hy).trans ((mul_le_mul_of_nonneg_left hpow hL).trans
      (mul_le_mul_of_nonneg_right (by linarith) (Real.rpow_nonneg (norm_nonneg _) _)))
  · calc
      _ ≤ ‖f x‖ + ‖f y‖ := norm_sub_le _ _
      _ ≤ 2 * M := by
        rw [two_mul]
        exact add_le_add ((hB _ hx).trans (le_max_left _ _)) ((hB _ hy).trans (le_max_left _ _))
      _ ≤ 2 * M + L := le_add_of_nonneg_right hL
      _ ≤ _ := le_mul_of_one_le_right (by positivity) (Real.one_le_rpow (le_of_not_ge hxy) ha)

theorem hasHolderDifferentialOn_of_contDiffAt_two {f : E → F} {s : Set E}
    (hs : IsCompact s) (hconv : Convex ℝ s) (hf : ∀ x ∈ s, ContDiffAt ℝ 2 f x)
    {a : ℝ} (ha : 0 ≤ a) (ha₁ : a ≤ 1) : HasHolderDifferentialOn a f s := by
  have hD (x : E) (hx : x ∈ s) : ContDiffAt ℝ 1 (fderiv ℝ f) x :=
    (hf x hx).fderiv_right (by norm_num)
  exact ⟨fun x hx => (hf x hx).of_le (by norm_num),
    exists_holder_bound_on_of_contDiffAt_one hs hconv hD ha ha₁⟩

/-- The chain rule preserves the exponent on a compact convex set in coordinates. -/
theorem HasHolderDifferentialOn.comp {f : F → G} {g : E → F} {s : Set E} {t : Set F}
    {a : ℝ} (hf : HasHolderDifferentialOn a f t) (hg : HasHolderDifferentialOn a g s)
    (hmaps : Set.MapsTo g s t) (hs : IsCompact s) (hconv : Convex ℝ s) (ha : 0 ≤ a) :
    HasHolderDifferentialOn a (f ∘ g) s := by
  obtain ⟨hF, C, hC, hCF⟩ := hf
  obtain ⟨hG, K, hK, hKG⟩ := hg
  obtain ⟨L, hL, hLip⟩ := exists_lipschitz_bound_on g hs hconv hG
  let A := fderiv ℝ f ∘ g
  let B := fderiv ℝ g
  have hFc : ContinuousOn (fderiv ℝ f) t :=
    fun y hy => ((hF y hy).continuousAt_fderiv one_ne_zero).continuousWithinAt
  have hGc : ContinuousOn g s := fun x hx => (hG x hx).continuousAt.continuousWithinAt
  have hAcon : ContinuousOn A s := hFc.comp hGc hmaps
  obtain ⟨N₀, hN₀⟩ := hs.exists_bound_of_continuousOn hAcon
  obtain ⟨M₀, hM₀⟩ := hs.exists_bound_of_continuousOn (f := B)
    (fun x hx => ((hG x hx).continuousAt_fderiv one_ne_zero).continuousWithinAt)
  let N := max N₀ 0
  let M := max M₀ 0
  have hN : 0 ≤ N := le_max_right _ _
  have hM : 0 ≤ M := le_max_right _ _
  have hA (x : E) (hx : x ∈ s) (y : E) (hy : y ∈ s) :
      ‖A x - A y‖ ≤ C * L ^ a * ‖x - y‖ ^ a := by
    calc
      _ ≤ C * ‖g x - g y‖ ^ a := hCF _ (hmaps hx) _ (hmaps hy)
      _ ≤ C * (L * ‖x - y‖) ^ a :=
        mul_le_mul_of_nonneg_left (Real.rpow_le_rpow (norm_nonneg _) (hLip x hx y hy) ha) hC
      _ = _ := by rw [Real.mul_rpow hL (norm_nonneg _), mul_assoc]
  have hD (x : E) (hx : x ∈ s) : fderiv ℝ (f ∘ g) x = (A x).comp (B x) :=
    fderiv_comp x ((hF _ (hmaps hx)).differentiableAt one_ne_zero)
      ((hG x hx).differentiableAt one_ne_zero)
  refine ⟨fun x hx => (hF _ (hmaps hx)).comp x (hG x hx),
    C * L ^ a * M + N * K, by positivity, fun x hx y hy => ?_⟩
  rw [hD x hx, hD y hy]
  have heq : (A x).comp (B x) - (A y).comp (B y) =
      (A x - A y).comp (B x) + (A y).comp (B x - B y) := by
    ext z
    simp only [ContinuousLinearMap.comp_apply, ContinuousLinearMap.sub_apply,
      ContinuousLinearMap.add_apply, map_sub]
    abel
  rw [heq]
  calc
    _ ≤ ‖(A x - A y).comp (B x)‖ + ‖(A y).comp (B x - B y)‖ := norm_add_le _ _
    _ ≤ ‖A x - A y‖ * ‖B x‖ + ‖A y‖ * ‖B x - B y‖ :=
      add_le_add (ContinuousLinearMap.opNorm_comp_le _ _) (ContinuousLinearMap.opNorm_comp_le _ _)
    _ ≤ (C * L ^ a * ‖x - y‖ ^ a) * M + N * (K * ‖x - y‖ ^ a) := by
      gcongr
      · exact hA x hx y hy
      · exact (hM₀ x hx).trans (le_max_left _ _)
      · exact (hN₀ y hy).trans (le_max_left _ _)
      · exact hKG x hx y hy
    _ = _ := by ring

end

end IsometricEmbeddingEndpoints

#print axioms IsometricEmbeddingEndpoints.HasHolderDifferentialOn.comp
