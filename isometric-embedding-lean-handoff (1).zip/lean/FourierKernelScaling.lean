import FourierCutoff
import Mathlib.MeasureTheory.Measure.Haar.NormedSpace
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.Ring

namespace IsometricEmbeddingEndpoints

open MeasureTheory
open scoped FourierTransform ComplexConjugate Topology

noncomputable section

variable {V : Type*} [NormedAddCommGroup V] [InnerProductSpace ℝ V] [FiniteDimensional ℝ V]
  [MeasurableSpace V] [BorelSpace V]

/-- The inverse transform of the real even symbol takes real values. -/
theorem unitCutoffKernel_conj (x : V) :
    conj (cutoffKernel (unitCutoffSymbol (V := V)) x) =
      cutoffKernel (unitCutoffSymbol (V := V)) x := by
  let χ := unitCutoffSymbol (V := V)
  change conj (cutoffKernel χ x) = cutoffKernel χ x
  simp only [cutoffKernel, SchwartzMap.fourierInv_coe, Real.fourierInv_eq', ← integral_conj]
  let f : V → ℂ := fun y => Complex.exp ((↑(2 * Real.pi * inner ℝ y x) : ℂ) * Complex.I) • χ y
  change (∫ y, conj (f y)) = ∫ y, f y
  have hconj (y : V) : conj (f y) = f (-y) := by
    dsimp [f, χ]
    rw [unitCutoffSymbol_even]
    simp only [map_mul, ← Complex.exp_conj, Complex.conj_ofReal, Complex.conj_I,
      unitCutoffSymbol_apply, inner_neg_left, mul_neg, Complex.ofReal_neg]
    rw [neg_mul]
  simp_rw [hconj]
  exact integral_neg_eq_self f volume

/-- The normalized dilation of an integrable cutoff kernel preserves mass. -/
theorem integral_dilate {G : Type*} [NormedAddCommGroup G] [NormedSpace ℝ G]
    (f : V → G) {scale : ℝ} (hscale : 0 < scale) :
    (∫ y, (scale ^ Module.finrank ℝ V) • f (scale • y)) = ∫ y, f y := by
  rw [integral_smul, Measure.integral_comp_smul_of_nonneg volume f scale (hR := hscale.le),
    smul_smul, mul_inv_cancel₀ (pow_ne_zero _ hscale.ne'), one_smul]

/-- Dilate a kernel at a positive frequency scale. -/
def dilatedKernel (scale : ℝ) (K : V → ℂ) (y : V) : ℂ :=
  (scale ^ Module.finrank ℝ V) • K (scale • y)

omit [FiniteDimensional ℝ V] [MeasurableSpace V] [BorelSpace V] in
theorem negativeCarrier_dilate {scale : ℝ} (hscale : scale ≠ 0) (ξ y : V) :
    negativeCarrier (scale⁻¹ • ξ) (scale • y) = negativeCarrier ξ y := by
  have h : inner ℝ (scale • y) (scale⁻¹ • ξ) = inner ℝ y ξ := by
    rw [real_inner_smul_right, real_inner_smul_left, ← mul_assoc, inv_mul_cancel₀ hscale, one_mul]
  exact congrArg (fun t : ℝ => (Real.fourierChar (-t) : ℂ)) h

/-- The normalized spatial dilation scales the frequency variable inversely. -/
theorem dilated_cutoffKernel_modulated_mass (χ : SchwartzMap V ℂ) {scale : ℝ}
    (hscale : 0 < scale) (ξ : V) :
    (∫ y, negativeCarrier ξ y * dilatedKernel scale (cutoffKernel χ) y) = χ (scale⁻¹ • ξ) := by
  let f : V → ℂ := fun y => negativeCarrier (scale⁻¹ • ξ) y * cutoffKernel χ y
  calc
    _ = ∫ y, (scale ^ Module.finrank ℝ V) • f (scale • y) := by
      apply integral_congr_ae
      exact Filter.Eventually.of_forall (fun y => by
        simp only [dilatedKernel, f, negativeCarrier_dilate hscale.ne', Complex.real_smul]
        rw [mul_left_comm])
    _ = ∫ y, f y := integral_dilate f hscale
    _ = χ (scale⁻¹ • ξ) := cutoffKernel_modulated_mass χ _

/-- The first-moment cancellation survives dilation at a carrier in the flat region. -/
theorem dilated_cutoffKernel_modulated_firstMoment (χ : SchwartzMap V ℂ) {scale : ℝ}
    (hscale : 0 < scale) {ξ : V}
    (hχ : (χ : V → ℂ) =ᶠ[𝓝 (scale⁻¹ • ξ)] fun _ => 1) (w : V) :
    (∫ y, negativeCarrier ξ y * ((inner ℝ y w : ℂ) * dilatedKernel scale (cutoffKernel χ) y)) = 0 := by
  let f : V → ℂ := fun y => negativeCarrier (scale⁻¹ • ξ) y *
    ((inner ℝ y w : ℂ) * cutoffKernel χ y)
  calc
    _ = scale⁻¹ • ∫ y, (scale ^ Module.finrank ℝ V) • f (scale • y) := by
      rw [← integral_smul]
      apply integral_congr_ae
      exact Filter.Eventually.of_forall (fun y => by
        simp only [dilatedKernel, f, negativeCarrier_dilate hscale.ne', real_inner_smul_left,
          Complex.real_smul, Complex.ofReal_mul, Complex.ofReal_inv]
        field_simp [Complex.ofReal_ne_zero.mpr hscale.ne'])
    _ = scale⁻¹ • ∫ y, f y := by rw [integral_dilate f hscale]
    _ = 0 := by
      change scale⁻¹ • (∫ y, negativeCarrier (scale⁻¹ • ξ) y *
        ((inner ℝ y w : ℂ) * cutoffKernel χ y)) = 0
      rw [cutoffKernel_modulated_firstMoment χ hχ w, smul_zero]

/-- An absolute moment of order `r` gains exactly the factor `scale ^ (-r)`. -/
theorem integral_dilatedKernel_norm_rpow (K : V → ℂ) {scale : ℝ} (hscale : 0 < scale) (r : ℝ) :
    (∫ y, ‖dilatedKernel scale K y‖ * ‖y‖ ^ r) =
      scale ^ (-r) * ∫ y, ‖K y‖ * ‖y‖ ^ r := by
  let f : V → ℝ := fun y => ‖K y‖ * ‖y‖ ^ r
  calc
    _ = scale ^ (-r) * ∫ y, (scale ^ Module.finrank ℝ V) • f (scale • y) := by
      rw [← integral_const_mul]
      apply integral_congr_ae
      exact Filter.Eventually.of_forall (fun y => by
        simp only [dilatedKernel, norm_smul, Real.norm_eq_abs,
          abs_of_nonneg (pow_nonneg hscale.le _), abs_of_pos hscale, f, smul_eq_mul,
          Real.mul_rpow hscale.le (norm_nonneg y), Real.rpow_neg hscale.le]
        field_simp [(Real.rpow_pos_of_pos hscale r).ne'])
    _ = _ := by rw [integral_dilate f hscale]

end

end IsometricEmbeddingEndpoints

#print axioms IsometricEmbeddingEndpoints.unitCutoffKernel_conj
#print axioms IsometricEmbeddingEndpoints.dilated_cutoffKernel_modulated_mass
#print axioms IsometricEmbeddingEndpoints.dilated_cutoffKernel_modulated_firstMoment
#print axioms IsometricEmbeddingEndpoints.integral_dilatedKernel_norm_rpow
