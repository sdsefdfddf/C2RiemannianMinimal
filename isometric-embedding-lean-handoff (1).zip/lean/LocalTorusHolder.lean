import MetricPullbackOperator
import PeriodicHolderDifferential

open scoped ContDiff

namespace IsometricEmbeddingEndpoints

open ContinuousLinearMap

noncomputable section

variable {d : Type*} [Fintype d] [DecidableEq d]

local instance : NormedAddCommGroup (MetricForm d) := inferInstance
local instance : NormedSpace ℝ (MetricForm d) := inferInstance

set_option maxHeartbeats 1000000 in
/-- The positive torus extension preserves Hölder regularity of the metric coefficients. -/
theorem hasHolderLift_localTorusMetric {R a C : ℝ} (hR : 0 < R) (h : Cover d → MetricForm d)
    (hc : ContinuousOn h (Metric.ball 0 R))
    (hs : ∀ x ∈ Metric.ball 0 R, ∀ v w, h x v w = h x w v)
    (hp : ∀ x ∈ Metric.ball 0 R, ∀ v ≠ 0, 0 < h x v v)
    (ha : 0 ≤ a) (ha₁ : a ≤ 1) (hC : 0 ≤ C)
    (hholder : ∀ x ∈ Metric.ball 0 R, ∀ y ∈ Metric.ball 0 R, ‖h x - h y‖ ≤ C * ‖x - y‖ ^ a) :
    HasHolderLift a (localTorusMetric hR h hc hs hp).form := by
  let b := R / (2 * ((Fintype.card d : ℝ) + 1))
  let X := torusSineCoordinates (d := d) b
  let A := torusSineDifferential (d := d) b
  let B := torusSineCorrection (d := d)
  have hH := HasHolderLift.of_comp hc hC ha hholder X
    (contDiff_torusSineCoordinates_lift b 1) (torusSineCoordinates_mem_ball hR)
  have hA : HasHolderLift a A :=
    hasHolderLift_of_contDiff A (contDiff_torusSineDifferential_lift b 1) ha ha₁
  have hB : HasHolderLift a B :=
    hasHolderLift_of_contDiff B (contDiff_torusSineCorrection_lift 1) ha ha₁
  let E := Cover d
  let W := E →L[ℝ] ℝ
  let L := compL ℝ E E W
  let P := (compL ℝ E E ℝ).flip
  let T := compL ℝ E W W
  have hHA := hH.bilinear L hA
  have hP := HasHolderLift.postcomp (F := E →L[ℝ] E) (G := W →L[ℝ] W) hA P
  have hPull := HasHolderLift.bilinear (E := W →L[ℝ] W) (F := MetricForm d)
    (G := MetricForm d) T hP hHA
  have hGram := hB.bilinear (differentialPairing (d := d) (H := E)) hB
  exact hPull.add hGram

private def torusPullbackOperator (b : ℝ) :
    C(UnitAddTorus d, MetricForm d →L[ℝ] MetricForm d) :=
  ⟨fun t => metricPullbackOperator (torusSineDifferential (d := d) b t),
    (contDiff_metricPullbackOperator (d := d) 0).continuous.comp
      (torusSineDifferential (d := d) b).continuous⟩

private theorem contDiff_torusPullbackOperator_lift (b : ℝ) (n : ℕ∞ω) :
    ContDiff ℝ n (fun x : Cover d => torusPullbackOperator b (flatProjection x)) :=
  (contDiff_metricPullbackOperator n).comp (contDiff_torusSineDifferential_lift b n)

private theorem contDiff_correctionGram_lift (n : ℕ∞) :
    ContDiff ℝ n (fun x : Cover d => torusGram torusSineCorrection (flatProjection x)) :=
  contDiff_bilinear_lift (differentialPairing (d := d) (H := Cover d))
    (contDiff_torusSineCorrection_lift n) (contDiff_torusSineCorrection_lift n)

set_option maxHeartbeats 1100000 in
/-- The same extension preserves the Hölder exponent of the first derivative. -/
theorem hasHolderLift_torusDifferential_localTorusMetric {R a C : ℝ}
    (hR : 0 < R) (h : Cover d → MetricForm d) (hc : ContDiffOn ℝ 1 h (Metric.ball 0 R))
    (hs : ∀ x ∈ Metric.ball 0 R, ∀ v w, h x v w = h x w v)
    (hp : ∀ x ∈ Metric.ball 0 R, ∀ v ≠ 0, 0 < h x v v)
    (ha : 0 ≤ a) (ha₁ : a ≤ 1) (hC : 0 ≤ C)
    (hholder : ∀ x ∈ Metric.ball 0 R, ∀ y ∈ Metric.ball 0 R,
      ‖fderiv ℝ h x - fderiv ℝ h y‖ ≤ C * ‖x - y‖ ^ a) :
    HasHolderLift a (torusDifferential (localTorusMetric hR h hc.continuousOn hs hp).form
      (contDiff_localTorusMetric_lift hR h hc hs hp)) := by
  let b := R / (2 * ((Fintype.card d : ℝ) + 1))
  let X := torusSineCoordinates (d := d) b
  have hmem : ∀ t, X t ∈ Metric.ball (0 : Cover d) R := torusSineCoordinates_mem_ball hR
  let H : C(UnitAddTorus d, MetricForm d) :=
    ⟨h ∘ X, hc.continuousOn.comp_continuous X.continuous hmem⟩
  have hX₁ := contDiff_torusSineCoordinates_lift (d := d) b 1
  have hH₁ : ContDiff ℝ 1 (fun x => H (flatProjection x)) := by
    rw [contDiff_iff_contDiffAt]
    intro x
    change ContDiffAt ℝ 1 (fun y => h (X (flatProjection y))) x
    exact (hc.contDiffAt (Metric.isOpen_ball.mem_nhds (hmem (flatProjection x)))).comp x
      hX₁.contDiffAt
  have hX := hasHolderLift_torusDifferential_of_contDiff_two X
    (contDiff_torusSineCoordinates_lift b 2) hX₁ ha ha₁
  have hH : HasHolderLift a (torusDifferential H hH₁) :=
    hasHolderLift_torusDifferential_comp Metric.isOpen_ball hc ha hC hholder X hX₁ hmem hX hH₁
  let P := torusPullbackOperator (d := d) b
  let Q := torusGram (torusSineCorrection (d := d))
  let U : C(UnitAddTorus d, MetricForm d) :=
    ⟨fun t => P t (H t), P.continuous.clm_apply H.continuous⟩
  have hP₁ := contDiff_torusPullbackOperator_lift (d := d) b 1
  have hQ₁ := contDiff_correctionGram_lift (d := d) 1
  have hU₁ : ContDiff ℝ 1 (fun x => U (flatProjection x)) := hP₁.clm_apply hH₁
  have hP := hasHolderLift_torusDifferential_of_contDiff_two P
    (contDiff_torusPullbackOperator_lift b 2) hP₁ ha ha₁
  have hQ := hasHolderLift_torusDifferential_of_contDiff_two Q
    (contDiff_correctionGram_lift 2) hQ₁ ha ha₁
  have hU : HasHolderLift a (torusDifferential U hU₁) :=
    hasHolderLift_torusDifferential_bilinear
      (ContinuousLinearMap.id ℝ (MetricForm d →L[ℝ] MetricForm d))
      P H hP₁ hH₁ hU₁ ha ha₁ hP hH
  have heq : (localTorusMetric hR h hc.continuousOn hs hp).form = U + Q := by
    apply ContinuousMap.ext
    intro t
    rfl
  obtain ⟨K, hK, hbound⟩ := hasHolderLift_torusDifferential_add U Q hU₁ hQ₁ hU hQ
  refine ⟨K, hK, fun x y => ?_⟩
  simp only [torusDifferential_apply] at hbound ⊢
  rw [heq]
  exact hbound x y

end

end IsometricEmbeddingEndpoints

#print axioms IsometricEmbeddingEndpoints.hasHolderLift_localTorusMetric
#print axioms IsometricEmbeddingEndpoints.hasHolderLift_torusDifferential_localTorusMetric
