import RealTorusBernstein
import Mathlib.Algebra.Group.Pointwise.Set.Basic

namespace IsometricEmbeddingEndpoints

open scoped Pointwise

noncomputable section

variable {d : Type*} [Fintype d]

theorem mul_mem_mFourier_span {band₁ band₂ : Set (d → ℤ)} {f g : C(UnitAddTorus d, ℂ)}
    (hf : f ∈ Submodule.span ℂ (UnitAddTorus.mFourier '' band₁))
    (hg : g ∈ Submodule.span ℂ (UnitAddTorus.mFourier '' band₂)) :
    f * g ∈ Submodule.span ℂ (UnitAddTorus.mFourier '' (band₁ + band₂)) := by
  let P := Submodule.span ℂ (UnitAddTorus.mFourier '' (band₁ + band₂))
  induction hf, hg using Submodule.span_induction₂ with
  | mem_mem a b ha hb =>
    obtain ⟨n, hn, rfl⟩ := ha
    obtain ⟨m, hm, rfl⟩ := hb
    have hp : UnitAddTorus.mFourier n * UnitAddTorus.mFourier m = UnitAddTorus.mFourier (n + m) := by
      ext t
      exact UnitAddTorus.mFourier_add.symm
    rw [hp]
    exact Submodule.subset_span ⟨n + m, Set.add_mem_add hn hm, rfl⟩
  | zero_left g _ => rw [zero_mul]; exact P.zero_mem
  | zero_right f _ => rw [mul_zero]; exact P.zero_mem
  | add_left a b c _ _ _ ha hb => rw [add_mul]; exact P.add_mem ha hb
  | add_right a b c _ _ _ hb hc => rw [mul_add]; exact P.add_mem hb hc
  | smul_left r a b _ _ h =>
    have heq : (r • a) * b = r • (a * b) := by
      ext t
      exact mul_assoc _ _ _
    rw [heq]
    exact P.smul_mem _ h
  | smul_right r a b _ _ h =>
    have heq : a * (r • b) = r • (a * b) := by
      ext t
      exact mul_left_comm _ _ _
    rw [heq]
    exact P.smul_mem _ h

variable {E F H : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E]
  [NormedAddCommGroup F] [NormedSpace ℝ F] [NormedAddCommGroup H] [NormedSpace ℝ H]

theorem HasFourierSupport.mono {band₁ band₂ : Set (d → ℤ)}
    {f : C(UnitAddTorus d, E)} (hf : HasFourierSupport band₁ f) (h : band₁ ⊆ band₂) :
    HasFourierSupport band₂ f :=
  fun L => Submodule.span_mono (Set.image_mono h) (hf L)

theorem HasFourierSupport.add {band : Set (d → ℤ)} {f g : C(UnitAddTorus d, E)}
    (hf : HasFourierSupport band f) (hg : HasFourierSupport band g) :
    HasFourierSupport band (f + g) := by
  intro L
  have heq : complexCoordinate L (f + g) = complexCoordinate L f + complexCoordinate L g := by
    ext t
    change ((L (f t + g t) : ℝ) : ℂ) = (L (f t) : ℂ) + (L (g t) : ℂ)
    rw [map_add, Complex.ofReal_add]
  rw [heq]
  exact Submodule.add_mem _ (hf L) (hg L)

theorem HasFourierSupport.sub {band : Set (d → ℤ)} {f g : C(UnitAddTorus d, E)}
    (hf : HasFourierSupport band f) (hg : HasFourierSupport band g) :
    HasFourierSupport band (f - g) := by
  intro L
  have heq : complexCoordinate L (f - g) = complexCoordinate L f - complexCoordinate L g := by
    ext t
    change ((L (f t - g t) : ℝ) : ℂ) = (L (f t) : ℂ) - (L (g t) : ℂ)
    rw [map_sub, Complex.ofReal_sub]
  rw [heq]
  exact Submodule.sub_mem _ (hf L) (hg L)

theorem HasFourierSupport.smul {band : Set (d → ℤ)} {f : C(UnitAddTorus d, E)}
    (hf : HasFourierSupport band f) (r : ℝ) :
    HasFourierSupport band (r • f) := by
  intro L
  have heq : complexCoordinate L (r • f) = (r : ℂ) • complexCoordinate L f := by
    ext t
    change ((L (r • f t) : ℝ) : ℂ) = (r : ℂ) * (L (f t) : ℂ)
    rw [map_smul, smul_eq_mul, Complex.ofReal_mul]
  rw [heq]
  exact Submodule.smul_mem _ _ (hf L)

theorem hasFourierSupport_const {band : Set (d → ℤ)} (h : 0 ∈ band) (z : E) :
    HasFourierSupport band (ContinuousMap.const _ z : C(UnitAddTorus d, E)) := by
  intro L
  have heq : complexCoordinate L (ContinuousMap.const _ z) =
      (L z : ℂ) • UnitAddTorus.mFourier (0 : d → ℤ) := by
    ext t
    change (L z : ℂ) = (L z : ℂ) * UnitAddTorus.mFourier 0 t
    rw [UnitAddTorus.mFourier_zero, ContinuousMap.one_apply, mul_one]
  rw [heq]
  exact Submodule.smul_mem _ _ (Submodule.subset_span ⟨0, h, rfl⟩)

theorem HasFourierSupport.postcomp {band : Set (d → ℤ)} {f : C(UnitAddTorus d, E)}
    (hf : HasFourierSupport band f) (A : E →L[ℝ] F) :
    HasFourierSupport band (⟨A ∘ f, A.continuous.comp f.continuous⟩ : C(UnitAddTorus d, F)) :=
  fun L => hf (L.comp A)

theorem hasFourierSupport_sum {ι : Type*} {band : Set (d → ℤ)} (s : Finset ι)
    (f : ι → C(UnitAddTorus d, E)) (hf : ∀ i ∈ s, HasFourierSupport band (f i)) :
    HasFourierSupport band (∑ i ∈ s, f i) := by
  classical
  induction s using Finset.induction_on with
  | empty =>
    intro L
    have hz : complexCoordinate L (0 : C(UnitAddTorus d, E)) = 0 := by
      ext t
      simp [complexCoordinate]
    rw [Finset.sum_empty, hz]
    exact Submodule.zero_mem _
  | insert i s hi ih =>
    rw [Finset.sum_insert hi]
    exact (hf i (Finset.mem_insert_self i s)).add (ih fun j hj => hf j (Finset.mem_insert_of_mem hj))

/-- A pointwise bilinear combination has frequencies in the sum of its two input bands. -/
theorem HasFourierSupport.bilinear [FiniteDimensional ℝ E] {band₁ band₂ : Set (d → ℤ)}
    {f : C(UnitAddTorus d, E)} {g : C(UnitAddTorus d, F)}
    (hf : HasFourierSupport band₁ f) (hg : HasFourierSupport band₂ g)
    (B : E →L[ℝ] F →L[ℝ] H) :
    HasFourierSupport (band₁ + band₂)
      (⟨fun t => B (f t) (g t), (B.continuous.comp f.continuous).clm_apply g.continuous⟩ :
        C(UnitAddTorus d, H)) := by
  intro L
  let b := Module.finBasis ℝ E
  let q := fun i => (ContinuousLinearMap.proj i).comp b.equivFunL.toContinuousLinearMap
  let r := fun i => L.comp (B (b i))
  have heq : complexCoordinate L
      (⟨fun t => B (f t) (g t), (B.continuous.comp f.continuous).clm_apply g.continuous⟩ :
        C(UnitAddTorus d, H)) =
      ∑ i, complexCoordinate (q i) f * complexCoordinate (r i) g := by
    ext t
    change ((L (B (f t) (g t)) : ℝ) : ℂ) = (ContinuousMap.evalCLM ℂ t)
      (∑ i, complexCoordinate (q i) f * complexCoordinate (r i) g)
    rw [map_sum]
    simp only [ContinuousMap.evalCLM_apply, ContinuousMap.mul_apply, complexCoordinate, ContinuousMap.coe_mk]
    have hx : (∑ i, q i (f t) • b i) = f t := b.sum_repr (f t)
    conv_lhs => rw [← hx]
    simp only [map_sum, map_smul, sum_apply, smul_apply, Complex.ofReal_sum,
      Complex.ofReal_mul, smul_eq_mul, r, ContinuousLinearMap.comp_apply]
  rw [heq]
  exact Submodule.sum_mem _ fun i _ => mul_mem_mFourier_span (hf (q i)) (hg (r i))

theorem HasFourierSupport.differential {scale : ℝ} (hs : 0 < scale)
    {band : Set (d → ℤ)} (hone : ∀ n ∈ band, ‖scale⁻¹ • latticeVector n‖ ≤ 1)
    {f : C(UnitAddTorus d, H)} (hf : HasFourierSupport band f)
    (Df : C(UnitAddTorus d, Cover d →L[ℝ] H))
    (hDf : ∀ x : Cover d, HasFDerivAt (fun z => f (flatProjection z)) (Df (flatProjection x)) x) :
    HasFourierSupport band Df := by
  let b := Module.finBasis ℝ (Cover d)
  let g := fun i =>
    (⟨fun t => Df t (b i), (ContinuousLinearMap.apply ℝ H (b i)).continuous.comp Df.continuous⟩ :
      C(UnitAddTorus d, H))
  have hg (i : Fin (Module.finrank ℝ (Cover d))) : HasFourierSupport band (g i) := by
    intro L
    let Lc := Complex.ofRealCLM.comp L
    have heq : complexCoordinate L (g i) = derivativeCutoff hs (b i) (complexCoordinate L f) := by
      ext t
      obtain ⟨x, rfl⟩ := flatProjection_surjective t
      obtain ⟨D, hD, hDval⟩ := exists_hasFDerivAt_of_modeSpan hs hone (hf L) x
      have hcomp : HasFDerivAt (fun z => complexCoordinate L f (flatProjection z))
          (Lc.comp (Df (flatProjection x))) x := Lc.hasFDerivAt.comp x (hDf x)
      rw [← hDval]
      exact DFunLike.congr_fun (hcomp.unique hD) (b i)
    rw [heq]
    exact derivativeCutoff_mem_modeSpan hs (b i) (hf L)
  let A := fun i => ContinuousLinearMap.smulRightL ℝ (Cover d) H
    ((ContinuousLinearMap.proj i).comp b.equivFunL.toContinuousLinearMap)
  have hsum : Df = ∑ i, (⟨A i ∘ g i, (A i).continuous.comp (g i).continuous⟩ :
      C(UnitAddTorus d, Cover d →L[ℝ] H)) := by
    ext t v
    change Df t v = ((ContinuousMap.evalCLM ℝ t)
      (∑ i, (⟨A i ∘ g i, (A i).continuous.comp (g i).continuous⟩ :
        C(UnitAddTorus d, Cover d →L[ℝ] H)))) v
    rw [map_sum]
    simp only [ContinuousMap.evalCLM_apply, ContinuousMap.coe_mk, sum_apply, Function.comp_apply]
    change Df t v = ∑ i, b.repr v i • Df t (b i)
    simpa only [map_sum, map_smul] using (congrArg (Df t) (b.sum_repr v)).symm
  rw [hsum]
  exact hasFourierSupport_sum Finset.univ _ (fun i _ => (hg i).postcomp (A i))

end

end IsometricEmbeddingEndpoints

#print axioms IsometricEmbeddingEndpoints.HasFourierSupport.bilinear
#print axioms IsometricEmbeddingEndpoints.HasFourierSupport.differential
