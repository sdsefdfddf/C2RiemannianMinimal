import ConvolutionStage
import LowStageGeometry
import Spiral

namespace IsometricEmbeddingEndpoints

open MeasureTheory

noncomputable section

variable {Ω E H ι : Type*} [MeasurableSpace Ω] {ν : Measure Ω}
  [NormedAddCommGroup E] [NormedSpace ℝ E]
  [NormedAddCommGroup H] [InnerProductSpace ℝ H] [CompleteSpace H] [Fintype ι]

/-- The stage estimate for the simultaneous circle pairs embedded into a fixed coordinate block.

The assumptions describe the kernel and the derivative of the filtered correction at a point.
The estimate leaves the difference between that derivative and the projected wave explicit. -/
theorem abs_filtered_spiral_stage_le
    {a : ι → E → ℝ} {A : ι → E →L[ℝ] ℝ} {x : E}
    (ha : ∀ i, HasFDerivAt (a i) (A i) x) (ξ : ι → E →L[ℝ] ℝ)
    {μ : ℝ} (hμ : μ ≠ 0) (J : PiLp 2 (fun _ : ι => CirclePair) →ₗᵢ[ℝ] H)
    (Q : H →L[ℝ] H)
    (hsym : ∀ p q, inner ℝ (Q p) q = inner ℝ p (Q q))
    (hidem : ∀ p, Q (Q p) = Q p)
    (k ρ : Ω → ℝ) (F₀ D : E →L[ℝ] H) (F U : Ω → E →L[ℝ] H) {L M R : ℝ}
    (hD : ∀ w, D w = ∫ y, k y • U y w ∂ν)
    (hU : ∀ w, Integrable (fun y => k y • U y w) ν)
    (hFU : ∀ v w, Integrable (fun y => k y * inner ℝ (F y v) (U y w)) ν)
    (hmass : Integrable (fun y => |k y|) ν)
    (hmoment : Integrable (fun y => |k y| * ρ y) ν)
    (hp : ∀ᵐ y ∂ν, ‖F₀ - F y‖ ≤ L * ρ y)
    (hbound : ∀ᵐ y ∂ν, ‖U y‖ ≤ M)
    (htangent : ∀ v w, ∀ᵐ y ∂ν, |inner ℝ (F y v) (U y w)| ≤ R * (‖v‖ * ‖w‖))
    (v w : E) :
    let W := J.toContinuousLinearMap.comp
      (fderiv ℝ (circlePairs (fun i y => μ⁻¹ * a i y) (fun i y => μ * ξ i y)) x)
    let C := (normalPart Q).comp W
    let cross := (L * M) * (∫ y, |k y| * ρ y ∂ν) + R * (∫ y, |k y| ∂ν)
    |inner ℝ ((F₀ + D) v) ((F₀ + D) w) - inner ℝ (F₀ v) (F₀ w) -
      ∑ i, (a i x) ^ 2 * (ξ i v * ξ i w)| ≤
      (2 * cross + ‖D - C‖ * (‖D‖ + ‖C‖) + ‖Q.comp W‖ ^ 2 +
        μ⁻¹ ^ 2 * (∑ i, ‖A i‖ ^ 2)) * (‖v‖ * ‖w‖) := by
  let W := J.toContinuousLinearMap.comp
    (fderiv ℝ (circlePairs (fun i y => μ⁻¹ * a i y) (fun i y => μ * ξ i y)) x)
  let metric : E → E → ℝ := fun v w => ∑ i, (a i x) ^ 2 * (ξ i v * ξ i w)
  have hwave (v w : E) :
      |inner ℝ (W v) (W w) - metric v w| ≤
        (μ⁻¹ ^ 2 * ∑ i, ‖A i‖ ^ 2) * (‖v‖ * ‖w‖) := by
    simpa only [W, metric, ContinuousLinearMap.comp_apply, LinearIsometry.coe_toContinuousLinearMap,
      J.inner_map_map] using abs_gram_scaledCirclePairs_remainder_le ha ξ hμ v w
  exact abs_gram_stage_le F₀ D W Q hsym hidem metric
    (abs_weighted_differential_le k ρ F₀ D F U hD hU hFU hmass hmoment hp hbound htangent)
    hwave v w

end

end IsometricEmbeddingEndpoints

#print axioms IsometricEmbeddingEndpoints.abs_filtered_spiral_stage_le
