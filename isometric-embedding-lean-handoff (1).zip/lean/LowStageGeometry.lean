import Mathlib.Analysis.InnerProductSpace.Adjoint
import Mathlib.Analysis.InnerProductSpace.Calculus
import Mathlib.Analysis.Normed.Module.FiniteDimension
import Mathlib.Tactic.GCongr
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Ring

namespace IsometricEmbeddingEndpoints

open ContinuousLinearMap
open scoped InnerProduct

noncomputable section

variable {E H : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E]
  [NormedAddCommGroup H] [InnerProductSpace ℝ H]

/-- The normal component associated to an orthogonal tangent projection. -/
def normalPart (Q : H →L[ℝ] H) : H →L[ℝ] H :=
  ContinuousLinearMap.id ℝ H - Q

/-- Orthogonal projection changes the Gram form by the Gram form of the discarded part. -/
theorem inner_normalPart (Q : H →L[ℝ] H)
    (hsym : ∀ x y, inner ℝ (Q x) y = inner ℝ x (Q y))
    (hidem : ∀ x, Q (Q x) = Q x) (x y : H) :
    inner ℝ (normalPart Q x) (normalPart Q y) =
      inner ℝ x y - inner ℝ (Q x) (Q y) := by
  have hleft : inner ℝ (Q x) (Q y) = inner ℝ x (Q y) := by
    rw [hsym, hidem]
  have hright : inner ℝ (Q x) y = inner ℝ (Q x) (Q y) :=
    (hsym x y).trans hleft.symm
  simp only [normalPart, sub_apply, id_apply, inner_sub_left, inner_sub_right, hright, ← hleft]
  ring

theorem norm_normalPart_apply_le (Q : H →L[ℝ] H)
    (hsym : ∀ x y, inner ℝ (Q x) y = inner ℝ x (Q y))
    (hidem : ∀ x, Q (Q x) = Q x) (x : H) :
    ‖normalPart Q x‖ ≤ ‖x‖ := by
  have h := inner_normalPart Q hsym hidem x x
  simp only [real_inner_self_eq_norm_sq] at h
  nlinarith [norm_nonneg (normalPart Q x), norm_nonneg x, sq_nonneg ‖Q x‖]

theorem abs_gram_change_normalPart (Q : H →L[ℝ] H)
    (hsym : ∀ x y, inner ℝ (Q x) y = inner ℝ x (Q y))
    (hidem : ∀ x, Q (Q x) = Q x) (W : E →L[ℝ] H) (v w : E) :
    |inner ℝ (normalPart Q (W v)) (normalPart Q (W w)) - inner ℝ (W v) (W w)| ≤
      ‖Q.comp W‖ ^ 2 * (‖v‖ * ‖w‖) := by
  rw [inner_normalPart Q hsym hidem, sub_sub_cancel_left, abs_neg]
  calc
    |inner ℝ (Q (W v)) (Q (W w))| ≤ ‖(Q.comp W) v‖ * ‖(Q.comp W) w‖ :=
      abs_real_inner_le_norm _ _
    _ ≤ (‖Q.comp W‖ * ‖v‖) * (‖Q.comp W‖ * ‖w‖) :=
      mul_le_mul (le_opNorm _ _) (le_opNorm _ _) (norm_nonneg _) (by positivity)
    _ = _ := by ring

section RangeProjection

variable {X : Type*} [NormedAddCommGroup X] [InnerProductSpace ℝ X]
  [CompleteSpace X] [CompleteSpace H]

/-- Write the projection as `F B F†`, where `B` inverts `F† F`. -/
def rangeProjection (F : X →L[ℝ] H) (B : X →L[ℝ] X) : H →L[ℝ] H :=
  F.comp (B.comp F.adjoint)

theorem rangeProjection_symmetric (F : X →L[ℝ] H) (B : X →L[ℝ] X)
    (hB : ∀ x y, inner ℝ (B x) y = inner ℝ x (B y)) (v w : H) :
    inner ℝ (rangeProjection F B v) w = inner ℝ v (rangeProjection F B w) := by
  simp only [rangeProjection, comp_apply]
  rw [← F.adjoint_inner_right, hB, F.adjoint_inner_left]

theorem rangeProjection_apply_range (F : X →L[ℝ] H) (B : X →L[ℝ] X)
    (hB : ∀ x, B (F.adjoint (F x)) = x) (x : X) :
    rangeProjection F B (F x) = F x := by
  simp [rangeProjection, hB]

theorem rangeProjection_idempotent (F : X →L[ℝ] H) (B : X →L[ℝ] X)
    (hB : ∀ x, B (F.adjoint (F x)) = x) (v : H) :
    rangeProjection F B (rangeProjection F B v) = rangeProjection F B v :=
  rangeProjection_apply_range F B hB (B (F.adjoint v))

/-- On the initially normal coordinates, the tangent projection is small to first order. -/
theorem norm_rangeProjection_comp_le (F F₀ : X →L[ℝ] H) (B : X →L[ℝ] X)
    (W : E →L[ℝ] H) (hn : ∀ v, F₀.adjoint (W v) = 0) :
    ‖(rangeProjection F B).comp W‖ ≤ ‖F‖ * ‖B‖ * ‖F - F₀‖ * ‖W‖ := by
  have hcomp : (rangeProjection F B).comp W =
      F.comp (B.comp ((F - F₀).adjoint.comp W)) := by
    ext v
    change F (B (F.adjoint (W v))) = F (B ((F - F₀).adjoint (W v)))
    rw [map_sub (ContinuousLinearMap.adjoint (𝕜 := ℝ)), sub_apply, hn, sub_zero]
  rw [hcomp]
  calc
    _ ≤ ‖F‖ * ‖B.comp ((F - F₀).adjoint.comp W)‖ := opNorm_comp_le _ _
    _ ≤ ‖F‖ * (‖B‖ * ‖(F - F₀).adjoint.comp W‖) := by
      gcongr
      exact opNorm_comp_le _ _
    _ ≤ ‖F‖ * (‖B‖ * (‖(F - F₀).adjoint‖ * ‖W‖)) := by
      gcongr
      exact opNorm_comp_le _ _
    _ = _ := by
      rw [LinearIsometryEquiv.norm_map]
      ring

/-- A lower singular-value bound gives an inverse of the tangent Gram operator with a uniform norm. -/
theorem exists_gramInverse [FiniteDimensional ℝ X] (F : X →L[ℝ] H) {σ : ℝ} (hσ : 0 < σ)
    (hF : ∀ x, σ * ‖x‖ ≤ ‖F x‖) :
    ∃ B : X →L[ℝ] X,
      (∀ x, B (F.adjoint (F x)) = x) ∧
      (∀ x y, inner ℝ (B x) y = inner ℝ x (B y)) ∧
      ‖B‖ ≤ (σ ^ 2)⁻¹ := by
  let G := F.adjoint.comp F
  have hG (x : X) : σ ^ 2 * ‖x‖ ≤ ‖G x‖ := by
    by_cases hx : x = 0
    · simp [hx]
    apply (mul_le_mul_iff_left₀ (norm_pos_iff.mpr hx)).mp
    calc
      (σ ^ 2 * ‖x‖) * ‖x‖ = (σ * ‖x‖) ^ 2 := by ring
      _ ≤ ‖F x‖ ^ 2 := pow_le_pow_left₀ (by positivity) (hF x) 2
      _ = inner ℝ (G x) x := by
        change ‖F x‖ ^ 2 = inner ℝ (F.adjoint (F x)) x
        rw [F.adjoint_inner_left, real_inner_self_eq_norm_sq]
      _ ≤ ‖G x‖ * ‖x‖ :=
        (le_abs_self _).trans (abs_real_inner_le_norm _ _)
  have hGinj : Function.Injective G := by
    intro x y hxy
    have hzero : G (x - y) = 0 := by rw [map_sub, hxy, sub_self]
    have hb := hG (x - y)
    rw [hzero, norm_zero] at hb
    by_contra hne
    exact (not_lt_of_ge hb) (mul_pos (pow_pos hσ _) (norm_pos_iff.mpr (sub_ne_zero.mpr hne)))
  let e : X ≃L[ℝ] X :=
    (LinearEquiv.ofInjectiveEndo G.toLinearMap hGinj).toContinuousLinearEquiv
  let B := e.symm.toContinuousLinearMap
  have hleft (x : X) : B (G x) = x := e.symm_apply_apply x
  have hright (x : X) : G (B x) = x := e.apply_symm_apply x
  refine ⟨B, hleft, ?_, ?_⟩
  · intro x y
    calc
      inner ℝ (B x) y = inner ℝ (B x) (G (B y)) := by rw [hright]
      _ = inner ℝ (F (B x)) (F (B y)) := F.adjoint_inner_right _ _
      _ = inner ℝ (G (B x)) (B y) := (F.adjoint_inner_left _ _).symm
      _ = inner ℝ x (B y) := by rw [hright]
  · apply B.opNorm_le_bound (by positivity)
    intro x
    have hb := hG (B x)
    rw [hright, mul_comm (σ ^ 2), ← le_div_iff₀ (pow_pos hσ 2), div_eq_mul_inv, mul_comm] at hb
    exact hb

end RangeProjection

/-- Differentiating normality replaces a derivative on the update by a derivative on the tangent. -/
theorem inner_deriv_of_normal {p V : E → H} {Dp DV : E →L[ℝ] H} {x : E}
    (hp : HasFDerivAt p Dp x) (hV : HasFDerivAt V DV x)
    (hn : ∀ y, inner ℝ (p y) (V y) = 0) (v : E) :
    inner ℝ (p x) (DV v) = -inner ℝ (Dp v) (V x) := by
  have hd := hp.inner ℝ hV
  have hzero : (fun y => inner ℝ (p y) (V y)) = (fun _ => (0 : ℝ)) := funext hn
  rw [hzero] at hd
  have hout := DFunLike.congr_fun
    (hd.unique (hasFDerivAt_const (0 : ℝ) x)) v
  simp only [comp_apply, ContinuousLinearMap.prod_apply, fderivInnerCLM_apply, zero_apply] at hout
  linarith

/-- The projected wave has the projected differential plus the derivative of the projection. -/
theorem hasFDerivAt_projectedWave {Q : E → H →L[ℝ] H} {W : E → H}
    {DQ : E →L[ℝ] H →L[ℝ] H} {DW : E →L[ℝ] H} {x : E}
    (hQ : HasFDerivAt Q DQ x) (hW : HasFDerivAt W DW x) :
    HasFDerivAt (fun y => normalPart (Q y) (W y))
      ((normalPart (Q x)).comp DW - DQ.flip (W x)) x := by
  have hd := hW.sub (hQ.clm_apply hW)
  convert hd using 1
  · ext y
    simp [normalPart]
  · ext v
    simp only [normalPart, sub_apply, comp_apply, id_apply, flip_apply, add_apply]
    abel

private theorem abs_gram_diff_le (A C : E →L[ℝ] H) (v w : E) :
    |inner ℝ (A v) (A w) - inner ℝ (C v) (C w)| ≤
      ‖A - C‖ * (‖A‖ + ‖C‖) * (‖v‖ * ‖w‖) := by
  have hsplit :
      inner ℝ (A v) (A w) - inner ℝ (C v) (C w) =
        inner ℝ ((A - C) v) (A w) + inner ℝ (C v) ((A - C) w) := by
    simp only [sub_apply, inner_sub_left, inner_sub_right]
    ring
  rw [hsplit]
  calc
    _ ≤ |inner ℝ ((A - C) v) (A w)| + |inner ℝ (C v) ((A - C) w)| := abs_add_le _ _
    _ ≤ (‖A - C‖ * ‖v‖) * (‖A‖ * ‖w‖) + (‖C‖ * ‖v‖) * (‖A - C‖ * ‖w‖) := by
      apply add_le_add
      · exact (abs_real_inner_le_norm _ _).trans
          (mul_le_mul (le_opNorm _ _) (le_opNorm _ _) (norm_nonneg _) (by positivity))
      · exact (abs_real_inner_le_norm _ _).trans
          (mul_le_mul (le_opNorm _ _) (le_opNorm _ _) (norm_nonneg _) (by positivity))
    _ = _ := by ring

/-- The pointwise Gram estimate for a stage, before the Fourier bounds are substituted.

`F` is the old differential, `A` the actual correction, and `W` the unprojected wave.
The linear cross term is supplied by the convolution commutator. -/
theorem abs_gram_stage_le (F A W : E →L[ℝ] H) (Q : H →L[ℝ] H)
    (hsym : ∀ x y, inner ℝ (Q x) y = inner ℝ x (Q y))
    (hidem : ∀ x, Q (Q x) = Q x)
    (metric : E → E → ℝ) {κ η : ℝ}
    (hcross : ∀ v w, |inner ℝ (F v) (A w)| ≤ κ * (‖v‖ * ‖w‖))
    (hwave : ∀ v w, |inner ℝ (W v) (W w) - metric v w| ≤ η * (‖v‖ * ‖w‖))
    (v w : E) :
    let C := (normalPart Q).comp W
    |inner ℝ ((F + A) v) ((F + A) w) - inner ℝ (F v) (F w) - metric v w| ≤
      (2 * κ + ‖A - C‖ * (‖A‖ + ‖C‖) + ‖Q.comp W‖ ^ 2 + η) * (‖v‖ * ‖w‖) := by
  let C := (normalPart Q).comp W
  let cross := inner ℝ (F v) (A w) + inner ℝ (A v) (F w)
  let d₁ := inner ℝ (A v) (A w) - inner ℝ (C v) (C w)
  let d₂ := inner ℝ (C v) (C w) - inner ℝ (W v) (W w)
  let d₃ := inner ℝ (W v) (W w) - metric v w
  change _ ≤ (2 * κ + ‖A - C‖ * (‖A‖ + ‖C‖) + ‖Q.comp W‖ ^ 2 + η) * (‖v‖ * ‖w‖)
  have hsplit :
      inner ℝ ((F + A) v) ((F + A) w) - inner ℝ (F v) (F w) - metric v w =
        cross + d₁ + d₂ + d₃ := by
    simp only [add_apply, inner_add_left, inner_add_right, cross, d₁, d₂, d₃]
    ring
  have hcross' : |cross| ≤ (2 * κ) * (‖v‖ * ‖w‖) := by
    calc
      |cross| ≤ |inner ℝ (F v) (A w)| + |inner ℝ (A v) (F w)| := abs_add_le _ _
      _ ≤ κ * (‖v‖ * ‖w‖) + κ * (‖w‖ * ‖v‖) := by
        rw [real_inner_comm (F w) (A v)]
        exact add_le_add (hcross v w) (hcross w v)
      _ = _ := by ring
  have hsum : |cross + d₁ + d₂ + d₃| ≤ |cross| + |d₁| + |d₂| + |d₃| := by
    exact (abs_add_le _ _).trans
      (add_le_add ((abs_add_le _ _).trans (add_le_add (abs_add_le _ _) le_rfl)) le_rfl)
  rw [hsplit]
  refine hsum.trans ?_
  calc
    _ ≤ (2 * κ) * (‖v‖ * ‖w‖) + ‖A - C‖ * (‖A‖ + ‖C‖) * (‖v‖ * ‖w‖) +
        ‖Q.comp W‖ ^ 2 * (‖v‖ * ‖w‖) + η * (‖v‖ * ‖w‖) :=
      add_le_add (add_le_add (add_le_add hcross' (abs_gram_diff_le A C v w))
        (abs_gram_change_normalPart Q hsym hidem W v w)) (hwave v w)
    _ = _ := by ring

end

end IsometricEmbeddingEndpoints

#print axioms IsometricEmbeddingEndpoints.norm_rangeProjection_comp_le
#print axioms IsometricEmbeddingEndpoints.exists_gramInverse
#print axioms IsometricEmbeddingEndpoints.inner_deriv_of_normal
#print axioms IsometricEmbeddingEndpoints.hasFDerivAt_projectedWave
#print axioms IsometricEmbeddingEndpoints.abs_gram_stage_le
