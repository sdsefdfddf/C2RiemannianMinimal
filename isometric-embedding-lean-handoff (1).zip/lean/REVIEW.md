# 闭流形上低阶等距嵌入的数学审核

## 度量和正则性

公开定理的维数是 `d : ℕ`。模型空间 `Euclidean d` 表示 $\mathbb R^d$。流形紧致、Hausdorff，取光滑无边界图册。度量使用 Mathlib 的 `Bundle.ContinuousRiemannianMetric` 和 `Bundle.ContMDiffRiemannianMetric`，分别包含连续性和 $C^1$ 正则性。

对坐标图 $e$，`metricInChart` 用逆图的微分 $D(e^{-1})$ 拉回切空间的度量。`HolderInCharts` 和 `HolderDifferentialInCharts` 分别要求坐标函数和其一阶导数在图中心的一个邻域满足 `HolderOnWith`。在指数为零时，这个条件只要求点差有界，可以对连续函数或连续导数缩小到紧坐标球来满足。[公开定义](ClosedManifoldStatement.lean) · [端点检查](Audit.lean)

`ClosedManifoldCoordinates` 将标准坐标图平移到原点，把两个正则性条件传给已有的局部构造。嵌入的导数估计再由平移后的坐标返回标准坐标。这里使用逆图的链式法则和 Mathlib 的切丛坐标公式。[坐标转换](ClosedManifoldCoordinates.lean)

## 嵌入和精确等距条件

`IsC1IsometricEmbedding` 要求 Mathlib 的 `Manifold.IsSmoothEmbedding` 在正则性 $1$ 下成立，并对每个 $p\in M$ 及 $v,w\in T_pM$ 要求

$$
\langle du_p(v),du_p(w)\rangle=g_p(v,w).
$$

正定性给出 $du_p$ 单射。把这个线性单射沿其值域的正交补延拓为线性同构，再用 Mathlib 的逆函数定理得到浸入所需的局部标准形式。已有构造给出拓扑嵌入。两者合起来得到 Mathlib 所定义的 $C^1$ 嵌入。[浸入的局部标准形式](FiniteDimensionalImmersion.lean) · [两条定理](ClosedManifoldEndpoints.lean)

## 证明的入口

1. **环面上的浸入。** 两个正指数结论共用一次度量修正和几何级数估计。连续度量情形逐步选择频率，使微分增量可求和。两类证明都对微分的 Gram 型取极限，得到准确的度量。[正指数](LowTorusEndpoints.lean) · [连续度量](ContinuousTorusEndpoint.lean)
2. **坐标球内的浸入。** 用周期正弦坐标将局部度量延拓为正定的环面度量，再沿较小球上的反正弦截面取回局部解。[正定周期延拓](LocalTorusMetric.lean) · [局部浸入](LocalIsometricImmersion.lean)
3. **闭流形上的嵌入。** 用 mathlib 的 Whitney 嵌入保证最终单射。在有限图册上统一缩小这个分量和球面绕映射的半径，预留相应的度量修正。各图内求局部解，绕入定半径球面，再乘光滑平方权重并取正交直和，Gram 型恰好补回原度量。这个拼接对两条临界线和连续度量共用。[统一缩放](ManifoldMetricCorrection.lean) · [闭流形拼接](ManifoldLowAssembly.lean)

整个证明以通常的切空间和拉回条件陈述。Wang/FatFish 的包也把拉回等式写成单独的 `HasIsometricDifferential`。这里使用 Mathlib 的有限最小值、有限和求导与 Whitney 嵌入。局部换图的估计可与 Tau Ceti 的 Hölder 图册接口对照。Tau Ceti 当前主分支的工具链版本较新，本包保持 Lean 4.36.0。[Wang/FatFish 的数学审核](https://github.com/sdsefdfddf/C2RiemannianMinimal/blob/main/REVIEW.md) · [Tau Ceti 的图册证明](https://github.com/TauCetiProject/TauCeti/blob/main/TauCeti/Geometry/Manifold/ContMDiffMap/Chart/Holder/Atlas.lean)

## 指数范围

两族正指数对应 Källén 留下的临界指数。第二族取 $a<1$。在 $a=1$ 会要求普遍的 $C^{1,1}\to C^{1,1}$ 结论，而 Wang 的 $C^2$ 度量反例已经落在 $C^{1,1}$ 度量类中。本包形式化的是低阶存在性。文献归属和首证仍需独立的学术审读。[Källén，第 29–32 页](https://archive.ymsc.tsinghua.edu.cn/pacm_download/116/7279-11512_2006_Article_BF02385981.pdf) · [Wang 的手稿和 Lean 反例](https://github.com/sdsefdfddf/C2RiemannianMinimal)
