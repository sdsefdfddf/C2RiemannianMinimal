import TorusLifts
import TorusGram
import Mathlib.Analysis.Calculus.UniformLimitsDeriv
import Mathlib.Topology.Algebra.InfiniteSum.Real

namespace IsometricEmbeddingEndpoints

open Filter
open scoped Topology

noncomputable section

variable {d H : Type*} [Fintype d] [NormedAddCommGroup H]
  [InnerProductSpace ℝ H] [CompleteSpace H]

local instance : NormedAddCommGroup (MetricForm d) := inferInstance
local instance : NormedSpace ℝ (MetricForm d) := inferInstance

/-- Summable increments of maps and differentials suffice for the continuous-metric
endpoint, regardless of the frequencies of the approximations. -/
theorem exists_isometric_contDiff_limit (g : TorusMetric d)
    (u : ℕ → C(UnitAddTorus d, H))
    (hu : ∀ j, ContDiff ℝ 1 (fun x => u j (flatProjection x)))
    (hvalue : Summable (fun j => dist (u j) (u (j + 1))))
    (hdiff : Summable (fun j => dist (torusDifferential (u j) (hu j))
      (torusDifferential (u (j + 1)) (hu (j + 1)))))
    (hmetric : Tendsto (fun j => torusGram (torusDifferential (u j) (hu j))) atTop (𝓝 g.form)) :
    ∃ v : C(UnitAddTorus d, H), ContDiff ℝ 1 (fun x => v (flatProjection x)) ∧
      g.HasIsometricDifferential v := by
  obtain ⟨v, hv⟩ := cauchySeq_tendsto_of_complete (cauchySeq_of_summable_dist hvalue)
  let D := fun j => torusDifferential (u j) (hu j)
  obtain ⟨F, hF⟩ : ∃ F, Tendsto D atTop (𝓝 F) :=
    cauchySeq_tendsto_of_complete (cauchySeq_of_summable_dist hdiff)
  have hderiv (x : Cover d) :
      HasFDerivAt (fun z => v (flatProjection z)) (F (flatProjection x)) x := by
    refine hasFDerivAt_of_tendstoUniformly (f := fun j y => u j (flatProjection y))
      ((ContinuousMap.tendsto_iff_tendstoUniformly.mp hF).comp flatProjection) ?_ ?_ x
    · intro j y
      change HasFDerivAt (fun z => u j (flatProjection z))
        (torusDifferential (u j) (hu j) (flatProjection y)) y
      rw [torusDifferential_apply]
      exact ((hu j).differentiable one_ne_zero y).hasFDerivAt
    · intro y
      exact (ContinuousMap.evalCLM ℝ (flatProjection y)).continuous.continuousAt.tendsto.comp hv
  have heq : fderiv ℝ (fun z => v (flatProjection z)) = fun x => F (flatProjection x) :=
    funext fun x => (hderiv x).fderiv
  have hreg : ContDiff ℝ 1 (fun x => v (flatProjection x)) :=
    contDiff_one_iff_fderiv.2 ⟨fun x => (hderiv x).differentiableAt,
      heq ▸ F.continuous.comp flatProjection.continuous⟩
  have hgram : torusGram F = g.form :=
    tendsto_nhds_unique (continuous_torusGram.continuousAt.tendsto.comp hF) hmetric
  refine ⟨v, hreg, hreg.differentiable one_ne_zero, fun x a b => ?_⟩
  rw [heq, ← torusGram_apply, hgram]

end

end IsometricEmbeddingEndpoints

#print axioms IsometricEmbeddingEndpoints.exists_isometric_contDiff_limit
