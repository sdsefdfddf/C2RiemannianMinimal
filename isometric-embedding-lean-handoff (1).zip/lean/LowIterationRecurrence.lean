import LowGeometricScales
import LowIterationBlocks
import LowIterationStep
import TorusMetricApproximation

namespace IsometricEmbeddingEndpoints

open Finset ContinuousLinearMap

noncomputable section

section Corrections

variable {d H : Type*} [Fintype d] [NormedAddCommGroup H] [InnerProductSpace ℝ H]

/-- A correction and its differentiability certificate on the torus cover. -/
structure TorusCorrection (d H : Type*) [Fintype d] [NormedAddCommGroup H] [InnerProductSpace ℝ H] where
  value : C(UnitAddTorus d, H)
  contDiff : ContDiff ℝ 1 (fun x => value (flatProjection x))

def TorusCorrection.differential (v : TorusCorrection d H) :
    C(UnitAddTorus d, Cover d →L[ℝ] H) := torusDifferential v.value v.contDiff

def TorusCorrection.HasIterationBounds (v : TorusCorrection d H)
    (S : LowGeometricScales) (c K : ℝ) (j : ℕ) : Prop :=
  HasFourierSupport (latticeBall d (c * (S.frequency (j + 1) : ℝ))) v.differential ∧
  ‖v.value‖ ≤ K * S.amplitude j / (S.frequency (j + 1) : ℝ) ∧
  ‖v.differential‖ ≤ K * S.amplitude j ∧
  ∀ x : Cover d, ‖fderiv ℝ (fun z => v.differential (flatProjection z)) x‖ ≤
    K * (S.frequency (j + 1) : ℝ) * S.amplitude j

end Corrections

variable {d H : Type*} [Fintype d] [DecidableEq d]
  [NormedAddCommGroup H] [InnerProductSpace ℝ H] [CompleteSpace H] [FiniteDimensional ℝ H]

local instance : NormedAddCommGroup (MetricForm d) := inferInstance
local instance : NormedSpace ℝ (MetricForm d) := inferInstance
local instance : NormedAddCommGroup C(UnitAddTorus d, MetricForm d) := inferInstance

def LowGeometricScales.driftBound (S : LowGeometricScales) (K : ℝ) : ℝ :=
  (K * √S.initialDefect) * (1 - S.decay)⁻¹

def LowGeometricScales.rotationConstant (S : LowGeometricScales) (K : ℝ) : ℝ :=
  1 + K * (S.growth / (S.growth - 1))

private def prefixDifferential {j : ℕ} (v : Fin j → TorusCorrection d H) (i : ℕ) :
    C(UnitAddTorus d, Cover d →L[ℝ] H) :=
  if h : i < j then (v ⟨i, h⟩).differential else 0

private theorem iteratedBlock_congr
    (F₀ : C(UnitAddTorus d, Cover d →L[ℝ] H))
    {D D' : ℕ → C(UnitAddTorus d, Cover d →L[ℝ] H)} {B j b : ℕ}
    (h : ∀ i < j, D i = D' i) :
    iteratedBlock F₀ D B j b = iteratedBlock F₀ D' B j b := by
  unfold iteratedBlock
  congr 1
  exact sum_congr rfl (fun i hi => h i (mem_range.1 (mem_filter.1 hi).1))

private theorem prefixDifferential_snoc_lt {j i : ℕ} (v : Fin j → TorusCorrection d H)
    (w : TorusCorrection d H) (hi : i < j) :
    prefixDifferential (Fin.snoc v w) i = prefixDifferential v i := by
  simp only [prefixDifferential, dif_pos hi, dif_pos (hi.trans (Nat.lt_succ_self j))]
  exact congrArg TorusCorrection.differential
    (Fin.snoc_castSucc (α := fun _ => TorusCorrection d H) w v ⟨i, hi⟩)

private theorem prefixDifferential_snoc_last {j : ℕ} (v : Fin j → TorusCorrection d H)
    (w : TorusCorrection d H) : prefixDifferential (Fin.snoc v w) j = w.differential := by
  rw [prefixDifferential, dif_pos (Nat.lt_succ_self j)]
  change (Fin.snoc (α := fun _ => TorusCorrection d H) v w (Fin.last j)).differential = _
  rw [Fin.snoc_last]

set_option maxHeartbeats 650000 in
/-- Extend the block corrections indefinitely if the geometric scales satisfy
the initial bounds and the one-step error budget. -/
theorem exists_rotatingCorrections {B : ℕ} (hB : 0 < B) {σ M : ℝ} (hσ : 0 < σ) (hM : 0 ≤ M) :
    ∃ ε δmax c A K : ℝ, 0 < ε ∧ 0 < δmax ∧ 1 ≤ c ∧ 1 ≤ A ∧ 0 ≤ K ∧
      ∀ (g : TorusMetric d) (F₀ : C(UnitAddTorus d, Cover d →L[ℝ] H))
        (J : PiLp 2 (fun _ : TwistIndex d => CirclePair) →ₗᵢ[ℝ] H)
        (S : LowGeometricScales) (ε₀ : ℝ), 0 < ε₀ → S.initialDefect ≤ δmax →
        A * S.smoothingFraction ≤ 1 → c ≤ (S.ratio : ℝ) * S.smoothingFraction →
        ε₀ + (1 + ε₀ / 2) * S.decay ^ 2 ≤ ε →
        S.rotationConstant K * √S.initialDefect ≤ 1 →
        K * (S.smoothingFraction ^ 2 + S.rotationConstant K / S.growth ^ B + S.driftBound K ^ 2) ≤
          (ε₀ / 2) * S.decay ^ 2 →
        ‖F₀‖ + S.driftBound K ≤ M →
        (∀ t v, (σ + S.driftBound K) * ‖v‖ ≤ ‖F₀ t v‖) →
        (∀ t z, (F₀ t).adjoint (J z) = 0) →
        HasFourierSupport (latticeBall d (c * (S.frequency 0 : ℝ))) F₀ →
        (∀ x : Cover d, ‖fderiv ℝ (fun z => F₀ (flatProjection z)) x‖ ≤
          ((S.frequency 1 : ℝ) * √S.initialDefect) / S.growth ^ B) →
        (∀ j, ‖realTorusCutoff (H := MetricForm d) (S.smoothing j) g.form - g.form‖ ≤
          (ε₀ / 2) * S.defect (j + 1)) →
        ‖(B : ℝ) • torusGram F₀ - (g.form - S.initialDefect • flatMetric)‖ ≤ ε₀ * S.initialDefect →
        ∃ v : ℕ → TorusCorrection d H,
          (∀ j, (v j).HasIterationBounds S c K j) ∧
          ∀ j, ‖torusBlockGram (fun b : Fin B =>
            iteratedBlock F₀ (fun i => (v i).differential) B j b) -
              (g.form - S.defect j • flatMetric)‖ ≤ ε₀ * S.defect j := by
  obtain ⟨ε, δmax, c, A, K, hε, hδmax, hc, hA, hK, hstep⟩ :=
    exists_lowIterationStep (d := d) (ι := Fin B) (H := H) hσ hM
  refine ⟨ε, δmax, c, A, K, hε, hδmax, hc, hA, hK, ?_⟩
  intro g F₀ J S ε₀ hε₀ hδ₀ hfraction hsep hrelative hrotSmall hbudget hF₀M hF₀σ hJ hF₀band hF₀deriv
    hsmooth hinit
  let drift := S.driftBound K
  let R := S.rotationConstant K
  have hR : 0 ≤ R := by
    have hp := sub_pos.mpr S.one_lt_growth
    have hp' := zero_lt_one.trans S.one_lt_growth
    dsimp only [R, LowGeometricScales.rotationConstant]
    positivity
  have hgrowth : 0 < S.growth := zero_lt_one.trans S.one_lt_growth
  have hpow : 0 < S.growth ^ B := pow_pos hgrowth _
  let P := fun j (v : Fin j → TorusCorrection d H) =>
    (∀ i : Fin j, (v i).HasIterationBounds S c K i) ∧
    ‖torusBlockGram (fun b : Fin B => iteratedBlock F₀ (prefixDifferential v) B j b) -
      (g.form - S.defect j • flatMetric)‖ ≤ ε₀ * S.defect j
  have hP₀ : P 0 Fin.elim0 := by
    refine ⟨fun i => Fin.elim0 i, ?_⟩
    simp only [iteratedBlock, earlierBlockSteps, range_zero, filter_empty, sum_empty, add_zero,
      torusBlockGram_const, Fintype.card_fin, S.defect_zero]
    exact hinit
  have hPstep (j : ℕ) (v : Fin j → TorusCorrection d H) (hv : P j v) :
      ∃ w : TorusCorrection d H, P (j + 1) (Fin.snoc v w) := by
    let D := prefixDifferential v
    let F := fun b : Fin B => iteratedBlock F₀ D B j b
    let b := activeBlock hB j
    let N := S.frequency (j + 1)
    let δ := S.defect j
    let δ' := S.defect (j + 1)
    let Λ := S.smoothing j
    let L := R * (N : ℝ) * S.amplitude j / S.growth ^ B
    let G := realTorusCutoff (H := MetricForm d) Λ g.form
    have hN : 0 < N := S.frequency_pos _
    have hN' : 0 < (N : ℝ) := by exact_mod_cast hN
    have hδ : 0 < δ := S.defect_pos _
    have hδ' : 0 < δ' := S.defect_pos _
    have hΛ : 0 < Λ := S.smoothing_pos _
    have hAΛ : A * Λ ≤ (N : ℝ) := by
      change A * (S.smoothingFraction * (N : ℝ)) ≤ _
      rw [← mul_assoc]
      exact mul_le_of_le_one_left hN'.le hfraction
    have hfreq : c * (S.frequency j : ℝ) ≤ Λ := by
      change _ ≤ S.smoothingFraction * (S.frequency (j + 1) : ℝ)
      rw [S.frequency_succ, Nat.cast_mul]
      calc
        _ ≤ ((S.ratio : ℝ) * S.smoothingFraction) * (S.frequency j : ℝ) :=
          mul_le_mul_of_nonneg_right hsep (by positivity)
        _ = _ := by ring
    have hD (i : ℕ) (hi : i < j) :
        HasFourierSupport (latticeBall d (c * (S.frequency (i + 1) : ℝ))) (D i) ∧
        ‖D i‖ ≤ K * S.amplitude i ∧
        ∀ x : Cover d, ‖fderiv ℝ (fun z => D i (flatProjection z)) x‖ ≤
          K * (S.frequency (i + 1) : ℝ) * S.amplitude i := by
      have h := hv.1 ⟨i, hi⟩
      simpa only [D, prefixDifferential, dif_pos hi] using And.intro h.1 (And.intro h.2.2.1 h.2.2.2)
    have hFband (k : Fin B) : HasFourierSupport (latticeBall d Λ) (F k) := by
      apply hasFourierSupport_iteratedBlock F₀ D B j k
      · apply hF₀band.mono (latticeBall_mono ?_)
        exact (mul_le_mul_of_nonneg_left (by exact_mod_cast S.frequency_mono (Nat.zero_le j))
          (zero_le_one.trans hc)).trans hfreq
      · intro i hi
        apply (hD i hi).1.mono (latticeBall_mono ?_)
        exact (mul_le_mul_of_nonneg_left (by exact_mod_cast S.frequency_mono (Nat.succ_le_of_lt hi))
          (zero_le_one.trans hc)).trans hfreq
    have hFdrift : ‖F b - F₀‖ ≤ drift := by
      apply norm_iteratedBlock_sub_initial_le F₀ D B j b
        (C := K * √S.initialDefect) (q := S.decay) (by positivity) S.decay_pos.le S.decay_lt_one
      intro i hi
      simpa only [LowGeometricScales.amplitude, mul_assoc] using (hD i hi).2.1
    have hFNorm : ‖F b‖ ≤ M := by
      calc
        ‖F b‖ = ‖F b - F₀ + F₀‖ := by rw [sub_add_cancel]
        _ ≤ ‖F b - F₀‖ + ‖F₀‖ := norm_add_le (F b - F₀) F₀
        _ ≤ _ := by linarith
    have hFσ (t : UnitAddTorus d) (x : Cover d) : σ * ‖x‖ ≤ ‖F b t x‖ := by
      have hAt : ‖F b t - F₀ t‖ ≤ drift := ((F b - F₀).norm_coe_le_norm t).trans hFdrift
      have hx : ‖F b t x - F₀ t x‖ ≤ drift * ‖x‖ :=
        (le_opNorm (F b t - F₀ t) x).trans (mul_le_mul_of_nonneg_right hAt (norm_nonneg _))
      have h := norm_sub_norm_le (F₀ t x) (F b t x)
      rw [norm_sub_rev] at h
      linarith only [h, hx, hF₀σ t x]
    have hDF (x : Cover d) : ‖fderiv ℝ (fun z => F b (flatProjection z)) x‖ ≤ L := by
      have h := norm_fderiv_iteratedBlock_active_le F₀ D B j x
        (C := K * ((S.frequency 1 : ℝ) * √S.initialDefect))
        S.one_lt_growth (by positivity)
        ((hF₀band.contDiff_lift (k := 1)).differentiable one_ne_zero x)
        (fun i hi => ((hD i hi).1.contDiff_lift (k := 1)).differentiable one_ne_zero x)
        (fun i hi => by
          refine ((hD i hi).2.2 x).trans_eq ?_
          rw [mul_assoc K, S.frequency_mul_amplitude]
          ring)
      refine h.trans ?_
      calc
        _ ≤ ((S.frequency 1 : ℝ) * √S.initialDefect) / S.growth ^ B +
            (K * ((S.frequency 1 : ℝ) * √S.initialDefect)) *
              ((S.growth / (S.growth - 1)) * (S.growth ^ j / S.growth ^ B)) :=
          add_le_add (hF₀deriv x) le_rfl
        _ ≤ (((S.frequency 1 : ℝ) * √S.initialDefect) / S.growth ^ B) * S.growth ^ j +
            (K * ((S.frequency 1 : ℝ) * √S.initialDefect)) *
              ((S.growth / (S.growth - 1)) * (S.growth ^ j / S.growth ^ B)) := by
          exact add_le_add
            (le_mul_of_one_le_right (by positivity) (one_le_pow₀ S.one_lt_growth.le)) le_rfl
        _ = L := by
          change _ = R * (N : ℝ) * S.amplitude j / S.growth ^ B
          rw [mul_assoc R]
          dsimp only [L, R, LowGeometricScales.rotationConstant, N]
          rw [S.frequency_mul_amplitude]
          ring
    have hL : 0 ≤ L := div_nonneg (mul_nonneg (mul_nonneg hR hN'.le) (S.amplitude_pos j).le) hpow.le
    have hLN : L ≤ (N : ℝ) := by
      have hRa : R * S.amplitude j ≤ 1 :=
        (mul_le_mul_of_nonneg_left (S.amplitude_le j) hR).trans hrotSmall
      have hp₁ : 1 ≤ S.growth ^ B := one_le_pow₀ S.one_lt_growth.le
      apply (div_le_iff₀ hpow).2
      calc
        R * (N : ℝ) * S.amplitude j = (R * S.amplitude j) * (N : ℝ) := by ring
        _ ≤ 1 * (N : ℝ) := mul_le_mul_of_nonneg_right hRa hN'.le
        _ ≤ _ := by rw [one_mul]; exact le_mul_of_one_le_right hN'.le hp₁
    have hGband : HasFourierSupport (latticeBall d (2 * Λ)) G :=
      (hasFourierSupport_realTorusCutoff hΛ g.form).mono (torusCutoffBand_subset_latticeBall _)
    have hEnorm : ‖normalizedDefect G (torusBlockGram F) δ δ'‖ ≤ ε := by
      refine (norm_normalizedDefect_le g.form G (torusBlockGram F) hδ hδ'.le (hsmooth j) hv.2).trans ?_
      have heq : ((ε₀ / 2) * δ' + ε₀ * δ + δ') / δ =
          ε₀ + (1 + ε₀ / 2) * S.decay ^ 2 := by
        dsimp only [δ', δ]
        rw [S.defect_succ]
        field_simp [(S.defect_pos j).ne']
        ring
      rw [heq]
      exact hrelative
    obtain ⟨w, hw, hwband, hDb, hw₀, hw₁, hw₂, hmetric⟩ :=
      hstep g.form G F F₀ b J hN hδ ((S.defect_le j).trans hδ₀) hΛ hAΛ hL hLN
        hFNorm hFσ hJ hFband hDF hGband (g.realTorusCutoff_symmetric hΛ) hEnorm
    let W : TorusCorrection d H := ⟨w, hw⟩
    have hW : W.HasIterationBounds S c K j := by
      simpa only [TorusCorrection.HasIterationBounds, TorusCorrection.differential, W, δ, N,
        S.sqrt_defect] using And.intro hDb (And.intro hw₀ (And.intro hw₁ hw₂))
    have hnext : ‖torusBlockGram (Function.update F b (F b + W.differential)) -
        (g.form - δ' • flatMetric)‖ ≤ ε₀ * δ' := by
      refine hmetric.trans ?_
      have hratio : Λ / (N : ℝ) = S.smoothingFraction := mul_div_cancel_right₀ _ hN'.ne'
      have hnum : √δ * L / (N : ℝ) = δ * (R / S.growth ^ B) := by
        dsimp only [δ, L]
        rw [S.sqrt_defect]
        dsimp only [LowGeometricScales.defect]
        field_simp <;> ring
      rw [hratio, hnum]
      have he : ‖G - g.form‖ ≤ ε₀ / 2 * δ' := hsmooth j
      have hdrift : 0 ≤ drift := by
        dsimp only [drift, LowGeometricScales.driftBound]
        exact mul_nonneg (by positivity) (inv_nonneg.mpr (sub_nonneg.mpr S.decay_lt_one.le))
      calc
        _ ≤ K * (δ * S.smoothingFraction ^ 2 + δ * (R / S.growth ^ B) + δ * drift ^ 2) +
            ε₀ / 2 * δ' := by gcongr
        _ = δ * (K * (S.smoothingFraction ^ 2 + R / S.growth ^ B + drift ^ 2) +
            (ε₀ / 2) * S.decay ^ 2) := by
          dsimp only [δ', δ]
          rw [S.defect_succ]
          ring
        _ ≤ _ := by
          have hbgt : K * (S.smoothingFraction ^ 2 + R / S.growth ^ B + drift ^ 2) ≤
              (ε₀ / 2) * S.decay ^ 2 := hbudget
          dsimp only [δ', δ]
          rw [S.defect_succ]
          nlinarith [mul_le_mul_of_nonneg_left hbgt hδ.le]
    have hchanges (k : Fin B) :
        iteratedBlock F₀ (prefixDifferential (Fin.snoc v W)) B (j + 1) k =
          Function.update F b (F b + W.differential) k := by
      rw [congrFun (iteratedBlock_succ F₀ (prefixDifferential (Fin.snoc v W)) hB j) k,
        prefixDifferential_snoc_last]
      have hprev (k' : Fin B) : iteratedBlock F₀ (prefixDifferential (Fin.snoc v W)) B j k' = F k' :=
        iteratedBlock_congr F₀ (fun i hi => prefixDifferential_snoc_lt v W hi)
      rw [funext hprev, hprev b]
    refine ⟨W, ?_, ?_⟩
    · intro i
      refine Fin.lastCases ?_ (fun i' => ?_) i
      · simpa only [Fin.snoc_last, Fin.val_last] using hW
      · simpa only [Fin.snoc_castSucc, Fin.val_castSucc] using hv.1 i'
    · rw [funext hchanges]
      exact hnext
  obtain ⟨v, hv⟩ := exists_sequence_of_prefix_extension P hP₀ hPstep
  refine ⟨v, fun j => (hv (j + 1)).1 (Fin.last j), ?_⟩
  intro j
  have hblocks : (fun b : Fin B => iteratedBlock F₀ (prefixDifferential (fun i : Fin j => v i)) B j b) =
      (fun b : Fin B => iteratedBlock F₀ (fun i => (v i).differential) B j b) :=
    funext fun b => iteratedBlock_congr F₀ (fun i hi => by simp only [prefixDifferential, dif_pos hi])
  rw [← hblocks]
  exact (hv j).2

end

end IsometricEmbeddingEndpoints

#print axioms IsometricEmbeddingEndpoints.exists_rotatingCorrections
