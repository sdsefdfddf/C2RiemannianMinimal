import LocalComposition
import Mathlib.Analysis.SpecialFunctions.Sqrt

namespace IsometricEmbeddingEndpoints

variable {E : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E]

/-- Taking the square root of a positive coefficient of size `δ` produces the factor
`√δ` in every derivative bound. The normalized coefficient stays in a fixed positive interval. -/
theorem exists_bound_iteratedFDeriv_amplitude {a b : ℝ} (ha : 0 < a) (n : ℕ) :
    ∃ C : ℝ, 0 ≤ C ∧ ∀ (f : E → ℝ) {δ : ℝ} (D : ℝ), 0 ≤ δ →
      ContDiff ℝ n f → (∀ x, f x ∈ Set.Icc a b) → ∀ (x : E) (j : ℕ), j ≤ n →
        (∀ i, 1 ≤ i → i ≤ j → ‖iteratedFDeriv ℝ i f x‖ ≤ D ^ i) →
        ‖iteratedFDeriv ℝ j (fun z => Real.sqrt (δ * f z)) x‖ ≤ j.factorial * C * Real.sqrt δ * D ^ j := by
  obtain ⟨C, hC, h⟩ := exists_uniform_iteratedFDeriv_comp_le (E := E)
    (g := Real.sqrt) isCompact_Icc n
    (fun y (hy : y ∈ Set.Icc a b) => Real.contDiffAt_sqrt (ha.trans_le hy.1).ne')
  refine ⟨C, hC, fun f δ D hδ hf hI x j hj hD => ?_⟩
  have hj' : (j : WithTop ℕ∞) ≤ n := by exact_mod_cast hj
  have hroot : ContDiffAt ℝ j (Real.sqrt ∘ f) x :=
    ((hf.of_le hj').contDiffAt.sqrt (ha.trans_le (hI x).1).ne')
  have hrange : Set.range f ⊆ Set.Icc a b := by
    rintro _ ⟨z, rfl⟩
    exact hI z
  simp only [Real.sqrt_mul hδ]
  change ‖iteratedFDeriv ℝ j (fun z => Real.sqrt δ • (Real.sqrt ∘ f) z) x‖ ≤ _
  rw [iteratedFDeriv_const_smul_apply' hroot, norm_smul, Real.norm_eq_abs, abs_of_nonneg (Real.sqrt_nonneg _)]
  calc
    _ ≤ Real.sqrt δ * (j.factorial * C * D ^ j) :=
      mul_le_mul_of_nonneg_left (h f D hf hrange x j hj hD) (Real.sqrt_nonneg _)
    _ = _ := by ring

variable {F G H : Type*}
  [NormedAddCommGroup F] [NormedSpace ℝ F] [NormedAddCommGroup G] [NormedSpace ℝ G]
  [NormedAddCommGroup H] [NormedSpace ℝ H]

/-- The Leibniz bound preserves a common spatial scale for the two inputs. -/
theorem norm_iteratedFDeriv_bilinear_le_of_scaled_bounds
    (B : F →L[ℝ] G →L[ℝ] H) {f : E → F} {g : E → G} {n : ℕ}
    (hf : ContDiff ℝ n f) (hg : ContDiff ℝ n g) (x : E)
    {A C Λ : ℝ} (hA : 0 ≤ A) (hΛ : 0 ≤ Λ)
    (hf' : ∀ i ≤ n, ‖iteratedFDeriv ℝ i f x‖ ≤ A * Λ ^ i)
    (hg' : ∀ i ≤ n, ‖iteratedFDeriv ℝ i g x‖ ≤ C * Λ ^ i) :
    ‖iteratedFDeriv ℝ n (fun y => B (f y) (g y)) x‖ ≤ ‖B‖ * (2 ^ n * (A * C * Λ ^ n)) := by
  refine (B.norm_iteratedFDeriv_le_of_bilinear hf hg x le_rfl).trans
    (mul_le_mul_of_nonneg_left ?_ (norm_nonneg B))
  calc
    _ ≤ ∑ i ∈ Finset.range (n + 1), (n.choose i : ℝ) * (A * C * Λ ^ n) := by
      apply Finset.sum_le_sum
      intro i hi
      have hin : i ≤ n := Nat.le_of_lt_succ (Finset.mem_range.mp hi)
      have hc : 0 ≤ (n.choose i : ℝ) := by positivity
      calc
        _ ≤ (n.choose i : ℝ) * (A * Λ ^ i) * (C * Λ ^ (n - i)) :=
          mul_le_mul (mul_le_mul_of_nonneg_left (hf' i hin) hc) (hg' _ (Nat.sub_le _ _))
            (norm_nonneg _) (mul_nonneg hc (mul_nonneg hA (pow_nonneg hΛ _)))
        _ = _ := by
          rw [show Λ ^ n = Λ ^ i * Λ ^ (n - i) by rw [← pow_add, Nat.add_sub_of_le hin]]
          ring
    _ = _ := by rw [← Finset.sum_mul, ← Nat.cast_sum, Nat.sum_range_choose]; norm_cast

end IsometricEmbeddingEndpoints

#print axioms IsometricEmbeddingEndpoints.exists_bound_iteratedFDeriv_amplitude
#print axioms IsometricEmbeddingEndpoints.norm_iteratedFDeriv_bilinear_le_of_scaled_bounds
