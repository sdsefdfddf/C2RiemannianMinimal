import ManifoldMetricCharts
import Mathlib.Geometry.Manifold.ContMDiff.Atlas
import Mathlib.Geometry.Manifold.ContMDiff.NormedSpace
import Mathlib.Topology.Algebra.Group.ContinuousDiv

open scoped ContDiff Manifold Topology

namespace IsometricEmbeddingEndpoints

open Set

noncomputable section

variable {d M : Type*} [Fintype d] [TopologicalSpace M] [ChartedSpace (Cover d) M]

local notation "𝕀" => 𝓘(ℝ, Cover d)

@[simp] theorem centeredChart_source (p : M) :
    (centeredChart (d := d) p).source = (chartAt (Cover d) p).source := rfl

@[simp] theorem mem_centeredChart_source (p : M) : p ∈ (centeredChart (d := d) p).source :=
  mem_chart_source _ _

@[simp] theorem centeredChart_self (p : M) : centeredChart (d := d) p p = 0 := by
  change chartAt (Cover d) p p - chartAt (Cover d) p p = 0
  exact sub_self _

theorem zero_mem_centeredChart_target (p : M) : (0 : Cover d) ∈ (centeredChart (d := d) p).target := by
  simpa only [centeredChart_self] using (centeredChart (d := d) p).map_source (mem_centeredChart_source p)

theorem contMDiffAt_centeredChart [IsManifold 𝕀 ∞ M] {p x : M}
    (hx : x ∈ (centeredChart (d := d) p).source) : ContMDiffAt 𝕀 𝕀 ∞ (centeredChart (d := d) p) x := by
  let b := chartAt (Cover d) p p
  have hchart : ContMDiffAt 𝕀 𝕀 ∞ (chartAt (Cover d) p) x :=
    (contMDiffOn_chart (I := 𝕀) (n := ∞) (x := p)).contMDiffAt
      ((chartAt (Cover d) p).open_source.mem_nhds hx)
  have hsub : ContDiff ℝ ∞ (fun y : Cover d => y - b) := contDiff_id.sub contDiff_const
  exact hsub.contDiffAt.contMDiffAt.comp x hchart

theorem contMDiffAt_centeredChart_symm [IsManifold 𝕀 ∞ M] {p : M} {x : Cover d}
    (hx : x ∈ (centeredChart (d := d) p).target) : ContMDiffAt 𝕀 𝕀 ∞ (centeredChart (d := d) p).symm x := by
  let b := chartAt (Cover d) p p
  have hx' : x + b ∈ (chartAt (Cover d) p).target := hx
  have hchart : ContMDiffAt 𝕀 𝕀 ∞ (chartAt (Cover d) p).symm (x + b) :=
    (contMDiffOn_chart_symm (I := 𝕀) (n := ∞) (x := p)).contMDiffAt
      ((chartAt (Cover d) p).open_target.mem_nhds hx')
  have hadd : ContDiff ℝ ∞ (fun y : Cover d => y + b) := contDiff_id.add contDiff_const
  change ContMDiffAt 𝕀 𝕀 ∞ (fun y => (chartAt (Cover d) p).symm (y + b)) x
  exact hchart.comp x hadd.contDiffAt.contMDiffAt

theorem mdifferentiable_centeredChart [IsManifold 𝕀 ∞ M] (p : M) :
    (centeredChart (d := d) p).MDifferentiable 𝕀 𝕀 := by
  constructor
  · intro x hx
    exact ((contMDiffAt_centeredChart hx).mdifferentiableAt (by simp)).mdifferentiableWithinAt
  · intro x hx
    exact ((contMDiffAt_centeredChart_symm hx).mdifferentiableAt (by simp)).mdifferentiableWithinAt

/-- The preimage of an open coordinate ball, restricted to the chart source. -/
def centeredChartBall (p : M) (r : ℝ) : Set M :=
  (centeredChart (d := d) p).source ∩ (centeredChart (d := d) p) ⁻¹' Metric.ball 0 r

theorem isOpen_centeredChartBall (p : M) (r : ℝ) : IsOpen (centeredChartBall (d := d) p r) :=
  (centeredChart (d := d) p).continuousOn.isOpen_inter_preimage (centeredChart (d := d) p).open_source Metric.isOpen_ball

theorem mem_centeredChartBall (p : M) {r : ℝ} (hr : 0 < r) : p ∈ centeredChartBall (d := d) p r := by
  exact ⟨mem_centeredChart_source p, by simpa [centeredChart_self] using hr⟩

/-- One may choose the radius at every center before taking a finite subcover. -/
theorem exists_finite_centeredChartBall_cover [CompactSpace M] (r : M → ℝ) (hr : ∀ p, 0 < r p) :
    ∃ s : Finset M, (Set.univ : Set M) ⊆ ⋃ p : s, centeredChartBall (d := d) p (r p) := by
  obtain ⟨s, hs⟩ := isCompact_univ.elim_finite_subcover (fun p => centeredChartBall (d := d) p (r p))
    (fun p => isOpen_centeredChartBall (d := d) p (r p))
    (fun p _ => mem_iUnion.2 ⟨p, mem_centeredChartBall (d := d) p (hr p)⟩)
  refine ⟨s, fun p hp => ?_⟩
  obtain ⟨q, hq, hmem⟩ := mem_iUnion₂.1 (hs hp)
  exact mem_iUnion.2 ⟨⟨q, hq⟩, hmem⟩

end

end IsometricEmbeddingEndpoints

#print axioms IsometricEmbeddingEndpoints.exists_finite_centeredChartBall_cover
