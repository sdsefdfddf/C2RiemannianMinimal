import LowIterationScales

namespace IsometricEmbeddingEndpoints

open Filter
open scoped Topology

/-- Frequency and defect scales for the block iteration. The smoothing radius
is a fixed fraction of the carrier frequency. -/
structure LowGeometricScales where
  ratio : ℕ
  initialFrequency : ℕ
  exponent : ℝ
  initialDefect : ℝ
  smoothingFraction : ℝ
  ratio_ge_two : 2 ≤ ratio
  initialFrequency_pos : 0 < initialFrequency
  exponent_pos : 0 < exponent
  exponent_lt_one : exponent < 1
  initialDefect_pos : 0 < initialDefect
  smoothingFraction_pos : 0 < smoothingFraction

namespace LowGeometricScales

noncomputable section

variable (S : LowGeometricScales)

def decay : ℝ := (S.ratio : ℝ) ^ (-S.exponent)
def growth : ℝ := (S.ratio : ℝ) ^ (1 - S.exponent)
def frequency (j : ℕ) : ℕ := S.initialFrequency * S.ratio ^ j
def amplitude (j : ℕ) : ℝ := √S.initialDefect * S.decay ^ j
def defect (j : ℕ) : ℝ := S.amplitude j ^ 2
def smoothing (j : ℕ) : ℝ := S.smoothingFraction * (S.frequency (j + 1) : ℝ)

theorem one_lt_ratio : 1 < (S.ratio : ℝ) := by
  exact_mod_cast (show 1 < S.ratio from S.ratio_ge_two)

theorem ratio_pos : 0 < S.ratio := (by decide : 0 < 2).trans_le S.ratio_ge_two

theorem decay_pos : 0 < S.decay := Real.rpow_pos_of_pos (zero_lt_one.trans S.one_lt_ratio) _

theorem decay_lt_one : S.decay < 1 :=
  Real.rpow_lt_one_of_one_lt_of_neg S.one_lt_ratio (neg_neg_of_pos S.exponent_pos)

theorem one_lt_growth : 1 < S.growth :=
  Real.one_lt_rpow S.one_lt_ratio (sub_pos.mpr S.exponent_lt_one)

theorem growth_eq : S.growth = (S.ratio : ℝ) * S.decay := by
  rw [growth, sub_eq_add_neg, Real.rpow_add (zero_lt_one.trans S.one_lt_ratio), Real.rpow_one, decay]

theorem frequency_pos (j : ℕ) : 0 < S.frequency j := mul_pos S.initialFrequency_pos (pow_pos S.ratio_pos _)

theorem frequency_mono : Monotone S.frequency := by
  intro i j hij
  exact Nat.mul_le_mul_left _ (Nat.pow_le_pow_right S.ratio_pos hij)

theorem frequency_zero : S.frequency 0 = S.initialFrequency := by simp [frequency]

theorem frequency_succ (j : ℕ) : S.frequency (j + 1) = S.frequency j * S.ratio := by
  simp only [frequency, pow_succ, mul_assoc]

theorem amplitude_pos (j : ℕ) : 0 < S.amplitude j :=
  mul_pos (Real.sqrt_pos.2 S.initialDefect_pos) (pow_pos S.decay_pos _)

theorem amplitude_le (j : ℕ) : S.amplitude j ≤ √S.initialDefect := by
  exact mul_le_of_le_one_right (Real.sqrt_nonneg _) (pow_le_one₀ S.decay_pos.le S.decay_lt_one.le)

theorem frequency_mul_amplitude (j : ℕ) :
    (S.frequency (j + 1) : ℝ) * S.amplitude j =
      ((S.frequency 1 : ℝ) * √S.initialDefect) * S.growth ^ j := by
  simp only [frequency, Nat.cast_mul, Nat.cast_pow, pow_one, amplitude, S.growth_eq, mul_pow]
  rw [pow_succ]
  ring

theorem defect_pos (j : ℕ) : 0 < S.defect j := sq_pos_of_pos (S.amplitude_pos j)

theorem defect_zero : S.defect 0 = S.initialDefect := by
  simp only [defect, amplitude, pow_zero, mul_one, Real.sq_sqrt S.initialDefect_pos.le]

theorem defect_le (j : ℕ) : S.defect j ≤ S.initialDefect := by
  rw [← S.defect_zero]
  apply pow_le_pow_left₀ (S.amplitude_pos j).le
  simpa only [amplitude, pow_zero, mul_one] using S.amplitude_le j

theorem sqrt_defect (j : ℕ) : √(S.defect j) = S.amplitude j := Real.sqrt_sq (S.amplitude_pos j).le

theorem defect_succ (j : ℕ) : S.defect (j + 1) = S.defect j * S.decay ^ 2 := by
  simp only [defect, amplitude, pow_succ]
  ring

theorem decay_sq : S.decay ^ 2 = (S.ratio : ℝ) ^ (-(2 * S.exponent)) := by
  rw [decay, ← Real.rpow_natCast _ 2, ← Real.rpow_mul (zero_lt_one.trans S.one_lt_ratio).le]
  congr 1
  push_cast
  ring

theorem defect_eq (j : ℕ) : S.defect j = S.initialDefect * ((S.ratio : ℝ) ^ (-(2 * S.exponent))) ^ j := by
  rw [← S.decay_sq]
  simp only [defect, amplitude, mul_pow, Real.sq_sqrt S.initialDefect_pos.le, ← pow_mul]
  rw [mul_comm j 2]

theorem tendsto_defect : Tendsto S.defect atTop (𝓝 0) := by
  change Tendsto (fun j : ℕ => (√S.initialDefect * S.decay ^ j) ^ 2) atTop (𝓝 0)
  have hq := tendsto_pow_atTop_nhds_zero_of_lt_one S.decay_pos.le S.decay_lt_one
  have h := ((hq.const_mul √S.initialDefect).pow 2)
  simpa only [defect, amplitude, mul_zero, zero_pow (by decide : 2 ≠ (0 : ℕ))] using h

theorem smoothing_pos (j : ℕ) : 0 < S.smoothing j := by
  exact mul_pos S.smoothingFraction_pos (by exact_mod_cast S.frequency_pos (j + 1))

end

end LowGeometricScales

end IsometricEmbeddingEndpoints
