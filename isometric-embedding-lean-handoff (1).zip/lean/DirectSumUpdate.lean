import Mathlib.Analysis.InnerProductSpace.PiL2
import Mathlib.Analysis.Calculus.FDeriv.Prod

namespace IsometricEmbeddingEndpoints

noncomputable section

variable {E H ι : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E]
  [NormedAddCommGroup H] [InnerProductSpace ℝ H] [Fintype ι]

/-- Assemble the differentials of finitely many orthogonal coordinate blocks. -/
def directSumDifferential (F : ι → E →L[ℝ] H) :
    E →L[ℝ] PiLp 2 (fun _ : ι => H) :=
  (PiLp.continuousLinearEquiv 2 ℝ (fun _ : ι => H)).symm.toContinuousLinearMap.comp
    (ContinuousLinearMap.pi F)

theorem hasFDerivAt_directSum {f : ι → E → H} {F : ι → E →L[ℝ] H} {x : E}
    (hf : ∀ i, HasFDerivAt (f i) (F i) x) :
    HasFDerivAt (fun y => WithLp.toLp 2 (fun i => f i y)) (directSumDifferential F) x :=
  (PiLp.continuousLinearEquiv 2 ℝ (fun _ : ι => H)).symm.toContinuousLinearMap.hasFDerivAt.comp x
    (hasFDerivAt_pi.mpr hf)

theorem inner_directSumDifferential (F : ι → E →L[ℝ] H) (v w : E) :
    inner ℝ (directSumDifferential F v) (directSumDifferential F w) =
      ∑ i, inner ℝ (F i v) (F i w) := by
  rw [PiLp.inner_apply]
  rfl

/-- When a single block is updated, its metric error is exactly the metric error of the
whole map. The other blocks cancel in the Gram sum. -/
theorem inner_directSumDifferential_update [DecidableEq ι]
    (F : ι → E →L[ℝ] H) (b : ι) (D : E →L[ℝ] H) (v w : E) :
    let G := directSumDifferential (Function.update F b (F b + D))
    inner ℝ (G v) (G w) -
      inner ℝ (directSumDifferential F v) (directSumDifferential F w) =
      inner ℝ ((F b + D) v) ((F b + D) w) - inner ℝ (F b v) (F b w) := by
  dsimp only
  rw [inner_directSumDifferential, inner_directSumDifferential, ← Finset.sum_sub_distrib]
  rw [Finset.sum_eq_single b]
  · simp only [Function.update_self]
  · intro i _ hi
    simp only [Function.update_of_ne hi, sub_self]
  · simp

end

end IsometricEmbeddingEndpoints

#print axioms IsometricEmbeddingEndpoints.inner_directSumDifferential_update
