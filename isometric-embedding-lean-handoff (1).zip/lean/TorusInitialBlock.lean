import TorusInitialMetric
import Mathlib.Analysis.InnerProductSpace.ProdL2

namespace IsometricEmbeddingEndpoints

open ContinuousLinearMap

noncomputable section

variable {d : Type*} [Fintype d] [DecidableEq d]

local instance : NormedAddCommGroup (MetricForm d) := inferInstance
local instance : NormedSpace ℝ (MetricForm d) := inferInstance

private def prodInlIsometry (H K : Type*) [NormedAddCommGroup H] [NormedAddCommGroup K]
    [NormedSpace ℝ H] [NormedSpace ℝ K] : H →ₗᵢ[ℝ] WithLp 2 (H × K) where
  toLinearMap := (WithLp.linearEquiv 2 ℝ (H × K)).symm.toLinearMap.comp (LinearMap.inl ℝ H K)
  norm_map' x := by
    change ‖WithLp.toLp 2 (x, (0 : K))‖ = ‖x‖
    rw [WithLp.prod_norm_eq_of_L2]
    simp

private def prodInrIsometry (H K : Type*) [NormedAddCommGroup H] [NormedAddCommGroup K]
    [NormedSpace ℝ H] [NormedSpace ℝ K] : K →ₗᵢ[ℝ] WithLp 2 (H × K) where
  toLinearMap := (WithLp.linearEquiv 2 ℝ (H × K)).symm.toLinearMap.comp (LinearMap.inr ℝ H K)
  norm_map' x := by
    change ‖WithLp.toLp 2 ((0 : H), x)‖ = ‖x‖
    rw [WithLp.prod_norm_eq_of_L2]
    simp

abbrev InitialBlockSpace (d : Type*) [Fintype d] (n : ℕ) :=
  WithLp 2
    (PiLp 2 (fun _ : (Fin n × Fin (Module.finrank ℝ (Cover d))) ⊕ TwistIndex d => CirclePair) ×
      PiLp 2 (fun _ : TwistIndex d => CirclePair))

instance (n : ℕ) : FiniteDimensional ℝ (InitialBlockSpace d n) :=
  (WithLp.linearEquiv 2 ℝ _).symm.finiteDimensional

set_option maxHeartbeats 570000 in
/-- An initial block with a prescribed metric deficit. Repeating the block (B)
times gives the required initial metric, and the second factor is available for
normal corrections. The differential bounds hold uniformly in the deficit. -/
theorem TorusMetric.exists_initialBlock (g : TorusMetric d) {B : ℕ} (hB : 0 < B) :
    ∃ (n : ℕ) (δmax σ M : ℝ)
      (J : PiLp 2 (fun _ : TwistIndex d => CirclePair) →ₗᵢ[ℝ] InitialBlockSpace d n),
      0 < δmax ∧ 0 < σ ∧ 0 ≤ M ∧
      ∀ δ ε : ℝ, 0 ≤ δ → δ ≤ δmax → 0 < ε → ε ≤ δmax →
        ∃ (s : ℝ) (u : C(UnitAddTorus d, InitialBlockSpace d n))
          (hu : ContDiff ℝ 1 (fun z => u (flatProjection z))), 0 < s ∧
          let F := torusDifferential u hu
          HasFourierSupport (torusCutoffBand (d := d) s : Set (d → ℤ)) u ∧
          HasFourierSupport (torusCutoffBand (d := d) s : Set (d → ℤ)) F ∧
          ‖F‖ ≤ M ∧ (∀ t v, σ * ‖v‖ ≤ ‖F t v‖) ∧ (∀ t z, (F t).adjoint (J z) = 0) ∧
          ‖(B : ℝ) • torusGram F - (g.form - δ • flatMetric)‖ < ε := by
  obtain ⟨m, hm, hmetric₀⟩ := g.exists_lowerBound
  obtain ⟨n, δ₀, hδ₀, hstart⟩ := g.exists_fixed_target_initialMap
  let δmax := min δ₀ (m / 4)
  have hδmax : 0 < δmax := lt_min hδ₀ (by positivity)
  have hB' : 0 < (B : ℝ) := by exact_mod_cast hB
  let σ := √((m / 2) / (B : ℝ))
  let M := √((‖g.form‖ + m / 4) / (B : ℝ))
  have hσ : 0 < σ := by dsimp only [σ]; positivity
  have hM : 0 ≤ M := Real.sqrt_nonneg _
  let H := PiLp 2 (fun _ : (Fin n × Fin (Module.finrank ℝ (Cover d))) ⊕ TwistIndex d => CirclePair)
  let K := PiLp 2 (fun _ : TwistIndex d => CirclePair)
  let I := prodInlIsometry H K
  let J := prodInrIsometry H K
  refine ⟨n, δmax, σ, M, J, hδmax, hσ, hM, ?_⟩
  intro δ ε hδ hδ' hε hε'
  obtain ⟨s, w, hw, hs, hband, hGram⟩ := hstart δ ε hδ (hδ'.trans (min_le_left _ _)) hε
  let r := (√(B : ℝ))⁻¹
  have hr : (B : ℝ) * r ^ 2 = 1 := by
    dsimp only [r]
    rw [inv_pow, Real.sq_sqrt hB'.le, mul_inv_cancel₀ hB'.ne']
  let T := r • I.toContinuousLinearMap
  let u := (ContinuousLinearMap.compLeftContinuous ℝ (UnitAddTorus d) T) w
  have hu : ContDiff ℝ 1 (fun z => u (flatProjection z)) := T.contDiff.comp hw
  have huBand : HasFourierSupport (torusCutoffBand (d := d) s : Set (d → ℤ)) u := hband.postcomp T
  let W := torusDifferential w hw
  let F := torusDifferential u hu
  have hF (t : UnitAddTorus d) (v : Cover d) : F t v = r • I (W t v) := by
    obtain ⟨x, rfl⟩ := flatProjection_surjective t
    dsimp only [F, W]
    rw [torusDifferential_apply, torusDifferential_apply]
    have h := T.hasFDerivAt.comp x (hw.differentiable one_ne_zero x).hasFDerivAt
    exact DFunLike.congr_fun h.fderiv v
  have hFband : HasFourierSupport (torusCutoffBand (d := d) s : Set (d → ℤ)) F := by
    have hs' : 0 < 2 * s := by positivity
    refine huBand.differential hs' (fun k hk => ?_) F (fun x => ?_)
    · rw [norm_smul, Real.norm_eq_abs, abs_of_nonneg (inv_nonneg.mpr hs'.le)]
      exact (mul_le_mul_of_nonneg_left (norm_le_of_mem_torusCutoffBand hk)
        (inv_nonneg.mpr hs'.le)).trans_eq (inv_mul_cancel₀ hs'.ne')
    · dsimp only [F]
      rw [torusDifferential_apply]
      exact (hu.differentiable one_ne_zero x).hasFDerivAt
  have horth (t : UnitAddTorus d) (z : K) : (F t).adjoint (J z) = 0 := by
    have hzero (v : Cover d) : inner ℝ ((F t).adjoint (J z)) v = 0 := by
      rw [(F t).adjoint_inner_left, hF, real_inner_smul_right]
      change r * inner ℝ (WithLp.toLp 2 ((0 : H), z)) (WithLp.toLp 2 (W t v, (0 : K))) = 0
      simp
    exact inner_self_eq_zero.mp (hzero _)
  have hgram (t : UnitAddTorus d) (v w' : Cover d) :
      (B : ℝ) * inner ℝ (F t v) (F t w') = inner ℝ (W t v) (W t w') := by
    simp only [hF, real_inner_smul_left, real_inner_smul_right, I.inner_map_map]
    calc
      _ = ((B : ℝ) * r ^ 2) * inner ℝ (W t v) (W t w') := by ring
      _ = _ := by rw [hr, one_mul]
  have hscaled : (B : ℝ) • torusGram F = torusGram W := by
    ext t v w'
    simpa only [ContinuousMap.smul_apply, smul_apply, smul_eq_mul, torusGram_apply] using hgram t v w'
  have hError (t : UnitAddTorus d) (v : Cover d) :
      |‖W t v‖ ^ 2 - (g.form t v v - δ * ‖v‖ ^ 2)| ≤ ε * ‖v‖ ^ 2 := by
    let Q := torusGram W - (g.form - δ • flatMetric)
    have hQt : ‖Q t‖ ≤ ε := (Q.norm_coe_le_norm t).trans hGram.le
    have h := (Q t).le_of_opNorm₂_le_of_le hQt (le_rfl (a := ‖v‖)) (le_rfl (a := ‖v‖))
    simpa only [Q, Real.norm_eq_abs, ContinuousMap.sub_apply, ContinuousMap.smul_apply, sub_apply,
      smul_apply, smul_eq_mul, torusGram_apply, flatMetric_apply, real_inner_self_eq_norm_sq,
      pow_two, mul_assoc] using h
  have hSq (t : UnitAddTorus d) (v : Cover d) :
      (B : ℝ) * ‖F t v‖ ^ 2 = ‖W t v‖ ^ 2 := by
    simpa only [real_inner_self_eq_norm_sq] using hgram t v v
  have hδ₁ : δ ≤ m / 4 := hδ'.trans (min_le_right _ _)
  have hε₁ : ε ≤ m / 4 := hε'.trans (min_le_right _ _)
  have hlow (t : UnitAddTorus d) (v : Cover d) : σ * ‖v‖ ≤ ‖F t v‖ := by
    apply (sq_le_sq₀ (by positivity) (norm_nonneg _)).1
    rw [mul_pow, Real.sq_sqrt (by positivity : 0 ≤ (m / 2) / (B : ℝ))]
    apply (mul_le_mul_iff_right₀ hB').1
    rw [hSq, show (B : ℝ) * (m / 2 / (B : ℝ) * ‖v‖ ^ 2) = m / 2 * ‖v‖ ^ 2 by field_simp]
    have h₁ := (abs_le.mp (hError t v)).1
    have h₂ := mul_le_mul_of_nonneg_right (show δ + ε ≤ m / 2 by linarith) (sq_nonneg ‖v‖)
    linarith [hmetric₀ t v]
  have hupp (t : UnitAddTorus d) (v : Cover d) : ‖F t v‖ ≤ M * ‖v‖ := by
    apply (sq_le_sq₀ (norm_nonneg _) (by positivity)).1
    rw [mul_pow, Real.sq_sqrt (by positivity : 0 ≤ (‖g.form‖ + m / 4) / (B : ℝ))]
    apply (mul_le_mul_iff_right₀ hB').1
    rw [hSq, show (B : ℝ) * (((‖g.form‖ + m / 4) / (B : ℝ)) * ‖v‖ ^ 2) =
      (‖g.form‖ + m / 4) * ‖v‖ ^ 2 by field_simp]
    have hg : g.form t v v ≤ ‖g.form‖ * ‖v‖ ^ 2 := by
      have h := (g.form t).le_of_opNorm₂_le_of_le (g.form.norm_coe_le_norm t)
        (le_rfl (a := ‖v‖)) (le_rfl (a := ‖v‖))
      rw [Real.norm_eq_abs] at h
      simpa only [pow_two, mul_assoc] using (le_abs_self _).trans h
    have h₁ := (abs_le.mp (hError t v)).2
    have h₂ := mul_le_mul_of_nonneg_right hε₁ (sq_nonneg ‖v‖)
    linarith [mul_nonneg hδ (sq_nonneg ‖v‖)]
  have hnorm : ‖F‖ ≤ M :=
    (ContinuousMap.norm_le _ hM).2 (fun t => (F t).opNorm_le_bound hM (hupp t))
  refine ⟨s, u, hu, hs, huBand, hFband, hnorm, hlow, horth, ?_⟩
  rw [hscaled]
  exact hGram

end

end IsometricEmbeddingEndpoints

#print axioms IsometricEmbeddingEndpoints.TorusMetric.exists_initialBlock
