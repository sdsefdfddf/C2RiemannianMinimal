import Mathlib.Analysis.InnerProductSpace.PiL2
import Mathlib.Analysis.InnerProductSpace.ProdL2
import Mathlib.Analysis.SpecialFunctions.Trigonometric.Deriv
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Ring

namespace IsometricEmbeddingEndpoints

open ContinuousLinearMap

noncomputable section

variable {E : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E]

abbrev CirclePair := WithLp 2 (ℝ × ℝ)

/-- One pair of coordinates of the spiral, with its Euclidean inner product. -/
def circlePair (a t : E → ℝ) (x : E) : CirclePair :=
  WithLp.toLp 2 (a x * Real.sin (t x), a x * Real.cos (t x))

/-- The pointwise differential of a circle pair with amplitude and phase derivatives `A` and `T`. -/
def circlePairDeriv (a t : ℝ) (A T : E →L[ℝ] ℝ) : E →L[ℝ] CirclePair :=
  (WithLp.prodContinuousLinearEquiv 2 ℝ ℝ ℝ).symm.toContinuousLinearMap.comp
    ((a • (Real.cos t • T) + Real.sin t • A).prod
      (a • (-Real.sin t • T) + Real.cos t • A))

theorem hasFDerivAt_circlePair {a t : E → ℝ} {A T : E →L[ℝ] ℝ} {x : E}
    (ha : HasFDerivAt a A x) (ht : HasFDerivAt t T x) :
    HasFDerivAt (circlePair a t) (circlePairDeriv (a x) (t x) A T) x := by
  let e := (WithLp.prodContinuousLinearEquiv 2 ℝ ℝ ℝ).symm.toContinuousLinearMap
  exact e.hasFDerivAt.comp x ((ha.mul ht.sin).prodMk (ha.mul ht.cos))

/-- The amplitude and phase terms in the induced metric do not have a mixed term. -/
theorem inner_circlePairDeriv (a t : ℝ) (A T : E →L[ℝ] ℝ) (v w : E) :
    inner ℝ (circlePairDeriv a t A T v) (circlePairDeriv a t A T w) =
      A v * A w + a ^ 2 * (T v * T w) := by
  simp only [circlePairDeriv, comp_apply, ContinuousLinearEquiv.coe_coe,
    ContinuousLinearMap.prod_apply, WithLp.prodContinuousLinearEquiv_symm_apply,
    WithLp.prod_inner_apply,
    Real.inner_apply, add_apply, smul_apply, smul_eq_mul]
  calc
    _ = (Real.sin t ^ 2 + Real.cos t ^ 2) * (A v * A w + a ^ 2 * (T v * T w)) := by ring
    _ = _ := by rw [Real.sin_sq_add_cos_sq, one_mul]

/-- The exact induced metric of a pair oscillating with frequency `μ` along a linear phase. -/
theorem inner_fderiv_scaledCirclePair {a : E → ℝ} {A : E →L[ℝ] ℝ} {x : E}
    (ha : HasFDerivAt a A x) (ξ : E →L[ℝ] ℝ) {μ : ℝ} (hμ : μ ≠ 0) (v w : E) :
    let W := circlePair (fun y => μ⁻¹ * a y) (fun y => μ * ξ y)
    inner ℝ (fderiv ℝ W x v) (fderiv ℝ W x w) =
      μ⁻¹ ^ 2 * (A v * A w) + a x ^ 2 * (ξ v * ξ w) := by
  dsimp only
  rw [(hasFDerivAt_circlePair (ha.const_mul μ⁻¹) (ξ.hasFDerivAt.const_mul μ)).fderiv]
  rw [inner_circlePairDeriv]
  simp only [smul_apply, smul_eq_mul]
  field_simp

/-- A finite family of circle pairs in orthogonal coordinate planes. -/
def circlePairs {ι : Type*} (a t : ι → E → ℝ) (x : E) :
    PiLp 2 (fun _ : ι => CirclePair) :=
  WithLp.toLp 2 (fun i => circlePair (a i) (t i) x)

/-- The direct sum of the differentials of the circle pairs. -/
def circlePairsDeriv {ι : Type*} [Fintype ι] (a t : ι → ℝ) (A T : ι → E →L[ℝ] ℝ) :
    E →L[ℝ] PiLp 2 (fun _ : ι => CirclePair) :=
  (PiLp.continuousLinearEquiv 2 ℝ (fun _ : ι => CirclePair)).symm.toContinuousLinearMap.comp
    (.pi fun i => circlePairDeriv (a i) (t i) (A i) (T i))

theorem hasFDerivAt_circlePairs {ι : Type*} [Fintype ι] {a t : ι → E → ℝ}
    {A T : ι → E →L[ℝ] ℝ} {x : E}
    (ha : ∀ i, HasFDerivAt (a i) (A i) x) (ht : ∀ i, HasFDerivAt (t i) (T i) x) :
    HasFDerivAt (circlePairs a t) (circlePairsDeriv (fun i => a i x) (fun i => t i x) A T) x := by
  let e := (PiLp.continuousLinearEquiv 2 ℝ (fun _ : ι => CirclePair)).symm.toContinuousLinearMap
  exact e.hasFDerivAt.comp x (hasFDerivAt_pi.mpr (fun i => hasFDerivAt_circlePair (ha i) (ht i)))

/-- The Gram identity adds over disjoint circle pairs. -/
theorem inner_circlePairsDeriv {ι : Type*} [Fintype ι] (a t : ι → ℝ)
    (A T : ι → E →L[ℝ] ℝ) (v w : E) :
    inner ℝ (circlePairsDeriv a t A T v) (circlePairsDeriv a t A T w) =
      ∑ i, (A i v * A i w + (a i) ^ 2 * (T i v * T i w)) := by
  rw [PiLp.inner_apply]
  exact Finset.sum_congr rfl (fun i _ => inner_circlePairDeriv (a i) (t i) (A i) (T i) v w)

/-- The exact induced metric of the simultaneous twists used for the initial map and for a stage. -/
theorem inner_fderiv_scaledCirclePairs {ι : Type*} [Fintype ι]
    {a : ι → E → ℝ} {A : ι → E →L[ℝ] ℝ} {x : E}
    (ha : ∀ i, HasFDerivAt (a i) (A i) x) (ξ : ι → E →L[ℝ] ℝ)
    {μ : ℝ} (hμ : μ ≠ 0) (v w : E) :
    let W := circlePairs (fun i y => μ⁻¹ * a i y) (fun i y => μ * ξ i y)
    inner ℝ (fderiv ℝ W x v) (fderiv ℝ W x w) =
      ∑ i, (μ⁻¹ ^ 2 * (A i v * A i w) + a i x ^ 2 * (ξ i v * ξ i w)) := by
  dsimp only
  rw [(hasFDerivAt_circlePairs (fun i => (ha i).const_mul μ⁻¹)
    (fun i => (ξ i).hasFDerivAt.const_mul μ)).fderiv, inner_circlePairsDeriv]
  apply Finset.sum_congr rfl
  intro i _
  simp only [smul_apply, smul_eq_mul]
  field_simp

/-- The part of the Gram form contributed by derivatives of the amplitudes. -/
theorem abs_gram_scaledCirclePairs_remainder_le {ι : Type*} [Fintype ι]
    {a : ι → E → ℝ} {A : ι → E →L[ℝ] ℝ} {x : E}
    (ha : ∀ i, HasFDerivAt (a i) (A i) x) (ξ : ι → E →L[ℝ] ℝ)
    {μ : ℝ} (hμ : μ ≠ 0) (v w : E) :
    let W := circlePairs (fun i y => μ⁻¹ * a i y) (fun i y => μ * ξ i y)
    |inner ℝ (fderiv ℝ W x v) (fderiv ℝ W x w) -
      ∑ i, a i x ^ 2 * (ξ i v * ξ i w)| ≤
        μ⁻¹ ^ 2 * (∑ i, ‖A i‖ ^ 2) * (‖v‖ * ‖w‖) := by
  dsimp only
  rw [inner_fderiv_scaledCirclePairs ha ξ hμ, Finset.sum_add_distrib, add_sub_cancel_right]
  calc
    _ ≤ ∑ i, |μ⁻¹ ^ 2 * (A i v * A i w)| := Finset.abs_sum_le_sum_abs _ _
    _ ≤ ∑ i, μ⁻¹ ^ 2 * (‖A i‖ ^ 2 * (‖v‖ * ‖w‖)) := by
      apply Finset.sum_le_sum
      intro i _
      rw [abs_mul, abs_of_nonneg (sq_nonneg μ⁻¹), abs_mul]
      apply mul_le_mul_of_nonneg_left _ (sq_nonneg μ⁻¹)
      calc
        |A i v| * |A i w| = ‖A i v‖ * ‖A i w‖ := by simp only [Real.norm_eq_abs]
        _ ≤ (‖A i‖ * ‖v‖) * (‖A i‖ * ‖w‖) :=
          mul_le_mul (le_opNorm _ _) (le_opNorm _ _) (norm_nonneg _) (by positivity)
        _ = _ := by ring
    _ = _ := by rw [← Finset.mul_sum, ← Finset.sum_mul, mul_assoc]

omit [NormedAddCommGroup E] [NormedSpace ℝ E] in
/-- The norm of the paired wave depends only on its amplitudes. -/
theorem norm_circlePairs_sq {ι : Type*} [Fintype ι] (a t : ι → E → ℝ) (x : E) :
    ‖circlePairs a t x‖ ^ 2 = ∑ i, a i x ^ 2 := by
  rw [← real_inner_self_eq_norm_sq, PiLp.inner_apply]
  apply Finset.sum_congr rfl
  intro i _
  simp only [circlePairs, circlePair, PiLp.toLp_apply, WithLp.prod_inner_apply, Real.inner_apply]
  calc
    _ = a i x ^ 2 * (Real.sin (t i x) ^ 2 + Real.cos (t i x) ^ 2) := by ring
    _ = _ := by rw [Real.sin_sq_add_cos_sq, mul_one]

/-- A derivative bound for the scaled circle pairs which keeps the two contributions
from the derivative of the amplitude and the derivative of the phase separate. -/
theorem norm_fderiv_scaledCirclePairs_le {ι : Type*} [Fintype ι]
    {a : ι → E → ℝ} {A : ι → E →L[ℝ] ℝ} {x : E}
    (ha : ∀ i, HasFDerivAt (a i) (A i) x) (ξ : ι → E →L[ℝ] ℝ) {μ : ℝ} (hμ : μ ≠ 0) :
    let W := circlePairs (fun i y => μ⁻¹ * a i y) (fun i y => μ * ξ i y)
    ‖fderiv ℝ W x‖ ≤ Real.sqrt (∑ i, (μ⁻¹ ^ 2 * ‖A i‖ ^ 2 + a i x ^ 2 * ‖ξ i‖ ^ 2)) := by
  dsimp only
  let s := ∑ i, (μ⁻¹ ^ 2 * ‖A i‖ ^ 2 + a i x ^ 2 * ‖ξ i‖ ^ 2)
  have hs : 0 ≤ s := Finset.sum_nonneg fun _ _ => by positivity
  apply ContinuousLinearMap.opNorm_le_bound _ (Real.sqrt_nonneg s)
  intro v
  apply le_of_pow_le_pow_left₀ two_ne_zero (mul_nonneg (Real.sqrt_nonneg s) (norm_nonneg _))
  rw [← real_inner_self_eq_norm_sq, inner_fderiv_scaledCirclePairs ha ξ hμ, mul_pow, Real.sq_sqrt hs]
  change _ ≤ s * ‖v‖ ^ 2
  rw [Finset.sum_mul]
  apply Finset.sum_le_sum
  intro i _
  rw [add_mul, mul_assoc (μ⁻¹ ^ 2), mul_assoc (a i x ^ 2)]
  apply add_le_add
  · apply mul_le_mul_of_nonneg_left _ (sq_nonneg _)
    rw [← pow_two (A i v), ← mul_pow, ← sq_abs (A i v), ← Real.norm_eq_abs]
    exact pow_le_pow_left₀ (norm_nonneg _) ((A i).le_opNorm v) _
  · apply mul_le_mul_of_nonneg_left _ (sq_nonneg _)
    rw [← pow_two (ξ i v), ← mul_pow, ← sq_abs (ξ i v), ← Real.norm_eq_abs]
    exact pow_le_pow_left₀ (norm_nonneg _) ((ξ i).le_opNorm v) _

omit [NormedSpace ℝ E] in
/-- The spiral descends through a period whenever the phase shifts are integral turns. -/
theorem circlePairs_periodic {ι : Type*} {a t : ι → E → ℝ} {z : E}
    (ha : ∀ i, Function.Periodic (a i) z)
    (ht : ∀ i x, ∃ n : ℤ, t i (x + z) = t i x + n * (2 * Real.pi)) :
    Function.Periodic (circlePairs a t) z := by
  intro x
  apply congrArg (WithLp.toLp 2)
  funext i
  obtain ⟨n, hn⟩ := ht i x
  simp only [circlePair, ha i x, hn, Real.sin_add_int_mul_two_pi, Real.cos_add_int_mul_two_pi]

section Lattice

variable {ι : Type*} [Fintype ι]

/-- The integer lattice inside the Euclidean covering space of the flat torus. -/
def latticeVector (z : ι → ℤ) : EuclideanSpace ℝ ι :=
  WithLp.toLp 2 (fun i => (z i : ℝ))

theorem inner_latticeVector (z : ι → ℤ) (v : EuclideanSpace ℝ ι) :
    inner ℝ (latticeVector z) v = ∑ i, (z i : ℝ) * v i := by
  simp only [PiLp.inner_apply, latticeVector, Real.inner_apply]

/-- A torus phase of integer frequency in the standard period-one coordinates. -/
def integerPhase (N : ℕ) (ξ : ι → ℤ) (x : EuclideanSpace ℝ ι) : ℝ :=
  (2 * Real.pi) * ((N : ℝ) * ∑ i, (ξ i : ℝ) * x i)

theorem integerPhase_eq_linear (N : ℕ) (ξ : ι → ℤ) (x : EuclideanSpace ℝ ι) :
    integerPhase N ξ x = (2 * Real.pi * (N : ℝ)) * inner ℝ (latticeVector ξ) x := by
  simp only [integerPhase, inner_latticeVector, mul_assoc]

theorem integerPhase_add_lattice (N : ℕ) (ξ z : ι → ℤ) (x : EuclideanSpace ℝ ι) :
    integerPhase N ξ (x + latticeVector z) =
      integerPhase N ξ x + (((N : ℤ) * ∑ i, ξ i * z i : ℤ) : ℝ) * (2 * Real.pi) := by
  simp only [integerPhase, PiLp.add_apply, latticeVector, mul_add,
    Finset.sum_add_distrib, Int.cast_mul, Int.cast_natCast, Int.cast_sum]
  ring

theorem circlePairs_periodic_lattice {κ : Type*} {a : κ → EuclideanSpace ℝ ι → ℝ}
    (N : ℕ) (ξ : κ → ι → ℤ) (z : ι → ℤ)
    (ha : ∀ i, Function.Periodic (a i) (latticeVector z)) :
    Function.Periodic (circlePairs a (fun i => integerPhase N (ξ i))) (latticeVector z) :=
  circlePairs_periodic ha (fun i x =>
    ⟨(N : ℤ) * ∑ j, ξ i j * z j, integerPhase_add_lattice N (ξ i) z x⟩)

end Lattice

end

end IsometricEmbeddingEndpoints

#print axioms IsometricEmbeddingEndpoints.hasFDerivAt_circlePair
#print axioms IsometricEmbeddingEndpoints.inner_fderiv_scaledCirclePair
#print axioms IsometricEmbeddingEndpoints.inner_fderiv_scaledCirclePairs
#print axioms IsometricEmbeddingEndpoints.abs_gram_scaledCirclePairs_remainder_le
#print axioms IsometricEmbeddingEndpoints.integerPhase_add_lattice
