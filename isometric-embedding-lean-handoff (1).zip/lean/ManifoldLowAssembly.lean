import ManifoldHolder
import ManifoldMetricCorrection
import ManifoldSphereAssembly
import LocalIsometricImmersion
import SmoothSquarePartition
import Mathlib.Geometry.Manifold.WhitneyEmbedding

open scoped ContDiff Manifold Topology

namespace IsometricEmbeddingEndpoints

open ContinuousLinearMap Filter Set

noncomputable section

variable {d M : Type*} [Fintype d] [DecidableEq d]
  [TopologicalSpace M] [ChartedSpace (Cover d) M] [IsManifold 𝓘(ℝ, Cover d) ∞ M]
  [T2Space M] [CompactSpace M]

local notation "𝕀" => 𝓘(ℝ, Cover d)
local notation "K₀" r:arg => Metric.closedBall (0 : Cover d) r
local notation "B₀" r:arg => Metric.ball (0 : Cover d) r

local instance : NormedAddCommGroup (MetricForm d) := inferInstance
local instance : NormedSpace ℝ (MetricForm d) := inferInstance

private theorem immersion_radius_le {R : ℝ} (hR : 0 < R) :
    localTorusRadius d R / 2 ≤ R := by
  let A := 2 * ((Fintype.card d : ℝ) + 1)
  have hA : 1 ≤ A := by dsimp [A]; linarith [Nat.cast_nonneg (α := ℝ) (Fintype.card d)]
  change R / A / 2 / 2 ≤ R
  calc
    _ ≤ R / A / 2 := div_le_self (by positivity) (by norm_num)
    _ ≤ R / A := div_le_self (by positivity) (by norm_num)
    _ ≤ R := div_le_self hR.le hA

private theorem interior_localImmersionBall {R : ℝ} :
    B₀ (localTorusRadius d R / 2) ⊆ interior (localImmersionBall d R) := by
  rw [← Metric.isOpen_ball.interior_eq]
  exact interior_mono Metric.ball_subset_closedBall

private theorem mvfderiv_chart_comp_apply
    {F : Type*} [NormedAddCommGroup F] [NormedSpace ℝ F]
    {f : Cover d → F} {e : OpenPartialHomeomorph M (Cover d)} {p : M}
    (hf : DifferentiableAt ℝ f (e p)) (he : MDifferentiableAt 𝕀 𝕀 e p)
    (v : TangentSpace 𝕀 p) :
    mvfderiv 𝕀 (f ∘ e) p v = fderiv ℝ f (e p) (mfderiv 𝕀 𝕀 e p v) := by
  have h := mvfderiv_comp_apply p hf.mdifferentiableAt he v
  rw [mvfderiv_eq_fderiv] at h
  exact h

private theorem wrapped_map_properties {F : Type*} [NormedAddCommGroup F] [InnerProductSpace ℝ F]
    {G : Type*} [NormedAddCommGroup G] [InnerProductSpace ℝ G]
    {s : F → G} {u : Cover d → F} {e : OpenPartialHomeomorph M (Cover d)} {p : M} {ρ : ℝ}
    (hs : DifferentiableAt ℝ s (u (e p))) (hu : DifferentiableAt ℝ u (e p))
    (he : MDifferentiableAt 𝕀 𝕀 e p)
    (hnorm : ‖s (u (e p))‖ ^ 2 = ρ ^ 2)
    (horth : ∀ v, inner ℝ (s (u (e p))) (fderiv ℝ s (u (e p)) v) = 0)
    (hiso : ∀ v z, inner ℝ (fderiv ℝ s (u (e p)) v) (fderiv ℝ s (u (e p)) z) = inner ℝ v z)
    (g : RiemannianMetric d M) (he' : e.MDifferentiable 𝕀 𝕀) (hp : p ∈ e.source)
    (hlocal : ∀ v z, inner ℝ (fderiv ℝ u (e p) v) (fderiv ℝ u (e p) z) = g.inChart e (e p) v z) :
    ‖((s ∘ u) ∘ e) p‖ ^ 2 = ρ ^ 2 ∧
      (∀ v, inner ℝ (((s ∘ u) ∘ e) p) (mvfderiv 𝕀 ((s ∘ u) ∘ e) p v) = 0) ∧
      ∀ v z, inner ℝ (mvfderiv 𝕀 ((s ∘ u) ∘ e) p v) (mvfderiv 𝕀 ((s ∘ u) ∘ e) p z) =
        g.form p v z := by
  have hD := fderiv_comp (e p) hs hu
  refine ⟨hnorm, fun v => ?_, fun v z => ?_⟩
  · rw [mvfderiv_chart_comp_apply (hs.comp (e p) hu) he, hD]
    exact horth _
  · apply g.isometricDifferential_of_inChart he' hp (hs.comp (e p) hu) _ v z
    intro y y'
    rw [hD, comp_apply, comp_apply, hiso]
    exact hlocal y y'

set_option maxHeartbeats 1500000 in
/-- The compact-manifold reduction for any class of coordinate metrics which
is preserved when a twice continuously differentiable correction is subtracted. -/
theorem RiemannianMetric.exists_embedding_of_local_solver
    (g : RiemannianMetric d M) (θ : ℝ) (hθ : 0 ≤ θ) (hθ₁ : θ ≤ 1)
    (P : Set (Cover d) → (Cover d → MetricForm d) → Prop)
    (hreg : g.locallyInCharts P)
    (hcont : ∀ s h, P s h → ContinuousOn h s)
    (hsub : ∀ {R : ℝ} {h q : Cover d → MetricForm d}, P (K₀ R) h →
      (∀ x ∈ K₀ R, ContDiffAt ℝ 2 q x) → P (K₀ R) (h - q))
    (hsolve : ∀ (R : ℝ) (h : Cover d → MetricForm d), 0 < R → P (K₀ R) h →
      (∀ x ∈ B₀ R, ∀ v z, h x v z = h x z v) →
      (∀ x ∈ B₀ R, ∀ v ≠ 0, 0 < h x v v) →
      ∃ (N : ℕ) (u : Cover d → EuclideanSpace ℝ (Fin N)),
        HasHolderDifferentialOn θ u (localImmersionBall d R) ∧
        ∀ x ∈ localImmersionBall d R, ∀ v z,
          inner ℝ (fderiv ℝ u x v) (fderiv ℝ u x z) = h x v z) :
    ∃ (N : ℕ) (u : M → EuclideanSpace ℝ (Fin N)),
      g.IsHolderIsometricEmbedding θ u := by
  classical
  choose R hR htarget hP using hreg
  let r : M → ℝ := fun p => localTorusRadius d (R p) / 2
  have hr (p : M) : 0 < r p := half_pos (localTorusRadius_pos (hR p))
  obtain ⟨J, hJ⟩ := exists_finite_centeredChartBall_cover (d := d) r hr
  let ι := {p : M // p ∈ J}
  let e (i : ι) := centeredChart (d := d) i.val
  let K (i : ι) := K₀ (R i.val)
  let U (i : ι) := centeredChartBall (d := d) i.val (r i.val)
  obtain ⟨a, ha, hasupp, ha₁⟩ := exists_smoothSquarePartition (I := 𝕀) U
    (fun i => isOpen_centeredChartBall (d := d) i.val (r i.val)) hJ
  obtain ⟨n, w, hw, hwEmb, _⟩ := exists_embedding_euclidean_of_compact (I := 𝕀) (M := M)
  let W := EuclideanSpace ℝ (Fin n)
  have he (i : ι) : (e i).MDifferentiable 𝕀 𝕀 := mdifferentiable_centeredChart i.val
  have heS (i : ι) (x : Cover d) (hx : x ∈ (e i).target) :
      ContMDiffAt 𝕀 𝕀 ∞ (e i).symm x := contMDiffAt_centeredChart_symm hx
  obtain ⟨δ, hδ, hmargin⟩ := exists_metric_correction_scale g w a e K
    (fun _ => isCompact_closedBall _ _) (fun i => htarget i.val) heS
    (fun i _ hx => (he i).mdifferentiableAt hx)
    (fun i => hcont _ _ (hP i.val)) hw ha
  let ρ := Real.sqrt δ
  have hρ : 0 < ρ := Real.sqrt_pos.2 hδ
  have hρsq : ρ ^ 2 = δ := Real.sq_sqrt hδ.le
  have hpos (p : M) (v : TangentSpace 𝕀 p) (hv : v ≠ 0) :
      0 < g.form p v v - δ * metricCorrection w a p v v := by
    obtain ⟨i, hi⟩ : ∃ i : ι, p ∈ U i := mem_iUnion.mp (hJ (mem_univ p))
    have hsource : p ∈ (e i).source := hi.1
    let z := mfderiv 𝕀 𝕀 (e i) p v
    have hzne : z ≠ 0 := by
      intro hz
      apply hv
      apply (he i).mfderiv_injective hsource
      exact hz.trans (map_zero _).symm
    have hmem : e i p ∈ K i :=
      Metric.closedBall_subset_closedBall (immersion_radius_le (hR i.val))
        (Metric.ball_subset_closedBall hi.2)
    have hh := hmargin i (e i p) hmem z hzne
    dsimp only [z] at hh
    rw [g.inChart_pullback (he i) hsource, metricCorrectionInChart_pullback w a (he i) hsource] at hh
    exact hh
  let g' := g.corrected w a δ hpos
  have hlocal (i : ι) :
      ∃ (N : ℕ) (u : Cover d → EuclideanSpace ℝ (Fin N)),
        HasHolderDifferentialOn θ u (localImmersionBall d (R i.val)) ∧
        ∀ x ∈ localImmersionBall d (R i.val), ∀ v z,
          inner ℝ (fderiv ℝ u x v) (fderiv ℝ u x z) = g'.inChart (e i) x v z := by
    apply hsolve (R i.val) (g'.inChart (e i)) (hR i.val) _ _ _
    · have heq : g'.inChart (e i) = g.inChart (e i) - δ • metricCorrectionInChart w a (e i) :=
        funext fun x => g.corrected_inChart w a δ hpos (e i) x
      rw [heq]
      exact hsub (hP i.val) (fun x hx =>
        (metricCorrectionInChart_contDiffAt_two (htarget i.val hx) (heS i) hw ha).const_smul δ)
    · intro x _ v z
      exact g'.inChart_symmetric (e i) x v z
    · intro x hx v hv
      exact g'.inChart_positive (he i) (htarget i.val (Metric.ball_subset_closedBall hx)) hv
  choose N u hu huIso using hlocal
  let V (i : ι) := WithLp 2 (PiLp 2 (fun _ : Fin (N i) => CirclePair) × ℝ)
  have hwrap (i : ι) :
      ∃ s : EuclideanSpace ℝ (Fin (N i)) → V i,
        ContDiff ℝ ⊤ s ∧ (∀ x, ‖s x‖ ^ 2 = ρ ^ 2) ∧
        (∀ x v, inner ℝ (s x) (fderiv ℝ s x v) = 0) ∧
        ∀ x v z, inner ℝ (fderiv ℝ s x v) (fderiv ℝ s x z) = inner ℝ v z :=
    exists_isometricSphereMap_withConstant hρ
  choose s hs hsNorm hsOrth hsIso using hwrap
  let f (i : ι) : M → V i := (s i ∘ u i) ∘ e i
  have hfinV (i : ι) : FiniteDimensional ℝ (V i) := by dsimp [V]; infer_instance
  letI : ∀ i, FiniteDimensional ℝ (V i) := hfinV
  have hf (i : ι) (p : M) (hp : p ∈ tsupport (a i)) :
      ContMDiffAt 𝕀 𝓘(ℝ, V i) 1 (f i) p := by
    have hi := hasupp i hp
    have hs' : ContMDiffAt 𝓘(ℝ, EuclideanSpace ℝ (Fin (N i))) 𝓘(ℝ, V i) 1
        (s i) (u i (e i p)) :=
      ((hs i).of_le (by simp : (1 : ℕ∞ω) ≤ ⊤)).contDiffAt.contMDiffAt
    have hu' := ((hu i).1 _ (Metric.ball_subset_closedBall hi.2)).contMDiffAt
    exact (hs'.comp _ hu').comp p ((contMDiffAt_centeredChart hi.1).of_le (by simp))
  have hfHolder (i : ι) (p : M) (hp : p ∈ tsupport (a i)) :
      HasLocalHolderDifferentialAt (d := d) θ (f i) p := by
    have hi := hasupp i hp
    have hsu : HasHolderDifferentialOn θ (s i ∘ u i) (localImmersionBall d (R i.val)) :=
      (hu i).smooth_comp (isCompact_closedBall _ _) (convex_closedBall _ _) hθ hθ₁
        ((hs i).of_le (by simp))
    exact hasLocalHolderDifferentialAt_of_chart hi.1 (fun _ hx => contMDiffAt_centeredChart hx)
      (interior_localImmersionBall hi.2) hsu hθ hθ₁
  have hfGeom (i : ι) (p : M) (hp : p ∈ tsupport (a i)) :
      ‖f i p‖ ^ 2 = ρ ^ 2 ∧
        (∀ v, inner ℝ (f i p) (mvfderiv 𝕀 (f i) p v) = 0) ∧
        ∀ v z, inner ℝ (mvfderiv 𝕀 (f i) p v) (mvfderiv 𝕀 (f i) p z) = g'.form p v z := by
    have hi := hasupp i hp
    have hix : e i p ∈ localImmersionBall d (R i.val) := Metric.ball_subset_closedBall hi.2
    exact wrapped_map_properties ((hs i).differentiable (by simp) _) (((hu i).1 _ hix).differentiableAt one_ne_zero)
      ((he i).mdifferentiableAt hi.1) (hsNorm i _) (hsOrth i _) (hsIso i _) g' (he i) hi.1
      (huIso i _ hix)
  let b : M → W := fun p => ρ • w p
  let S := ρ • ContinuousLinearMap.id ℝ W
  have hb : ContMDiff 𝕀 𝓘(ℝ, W) ∞ b := S.contMDiff.comp hw
  have hbInj : Function.Injective b := fun p q hpq => hwEmb.injective
    (smul_right_injective W hρ.ne' hpq)
  let T := PiLp 2 (SphereAssemblyFactors W V)
  let u₁ : M → T := sphereAssembly b a f
  have huEmb : Topology.IsEmbedding u₁ := isEmbedding_sphereAssembly
    (hb.of_le (by simp)) hbInj (fun i => (ha i).of_le (by simp)) hf
  have hu₁ : ContMDiff 𝕀 𝓘(ℝ, T) 1 u₁ := fun p => contMDiffAt_sphereAssembly
    ((hb.of_le (by simp)).contMDiffAt) (fun i => ((ha i).of_le (by simp)).contMDiffAt) (fun i => hf i p)
  have hD (p : M) : mvfderiv 𝕀 b p = ρ • mvfderiv 𝕀 w p := by
    change mvfderiv 𝕀 (fun p => (fun _ : M => ρ) p • w p) p = _
    rw [mvfderiv_fun_smul mdifferentiableAt_const
      (hw.contMDiffAt.mdifferentiableAt (by simp)), mvfderiv_const]
    simp
  have huIso (p : M) (v z : TangentSpace 𝕀 p) :
      inner ℝ (mvfderiv 𝕀 u₁ p v) (mvfderiv 𝕀 u₁ p z) = g.form p v z := by
    have hsum := inner_mvfderiv_sphereAssembly
      ((hb.of_le (by simp)).contMDiffAt) (fun i => ((ha i).of_le (by simp)).contMDiffAt)
      (ha₁ p) (fun i => hf i p) (fun i hp => (hfGeom i p hp).1)
      (fun i hp => (hfGeom i p hp).2.1) (g'.form p) (fun i hp => (hfGeom i p hp).2.2) v z
    change inner ℝ (mvfderiv 𝕀 u₁ p v) (mvfderiv 𝕀 u₁ p z) = _
    rw [hsum, hD]
    change inner ℝ ((ρ • mvfderiv 𝕀 w p) v) ((ρ • mvfderiv 𝕀 w p) z) +
      (g.form p v z - δ * metricCorrection w a p v z +
        ρ ^ 2 * ∑ i, mvfderiv 𝕀 (a i) p v * mvfderiv 𝕀 (a i) p z) = _
    simp only [smul_apply, real_inner_smul_left, real_inner_smul_right, metricCorrection_apply, ← hρsq]
    ring
  letI (i : Option ι) : FiniteDimensional ℝ (SphereAssemblyFactors W V i) :=
    match i with
    | none => inferInstanceAs (FiniteDimensional ℝ W)
    | some j => inferInstanceAs (FiniteDimensional ℝ (V j))
  have huHolder (p : M) : HasLocalHolderDifferentialAt (d := d) θ u₁ p := by
    apply hasLocalHolderDifferentialAt_directSumMap _ hθ hθ₁
    intro i
    cases i with
    | none => exact HasLocalHolderDifferentialAt.of_smooth hb hθ hθ₁
    | some i =>
      change HasLocalHolderDifferentialAt (d := d) θ (fun x => a i x • f i x) p
      by_cases hp : p ∈ tsupport (a i)
      · exact (HasLocalHolderDifferentialAt.of_smooth (ha i) hθ hθ₁).smul (hfHolder i p hp) hθ hθ₁
      · have hz : (fun x => a i x • f i x) =ᶠ[𝓝 p] fun _ => (0 : V i) := by
          filter_upwards [isClosed_closure.isOpen_compl.mem_nhds hp] with x hx
          change a i x • f i x = 0
          rw [image_eq_zero_of_notMem_tsupport hx, zero_smul]
        exact (HasLocalHolderDifferentialAt.of_smooth contMDiff_const hθ hθ₁).congr_of_eventuallyEq hz
  let L := (stdOrthonormalBasis ℝ T).repr
  let Lc := L.toContinuousLinearEquiv.toContinuousLinearMap
  have hL : ContDiff ℝ 2 Lc := Lc.contDiff
  refine ⟨Module.finrank ℝ T, Lc ∘ u₁,
    ⟨L.toContinuousLinearEquiv.toHomeomorph.isEmbedding.comp huEmb,
      Lc.contMDiff.comp hu₁, fun p v z => ?_⟩,
    fun p => (huHolder p).smooth_comp hL hθ hθ₁⟩
  have hcomp : mvfderiv 𝕀 (Lc ∘ u₁) p = Lc.comp (mvfderiv 𝕀 u₁ p) := by
    have h := mvfderiv_comp p Lc.differentiableAt.mdifferentiableAt
      ((hu₁ p).mdifferentiableAt one_ne_zero)
    rw [mvfderiv_eq_fderiv, Lc.fderiv] at h
    exact h
  rw [hcomp, comp_apply, comp_apply]
  exact (L.inner_map_map _ _).trans (huIso p v z)

end

end IsometricEmbeddingEndpoints

#print axioms IsometricEmbeddingEndpoints.RiemannianMetric.exists_embedding_of_local_solver
