import HolderInCoordinates
import Mathlib.Analysis.Calculus.ContDiff.Operations
import Mathlib.Analysis.InnerProductSpace.PiL2
import Mathlib.Analysis.Normed.Module.FiniteDimension

open scoped ContDiff Topology

namespace IsometricEmbeddingEndpoints

open ContinuousLinearMap

noncomputable section

variable {E F G : Type*}
  [NormedAddCommGroup E] [NormedSpace ℝ E]
  [NormedAddCommGroup F] [NormedSpace ℝ F]
  [NormedAddCommGroup G] [NormedSpace ℝ G]

theorem HasHolderDifferentialOn.mono {a : ℝ} {f : E → F} {s t : Set E}
    (hf : HasHolderDifferentialOn a f s) (ht : t ⊆ s) : HasHolderDifferentialOn a f t := by
  obtain ⟨hd, C, hC, h⟩ := hf
  exact ⟨fun x hx => hd x (ht hx), C, hC, fun x hx y hy => h x (ht hx) y (ht hy)⟩

theorem HasHolderDifferentialOn.congr_of_eventuallyEq {a : ℝ} {f g : E → F} {s : Set E}
    (hf : HasHolderDifferentialOn a f s) (he : ∀ x ∈ s, g =ᶠ[𝓝 x] f) :
    HasHolderDifferentialOn a g s := by
  obtain ⟨hd, C, hC, h⟩ := hf
  refine ⟨fun x hx => (hd x hx).congr_of_eventuallyEq (he x hx), C, hC, fun x hx y hy => ?_⟩
  rw [(he x hx).fderiv_eq, (he y hy).fderiv_eq]
  exact h x hx y hy

/-- Exponent zero for the differential is automatic on a compact set for a
continuously differentiable map. -/
theorem hasHolderDifferentialOn_zero_of_contDiffAt {s : Set E} {f : E → F}
    (hs : IsCompact s) (hf : ∀ x ∈ s, ContDiffAt ℝ 1 f x) :
    HasHolderDifferentialOn 0 f s := by
  obtain ⟨B, hB⟩ := hs.exists_bound_of_continuousOn (f := fderiv ℝ f)
    (fun x hx => ((hf x hx).continuousAt_fderiv one_ne_zero).continuousWithinAt)
  let M := max B 0
  have hm (x : E) (hx : x ∈ s) : ‖fderiv ℝ f x‖ ≤ M := (hB x hx).trans (le_max_left _ _)
  refine ⟨hf, M + M, add_nonneg (le_max_right _ _) (le_max_right _ _), fun x hx y hy => ?_⟩
  rw [Real.rpow_zero, mul_one]
  exact (norm_sub_le _ _).trans (add_le_add (hm x hx) (hm y hy))

theorem HasHolderDifferentialOn.sub {a : ℝ} {f g : E → F} {s : Set E}
    (hf : HasHolderDifferentialOn a f s) (hg : HasHolderDifferentialOn a g s) :
    HasHolderDifferentialOn a (fun x => f x - g x) s := by
  obtain ⟨hF, C, hC, hCF⟩ := hf
  obtain ⟨hG, L, hL, hLG⟩ := hg
  refine ⟨fun x hx => (hF x hx).sub (hG x hx), C + L, add_nonneg hC hL, fun x hx y hy => ?_⟩
  change ‖fderiv ℝ (f - g) x - fderiv ℝ (f - g) y‖ ≤ _
  rw [fderiv_sub ((hF x hx).differentiableAt one_ne_zero) ((hG x hx).differentiableAt one_ne_zero),
    fderiv_sub ((hF y hy).differentiableAt one_ne_zero) ((hG y hy).differentiableAt one_ne_zero)]
  rw [sub_sub_sub_comm, add_mul]
  exact (norm_sub_le _ _).trans (add_le_add (hCF x hx y hy) (hLG x hx y hy))

theorem HasHolderDifferentialOn.prodMk {a : ℝ} {f : E → F} {g : E → G} {s : Set E}
    (hf : HasHolderDifferentialOn a f s) (hg : HasHolderDifferentialOn a g s) :
    HasHolderDifferentialOn a (fun x => (f x, g x)) s := by
  obtain ⟨hF, C, hC, hCF⟩ := hf
  obtain ⟨hG, L, hL, hLG⟩ := hg
  have hD (x : E) (hx : x ∈ s) : fderiv ℝ (fun y => (f y, g y)) x =
      (fderiv ℝ f x).prod (fderiv ℝ g x) :=
    (((hF x hx).differentiableAt one_ne_zero).hasFDerivAt.prodMk
      ((hG x hx).differentiableAt one_ne_zero).hasFDerivAt).fderiv
  refine ⟨fun x hx => (hF x hx).prodMk (hG x hx), C + L, add_nonneg hC hL, fun x hx y hy => ?_⟩
  rw [hD x hx, hD y hy]
  apply opNorm_le_bound _ (by positivity)
  intro v
  change max ‖(fderiv ℝ f x - fderiv ℝ f y) v‖ ‖(fderiv ℝ g x - fderiv ℝ g y) v‖ ≤ _
  rw [add_mul _ _ (‖x - y‖ ^ a), add_mul]
  exact max_le
    ((le_opNorm _ _).trans ((mul_le_mul_of_nonneg_right (hCF x hx y hy) (norm_nonneg _)).trans
      (le_add_of_nonneg_right (by positivity))))
    ((le_opNorm _ _).trans ((mul_le_mul_of_nonneg_right (hLG x hx y hy) (norm_nonneg _)).trans
      (le_add_of_nonneg_left (by positivity))))

/-- Smooth postcomposition preserves the exponent on a compact coordinate domain. -/
theorem HasHolderDifferentialOn.smooth_comp [FiniteDimensional ℝ F] {a : ℝ}
    {f : E → F} {s : Set E} (hf : HasHolderDifferentialOn a f s)
    (hs : IsCompact s) (hconv : Convex ℝ s) (ha : 0 ≤ a) (ha₁ : a ≤ 1)
    {g : F → G} (hg : ContDiff ℝ 2 g) : HasHolderDifferentialOn a (g ∘ f) s := by
  obtain ⟨C, hC⟩ := hs.exists_bound_of_continuousOn (f := f)
    (fun x hx => (hf.1 x hx).continuousAt.continuousWithinAt)
  have hmaps : Set.MapsTo f s (Metric.closedBall 0 C) := by
    intro x hx
    simpa only [Metric.mem_closedBall, dist_zero_right] using hC x hx
  exact (hasHolderDifferentialOn_of_contDiffAt_two (isCompact_closedBall _ _)
    (convex_closedBall _ _) (fun _ _ => hg.contDiffAt) ha ha₁).comp hf hmaps hs hconv ha

theorem HasHolderDifferentialOn.smul [FiniteDimensional ℝ F] {a : ℝ}
    {f : E → ℝ} {g : E → F} {s : Set E}
    (hf : HasHolderDifferentialOn a f s) (hg : HasHolderDifferentialOn a g s)
    (hs : IsCompact s) (hconv : Convex ℝ s) (ha : 0 ≤ a) (ha₁ : a ≤ 1) :
    HasHolderDifferentialOn a (fun x => f x • g x) s :=
  (hf.prodMk hg).smooth_comp hs hconv ha ha₁ contDiff_smul

theorem hasHolderDifferentialOn_piLp {ι : Type*} [Fintype ι]
    {V : ι → Type*} [∀ i, NormedAddCommGroup (V i)] [∀ i, NormedSpace ℝ (V i)]
    [∀ i, FiniteDimensional ℝ (V i)] {a : ℝ} {s : Set E} {f : (i : ι) → E → V i}
    (hf : ∀ i, HasHolderDifferentialOn a (f i) s) (hs : IsCompact s) (hconv : Convex ℝ s)
    (ha : 0 ≤ a) (ha₁ : a ≤ 1) :
    HasHolderDifferentialOn a (fun x => WithLp.toLp 2 (fun i => f i x)) s := by
  classical
  choose C hC hCF using fun i => (hf i).2
  have hD (x : E) (hx : x ∈ s) : fderiv ℝ (fun y i => f i y) x =
      ContinuousLinearMap.pi (fun i => fderiv ℝ (f i) x) :=
    fderiv_pi fun i => ((hf i).1 x hx).differentiableAt one_ne_zero
  have hsum : 0 ≤ ∑ i, C i := Finset.sum_nonneg (fun i _ => hC i)
  have hPi : HasHolderDifferentialOn a (fun x i => f i x) s := by
    refine ⟨fun x hx => contDiffAt_pi.mpr (fun i => (hf i).1 x hx), ∑ i, C i, hsum,
      fun x hx y hy => ?_⟩
    rw [hD x hx, hD y hy]
    apply opNorm_le_bound _ (by positivity)
    intro v
    apply (pi_norm_le_iff_of_nonneg (by positivity)).mpr
    intro i
    change ‖(fderiv ℝ (f i) x - fderiv ℝ (f i) y) v‖ ≤ _
    have hi : C i ≤ ∑ j, C j :=
      Finset.single_le_sum (fun j _ => hC j) (Finset.mem_univ i)
    exact (le_opNorm _ v).trans (mul_le_mul_of_nonneg_right
      ((hCF i x hx y hy).trans (mul_le_mul_of_nonneg_right hi (by positivity))) (norm_nonneg v))
  let L := (PiLp.continuousLinearEquiv 2 ℝ V).symm
  exact hPi.smooth_comp hs hconv ha ha₁ L.contDiff

end

end IsometricEmbeddingEndpoints

#print axioms IsometricEmbeddingEndpoints.HasHolderDifferentialOn.smooth_comp
#print axioms IsometricEmbeddingEndpoints.hasHolderDifferentialOn_piLp
