import ContinuousTorusEndpoint
import LowTorusEndpoints
import LocalTorusHolder
import HolderInCoordinates

namespace IsometricEmbeddingEndpoints

noncomputable section

variable {d : Type*} [Fintype d] [DecidableEq d]

local instance : NormedAddCommGroup (MetricForm d) := inferInstance
local instance : NormedSpace ℝ (MetricForm d) := inferInstance

/-- A compact coordinate ball lying inside the domain of the inverse sine chart. -/
def localImmersionBall (d : Type*) [Fintype d] (R : ℝ) : Set (Cover d) :=
  Metric.closedBall 0 (localTorusRadius d R / 2)

private theorem localImmersionBall_subset {R : ℝ} (hR : 0 < R) :
    localImmersionBall d R ⊆ Metric.ball 0 (localTorusRadius d R) := by
  intro x hx
  exact (Metric.mem_closedBall.mp hx).trans_lt (half_lt_self (localTorusRadius_pos hR))

private theorem hasHolderDifferentialOn_localTorusChart_comp
    {H : Type*} [NormedAddCommGroup H] [NormedSpace ℝ H]
    {a R : ℝ} (ha : 0 ≤ a) (ha₁ : a ≤ 1) (hR : 0 < R)
    {u : C(UnitAddTorus d, H)} (hu : HasHolderDifferential a u) :
    HasHolderDifferentialOn a (fun x => u (flatProjection (localTorusChart R x)))
      (localImmersionBall d R) := by
  obtain ⟨hu, C, hC, hbound⟩ := hu
  let f := fun x : Cover d => u (flatProjection x)
  have hf : HasHolderDifferentialOn a f Set.univ := by
    refine ⟨fun x _ => hu.contDiffAt, C, hC, fun x _ y _ => ?_⟩
    simpa only [dist_eq_norm, f] using hbound x y
  have hball : IsCompact (localImmersionBall d R) := isCompact_closedBall _ _
  have hconv : Convex ℝ (localImmersionBall d R) := convex_closedBall _ _
  have hg := hasHolderDifferentialOn_of_contDiffAt_two hball hconv
    (fun x hx => contDiffAt_localTorusChart hR (localImmersionBall_subset hR hx) 2) ha ha₁
  change HasHolderDifferentialOn a (f ∘ localTorusChart R) (localImmersionBall d R)
  exact HasHolderDifferentialOn.comp (f := f) (g := localTorusChart R)
    hf hg (fun _ _ => Set.mem_univ _) hball hconv ha

/-- Continuous positive metrics admit (C^1) isometric immersions on smaller coordinate balls. -/
theorem exists_localIsometricImmersion_contDiff {R : ℝ}
    (hR : 0 < R) (h : Cover d → MetricForm d) (hc : ContinuousOn h (Metric.ball 0 R))
    (hs : ∀ x ∈ Metric.ball 0 R, ∀ v w, h x v w = h x w v)
    (hp : ∀ x ∈ Metric.ball 0 R, ∀ v ≠ 0, 0 < h x v v) :
    ∃ (N : ℕ) (u : Cover d → EuclideanSpace ℝ (Fin N)),
      (∀ x ∈ localImmersionBall d R, ContDiffAt ℝ 1 u x) ∧
      ∀ x ∈ localImmersionBall d R, ∀ v w,
        inner ℝ (fderiv ℝ u x v) (fderiv ℝ u x w) = h x v w := by
  obtain ⟨N, u, hu, huIso⟩ := (localTorusMetric hR h hc hs hp).exists_euclideanImmersion_contDiff
  refine ⟨N, fun x => u (flatProjection (localTorusChart R x)), ?_, ?_⟩
  · intro x hx
    exact (hu.contDiffAt (x := localTorusChart R x)).comp x
      (contDiffAt_localTorusChart hR (localImmersionBall_subset hR hx) 1)
  · intro x hx v w
    exact localTorusMetric_isometricDifferential hR h hc hs hp huIso
      (localImmersionBall_subset hR hx) v w

/-- The local endpoint for positive (C^{0,a}) metrics, including Lipschitz metrics. -/
theorem exists_localIsometricImmersion_of_holder {R a C : ℝ}
    (hR : 0 < R) (h : Cover d → MetricForm d) (hc : ContinuousOn h (Metric.ball 0 R))
    (hs : ∀ x ∈ Metric.ball 0 R, ∀ v w, h x v w = h x w v)
    (hp : ∀ x ∈ Metric.ball 0 R, ∀ v ≠ 0, 0 < h x v v)
    (ha : 0 < a) (ha₁ : a ≤ 1) (hC : 0 ≤ C)
    (hh : ∀ x ∈ Metric.ball 0 R, ∀ y ∈ Metric.ball 0 R, ‖h x - h y‖ ≤ C * ‖x - y‖ ^ a) :
    ∃ (N : ℕ) (u : Cover d → EuclideanSpace ℝ (Fin N)),
      HasHolderDifferentialOn (a / 2) u (localImmersionBall d R) ∧
      ∀ x ∈ localImmersionBall d R, ∀ v w,
        inner ℝ (fderiv ℝ u x v) (fderiv ℝ u x w) = h x v w := by
  obtain ⟨K, hK, hperiodic⟩ := hasHolderLift_localTorusMetric hR h hc hs hp ha.le ha₁ hC hh
  obtain ⟨N, u, hu, huIso⟩ := (localTorusMetric hR h hc hs hp).exists_euclideanImmersion_of_holder
    ha ha₁ hK (fun x y => hperiodic y x)
  refine ⟨N, fun x => u (flatProjection (localTorusChart R x)),
    hasHolderDifferentialOn_localTorusChart_comp (by positivity) (by linarith) hR hu, ?_⟩
  intro x hx v w
  exact localTorusMetric_isometricDifferential hR h hc hs hp huIso
    (localImmersionBall_subset hR hx) v w

/-- The local endpoint for positive (C^{1,a}) metrics, including (a=0). -/
theorem exists_localIsometricImmersion_of_holderDifferential {R a C : ℝ}
    (hR : 0 < R) (h : Cover d → MetricForm d) (hc : ContDiffOn ℝ 1 h (Metric.ball 0 R))
    (hs : ∀ x ∈ Metric.ball 0 R, ∀ v w, h x v w = h x w v)
    (hp : ∀ x ∈ Metric.ball 0 R, ∀ v ≠ 0, 0 < h x v v)
    (ha : 0 ≤ a) (ha₁ : a < 1) (hC : 0 ≤ C)
    (hh : ∀ x ∈ Metric.ball 0 R, ∀ y ∈ Metric.ball 0 R,
      ‖fderiv ℝ h x - fderiv ℝ h y‖ ≤ C * ‖x - y‖ ^ a) :
    ∃ (N : ℕ) (u : Cover d → EuclideanSpace ℝ (Fin N)),
      HasHolderDifferentialOn ((1 + a) / 2) u (localImmersionBall d R) ∧
      ∀ x ∈ localImmersionBall d R, ∀ v w,
        inner ℝ (fderiv ℝ u x v) (fderiv ℝ u x w) = h x v w := by
  let g := localTorusMetric hR h hc.continuousOn hs hp
  have hg := contDiff_localTorusMetric_lift hR h hc hs hp
  obtain ⟨K, hK, hperiodic⟩ := hasHolderLift_torusDifferential_localTorusMetric hR h hc hs hp
    ha ha₁.le hC hh
  obtain ⟨N, u, hu, huIso⟩ := g.exists_euclideanImmersion_of_holderDifferential
    ha ha₁ hK hg (fun x y => by
      simpa only [torusDifferential_apply] using hperiodic y x)
  refine ⟨N, fun x => u (flatProjection (localTorusChart R x)),
    hasHolderDifferentialOn_localTorusChart_comp (by linarith) (by linarith) hR hu, ?_⟩
  intro x hx v w
  exact localTorusMetric_isometricDifferential hR h hc.continuousOn hs hp huIso
    (localImmersionBall_subset hR hx) v w

/-- The endpoint at exponent zero requires only a continuously differentiable metric. -/
theorem exists_localIsometricImmersion_of_contDiffMetric {R : ℝ}
    (hR : 0 < R) (h : Cover d → MetricForm d) (hc : ContDiffOn ℝ 1 h (Metric.ball 0 R))
    (hs : ∀ x ∈ Metric.ball 0 R, ∀ v w, h x v w = h x w v)
    (hp : ∀ x ∈ Metric.ball 0 R, ∀ v ≠ 0, 0 < h x v v) :
    ∃ (N : ℕ) (u : Cover d → EuclideanSpace ℝ (Fin N)),
      HasHolderDifferentialOn (1 / 2) u (localImmersionBall d R) ∧
      ∀ x ∈ localImmersionBall d R, ∀ v w,
        inner ℝ (fderiv ℝ u x v) (fderiv ℝ u x w) = h x v w := by
  let g := localTorusMetric hR h hc.continuousOn hs hp
  obtain ⟨N, u, hu, huIso⟩ :=
    g.exists_euclideanImmersion_of_contDiff (contDiff_localTorusMetric_lift hR h hc hs hp)
  refine ⟨N, fun x => u (flatProjection (localTorusChart R x)),
    hasHolderDifferentialOn_localTorusChart_comp (by norm_num) (by norm_num) hR hu, ?_⟩
  intro x hx v w
  exact localTorusMetric_isometricDifferential hR h hc.continuousOn hs hp huIso
    (localImmersionBall_subset hR hx) v w

end

end IsometricEmbeddingEndpoints

#print axioms IsometricEmbeddingEndpoints.exists_localIsometricImmersion_contDiff
#print axioms IsometricEmbeddingEndpoints.exists_localIsometricImmersion_of_holder
#print axioms IsometricEmbeddingEndpoints.exists_localIsometricImmersion_of_holderDifferential
#print axioms IsometricEmbeddingEndpoints.exists_localIsometricImmersion_of_contDiffMetric
