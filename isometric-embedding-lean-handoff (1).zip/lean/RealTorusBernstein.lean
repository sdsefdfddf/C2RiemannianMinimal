import RealTorusCutoff
import TorusBernstein
import Mathlib.Analysis.Normed.Module.HahnBanach

namespace IsometricEmbeddingEndpoints

noncomputable section

variable {d H : Type*} [Fintype d] [NormedAddCommGroup H] [NormedSpace ℝ H]

/-- A real vector-valued torus function has frequencies in `band` if every real linear
coordinate, regarded as a complex function, belongs to the span of those modes. -/
def HasFourierSupport (band : Set (d → ℤ)) (f : C(UnitAddTorus d, H)) : Prop :=
  ∀ L : H →L[ℝ] ℝ, complexCoordinate L f ∈ Submodule.span ℂ (UnitAddTorus.mFourier '' band)

theorem hasFourierSupport_realTorusCutoff [CompleteSpace H] {scale : ℝ} (hs : 0 < scale)
    (f : C(UnitAddTorus d, H)) :
    HasFourierSupport (torusCutoffBand (d := d) scale : Set (d → ℤ)) (realTorusCutoff scale f) :=
  fun L => complexCoordinate_realTorusCutoff_mem_band hs L f

omit [Fintype d] in
theorem norm_complexCoordinate_le (L : H →L[ℝ] ℝ) (f : C(UnitAddTorus d, H)) :
    ‖complexCoordinate L f‖ ≤ ‖L‖ * ‖f‖ := by
  apply (ContinuousMap.norm_le _ (mul_nonneg (norm_nonneg _) (norm_nonneg _))).2
  intro x
  change ‖((L (f x) : ℝ) : ℂ)‖ ≤ _
  rw [Complex.norm_real]
  exact (L.le_opNorm (f x)).trans (mul_le_mul_of_nonneg_left (f.norm_coe_le_norm x) (norm_nonneg _))

theorem HasFourierSupport.contDiff_lift [FiniteDimensional ℝ H] {band : Set (d → ℤ)}
    {f : C(UnitAddTorus d, H)} (hf : HasFourierSupport band f) {k : WithTop ℕ∞} :
    ContDiff ℝ k (fun x : Cover d => f (flatProjection x)) := by
  let e := (Module.finBasis ℝ H).equivFunL
  have h : ContDiff ℝ k (fun x : Cover d => e (f (flatProjection x))) := by
    apply contDiff_pi.mpr
    intro i
    let L := (ContinuousLinearMap.proj i).comp e.toContinuousLinearMap
    have hc := contDiff_lift_of_modeSpan (hf L) (k := k)
    exact Complex.reCLM.contDiff.comp hc
  simpa only [Function.comp_def, ContinuousLinearEquiv.coe_coe, e.symm_apply_apply] using
    e.symm.toContinuousLinearMap.contDiff.comp h

/-- Bernstein's inequality for a finite-dimensional real target with its original norm. -/
theorem HasFourierSupport.norm_iteratedFDeriv_lift_le [FiniteDimensional ℝ H] {scale : ℝ}
    (hs : 0 < scale) {band : Set (d → ℤ)} (hone : ∀ n ∈ band, ‖scale⁻¹ • latticeVector n‖ ≤ 1)
    {f : C(UnitAddTorus d, H)} (hf : HasFourierSupport band f) (x : Cover d) (j : ℕ) :
    ‖iteratedFDeriv ℝ j (fun z => f (flatProjection z)) x‖ ≤
      (scale * bernsteinConstant d) ^ j * ‖f‖ := by
  have hC : 0 ≤ (scale * bernsteinConstant d) ^ j :=
    pow_nonneg (mul_nonneg hs.le (MeasureTheory.integral_nonneg fun _ => norm_nonneg _)) _
  apply ContinuousMultilinearMap.opNorm_le_bound (mul_nonneg hC (norm_nonneg _))
  intro m
  let D := iteratedFDeriv ℝ j (fun z => f (flatProjection z)) x
  obtain ⟨L, hL, hLm⟩ := exists_dual_vector'' ℝ (D m)
  let Lc := Complex.ofRealCLM.comp L
  have hm : iteratedFDeriv ℝ j (fun z => complexCoordinate L f (flatProjection z)) x m =
      (‖D m‖ : ℂ) := by
    change iteratedFDeriv ℝ j (Lc ∘ fun z => f (flatProjection z)) x m = _
    rw [Lc.iteratedFDeriv_comp_left (hf.contDiff_lift (k := (j : WithTop ℕ∞))).contDiffAt le_rfl]
    change ((L (D m) : ℝ) : ℂ) = _
    exact congrArg Complex.ofReal (by simpa using hLm)
  calc
    ‖D m‖ = ‖iteratedFDeriv ℝ j (fun z => complexCoordinate L f (flatProjection z)) x m‖ := by
      rw [hm, Complex.norm_real, norm_norm]
    _ ≤ ((scale * bernsteinConstant d) ^ j * ‖complexCoordinate L f‖) * ∏ i, ‖m i‖ :=
      ContinuousMultilinearMap.le_of_opNorm_le
        (norm_iteratedFDeriv_lift_le_of_modeSpan hs hone (hf L) x j) _
    _ ≤ _ := by
      refine mul_le_mul_of_nonneg_right (mul_le_mul_of_nonneg_left ?_ hC)
        (Finset.prod_nonneg fun i _ => norm_nonneg (m i))
      exact (norm_complexCoordinate_le L f).trans
        ((mul_le_mul_of_nonneg_right hL (norm_nonneg f)).trans_eq (one_mul _))

theorem HasFourierSupport.norm_iteratedFDeriv_lift_le_of_radius [FiniteDimensional ℝ H]
    {R : ℝ} (hR : 0 < R) {band : Set (d → ℤ)}
    (hband : ∀ n ∈ band, ‖latticeVector n‖ ≤ R)
    {f : C(UnitAddTorus d, H)} (hf : HasFourierSupport band f) (x : Cover d) (j : ℕ) :
    ‖iteratedFDeriv ℝ j (fun z => f (flatProjection z)) x‖ ≤
      (R * bernsteinConstant d) ^ j * ‖f‖ := by
  apply hf.norm_iteratedFDeriv_lift_le hR _ x j
  intro n hn
  rw [norm_smul, Real.norm_eq_abs, abs_of_nonneg (inv_nonneg.mpr hR.le)]
  exact (mul_le_mul_of_nonneg_left (hband n hn) (inv_nonneg.mpr hR.le)).trans_eq (inv_mul_cancel₀ hR.ne')

theorem HasFourierSupport.norm_iteratedFDeriv_le_pow [FiniteDimensional ℝ H]
    {R A : ℝ} (hR : 0 < R) {band : Set (d → ℤ)}
    (hband : ∀ n ∈ band, ‖latticeVector n‖ ≤ R)
    {f : C(UnitAddTorus d, H)} (hf : HasFourierSupport band f) (hfA : ‖f‖ ≤ A)
    (x : Cover d) {j : ℕ} (hj : 1 ≤ j) :
    ‖iteratedFDeriv ℝ j (fun z => f (flatProjection z)) x‖ ≤
      (R * bernsteinConstant d * (1 + A)) ^ j := by
  have hA : 0 ≤ A := (norm_nonneg f).trans hfA
  have hA' : A ≤ (1 + A) ^ j := by
    exact (by linarith : A ≤ 1 + A).trans
      (le_self_pow₀ (by linarith : 1 ≤ 1 + A) (by omega))
  have hpos : 0 ≤ R * bernsteinConstant d :=
    mul_nonneg hR.le (MeasureTheory.integral_nonneg fun _ => norm_nonneg _)
  rw [mul_pow]
  exact (hf.norm_iteratedFDeriv_lift_le_of_radius hR hband x j).trans
    (mul_le_mul_of_nonneg_left (hfA.trans hA') (pow_nonneg hpos _))

end

end IsometricEmbeddingEndpoints

#print axioms IsometricEmbeddingEndpoints.HasFourierSupport.norm_iteratedFDeriv_lift_le
