import TorusCutoff
import Mathlib.Topology.Order.Compact

namespace IsometricEmbeddingEndpoints

noncomputable section

variable {d : Type*} [Fintype d]

/-- The constant Euclidean metric on the covering coordinates. -/
def flatMetric : C(UnitAddTorus d, MetricForm d) :=
  ContinuousMap.const _ (innerSL ℝ)

@[simp] theorem flatMetric_apply (t : UnitAddTorus d) (v w : Cover d) :
    flatMetric t v w = inner ℝ v w := rfl

/-- A continuous positive Riemann metric in the flat torus coordinates. Higher regularity
is a condition on the periodic lift of `form`. -/
structure TorusMetric (d : Type*) [Fintype d] where
  form : C(UnitAddTorus d, MetricForm d)
  symmetric : ∀ x v w, form x v w = form x w v
  positive : ∀ x v, v ≠ 0 → 0 < form x v v

/-- Pointwise positivity on the compact torus gives a uniform lower bound as a quadratic form. -/
theorem TorusMetric.exists_lowerBound (g : TorusMetric d) :
    ∃ m : ℝ, 0 < m ∧ ∀ x v, m * ‖v‖ ^ 2 ≤ g.form x v v := by
  let S := (Set.univ : Set (UnitAddTorus d)) ×ˢ Metric.sphere (0 : Cover d) 1
  let G := fun p : UnitAddTorus d × Cover d => g.form p.1 p.2 p.2
  have hS : IsCompact S := isCompact_univ.prod (isCompact_sphere _ _)
  have hG : Continuous G := ((g.form.continuous.comp continuous_fst).clm_apply
    continuous_snd).clm_apply continuous_snd
  have hnormalize {v : Cover d} (hv : v ≠ 0) :
      ‖v‖⁻¹ • v ∈ Metric.sphere (0 : Cover d) 1 := by
    rw [Metric.mem_sphere, dist_zero_right, norm_smul, Real.norm_eq_abs,
      abs_of_pos (inv_pos.mpr (norm_pos_iff.mpr hv)), inv_mul_cancel₀ (norm_ne_zero_iff.mpr hv)]
  by_cases hSne : S.Nonempty
  · obtain ⟨q, hq, hmin⟩ := hS.exists_isMinOn hSne hG.continuousOn
    have hqnorm : ‖q.2‖ = 1 := by
      simpa only [Metric.mem_sphere, dist_zero_right] using hq.2
    have hqne : q.2 ≠ 0 := by
      intro hz
      simp [hz] at hqnorm
    refine ⟨G q, g.positive q.1 q.2 hqne, fun t v => ?_⟩
    by_cases hv : v = 0
    · simp [hv]
    · have hle : G q ≤ G (t, ‖v‖⁻¹ • v) :=
        hmin (show (t, ‖v‖⁻¹ • v) ∈ S from ⟨Set.mem_univ _, hnormalize hv⟩)
      calc
        _ ≤ G (t, ‖v‖⁻¹ • v) * ‖v‖ ^ 2 := mul_le_mul_of_nonneg_right hle (sq_nonneg _)
        _ = _ := by
          simp only [G, map_smul, smul_apply, smul_eq_mul]
          field_simp [norm_ne_zero_iff.mpr hv]
  · refine ⟨1, zero_lt_one, fun t v => ?_⟩
    by_cases hv : v = 0
    · simp [hv]
    · exact (hSne ⟨(t, ‖v‖⁻¹ • v), ⟨Set.mem_univ _, hnormalize hv⟩⟩).elim

variable {H : Type*} [NormedAddCommGroup H] [InnerProductSpace ℝ H]

/-- Isometry in the differential sense, stated on the Euclidean cover of the torus. -/
def TorusMetric.HasIsometricDifferential (g : TorusMetric d) (u : C(UnitAddTorus d, H)) : Prop :=
  Differentiable ℝ (fun x : Cover d => u (flatProjection x)) ∧
    ∀ x v w : Cover d,
      inner ℝ (fderiv ℝ (fun z => u (flatProjection z)) x v)
        (fderiv ℝ (fun z => u (flatProjection z)) x w) =
        g.form (flatProjection x) v w

theorem TorusMetric.HasIsometricDifferential.injective_fderiv {g : TorusMetric d}
    {u : C(UnitAddTorus d, H)} (hu : g.HasIsometricDifferential u) (x : Cover d) :
    Function.Injective (fderiv ℝ (fun z => u (flatProjection z)) x) := by
  let D := fderiv ℝ (fun z => u (flatProjection z)) x
  intro v w hvw
  have hzero : D (v - w) = 0 := by rw [map_sub, hvw, sub_self]
  by_contra hne
  have hp := g.positive (flatProjection x) (v - w) (sub_ne_zero.mpr hne)
  rw [← hu.2 x (v - w) (v - w)] at hp
  change 0 < inner ℝ (D (v - w)) (D (v - w)) at hp
  simp only [hzero, inner_zero_left, lt_self_iff_false] at hp

end

end IsometricEmbeddingEndpoints

#print axioms IsometricEmbeddingEndpoints.TorusMetric.exists_lowerBound
#print axioms IsometricEmbeddingEndpoints.TorusMetric.HasIsometricDifferential.injective_fderiv
