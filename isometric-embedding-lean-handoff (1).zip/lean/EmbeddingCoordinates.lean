import Mathlib.Analysis.Calculus.ContDiff.Defs
import Mathlib.Analysis.InnerProductSpace.PiL2
import Mathlib.Analysis.SpecialFunctions.Pow.Real

namespace IsometricEmbeddingEndpoints

noncomputable section

abbrev Cover (d : Type*) := EuclideanSpace ℝ d

abbrev MetricForm (d : Type*) [Fintype d] := Cover d →L[ℝ] Cover d →L[ℝ] ℝ

variable {d : Type*} [Fintype d]

open ContinuousLinearMap in
/-- The pullback of a bilinear form by a continuous linear map. -/
def pullbackMetricForm (h : MetricForm d) (A : Cover d →L[ℝ] Cover d) : MetricForm d :=
  ((compL ℝ (Cover d) (Cover d) ℝ).flip A).comp (h.comp A)

@[simp] theorem pullbackMetricForm_apply (h : MetricForm d) (A : Cover d →L[ℝ] Cover d)
    (v w : Cover d) : pullbackMetricForm h A v w = h (A v) (A w) := rfl

variable {E F : Type*}
  [NormedAddCommGroup E] [NormedSpace ℝ E]
  [NormedAddCommGroup F] [NormedSpace ℝ F]

/-- A map is continuously differentiable at the points of the set, with a uniform
Hölder estimate for its derivative there. -/
def HasHolderDifferentialOn (a : ℝ) (f : E → F) (s : Set E) : Prop :=
  (∀ x ∈ s, ContDiffAt ℝ 1 f x) ∧
    ∃ C : ℝ, 0 ≤ C ∧ ∀ x ∈ s, ∀ y ∈ s,
      ‖fderiv ℝ f x - fderiv ℝ f y‖ ≤ C * ‖x - y‖ ^ a

end

end IsometricEmbeddingEndpoints
