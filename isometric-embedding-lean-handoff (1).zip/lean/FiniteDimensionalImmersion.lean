module

public import ClosedManifoldStatement
public import Mathlib.Geometry.Manifold.Immersion
import Mathlib.Analysis.Calculus.InverseFunctionTheorem.ContDiff
import Mathlib.Analysis.InnerProductSpace.Projection.FiniteDimensional
import Mathlib.Geometry.Manifold.ContMDiff.Atlas
import Mathlib.Geometry.Manifold.MFDeriv.Atlas

open scoped ContDiff Manifold Topology
open Filter Function Manifold Set

public section

namespace IsometricEmbeddingEndpoints

noncomputable section

private theorem extendInjective {d N : ℕ}
    (A : Euclidean d →L[ℝ] Euclidean N) (ha : Injective A) :
    ∃ L : (Euclidean d × Euclidean (N - d)) ≃L[ℝ] Euclidean N,
      ∀ v, L (v, 0) = A v := by
  let R := LinearMap.range A.toLinearMap
  let e := LinearEquiv.ofInjective A.toLinearMap ha
  have he : Module.finrank ℝ R = d := by
    simpa [R] using e.finrank_eq.symm
  have hdim := R.finrank_add_finrank_orthogonal
  rw [he, finrank_euclideanSpace_fin] at hdim
  let k : Euclidean (N - d) ≃ₗ[ℝ] Rᗮ := LinearEquiv.ofFinrankEq _ _ (by simp; omega)
  let L := (e.prodCongr k).trans (R.prodEquivOfIsCompl _ R.isCompl_orthogonal)
  refine ⟨L.toContinuousLinearEquiv, fun v => ?_⟩
  change (R.prodEquivOfIsCompl _ R.isCompl_orthogonal) (e v, k 0) = A v
  simp [e]

/-- Straighten a local graph by the inverse function theorem. -/
private theorem straighten {E F G : Type*}
    [NormedAddCommGroup E] [NormedSpace ℝ E] [CompleteSpace E]
    [NormedAddCommGroup F] [NormedSpace ℝ F]
    [NormedAddCommGroup G] [NormedSpace ℝ G] [CompleteSpace G]
    {h : E → F} {x : E} (hh : ContDiffAt ℝ 1 h x)
    (L : (E × G) ≃L[ℝ] F) (hL : ∀ v, L (v, 0) = fderiv ℝ h x v) :
    ∃ e : OpenPartialHomeomorph (E × G) F, (x, 0) ∈ e.source ∧
      ContDiffOn ℝ 1 e e.source ∧ ContDiffOn ℝ 1 e.symm e.target ∧
      ∀ y, e (y, 0) = h y := by
  let B : E × G →L[ℝ] F :=
    (L : E × G →L[ℝ] F).comp ((ContinuousLinearMap.inr ℝ E G).comp
      (ContinuousLinearMap.snd ℝ E G))
  let H : E × G → F := fun y => h y.1 + B y
  have hH : ContDiffAt ℝ 1 H (x, 0) :=
    (hh.comp _ contDiffAt_fst).add B.contDiff.contDiffAt
  have hD : HasFDerivAt H (L : E × G →L[ℝ] F) (x, 0) := by
    have hlin : (L : E × G →L[ℝ] F) =
        (fderiv ℝ h x).comp (ContinuousLinearMap.fst ℝ E G) + B := by
      apply ContinuousLinearMap.ext
      intro v
      change L v = fderiv ℝ h x v.1 + L (0, v.2)
      rw [← hL, ← map_add]
      exact congrArg (fun z : E × G => L z) (by ext <;> simp)
    rw [hlin]
    exact ((hh.differentiableAt one_ne_zero).hasFDerivAt.comp (x, (0 : G))
      (hasFDerivAt_fst (𝕜 := ℝ))).add B.hasFDerivAt
  let e := hH.toOpenPartialHomeomorph H hD one_ne_zero
  have hx : (x, 0) ∈ e.source := hH.mem_toOpenPartialHomeomorph_source hD one_ne_zero
  have he : ContDiffAt ℝ 1 e.symm (e (x, 0)) := hH.to_localInverse hD one_ne_zero
  let s := interior {y | ContDiffAt ℝ 1 H y ∧ ContDiffAt ℝ 1 e.symm (e y)}
  have hs : (x, 0) ∈ s := mem_interior_iff_mem_nhds.mpr <|
    (hH.eventually (by simp)).and <|
      (e.continuousAt hx).tendsto.eventually (he.eventually (by simp))
  let e' := e.restrOpen s isOpen_interior
  have hsrc : ∀ ⦃y⦄, y ∈ e'.source → ContDiffAt ℝ 1 H y ∧ ContDiffAt ℝ 1 e.symm (e y) := by
    intro y hy
    rw [OpenPartialHomeomorph.restrOpen_source] at hy
    exact interior_subset hy.2
  refine ⟨e', ⟨hx, hs⟩, fun y hy => (hsrc hy).1.contDiffWithinAt, ?_, fun y => ?_⟩
  · intro y hy
    have hy' := e'.map_target hy
    have heq : e (e'.symm y) = y := e'.right_inv hy
    change ContDiffWithinAt ℝ 1 e.symm e'.target y
    simpa only [heq] using (hsrc hy').2.contDiffWithinAt (s := e'.target)
  · change h y + L (0, 0) = h y
    simp

local notation "𝓔" d:arg => 𝓘(ℝ, Euclidean d)

set_option backward.isDefEq.respectTransparency false in
/-- A differentiably injective map between finite-dimensional manifolds is an immersion. -/
theorem isImmersion_of_injective_mvfderiv {d N : ℕ} {M : Type*}
    [TopologicalSpace M] [ChartedSpace (Euclidean d) M] [IsManifold (𝓔 d) 1 M]
    {f : M → Euclidean N} (hf : ContMDiff (𝓔 d) (𝓔 N) 1 f)
    (hinj : ∀ p, Injective (mvfderiv (𝓔 d) f p)) :
    IsImmersion (𝓔 d) (𝓔 N) 1 f := by
  apply IsImmersionOfComplement.isImmersion (F := Euclidean (N - d))
  intro p
  let c := chartAt (Euclidean d) p
  have hp : p ∈ c.source := mem_chart_source _ _
  have hcp := c.map_source hp
  let h := f ∘ c.symm
  have hc : ContMDiffAt (𝓔 d) (𝓔 d) 1 c.symm (c p) :=
    contMDiffOn_chart_symm.contMDiffAt (c.open_target.mem_nhds hcp)
  have hh : ContDiffAt ℝ 1 h (c p) := (hf.contMDiffAt.comp _ hc).contDiffAt
  obtain ⟨L, hL⟩ := extendInjective (fderiv ℝ h (c p)) (by
    have himm := (mdifferentiable_chart (I := 𝓔 d) p).symm
    have hd := mvfderiv_comp (c p) (hf.mdifferentiable (by simp) _)
      (himm.mdifferentiableAt hcp)
    rw [mvfderiv_eq_fderiv, c.left_inv hp] at hd
    have hfd : fderiv ℝ h (c p) = (mvfderiv (𝓔 d) f p).comp
        (mfderiv (𝓔 d) (𝓔 d) c.symm (c p)) := hd
    rw [hfd]
    exact (hinj p).comp (himm.mfderiv_injective hcp))
  obtain ⟨e, he, heS, heT, hgraph⟩ := straighten hh L hL
  let s := c.source ∩ (fun y => (c y, (0 : Euclidean (N - d)))) ⁻¹' e.source
  have hs : IsOpen s := ((c.continuousOn.prodMk continuousOn_const).isOpen_inter_preimage
    c.open_source e.open_source)
  let dom := c.restrOpen s hs
  let cod := e.symm.transHomeomorph L.toHomeomorph
  have hcodAtlas : cod ∈ IsManifold.maximalAtlas (𝓔 N) 1 (Euclidean N) := by
    apply cod.mem_maximalAtlas_of_contMDiffOn
    · exact (L.contDiff.contDiffOn.comp heT (mapsTo_univ _ _)).contMDiffOn
    · exact (heS.comp L.symm.contDiff.contDiffOn (fun y hy => hy)).contMDiffOn
  refine IsImmersionAtOfComplement.mk_of_continuousAt hf.continuous.continuousAt L dom cod
    ⟨hp, hp, he⟩ ?_ ?_ hcodAtlas ?_
  · change f p ∈ e.target
    rw [← show e (c p, 0) = f p by
      rw [hgraph]
      change f (c.symm (c p)) = f p
      rw [c.left_inv hp]]
    exact e.map_source he
  · have hcAtlas : c ∈ IsManifold.maximalAtlas (𝓔 d) 1 M :=
      IsManifold.chart_mem_maximalAtlas p
    rw [IsManifold.mem_maximalAtlas_iff] at hcAtlas ⊢
    change c.restrOpen s hs ∈ (contDiffGroupoid 1 (𝓔 d)).maximalAtlas M
    simpa only [OpenPartialHomeomorph.restr, hs.interior_eq] using
      restr_mem_maximalAtlas (contDiffGroupoid 1 (𝓔 d)) hcAtlas hs
  · intro x hx
    have hx' : x ∈ dom.target := by simpa using hx
    have hy : dom.symm x ∈ dom.source := dom.map_target hx'
    have hgood : (x, (0 : Euclidean (N - d))) ∈ e.source := by
      rw [← dom.right_inv hx']
      exact hy.2.2
    change L (e.symm (f (dom.symm x))) = L (x, 0)
    rw [← e.left_inv hgood, hgraph]
    rfl

end

end IsometricEmbeddingEndpoints
