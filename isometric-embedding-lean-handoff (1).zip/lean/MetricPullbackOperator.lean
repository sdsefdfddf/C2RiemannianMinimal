import LocalTorusMetric

open scoped ContDiff

namespace IsometricEmbeddingEndpoints

open ContinuousLinearMap

noncomputable section

variable {d : Type*} [Fintype d]

local instance : NormedAddCommGroup (MetricForm d) := inferInstance
local instance : NormedSpace ℝ (MetricForm d) := inferInstance

/-- Pullback by a fixed differential, as a linear operator on bilinear forms. -/
def metricPullbackOperator (A : Cover d →L[ℝ] Cover d) : MetricForm d →L[ℝ] MetricForm d :=
  let E := Cover d
  let W := E →L[ℝ] ℝ
  (compL ℝ E W W ((compL ℝ E E ℝ).flip A)).comp ((compL ℝ E E W).flip A)

@[simp] theorem metricPullbackOperator_apply (A : Cover d →L[ℝ] Cover d) (h : MetricForm d) :
    metricPullbackOperator A h = pullbackMetricForm h A := rfl

set_option maxHeartbeats 900000 in
theorem contDiff_metricPullbackOperator (n : ℕ∞ω) :
    ContDiff ℝ n (metricPullbackOperator (d := d)) := by
  let E := Cover d
  let W := E →L[ℝ] ℝ
  let D := E →L[ℝ] E
  let V := MetricForm d
  let pre : D →L[ℝ] V →L[ℝ] V := (compL ℝ E E W).flip
  let post : D →L[ℝ] V →L[ℝ] V := (compL ℝ E W W).comp (compL ℝ E E ℝ).flip
  have hpre := ContinuousLinearMap.contDiff (𝕜 := ℝ) (n := n) (E := D) (F := V →L[ℝ] V) pre
  have hpost := ContinuousLinearMap.contDiff (𝕜 := ℝ) (n := n) (E := D) (F := V →L[ℝ] V) post
  exact hpost.clm_comp hpre

end

end IsometricEmbeddingEndpoints

#print axioms IsometricEmbeddingEndpoints.contDiff_metricPullbackOperator
