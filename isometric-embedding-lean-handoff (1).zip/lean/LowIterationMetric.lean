import TorusGram

namespace IsometricEmbeddingEndpoints

open ContinuousLinearMap
open scoped Pointwise

noncomputable section

variable {d ι H : Type*} [Fintype d] [Fintype ι]
  [NormedAddCommGroup H] [InnerProductSpace ℝ H] [CompleteSpace H]

local instance : NormedAddCommGroup (MetricForm d) := inferInstance
local instance : NormedSpace ℝ (MetricForm d) := inferInstance

/-- Sum the Gram forms of the orthogonal blocks of the iteration. -/
def torusBlockGram (F : ι → C(UnitAddTorus d, Cover d →L[ℝ] H)) : C(UnitAddTorus d, MetricForm d) :=
  ∑ b, torusGram (F b)

@[simp] theorem torusBlockGram_apply (F : ι → C(UnitAddTorus d, Cover d →L[ℝ] H))
    (t : UnitAddTorus d) (v w : Cover d) :
    torusBlockGram F t v w = ∑ b, inner ℝ (F b t v) (F b t w) := by
  simp only [torusBlockGram, ContinuousMap.coe_sum, Finset.sum_apply, sum_apply, torusGram_apply]

theorem torusBlockGram_symmetric (F : ι → C(UnitAddTorus d, Cover d →L[ℝ] H))
    (t : UnitAddTorus d) (v w : Cover d) :
    torusBlockGram F t v w = torusBlockGram F t w v := by
  rw [torusBlockGram_apply, torusBlockGram_apply]
  exact Finset.sum_congr rfl fun _ _ => real_inner_comm _ _

theorem torusBlockGram_const (F : C(UnitAddTorus d, Cover d →L[ℝ] H)) :
    torusBlockGram (fun _ : ι => F) = (Fintype.card ι : ℝ) • torusGram F := by
  ext t v w
  simp only [torusBlockGram_apply, ContinuousMap.smul_apply, smul_apply, smul_eq_mul, torusGram_apply,
    Finset.sum_const, Finset.card_univ, nsmul_eq_mul]

theorem hasFourierSupport_torusBlockGram [FiniteDimensional ℝ H] {band : Set (d → ℤ)}
    (F : ι → C(UnitAddTorus d, Cover d →L[ℝ] H)) (hF : ∀ b, HasFourierSupport band (F b)) :
    HasFourierSupport (band + band) (torusBlockGram F) :=
  hasFourierSupport_sum Finset.univ _ (fun i _ => (hF i).torusGram)

theorem torusBlockGram_sub_update [DecidableEq ι]
    (F : ι → C(UnitAddTorus d, Cover d →L[ℝ] H)) (b : ι) (D : C(UnitAddTorus d, Cover d →L[ℝ] H)) :
    torusBlockGram (Function.update F b (F b + D)) - torusBlockGram F =
      torusGram (F b + D) - torusGram (F b) := by
  ext t v w
  simp only [ContinuousMap.sub_apply, sub_apply, torusBlockGram_apply, torusGram_apply]
  rw [← Finset.sum_sub_distrib, Finset.sum_eq_single b]
  · simp only [Function.update_self]
  · intro i _ hi
    simp only [Function.update_of_ne hi, sub_self]
  · simp

omit [Fintype ι] [NormedAddCommGroup H] [InnerProductSpace ℝ H] [CompleteSpace H] in
theorem norm_flatMetric_le_one : ‖(flatMetric (d := d))‖ ≤ 1 := by
  refine (ContinuousMap.norm_le _ zero_le_one).2 (fun t => norm_metricForm_le_of_pointwise zero_le_one ?_)
  intro v w
  rw [flatMetric_apply, one_mul]
  exact abs_real_inner_le_norm v w

/-- Normalize the remaining metric increment by the current scalar defect. -/
def normalizedDefect (G P : C(UnitAddTorus d, MetricForm d)) (δ δ' : ℝ) :
    C(UnitAddTorus d, MetricForm d) :=
  δ⁻¹ • (G - P - δ' • flatMetric) - flatMetric

theorem scaled_normalizedDefect (G P : C(UnitAddTorus d, MetricForm d)) {δ δ' : ℝ}
    (hδ : δ ≠ 0) : δ • (flatMetric + normalizedDefect G P δ δ') = G - P - δ' • flatMetric := by
  ext t v w
  simp only [normalizedDefect, ContinuousMap.smul_apply, ContinuousMap.add_apply,
    ContinuousMap.sub_apply, smul_apply, smul_eq_mul, add_apply, sub_apply, flatMetric_apply]
  field_simp [hδ]
  ring

theorem normalizedDefect_symmetric (G P : C(UnitAddTorus d, MetricForm d))
    (hG : ∀ t v w, G t v w = G t w v) (hP : ∀ t v w, P t v w = P t w v)
    (δ δ' : ℝ) (t : UnitAddTorus d) (v w : Cover d) :
    normalizedDefect G P δ δ' t v w = normalizedDefect G P δ δ' t w v := by
  simp only [normalizedDefect, ContinuousMap.sub_apply, ContinuousMap.smul_apply,
    sub_apply, smul_apply, flatMetric_apply, hG t v w, hP t v w, real_inner_comm v w]

theorem hasFourierSupport_normalizedDefect {band : Set (d → ℤ)} (hzero : 0 ∈ band)
    (G P : C(UnitAddTorus d, MetricForm d)) (hG : HasFourierSupport band G)
    (hP : HasFourierSupport band P) (δ δ' : ℝ) :
    HasFourierSupport band (normalizedDefect G P δ δ') := by
  have hI : HasFourierSupport band (flatMetric (d := d)) := hasFourierSupport_const hzero _
  exact ((((hG.sub hP).sub (hI.smul δ')).smul δ⁻¹).sub hI)

/-- Compare the normalized metric increment to the identity using the previous
defect and the error of smoothing the given metric. -/
theorem norm_normalizedDefect_le (g G P : C(UnitAddTorus d, MetricForm d)) {δ δ' a b : ℝ}
    (hδ : 0 < δ) (hδ' : 0 ≤ δ') (ha : ‖G - g‖ ≤ a) (hb : ‖P - (g - δ • flatMetric)‖ ≤ b) :
    ‖normalizedDefect G P δ δ'‖ ≤ (a + b + δ') / δ := by
  have heq : normalizedDefect G P δ δ' =
      δ⁻¹ • ((G - g) - (P - (g - δ • flatMetric)) - δ' • flatMetric) := by
    ext t v w
    simp only [normalizedDefect, ContinuousMap.smul_apply, ContinuousMap.sub_apply,
      smul_apply, sub_apply, smul_eq_mul, flatMetric_apply]
    field_simp [hδ.ne']
    ring
  rw [heq, norm_smul δ⁻¹, Real.norm_eq_abs, abs_of_nonneg (inv_nonneg.mpr hδ.le), div_eq_inv_mul]
  apply mul_le_mul_of_nonneg_left _ (inv_nonneg.mpr hδ.le)
  calc
    _ ≤ ‖(G - g) - (P - (g - δ • flatMetric))‖ + ‖δ' • (flatMetric (d := d))‖ := norm_sub_le _ _
    _ ≤ (a + b) + δ' := by
      apply add_le_add ((norm_sub_le _ _).trans (add_le_add ha hb))
      rw [norm_smul δ', Real.norm_eq_abs, abs_of_nonneg hδ']
      exact (mul_le_mul_of_nonneg_left norm_flatMetric_le_one hδ').trans_eq (mul_one _)

/-- When one block is updated, the next metric defect is the local Gram error
plus the error from truncating the given metric. -/
theorem torusBlockGram_next_defect [DecidableEq ι]
    (g G : C(UnitAddTorus d, MetricForm d)) (F : ι → C(UnitAddTorus d, Cover d →L[ℝ] H))
    (b : ι) (D : C(UnitAddTorus d, Cover d →L[ℝ] H)) {δ δ' : ℝ} (hδ : δ ≠ 0) :
    torusBlockGram (Function.update F b (F b + D)) - (g - δ' • flatMetric) =
      (torusGram (F b + D) -
        (torusGram (F b) + δ • (flatMetric + normalizedDefect G (torusBlockGram F) δ δ'))) + (G - g) := by
  rw [scaled_normalizedDefect G (torusBlockGram F) hδ]
  have h := torusBlockGram_sub_update F b D
  ext t v w
  have h' := congrArg (fun q : C(UnitAddTorus d, MetricForm d) => q t v w) h
  simp only [ContinuousMap.sub_apply, sub_apply] at h'
  simp only [ContinuousMap.sub_apply, ContinuousMap.add_apply, ContinuousMap.smul_apply, sub_apply,
    add_apply, smul_apply, smul_eq_mul, flatMetric_apply]
  linarith only [h']

end

end IsometricEmbeddingEndpoints

#print axioms IsometricEmbeddingEndpoints.norm_normalizedDefect_le
#print axioms IsometricEmbeddingEndpoints.torusBlockGram_next_defect
