import SphereWrapping
import Mathlib.Geometry.Manifold.MFDeriv.NormedSpace

namespace IsometricEmbeddingEndpoints

open Filter Function Set
open scoped Manifold Topology

noncomputable section

variable {E H M : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E]
  [TopologicalSpace H] {I : ModelWithCorners ℝ E H} [TopologicalSpace M] [ChartedSpace H M]

private theorem mvfderiv_eq_zero_of_eventuallyEq_zero {F : Type*}
    [NormedAddCommGroup F] [NormedSpace ℝ F] {f : M → F} {p : M}
    (h : f =ᶠ[𝓝 p] fun _ => 0) : mvfderiv I f p = 0 := by
  rw [mvfderiv, h.mfderiv_eq (I := I) (I' := 𝓘(ℝ, F)), mfderiv_const]
  simp

/-- The local weighted maps contribute the desired metric and one explicit term
from the derivatives of the weights. This uses each local map only on the
topological support of its weight. -/
theorem sum_inner_mvfderiv_weightedSphere {ι : Type*} [Fintype ι] {F : ι → Type*}
    [∀ i, NormedAddCommGroup (F i)] [∀ i, InnerProductSpace ℝ (F i)]
    (a : ι → M → ℝ) (f : (i : ι) → M → F i) {p : M} {ρ : ℝ}
    (ha : ∀ i, MDifferentiableAt I 𝓘(ℝ) (a i) p)
    (ha₁ : (∑ i, a i p ^ 2) = 1)
    (hf : ∀ i, p ∈ tsupport (a i) → MDifferentiableAt I 𝓘(ℝ, F i) (f i) p)
    (hρ : ∀ i, p ∈ tsupport (a i) → ‖f i p‖ ^ 2 = ρ ^ 2)
    (horth : ∀ i, p ∈ tsupport (a i) → ∀ v : TangentSpace I p,
      inner ℝ (f i p) (mvfderiv I (f i) p v) = 0)
    (g : TangentSpace I p →L[ℝ] TangentSpace I p →L[ℝ] ℝ)
    (hg : ∀ i, p ∈ tsupport (a i) → ∀ v w : TangentSpace I p,
      inner ℝ (mvfderiv I (f i) p v) (mvfderiv I (f i) p w) = g v w)
    (v w : TangentSpace I p) :
    (∑ i, inner ℝ (mvfderiv I (fun x => a i x • f i x) p v)
        (mvfderiv I (fun x => a i x • f i x) p w)) =
      g v w + ρ ^ 2 * ∑ i, mvfderiv I (a i) p v * mvfderiv I (a i) p w := by
  calc
    _ = ∑ i, (a i p ^ 2 * g v w + ρ ^ 2 * (mvfderiv I (a i) p v * mvfderiv I (a i) p w)) := by
      apply Finset.sum_congr rfl
      intro i _
      by_cases hi : p ∈ tsupport (a i)
      · rw [mvfderiv_fun_smul (ha i) (hf i hi)]
        have h := inner_weightedSphereDifferential (a := a i p) (mvfderiv I (f i) p)
          (mvfderiv I (a i) p) (hρ i hi) (horth i hi) v w
        dsimp only at h
        rw [hg i hi] at h
        exact h
      · have hc : IsClosed (tsupport (a i)) := isClosed_closure
        have hmem : ∀ᶠ x in 𝓝 p, x ∉ tsupport (a i) := hc.isOpen_compl.mem_nhds hi
        have hzero : a i =ᶠ[𝓝 p] (fun _ => 0) :=
          hmem.mono fun x hx => image_eq_zero_of_notMem_tsupport hx
        have hzero' : (fun x => a i x • f i x) =ᶠ[𝓝 p] (fun _ => 0) :=
          hzero.mono fun x hx => by simp only [hx, zero_smul]
        have hp : a i p = 0 := mem_of_mem_nhds hzero
        rw [mvfderiv_eq_zero_of_eventuallyEq_zero hzero, mvfderiv_eq_zero_of_eventuallyEq_zero hzero', hp]
        simp
    _ = _ := by rw [Finset.sum_add_distrib, ← Finset.sum_mul, ← Finset.mul_sum, ha₁, one_mul]

end

end IsometricEmbeddingEndpoints

#print axioms IsometricEmbeddingEndpoints.sum_inner_mvfderiv_weightedSphere
