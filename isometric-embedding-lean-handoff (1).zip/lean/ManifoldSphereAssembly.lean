import ManifoldDirectSum
import ManifoldSphereDifferential
import Mathlib.Geometry.Manifold.Algebra.SMul

open scoped Manifold Topology

namespace IsometricEmbeddingEndpoints

open Filter Function Set

noncomputable section

universe u

variable {ι E H M : Type*} [Fintype ι]
  [NormedAddCommGroup E] [NormedSpace ℝ E]
  [TopologicalSpace H] {I : ModelWithCorners ℝ E H} [TopologicalSpace M] [ChartedSpace H M]
  {W : Type u} [NormedAddCommGroup W] [InnerProductSpace ℝ W]
  {F : ι → Type u} [∀ i, NormedAddCommGroup (F i)] [∀ i, InnerProductSpace ℝ (F i)]

/-- The unweighted embedding occupies its own orthogonal summand. -/
def SphereAssemblyFactors (W : Type u) (F : ι → Type u) : Option ι → Type u
  | none => W
  | some i => F i

instance (i : Option ι) : NormedAddCommGroup (SphereAssemblyFactors W F i) := by
  cases i
  · exact inferInstanceAs (NormedAddCommGroup W)
  · exact inferInstanceAs (NormedAddCommGroup (F _))

instance (i : Option ι) : InnerProductSpace ℝ (SphereAssemblyFactors W F i) := by
  cases i
  · exact inferInstanceAs (InnerProductSpace ℝ W)
  · exact inferInstanceAs (InnerProductSpace ℝ (F _))

def sphereAssemblyComponents (w : M → W) (a : ι → M → ℝ) (f : (i : ι) → M → F i) :
    (i : Option ι) → M → SphereAssemblyFactors W F i
  | none => w
  | some i => fun x => a i x • f i x

/-- The Whitney map and the weighted local sphere maps in orthogonal summands. -/
def sphereAssembly (w : M → W) (a : ι → M → ℝ) (f : (i : ι) → M → F i) :
    M → PiLp 2 (SphereAssemblyFactors W F) :=
  directSumMap (sphereAssemblyComponents w a f)

private theorem contMDiffAt_sphereAssemblyComponents
    {w : M → W} {a : ι → M → ℝ} {f : (i : ι) → M → F i} {p : M}
    (hw : ContMDiffAt I 𝓘(ℝ, W) 1 w p)
    (ha : ∀ i, ContMDiffAt I 𝓘(ℝ) 1 (a i) p)
    (hf : ∀ i, p ∈ tsupport (a i) → ContMDiffAt I 𝓘(ℝ, F i) 1 (f i) p) :
    ∀ i, ContMDiffAt I 𝓘(ℝ, SphereAssemblyFactors W F i) 1 (sphereAssemblyComponents w a f i) p := by
  intro i
  cases i with
  | none => exact hw
  | some i =>
    change ContMDiffAt I 𝓘(ℝ, F i) 1 (fun x => a i x • f i x) p
    by_cases hi : p ∈ tsupport (a i)
    · exact (ha i).smul (hf i hi)
    · have hc : IsClosed (tsupport (a i)) := isClosed_closure
      have ht : ∀ᶠ x in 𝓝 p, x ∉ tsupport (a i) := hc.isOpen_compl.mem_nhds hi
      have hzero : (fun x => a i x • f i x) =ᶠ[𝓝 p] (fun _ => (0 : F i)) := ht.mono fun x hx => by
        change a i x • f i x = 0
        rw [image_eq_zero_of_notMem_tsupport hx, zero_smul]
      exact hzero.contMDiffAt_iff.mpr contMDiffAt_const

theorem contMDiffAt_sphereAssembly
    {w : M → W} {a : ι → M → ℝ} {f : (i : ι) → M → F i} {p : M}
    (hw : ContMDiffAt I 𝓘(ℝ, W) 1 w p)
    (ha : ∀ i, ContMDiffAt I 𝓘(ℝ) 1 (a i) p)
    (hf : ∀ i, p ∈ tsupport (a i) → ContMDiffAt I 𝓘(ℝ, F i) 1 (f i) p) :
    ContMDiffAt I 𝓘(ℝ, PiLp 2 (SphereAssemblyFactors W F)) 1 (sphereAssembly w a f) p :=
  contMDiffAt_directSumMap (contMDiffAt_sphereAssemblyComponents hw ha hf)

theorem isEmbedding_sphereAssembly [CompactSpace M]
    {w : M → W} {a : ι → M → ℝ} {f : (i : ι) → M → F i}
    (hw : ContMDiff I 𝓘(ℝ, W) 1 w) (hwInj : Function.Injective w)
    (ha : ∀ i, ContMDiff I 𝓘(ℝ) 1 (a i))
    (hf : ∀ i p, p ∈ tsupport (a i) → ContMDiffAt I 𝓘(ℝ, F i) 1 (f i) p) :
    Topology.IsEmbedding (sphereAssembly w a f) := by
  exact isEmbedding_directSumMap
    (fun i p => contMDiffAt_sphereAssemblyComponents (hw p) (fun j => ha j p)
      (fun j => hf j p) i) none hwInj

set_option maxHeartbeats 900000 in
/-- The Gram form of the assembly is the sum of the Whitney term, the prescribed
local metric and the explicit contribution of the derivatives of the weights. -/
theorem inner_mvfderiv_sphereAssembly
    {w : M → W} {a : ι → M → ℝ} {f : (i : ι) → M → F i} {p : M} {ρ : ℝ}
    (hw : ContMDiffAt I 𝓘(ℝ, W) 1 w p)
    (ha : ∀ i, ContMDiffAt I 𝓘(ℝ) 1 (a i) p)
    (ha₁ : ∑ i, a i p ^ 2 = 1)
    (hf : ∀ i, p ∈ tsupport (a i) → ContMDiffAt I 𝓘(ℝ, F i) 1 (f i) p)
    (hρ : ∀ i, p ∈ tsupport (a i) → ‖f i p‖ ^ 2 = ρ ^ 2)
    (horth : ∀ i, p ∈ tsupport (a i) → ∀ v : TangentSpace I p,
      inner ℝ (f i p) (mvfderiv I (f i) p v) = 0)
    (g : TangentSpace I p →L[ℝ] TangentSpace I p →L[ℝ] ℝ)
    (hg : ∀ i, p ∈ tsupport (a i) → ∀ v w : TangentSpace I p,
      inner ℝ (mvfderiv I (f i) p v) (mvfderiv I (f i) p w) = g v w)
    (v z : TangentSpace I p) :
    inner ℝ (mvfderiv I (sphereAssembly w a f) p v) (mvfderiv I (sphereAssembly w a f) p z) =
      inner ℝ (mvfderiv I w p v) (mvfderiv I w p z) +
        (g v z + ρ ^ 2 * ∑ i, mvfderiv I (a i) p v * mvfderiv I (a i) p z) := by
  have hcomponents := contMDiffAt_sphereAssemblyComponents hw ha hf
  rw [sphereAssembly, inner_mvfderiv_directSumMap hcomponents, Fintype.sum_option]
  change inner ℝ (mvfderiv I w p v) (mvfderiv I w p z) +
    (∑ i, inner ℝ (mvfderiv I (fun x => a i x • f i x) p v)
      (mvfderiv I (fun x => a i x • f i x) p z)) = _
  rw [sum_inner_mvfderiv_weightedSphere a f (fun i => (ha i).mdifferentiableAt one_ne_zero)
    ha₁ (fun i hi => (hf i hi).mdifferentiableAt one_ne_zero) hρ horth g hg v z]

end

end IsometricEmbeddingEndpoints

#print axioms IsometricEmbeddingEndpoints.isEmbedding_sphereAssembly
#print axioms IsometricEmbeddingEndpoints.inner_mvfderiv_sphereAssembly
