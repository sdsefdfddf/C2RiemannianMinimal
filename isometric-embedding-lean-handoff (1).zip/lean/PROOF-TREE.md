# 两条等距嵌入定理的 Lean 拆分

按最终定理需要的引理从上往下展开。每条编号末尾给出该步可以直接使用的上一层结果、已有库接口，或要做的有限计算。式号对应同包的证明 PDF。实现时从每一节末端往上接。

## 1. 最终陈述

在紧致无边界的光滑 $n$ 维流形 $M$ 上，设 $g$ 是正定对称双线性型场。最终结论都量化一个有限的 $N$ 和 $u:M\to\mathbb R^N$，并包含 Mathlib 的 $C^1$ 嵌入条件、$du$ 在图中的 Hölder 正则性以及

$$
\forall p,v,w,\quad \langle du_p(v),du_p(w)\rangle=g_p(v,w).
$$

- **1.1 正指数端点。** 若 $g\in C^{0,a}$ 且 $0<a\le1$，取 $u\in C^{1,a/2}$。若 $g\in C^{1,a}$ 且 $0\le a<1$，取 $u\in C^{1,(1+a)/2}$。两条由 2 和 3 得到。[公开定理](ClosedManifoldEndpoints.lean)普通 $C^1$ 度量可以直接用其连续导数的有界性。$C^{1,1}$ 度量到 $C^{1,1}$ 浸入已有反例。
- **1.2 连续度量。** 若 $g\in C^0$，取 $u\in C^1$。在环面上复用低阶单步，各步的频率按该步所需的一致逼近精度选取，再应用 2。
- **1.3 正则性谓词。** 有限阶连续导数用 `ContDiff` 或 `ContMDiff`。在图中，对 $D^k$ 加 $a$-Hölder 界，$a=1$ 用真实的 Lipschitz 界。向量及矩阵值的条件可逐坐标加起来。两个紧坐标域之间，先由导数界证明光滑坐标变化局部 Lipschitz，再用链式法则和乘积的 Hölder 界，证明换图后仍有同一指数。
- **1.4 与现有环面接口合并。** `FlatTorus n = Fin n → AddCircle (1 : ℝ)`，覆盖空间是 `EuclideanSpace ℝ (Fin n)`。在 $n=2$ 时，度量的 `form`、正定性和 `HasIsometricDifferential` 的等式保持原样。这与 Wang/FatFish 的二维接口采用相同的切向量与 Gram 等式约定。在公开定理中用 `mvfderiv` 写逐切向量的等距条件。[坐标转换](ClosedManifoldCoordinates.lean)

## 2. 只证明一次的闭流形推广

取有限坐标覆盖的光滑权重 $\phi_i$，使 $\sum_i\phi_i^2=1$，并把光滑 Whitney 嵌入 $w$ 缩小。取共同的小半径 $\rho>0$，令

$$
h=g-w^*e-\rho^2\sum_i d\phi_i\otimes d\phi_i>0.
$$

在包含 $\operatorname{supp}\phi_i$ 的坐标开集上截取 $h$，在环面上正定地延拓。可取缩小的逐坐标正弦映射 $X$，使其像落入坐标球。度量取 $X^*h+B^*e$，其中 $B$ 是对角算子，在 $DX$ 的零方向上取恒等，在原点附近取零。小坐标球上用逐坐标反正弦取截面，拉回后正好得到 $h$。应用环面定理得到局部等距浸入，再把每个欧氏坐标等距绕到一个圆上，使局部映射 $f_i$ 落在半径 $\rho$ 的球面。此时 $\langle f_i,df_i\rangle=0$，故

$$
(\phi_i f_i)^*e=\phi_i^2h+\rho^2\,d\phi_i\otimes d\phi_i.
$$

把各局部映射乘权重后延零，与 $w$ 一起取正交直和。该公式保证总拉回严格等于 $g$。球面绕映射与平方分片统一对低阶和高阶共用。

周期延拓的 Hölder 估计只用有界映射的双线性乘积。令 $A=DX$，则延拓的系数是 $h(X)(A\cdot,A\cdot)+B^*e$。对 $C^{0,a}$ 输入，$h\circ X$ 由 $X$ 的 Lipschitz 界继承指数 $a$。对 $C^{1,a}$ 输入，$D(h\circ X)=(Dh)(X) A$；用相同估计处理乘积，再对 $h(X)(A\cdot,A\cdot)+B^*e$ 用乘积法则。周期光滑因子的有界性及 Lipschitz 界来自环面的紧致性。拉回小球时，用反正弦截面的光滑性和链式法则保留浸入的 Hölder 指数。

## 3. 环面低阶等距浸入

设 $r\in(0,2)$ 且度量满足 (2) 的估计。令 $\theta=r/2$。从以下三项得到闭流形定理 1.1 所用的环面版本。

当 $r=0$ 时，亏量仍按几何级数衰减。每一步先把截断半径选大，使连续度量的一致截断误差小于下一步亏量的固定倍数；再取充分大的载波频率，使单步误差中含频率倒数的项达到同一精度。剩下的法向投影误差由初始亏量足够小控制。用一个目标坐标块即可迭代，修正和修正的微分都按几何级数求和。

### 3.1 极限

- **3.1a 函数和导数。** $\|v_j\|_\infty\lesssim\sqrt{\delta_j}/\lambda_{j+1}$ 及 $\|Dv_j\|_\infty\lesssim\sqrt{\delta_j}$ 各自可被几何级数控制。在导数级数上用 `hasFDerivAt_tsum`。周期等式由逐项相等保留，再通过 `torusProjection_openQuotient` 下降。
- **3.1b 正好取到指数。** 用 (1) 得 $\|D^2v_j\|_\infty\lesssim\lambda_{j+1}\sqrt{\delta_j}$。沿线段积分得到每项的 Lipschitz 界。`holder_tsum_of_geometric` 处理 $Dv_j$ 级数。初值为三角多项式，$Du_0$ 有界且 Lipschitz，按距离是否至多 $1$ 得 Hölder 界。
- **3.1c 逐点等距。** (6) 给出 Gram 收敛到 $g$。对每个固定点、两个切向量，使用 `inner_of_tendsto_differentials`。因 $g$ 正定，极限微分单射。

### 3.2 构造全部修正

- **3.2a 数值参数。** $\eta=(1+\theta)/2$ 给 $2\eta-r=1-\theta>0$。用 Archimedean 性取正整数 $B$，使 $B(1-\theta)>r$。固定目标维数及常数后，用负幂趋零选择整数 $L\ge2$，使两个误差幂之和可吸收。再选 $\delta_0$，同时控制总梯度偏离和其平方对 (9) 的贡献。最后选 $\lambda_0$，接受初值的频带和二阶导数，以及 (2) 的误差。
- **3.2b 初值。** 先固定 $\rho>0$ 使 $g-\rho I$ 正定，用有限整数方向的平方振幅和 $R$ 一致逼近它。将 $g-\delta_0 I-R$ 除以 $\rho-\delta_0$ 后接近 $I$，故可用 5.2 精确分解。截断振幅并取圆对，再把圆对连同一阶导数一起截断，得到三角多项式 $u_*$。目标维数在选 $\delta_0$ 和误差前已经固定。将 $u_*$ 除以 $\sqrt B$ 并预留正交坐标，得到 `TorusMetric.exists_initialBlock`。
- **3.2c 记录更新。** 用乘积指标 `Fin B × Fin q` 表示固定的目标坐标。第 $i$ 步所在块是 $i\bmod B$。同块且 $i<j$ 蕴含 $i\le j-B$。对这些过去修正用 Bernstein，将二阶导数界按 $L^{i(1-\theta)}$ 作有限几何和。对 $j<B$，当前块尚未改动，直接使用初值的二阶导数界。得到 (7)。普通的 $C\lambda_j$ 频带界只用所有过去步的最大频率。
- **3.2d 选单步的 $E$。** 令 $E=S_{\Lambda_j}g-P(u_j)-\delta_{j+1}I$。由 (6)、(2) 得
$\|E/\delta_j-I\|\le\varepsilon+(1+\varepsilon/2)L^{-r}$。乘积的频带支集加和给出 $E$ 的频带。先证明 $\Lambda_j^{-r}/\delta_{j+1}=\lambda_0^{-r}L^{r\eta}/\delta_0$，使粗糙度量的截断误差与步号无关。
- **3.2e 关闭归纳。** 每次将 3.3 应用于当前块，延长满足归纳条件的有限修正序列。更新只在该块，其他块在 Gram 差中相消。把该步的相对误差乘回 $\delta_j$，和 (2) 的误差相加，得到 (6) 在下一步的界。累加梯度界保持与初始梯度的偏离小。

Lean 中可以用 `exists_sequence_of_prefix_extension` 直接逐次延长满足归纳不变量的有限修正序列。初始块给出的梯度界记为 $\sigma_0,M_0$。以 $\sigma_0/2,M_0+1$ 调用 `exists_lowIterationStep`，记其误差常数为 $K$。令

$$
C_u=\frac{K}{1-2^{-\theta}},\qquad
C_d=1+K\frac{2^{1-\theta}}{2^{1-\theta}-1}.
$$

轮换归纳用 $C_u\sqrt{\delta_0}$ 控制各块的总梯度偏离，用 $C_d\lambda_{j+1}\sqrt{\delta_j}\,L^{-B(1-\theta)}$ 控制当前块的梯度导数。两个常数都可在选择 $L$ 之前固定。初始频率 $\lambda_0$ 最后选择，既要接受初始块的频带和 Hessian，又要使 $K_g\lambda_0^{-2\theta}L^{2\theta\eta}$ 至多为 $\varepsilon\delta_0/2$。用这个不等式和 `smoothingScale_rpow` 控制每一步的度量截断误差。最后将扰动零填充到它所更新的块，在 `LowIterationLimit` 中取直和极限。

### 3.3 当前块上的局部引理

输入 $F=Du_{\rm act}$、初始块梯度 $F_0$ 和固定子空间 $Z$，使 $F_0^\mathsf T|_Z=0$。给定 $F$ 的统一上下界，频带 $\le C\Lambda$ 的 $F,E$，$E/\delta$ 近 $I$，整数 $\lambda$，以及 $1\le\Lambda\le\lambda$、$0<\delta\le1$。输出该块中的 $v$、频带 $\le 2c_*\lambda$、$\|v\|_\infty\lesssim\sqrt\delta/\lambda$、$\|Dv\|_\infty\lesssim\sqrt\delta$，以及

$$
\delta^{-1}\|P(u+v)-P(u)-E\|_\infty
\lesssim (\Lambda/\lambda)^2+
\|DF\|_\infty/(\lambda\sqrt\delta)+\|F-F_0\|_\infty^2.
$$

1. **投影的代数。** 从 $F^\mathsf T F$ 的正定性得到逆。展开 $Q=F(F^\mathsf T F)^{-1}F^\mathsf T$，证明对称、幂等及 $(I-Q)F=0$。在 $Z$ 上把 $F^\mathsf T$ 换成 $(F-F_0)^\mathsf T$，得 (8)。
2. **投影导数。** 伴随矩阵是多项式，$\det(F^\mathsf T F)$ 有统一正下界。用乘积及求逆链式法则得到前两阶对于 $F$ 的导数界。再代入 (1)，得空间的 $\|D^s(I-Q)\|_\infty\lesssim\Lambda^s$，$s=1,2$。同时保留更好的 $\|DQ\|_\infty\lesssim\|DF\|_\infty$ 给下面的 Gram 误差用。
3. **固定圆对。** 用 5.2 取 $E=\sum_\ell a_\ell^2\,\xi_\ell\otimes\xi_\ell$。用 5.1 得 $W$，列出振幅、梯度与 Gram 误差三个界。设 $V=(I-Q)W$。展开导数，使用
$( (I-Q)DW)^{\mathsf T}( (I-Q)DW)=P(W)-(QDW)^{\mathsf T}QDW$。
由于 $DW$ 仍取值于 $Z$，误差由 (8) 的平方控制。乘积中含 $DQ$ 的项用 $\|DF\|_\infty/\lambda$。
4. **截断整个修正。** 对正弦和余弦乘上 $a_\ell(I-Q)e$，其二阶导数由 $C\sqrt\delta\Lambda^2$ 控制。选一个固定的 $c_*$ 使载频位于乘子的平坦区。分别截断求导振荡和求导振幅的项，用 (5) 给 $\|Dv-DV\|_\infty\lesssim\sqrt\delta(\Lambda/\lambda)^2$。
5. **切向交叉项。** 用 $p\cdot V=0$ 微分，再把 $p\cdot S_{c_*\lambda}DV$ 加减 $S_{c_*\lambda}(p\cdot DV)$。分别用交换子 (4) 和截断的 $L^\infty$ 有界性。最后，单独展开 $P(u+v)$，将线性项和二次项合并。由 $\delta\le1$ 吸收二次项中的 $\delta\|DF\|_\infty/\lambda$。

## 4. 截断引理的末端

1. **核和矩。** 取欧氏光滑 bump，和它在原点反射后的函数平均，得到偶的 $\chi$，在单位球为 $1$，在半径 $2$ 的球外为 $0$。Schwartz Fourier 反演得到 $K$。由逆变换的积分表达式和 $\chi$ 的偶性可取实值核。缩放核的绝对矩通过变量替换得到 $\int |K_\lambda(y)||y|^r\,dy=\lambda^{-r}\int |K(y)||y|^r\,dy$。卷积的有界性由核的零阶绝对矩直接给出。
2. **频带。** 验证 $S_\lambda c_\xi=\chi(\xi/\lambda)c_\xi$。有限 Fourier 和由 `mFourierCoeff` 表示，固定 $\lambda$ 时是有界线性算子。由 `span_mFourier_closure_eq_top` 与两个算子的连续性推广到所有连续周期函数。频带的导数不增加支集，乘积用 `mFourier_add` 相加支集。再生公式后对核求导，给 (1)。
3. **消失矩和 Taylor。** 质量是乘子在 $0$ 的值，正阶矩用 `iteratedFDeriv_fourier` 在 $0$ 的式子。低阶首先证明 $C^{0,a}$ 的点差余项，再证明 $C^{1,a}$ 的一阶积分余项，分别给 (2)。将同一论证用于乘子在 $\xi$ 附近平坦的调制核，得到 (5)。高阶用 $\Delta_j$ 的核，在原点处连零阶矩也消失，Taylor 展到所需阶数即可。
4. **两种卷积差。** 在交换子的积分里保留 $p(x)-p(x-y)$，给 (4)。在 $D^sK_\lambda*a$ 中减去 $a(x)$，用 $\int D^sK_\lambda=0$ 和 $a$ 的 Hölder 差，给 (3)。

## 5. 固定圆对的末端

- **5.1 一对坐标。** 对任意切向量 $v$，直接写出
$D(a\sin t,a\cos t)v=Da(v)(\sin t,\cos t)+aDt(v)(\cos t,-\sin t)$。
两个向量的内积为零，范数均为 $1$。再对两个切向量取内积，得到 $da\otimes da+a^2 dt\otimes dt$，乘上归一化因子并取有限直和。
- **5.2 单位矩阵附近。** 取 $e_i$、$e_i\pm e_h$。逐个矩阵元检查第 4 节给出的正系数分解。对角线上每一对抵消掉 $2c\delta$，非对角线的两符号项给 $E_{ih}$。选择例如 $c=1/(8n)$ 及足够小的锥邻域。对每个正系数用平方根链式法则，再用 Bernstein 控制 $Da,D^2a$。
- **5.3 统一有限方向。** 给定紧正定矩阵范围，对每个中心 $Q$ 取可逆有理 $R$ 近 $Q^{1/2}$。把 5.2 施于 $R^{-1}GR^{-\mathsf T}$，乘回 $R$ 后清分母。有限子覆盖上取光滑 bump，平方归一化，再乘各自的平方根振幅。每个振幅在相应开集外用零延拓。由 5.1 的 $N^{-2}$ 余项给光滑 Gram 逼近，由 4 的截断给三角多项式逼近。所有覆盖都在矩阵空间中，方向的数目只由预先固定的范围决定。

低阶初值只要求 Gram 型在一致范数中逼近。有限子覆盖可用到各开集补集的距离归一化，得到连续的分片统一。将这些权重与对应的非负系数相乘再开平方，得到连续振幅。先用 Fourier 截断一致逼近振幅，再选载波频率 $N$ 压低圆对的振幅导数误差。此处所需的方向数仍只依赖紧正定矩阵范围。高阶初值保留 5.3 的光滑分片统一。

## 6. 环面高阶等距浸入（文献背景及证明参考）

目标 $g\in C^{k,1}$，$m=k+1\ge3$。固定 $\gamma=1/2$ 即可。

### 6.1 从整体度量到小残差

选自由 $f$ 且缩放到 $g-P(f)>0$。将 $g-P(f)$ 在 $C^{2,\gamma}$ 中平滑逼近，再由 5.3 构造光滑映射 $u$ 使 $h=g-P(f)-P(u)$ 在这个范数中小。对 $f$ 应用 6.2，最后把结果与 $u$ 取直和。

自由 $f$ 及其右逆分三步。先在每个 $2\pi x_i$ 的圆对取切向和径向，分别检出一阶与二阶对角系数。再在 $2\pi(x_i+x_h)$ 的圆对取径向，检出混合系数。这样只需要在 $0$ 处取一次线性右逆 $A_0$。最后令 $O(x)$ 是各圆对旋转的直和，验证 $f_i(x)=O(x)f_i(0)$ 与 $f_{ih}(x)=O(x)f_{ih}(0)$。由 $O(x)$ 保持内积得点态右逆 $O(x)A_0$。系数的光滑性来自三角函数，整步无需对依赖 $x$ 的矩阵求逆。

### 6.2 小残差修正的极限

1. **平滑输入。** $h_j=S_jh$。用卷积的 $L^1$ 界保持低范数小。对 $D^kh$ 的差商，先把差分移入卷积，再用其 Lipschitz 界，得到 $\sup_j\|h_j\|_{C^{k+1}}<\infty$。用 $\|\Delta_j D^2 h\|_\infty\lesssim2^{-j}\|h\|_{C^{2,1}}$，随后用 Bernstein 的导数界，按短距离和长距离分开，得到 $C^{2,\gamma}$ 下可求和的相邻差。
2. **递推。** 从零开始按 (14) 构造光滑 $w_j$。用 6.3 的低阶双线性界推出球不变与相邻差递推。对递推作有限求和，得相邻差可求和。用高阶估计 (13) 作几何归纳，得 $C^{k+1}$ 一致有界。各个常数可以依赖 $f,k$；小球足够小以后再选择 $h$。
3. **极限和正则性。** 从 $C^2$ 收敛开始，对两个迭代的差及各阶导数，沿单位方向写一阶有限差商，并用二阶 Taylor 余项。先固定足够小的差分步长，再取迭代指标充分大，逐阶证明导数一致 Cauchy。用 `hasFDerivAt_of_tendstoUniformly` 识别导数。对 $D^k w_j$ 用最高阶导数界得到 Lipschitz 不等式，取极限即可。
4. **度量。** 对 (14) 逐项微分，并用 (11) 得 $DP_f(w_{j+1})+P(w_j)=h_j$。左边只含一阶导数，故直接取极限。无需对粗糙函数定义 $U,R$。

### 6.3 两个估计的末端

- **代数恒等式。** 展开 $S_j a S_j b-S_{j-1}a S_{j-1}b$，用有限望远镜和证明 (10)。对 $P(S_jv)-P(S_{j-1}v)$ 使用乘积法则，把两项混合积移入 $DU$，剩下 (11) 的 $R$。
- **低范数。** 用 4 的矩和 Taylor 得 (12) 的 Hölder 版本。低频 $D^d S_{j-1}v$ 一致有界。分别对一低一高、两个高频增量的乘积估计零阶范数，给 $2^{-j(2+\gamma)}$ 和 $2^{-2j(1+\gamma)}$。由支集加和及 Bernstein 给二阶、三阶界。归到 3.1b 的几何级数。两个函数做因子时，每个界是对应低范数的乘积。
- **高范数。** 求 $\ell\le m$ 阶偏导。至少一个导数落在低频上的每项，用 (3) 和 (12) 相乘，剩 $2^{-j(m-\ell+\gamma)}$。全部落在高频的和，由 (10) 写成 $aD^\ell v-\sum_j(\Delta_ja)S_jD^\ell v$。对后一项只用 $\|\Delta_ja\|_\infty\lesssim2^{-j\gamma}\|a\|_{C^\gamma}$。两个增量相乘的项用一次低范数界、一次高范数界，再用 Bernstein 控制整体导数。三个求和给 (13)。

## 7. 构建检查

已检查两条低阶输入类在任意维数环面上的浸入定理和在任意闭流形上的嵌入定理，包括连续度量。四条定理的一般签名、闭曲面特化和公理检查都在 [Audit.lean](Audit.lean)。

`LowTorusEndpoints.lean` 中有两族低阶的环面定理，`ContinuousTorusEndpoint.lean` 另有连续度量的环面定理。`LocalIsometricImmersion.lean` 应用正定周期延拓，在坐标球上得到所有低阶存在性。`ManifoldLowAssembly.lean` 在有限图册上统一选择缩放参数，把调整后度量的局部解接到平方权重的正交拼接，再用线性等距同构转入 $\mathbb R^N$。`ManifoldLowEndpoints.lean` 导出两个临界指数和两个零指数的最终定理。
