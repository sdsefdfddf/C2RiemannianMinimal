import BlockRotation
import FourierSupportAlgebra
import Mathlib.Analysis.SpecificLimits.Basic

namespace IsometricEmbeddingEndpoints

open Finset

noncomputable section

variable {d H : Type*} [Fintype d] [NormedAddCommGroup H] [NormedSpace ℝ H]

/-- A property of finite histories that can always be extended holds on every
prefix of a single infinite history. -/
theorem exists_sequence_of_prefix_extension {X : Type*} (P : (n : ℕ) → (Fin n → X) → Prop)
    (h₀ : P 0 Fin.elim0)
    (hstep : ∀ n (a : Fin n → X), P n a → ∃ b : X, P (n + 1) (Fin.snoc a b)) :
    ∃ a : ℕ → X, ∀ n, P n (fun i => a i) := by
  let next (n : ℕ) (a : {a : Fin n → X // P n a}) : {a : Fin (n + 1) → X // P (n + 1) a} :=
    ⟨Fin.snoc a.val (Classical.choose (hstep n a.val a.property)), Classical.choose_spec (hstep n a.val a.property)⟩
  let history : (n : ℕ) → {a : Fin n → X // P n a} :=
    Nat.rec ⟨Fin.elim0, h₀⟩ next
  let a := fun n => (history (n + 1)).val (Fin.last n)
  refine ⟨a, fun n => ?_⟩
  have hmatch (n : ℕ) : ∀ i : Fin n, (history n).val i = a i := by
    induction n with
    | zero => intro i; exact Fin.elim0 i
    | succ n ih =>
        intro i
        refine Fin.lastCases ?_ (fun j => ?_) i
        · rfl
        · change (next n (history n)).val j.castSucc = a j
          dsimp only [next]
          rw [Fin.snoc_castSucc]
          exact ih j
  rw [← funext (hmatch n)]
  exact (history n).property

/-- The differential of a block after the previously assigned corrections. -/
def iteratedBlock (F₀ : C(UnitAddTorus d, Cover d →L[ℝ] H))
    (D : ℕ → C(UnitAddTorus d, Cover d →L[ℝ] H)) (B j b : ℕ) :
    C(UnitAddTorus d, Cover d →L[ℝ] H) :=
  F₀ + ∑ i ∈ earlierBlockSteps B j b, D i

def activeBlock {B : ℕ} (hB : 0 < B) (j : ℕ) : Fin B :=
  ⟨j % B, Nat.mod_lt _ hB⟩

omit [Fintype d] in
theorem iteratedBlock_succ (F₀ : C(UnitAddTorus d, Cover d →L[ℝ] H))
    (D : ℕ → C(UnitAddTorus d, Cover d →L[ℝ] H)) {B : ℕ} (hB : 0 < B) (j : ℕ) :
    (fun b : Fin B => iteratedBlock F₀ D B (j + 1) b) =
      Function.update (fun b : Fin B => iteratedBlock F₀ D B j b) (activeBlock hB j)
        (iteratedBlock F₀ D B j (activeBlock hB j) + D j) := by
  funext b
  have hstep := add_blocks_succ (fun _ => F₀) D B j b
  by_cases hb : b = activeBlock hB j
  · subst b
    rw [Function.update_self]
    simpa [iteratedBlock, activeBlock] using hstep
  · rw [Function.update_of_ne hb]
    have hb' : j % B ≠ (b : ℕ) := fun h => hb (Fin.ext h.symm)
    simpa [iteratedBlock, hb'] using hstep

theorem hasFourierSupport_iteratedBlock {band : Set (d → ℤ)}
    (F₀ : C(UnitAddTorus d, Cover d →L[ℝ] H))
    (D : ℕ → C(UnitAddTorus d, Cover d →L[ℝ] H)) (B j b : ℕ)
    (hF₀ : HasFourierSupport band F₀) (hD : ∀ i < j, HasFourierSupport band (D i)) :
    HasFourierSupport band (iteratedBlock F₀ D B j b) :=
  hF₀.add (hasFourierSupport_sum _ D (fun i hi => hD i (mem_range.1 (mem_filter.1 hi).1)))

theorem norm_iteratedBlock_sub_initial_le
    (F₀ : C(UnitAddTorus d, Cover d →L[ℝ] H))
    (D : ℕ → C(UnitAddTorus d, Cover d →L[ℝ] H)) (B j b : ℕ) {C q : ℝ}
    (hC : 0 ≤ C) (hq₀ : 0 ≤ q) (hq₁ : q < 1) (hD : ∀ i < j, ‖D i‖ ≤ C * q ^ i) :
    ‖iteratedBlock F₀ D B j b - F₀‖ ≤ C * (1 - q)⁻¹ := by
  rw [iteratedBlock, add_sub_cancel_left]
  calc
    _ ≤ ∑ i ∈ earlierBlockSteps B j b, ‖D i‖ := norm_sum_le (earlierBlockSteps B j b) D
    _ ≤ ∑ i ∈ earlierBlockSteps B j b, C * q ^ i := by
      apply sum_le_sum
      intro i hi
      have hij : i < j := mem_range.1 (mem_filter.1 hi).1
      exact hD i hij
    _ = C * ∑ i ∈ earlierBlockSteps B j b, q ^ i := by rw [Finset.mul_sum]
    _ ≤ _ := by
      apply mul_le_mul_of_nonneg_left _ hC
      rw [← tsum_geometric_of_lt_one hq₀ hq₁]
      exact (summable_geometric_of_lt_one hq₀ hq₁).sum_le_tsum _ (fun i _ => pow_nonneg hq₀ i)

/-- Differentiating a block uses only its own earlier corrections. The last
possible correction is at least a whole cycle in the past. -/
theorem norm_fderiv_iteratedBlock_active_le
    (F₀ : C(UnitAddTorus d, Cover d →L[ℝ] H))
    (D : ℕ → C(UnitAddTorus d, Cover d →L[ℝ] H)) (B j : ℕ) (x : Cover d) {C q : ℝ}
    (hq : 1 < q) (hC : 0 ≤ C)
    (hF₀ : DifferentiableAt ℝ (fun z => F₀ (flatProjection z)) x)
    (hd : ∀ i < j, DifferentiableAt ℝ (fun z => D i (flatProjection z)) x)
    (hD : ∀ i < j, ‖fderiv ℝ (fun z => D i (flatProjection z)) x‖ ≤ C * q ^ i) :
    ‖fderiv ℝ (fun z => iteratedBlock F₀ D B j (j % B) (flatProjection z)) x‖ ≤
      ‖fderiv ℝ (fun z => F₀ (flatProjection z)) x‖ + C * ((q / (q - 1)) * (q ^ j / q ^ B)) := by
  let s := earlierBlockSteps B j (j % B)
  let A := fun i : ℕ => fderiv ℝ (fun z => D i (flatProjection z)) x
  have hi (i : ℕ) (hi : i ∈ s) : HasFDerivAt (fun z => D i (flatProjection z)) (A i) x :=
    (hd i (mem_range.1 (mem_filter.1 hi).1)).hasFDerivAt
  have hsum := hF₀.hasFDerivAt.add (HasFDerivAt.sum hi)
  have heq : (fun z => iteratedBlock F₀ D B j (j % B) (flatProjection z)) =
      (fun z => F₀ (flatProjection z) + ∑ i ∈ s, D i (flatProjection z)) := by
    funext z
    simp only [iteratedBlock, ContinuousMap.add_apply, ContinuousMap.coe_sum, Finset.sum_apply, s]
  have hderiv : HasFDerivAt (fun z => F₀ (flatProjection z) + ∑ i ∈ s, D i (flatProjection z))
      ((fderiv ℝ (fun z => F₀ (flatProjection z)) x) + ∑ i ∈ s, A i) x := by
    convert hsum using 1
    funext z
    simp only [Pi.add_apply, Finset.sum_apply]
  rw [heq, hderiv.fderiv]
  refine (norm_add_le (fderiv ℝ (fun z => F₀ (flatProjection z)) x) (∑ i ∈ s, A i)).trans
    (add_le_add le_rfl ?_)
  calc
    ‖∑ i ∈ s, A i‖ ≤ ∑ i ∈ s, ‖A i‖ := norm_sum_le s A
    _ ≤ ∑ i ∈ s, C * q ^ i := sum_le_sum fun i hi => hD i (mem_range.1 (mem_filter.1 hi).1)
    _ = C * ∑ i ∈ s, q ^ i := by rw [Finset.mul_sum]
    _ ≤ _ := mul_le_mul_of_nonneg_left (sum_currentBlockSteps_pow_le hq B j) hC

end

end IsometricEmbeddingEndpoints

#print axioms IsometricEmbeddingEndpoints.norm_fderiv_iteratedBlock_active_le
