import ClosedManifoldEndpoints

open scoped ContDiff ENNReal Manifold NNReal Topology
open IsometricEmbeddingEndpoints Set

#check exists_holder_isometricEmbedding
#check exists_holderDifferential_isometricEmbedding

#print Euclidean
#print metricInChart
#print HolderInCharts
#print HolderDifferentialInCharts
#print IsC1IsometricEmbedding
#print IsHolderIsometricEmbedding

private theorem locally_holder_zero {X Y : Type*} [PseudoMetricSpace X] [ProperSpace X]
    [PseudoMetricSpace Y] {x : X} {s : Set X} {f : X → Y}
    (hs : s ∈ 𝓝 x) (hf : ContinuousOn f s) :
    ∃ C : ℝ≥0, ∃ t ∈ 𝓝 x, HolderOnWith C 0 f t := by
  obtain ⟨r, hr, hball⟩ := Metric.nhds_basis_closedBall.mem_iff.mp hs
  have hB := ((isCompact_closedBall x r).image_of_continuousOn (hf.mono hball)).isBounded
  let D := Metric.ediam (f '' Metric.closedBall x r)
  have hD : D ≠ ⊤ := hB.ediam_ne_top
  refine ⟨D.toNNReal, Metric.closedBall x r, Metric.closedBall_mem_nhds x hr, ?_⟩
  intro y hy z hz
  simpa only [NNReal.coe_zero, ENNReal.rpow_zero, mul_one,
    ENNReal.coe_toNNReal hD] using
      Metric.edist_le_ediam_of_mem (mem_image_of_mem f hy) (mem_image_of_mem f hz)

section ClosedSurface

variable {M : Type*} [TopologicalSpace M] [T2Space M] [CompactSpace M]
  [ChartedSpace (Euclidean 2) M] [IsManifold 𝓘(ℝ, Euclidean 2) ∞ M]

local notation "𝓔" d:arg => 𝓘(ℝ, Euclidean d)
local notation "T" M:arg => TangentSpace (𝓔 2) (M := M)

example (g : Bundle.ContinuousRiemannianMetric (Euclidean 2) (T M)) :
    ∃ (N : ℕ) (u : M → Euclidean N), IsC1IsometricEmbedding g.toRiemannianMetric u := by
  obtain ⟨N, u, hu⟩ := exists_holder_isometricEmbedding (a := 0) g (by simp)
    (fun p => locally_holder_zero
      ((isOpen_extChartAt_target (I := 𝓔 2) p).mem_nhds (mem_extChartAt_target p))
      (metricInChart_continuousOn g p))
  exact ⟨N, u, hu.1⟩

example (g : Bundle.ContinuousRiemannianMetric (Euclidean 2) (T M))
    (hg : ∀ p, ∃ C : ℝ≥0, ∃ s ∈ 𝓝 (extChartAt (𝓔 2) p p),
      LipschitzOnWith C (metricInChart g.toRiemannianMetric p) s) :
    ∃ (N : ℕ) (u : M → Euclidean N), IsHolderIsometricEmbedding g.toRiemannianMetric (1 / 2) u := by
  apply exists_holder_isometricEmbedding (a := 1) g le_rfl
  intro p
  obtain ⟨C, s, hs, hL⟩ := hg p
  exact ⟨C, s, hs, hL.holderOnWith⟩

example (g : Bundle.ContMDiffRiemannianMetric (𝓔 2) 1 (Euclidean 2) (T M)) :
    ∃ (N : ℕ) (u : M → Euclidean N), IsHolderIsometricEmbedding g.toRiemannianMetric (1 / 2) u := by
  have hg : HolderDifferentialInCharts 0 (metricInChart g.toRiemannianMetric) := fun p => by
    have h := (metricInChart_contDiffAt g p).eventually (by simp)
    apply locally_holder_zero h
    intro x hx
    change ContDiffAt ℝ 1 (metricInChart g.toRiemannianMetric p) x at hx
    exact (hx.continuousAt_fderiv one_ne_zero).continuousWithinAt
  simpa only [add_zero] using
    exists_holderDifferential_isometricEmbedding (a := 0) g (by simp) hg

end ClosedSurface

#print axioms exists_holder_isometricEmbedding
#print axioms exists_holderDifferential_isometricEmbedding
