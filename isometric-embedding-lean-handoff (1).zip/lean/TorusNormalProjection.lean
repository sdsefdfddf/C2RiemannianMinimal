import ProjectionRegularity
import TorusLifts

namespace IsometricEmbeddingEndpoints

open ContinuousLinearMap

noncomputable section

variable {d H : Type*} [Fintype d] [NormedAddCommGroup H] [InnerProductSpace ℝ H] [CompleteSpace H]

/-- The range projections of a uniformly injective field of differentials on the torus. -/
def torusTangentProjection (F : C(UnitAddTorus d, Cover d →L[ℝ] H))
    {σ : ℝ} (hσ : 0 < σ) (hF : ∀ t v, σ * ‖v‖ ≤ ‖F t v‖) :
    C(UnitAddTorus d, H →L[ℝ] H) :=
  ⟨fun t => tangentProjection (F t), continuous_iff_continuousAt.2 fun t =>
    ((contDiffAt_tangentProjection (n := 1) hσ (hF t)).continuousAt).comp
      F.continuous.continuousAt⟩

@[simp] theorem torusTangentProjection_apply (F : C(UnitAddTorus d, Cover d →L[ℝ] H))
    {σ : ℝ} (hσ : 0 < σ) (hF : ∀ t v, σ * ‖v‖ ≤ ‖F t v‖) (t : UnitAddTorus d) :
    torusTangentProjection F hσ hF t = tangentProjection (F t) := rfl

theorem contDiff_torusTangentProjection_lift (F : C(UnitAddTorus d, Cover d →L[ℝ] H))
    {σ : ℝ} (hσ : 0 < σ) (hF : ∀ t v, σ * ‖v‖ ≤ ‖F t v‖) {k : WithTop ℕ∞}
    (hd : ContDiff ℝ k (fun z => F (flatProjection z))) :
    ContDiff ℝ k (fun z => torusTangentProjection F hσ hF (flatProjection z)) := by
  apply contDiff_iff_contDiffAt.2
  intro z
  change ContDiffAt ℝ k (tangentProjection ∘ fun y => F (flatProjection y)) z
  exact (contDiffAt_tangentProjection hσ (hF (flatProjection z))).comp z hd.contDiffAt

/-- The tangent projection of a differential in the initially unused coordinates. -/
theorem norm_torusTangentProjection_comp_le
    (F F₀ : C(UnitAddTorus d, Cover d →L[ℝ] H)) {σ : ℝ}
    (hσ : 0 < σ) (hF : ∀ t v, σ * ‖v‖ ≤ ‖F t v‖)
    (t : UnitAddTorus d) (W : Cover d →L[ℝ] H)
    (hn : ∀ v, (F₀ t).adjoint (W v) = 0) :
    ‖(torusTangentProjection F hσ hF t).comp W‖ ≤
      ‖F‖ * (σ ^ 2)⁻¹ * ‖F - F₀‖ * ‖W‖ := by
  let B := ((F t).adjoint.comp (F t)).inverse
  have hB : ‖B‖ ≤ (σ ^ 2)⁻¹ := (gramInverse_properties (F t) hσ (hF t)).2.2
  have hsub : ‖F t - F₀ t‖ ≤ ‖F - F₀‖ := (F - F₀).norm_coe_le_norm t
  calc
    _ ≤ ‖F t‖ * ‖B‖ * ‖F t - F₀ t‖ * ‖W‖ := norm_rangeProjection_comp_le _ _ _ _ hn
    _ ≤ _ := by gcongr; exact F.norm_coe_le_norm t

/-- The fine first derivative bound and the bounds at the spatial scale used for amplitudes. -/
theorem exists_torusProjection_derivative_bounds [FiniteDimensional ℝ H]
    {σ : ℝ} (hσ : 0 < σ) (M : ℝ) :
    ∃ C : ℝ, 1 ≤ C ∧ ∀ (F : C(UnitAddTorus d, Cover d →L[ℝ] H))
      (hF : ∀ t v, σ * ‖v‖ ≤ ‖F t v‖) (Λ : ℝ), 0 ≤ Λ → ‖F‖ ≤ M →
      ContDiff ℝ 2 (fun z => F (flatProjection z)) →
      (∀ z i, 1 ≤ i → i ≤ 2 → ‖iteratedFDeriv ℝ i (fun y => F (flatProjection y)) z‖ ≤ Λ ^ i) →
      let Q := torusTangentProjection F hσ hF
      (∀ z, ‖fderiv ℝ (fun y => Q (flatProjection y)) z‖ ≤ C *
          ‖fderiv ℝ (fun y => F (flatProjection y)) z‖) ∧
      ∀ z j, j ≤ 2 →
        ‖iteratedFDeriv ℝ j (fun y => normalPart (Q (flatProjection y))) z‖ ≤ C * Λ ^ j := by
  obtain ⟨B, hB, hB'⟩ := exists_bound_fderiv_tangentProjection_comp
    (E := Cover d) (X := Cover d) (H := H) hσ M
  obtain ⟨A, hA, hA'⟩ := exists_bound_iteratedFDeriv_tangentProjection_comp
    (E := Cover d) (X := Cover d) (H := H) hσ M 2
  let C := 1 + B + 2 * A
  have hC : 1 ≤ C := by dsimp [C]; linarith
  have hBC : B ≤ C := by dsimp [C]; linarith
  have hAC : 2 * A ≤ C := by dsimp [C]; linarith
  refine ⟨C, hC, ?_⟩
  intro F hF Λ hΛ hFN hdiff hscale
  let f := fun z : Cover d => F (flatProjection z)
  let Q := torusTangentProjection F hσ hF
  have hfn (z : Cover d) : ‖f z‖ ≤ M := (F.norm_coe_le_norm _).trans hFN
  have hQ : ContDiff ℝ 2 (fun y => Q (flatProjection y)) :=
    contDiff_torusTangentProjection_lift F hσ hF hdiff
  refine ⟨fun z => ?_, fun z j hj => ?_⟩
  · exact (hB' f (hdiff.differentiable (by norm_num)) hfn (fun z => hF (flatProjection z)) z).trans
      (mul_le_mul_of_nonneg_right hBC (norm_nonneg (fderiv ℝ f z)))
  · change ‖iteratedFDeriv ℝ j (fun y => normalPart (Q (flatProjection y))) z‖ ≤ _
    by_cases hj₀ : j = 0
    · subst j
      rw [norm_iteratedFDeriv_zero, pow_zero, mul_one]
      obtain ⟨hsym, hidem, _⟩ := tangentProjection_properties (F (flatProjection z)) hσ (hF _)
      exact (opNorm_le_bound _ zero_le_one fun v => by
        rw [one_mul]
        exact norm_normalPart_apply_le _ hsym hidem v).trans hC
    · have hj' : (j : WithTop ℕ∞) ≤ 2 := by exact_mod_cast hj
      have hnorm :
          ‖iteratedFDeriv ℝ j (fun y => normalPart (Q (flatProjection y))) z‖ =
            ‖iteratedFDeriv ℝ j (fun y => Q (flatProjection y)) z‖ := by
        change ‖iteratedFDeriv ℝ j
          ((fun _ : Cover d => ContinuousLinearMap.id ℝ H) - fun y => Q (flatProjection y)) z‖ = _
        rw [iteratedFDeriv_sub contDiff_const (hQ.of_le hj'),
          iteratedFDeriv_const_of_ne hj₀, zero_sub, Pi.neg_apply, norm_neg]
      rw [hnorm]
      have hfact : (j.factorial : ℝ) ≤ 2 := by interval_cases j <;> norm_num
      refine (hA' f Λ hdiff hfn (fun y => hF (flatProjection y)) z j hj
        (fun i hi hij => hscale z i hi (hij.trans hj))).trans ?_
      exact mul_le_mul_of_nonneg_right
        ((mul_le_mul_of_nonneg_right hfact hA).trans hAC) (pow_nonneg hΛ _)

end

end IsometricEmbeddingEndpoints

#print axioms IsometricEmbeddingEndpoints.exists_torusProjection_derivative_bounds
