import Mathlib.Analysis.InnerProductSpace.PiL2
import Mathlib.Geometry.Manifold.ContMDiff.Constructions
import Mathlib.Geometry.Manifold.ContMDiff.NormedSpace
import Mathlib.Geometry.Manifold.MFDeriv.NormedSpace

open scoped ContDiff Manifold

namespace IsometricEmbeddingEndpoints

noncomputable section

variable {ι E H M : Type*} [Fintype ι]
  [NormedAddCommGroup E] [NormedSpace ℝ E] [TopologicalSpace H]
  {I : ModelWithCorners ℝ E H} [TopologicalSpace M] [ChartedSpace H M]
  {F : ι → Type*} [∀ i, NormedAddCommGroup (F i)] [∀ i, InnerProductSpace ℝ (F i)]

/-- The finite orthogonal direct sum of a family of maps. -/
def directSumMap (f : (i : ι) → M → F i) (x : M) : PiLp 2 F :=
  WithLp.toLp 2 (fun i => f i x)

theorem contMDiffAt_directSumMap {n : ℕ∞ω} {f : (i : ι) → M → F i} {p : M}
    (hf : ∀ i, ContMDiffAt I 𝓘(ℝ, F i) n (f i) p) :
    ContMDiffAt I 𝓘(ℝ, PiLp 2 F) n (directSumMap f) p := by
  let L := (PiLp.continuousLinearEquiv 2 ℝ F).symm.toContinuousLinearMap
  have h : ContMDiffAt I 𝓘(ℝ, (i : ι) → F i) n (fun (x : M) i => f i x) p :=
    contMDiffAt_pi_module_iff.mpr hf
  have hL : ContMDiffAt 𝓘(ℝ, (i : ι) → F i) 𝓘(ℝ, PiLp 2 F) n L
      (fun i => f i p) := L.contMDiffAt
  exact hL.comp p h

theorem inner_mvfderiv_directSumMap {f : (i : ι) → M → F i} {p : M}
    (hf : ∀ i, ContMDiffAt I 𝓘(ℝ, F i) 1 (f i) p) (v w : TangentSpace I p) :
    inner ℝ (mvfderiv I (directSumMap f) p v) (mvfderiv I (directSumMap f) p w) =
      ∑ i, inner ℝ (mvfderiv I (f i) p v) (mvfderiv I (f i) p w) := by
  have hU := (contMDiffAt_directSumMap hf).mdifferentiableAt one_ne_zero
  have he (i : ι) (z : TangentSpace I p) :
      mvfderiv I (directSumMap f) p z i = mvfderiv I (f i) p z := by
    let L : PiLp 2 F →L[ℝ] F i := PiLp.proj 2 F i
    have hd : HasMFDerivAt 𝓘(ℝ, PiLp 2 F) 𝓘(ℝ, F i) L (directSumMap f p) L :=
      L.hasFDerivAt.hasMFDerivAt
    have hcomp :
        mvfderiv I (L ∘ directSumMap f) p =
          L.comp (mvfderiv I (directSumMap f) p) := by
      rw [mvfderiv_comp p hd.mdifferentiableAt hU]
      exact congrArg (fun A => A.comp (mvfderiv I (directSumMap f) p)) hd.mfderiv
    exact (DFunLike.congr_fun hcomp z).symm
  rw [PiLp.inner_apply]
  exact Finset.sum_congr rfl (fun i _ => by rw [he i v, he i w])

theorem isEmbedding_directSumMap [CompactSpace M] {f : (i : ι) → M → F i}
    (hf : ∀ i p, ContMDiffAt I 𝓘(ℝ, F i) 1 (f i) p)
    (i : ι) (hinj : Function.Injective (f i)) : Topology.IsEmbedding (directSumMap f) := by
  have hc : Continuous (directSumMap f) := continuous_iff_continuousAt.mpr fun p =>
    (contMDiffAt_directSumMap (fun j => hf j p)).continuousAt
  have hj : Function.Injective (directSumMap f) := fun x y hxy =>
    hinj (congrArg (fun z : PiLp 2 F => z i) hxy)
  exact (hc.isClosedEmbedding hj).isEmbedding

end

end IsometricEmbeddingEndpoints

#print axioms IsometricEmbeddingEndpoints.inner_mvfderiv_directSumMap
