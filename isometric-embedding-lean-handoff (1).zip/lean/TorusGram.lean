import FourierSupportAlgebra
import TorusMetric
import Mathlib.Analysis.InnerProductSpace.Adjoint

namespace IsometricEmbeddingEndpoints

open ContinuousLinearMap
open scoped Pointwise

noncomputable section

variable {d H : Type*} [Fintype d] [NormedAddCommGroup H] [InnerProductSpace ℝ H] [CompleteSpace H]

local instance : NormedAddCommGroup (MetricForm d) := inferInstance
local instance : NormedSpace ℝ (MetricForm d) := inferInstance

/-- Pair two vector-valued differentials by the target inner product. -/
def differentialPairing :
    (Cover d →L[ℝ] H) →L[ℝ] (Cover d →L[ℝ] H) →L[ℝ] MetricForm d :=
  let E := Cover d
  let J := (compL ℝ E E (E →L[ℝ] ℝ)) (innerSL ℝ)
  let A := (ContinuousLinearMap.adjoint (𝕜 := ℝ) (E := E) (F := H)).toContinuousLinearEquiv
  (compL ℝ (E →L[ℝ] H) (E →L[ℝ] E) (MetricForm d) J).comp
    ((compL ℝ E H E).comp A.toContinuousLinearMap)

theorem differentialPairing_apply (F G : Cover d →L[ℝ] H) (v w : Cover d) :
    differentialPairing F G v w = inner ℝ (G v) (F w) := by
  change inner ℝ (F.adjoint (G v)) w = _
  exact F.adjoint_inner_left w (G v)

/-- The Gram form of a field of differentials on the torus. -/
def torusGram (F : C(UnitAddTorus d, Cover d →L[ℝ] H)) : C(UnitAddTorus d, MetricForm d) :=
  ⟨fun x => differentialPairing (F x) (F x),
    (differentialPairing.continuous.comp F.continuous).clm_apply F.continuous⟩

@[simp] theorem torusGram_apply (F : C(UnitAddTorus d, Cover d →L[ℝ] H))
    (x : UnitAddTorus d) (v w : Cover d) :
    torusGram F x v w = inner ℝ (F x v) (F x w) :=
  differentialPairing_apply _ _ _ _

theorem continuous_torusGram :
    Continuous (torusGram (d := d) (H := H)) := by
  apply ContinuousMap.continuous_of_continuous_uncurry
  exact (differentialPairing.continuous.comp continuous_eval).clm_apply continuous_eval

theorem HasFourierSupport.torusGram [FiniteDimensional ℝ H] {band : Set (d → ℤ)}
    {F : C(UnitAddTorus d, Cover d →L[ℝ] H)} (hF : HasFourierSupport band F) :
    HasFourierSupport (band + band) (torusGram F) :=
  hF.bilinear hF differentialPairing

theorem norm_metricForm_le_of_pointwise {B : MetricForm d} {M : ℝ} (hM : 0 ≤ M)
    (h : ∀ v w, |B v w| ≤ M * (‖v‖ * ‖w‖)) : ‖B‖ ≤ M := by
  refine B.opNorm_le_bound₂ hM fun v w => ?_
  rw [Real.norm_eq_abs, mul_assoc]
  exact h v w

/-- A pointwise bound in two tangent directions gives a uniform norm bound for the
metric defect appearing in the iteration. -/
theorem norm_torusGram_sub_le_of_pointwise (F : C(UnitAddTorus d, Cover d →L[ℝ] H))
    (g : C(UnitAddTorus d, MetricForm d)) {M : ℝ} (hM : 0 ≤ M)
    (h : ∀ x v w, |inner ℝ (F x v) (F x w) - g x v w| ≤ M * (‖v‖ * ‖w‖)) :
    ‖torusGram F - g‖ ≤ M := by
  apply (ContinuousMap.norm_le _ hM).mpr
  intro x
  apply norm_metricForm_le_of_pointwise hM
  intro v w
  simpa only [ContinuousMap.sub_apply, sub_apply, torusGram_apply] using h x v w

end

end IsometricEmbeddingEndpoints

#print axioms IsometricEmbeddingEndpoints.HasFourierSupport.torusGram
#print axioms IsometricEmbeddingEndpoints.norm_torusGram_sub_le_of_pointwise
