import FilteredTangent
import ModulatedWave

namespace IsometricEmbeddingEndpoints

open ContinuousLinearMap

noncomputable section

variable {d H : Type*} [Fintype d] [NormedAddCommGroup H] [InnerProductSpace ℝ H]

/-- Project a wave on the torus onto the normal space at each point. -/
def projectedWave (Q : C(UnitAddTorus d, H →L[ℝ] H)) (W : C(UnitAddTorus d, H)) :
    C(UnitAddTorus d, H) :=
  ⟨fun t => normalPart (Q t) (W t),
    (continuous_const.sub Q.continuous).clm_apply W.continuous⟩

theorem contDiff_projectedWave_lift (Q : C(UnitAddTorus d, H →L[ℝ] H)) (W : C(UnitAddTorus d, H))
    {k : WithTop ℕ∞} (hQ : ContDiff ℝ k (fun z => Q (flatProjection z)))
    (hW : ContDiff ℝ k (fun z => W (flatProjection z))) :
    ContDiff ℝ k (fun z => projectedWave Q W (flatProjection z)) :=
  (contDiff_const.sub hQ).clm_apply hW

private theorem norm_normalPart_comp_le {E : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E]
    (Q : H →L[ℝ] H) (hsym : ∀ x y, inner ℝ (Q x) y = inner ℝ x (Q y))
    (hidem : ∀ x, Q (Q x) = Q x) (D : E →L[ℝ] H) :
    ‖(normalPart Q).comp D‖ ≤ ‖D‖ :=
  opNorm_le_bound _ (norm_nonneg _) fun v =>
    (norm_normalPart_apply_le Q hsym hidem (D v)).trans (D.le_opNorm v)

variable [CompleteSpace H]

set_option maxHeartbeats 450000 in
/-- The Gram error of the actual Fourier-filtered normal correction. The input bounds
are for the unfiltered wave, the tangent projection and the differentiated cutoff;
the output separates the square of the frequency ratio, the rotation term and the
square of the projection on the initially unused coordinates. -/
theorem exists_bound_gram_filtered_projection_stage {C : ℝ} (hC : 0 ≤ C) :
    ∃ K : ℝ, 0 ≤ K ∧
      ∀ (F : C(UnitAddTorus d, Cover d →L[ℝ] H))
        (Q : C(UnitAddTorus d, H →L[ℝ] H)) (W : C(UnitAddTorus d, H))
        {s freq a b L τ : ℝ}, 0 < freq → freq ≤ s → 0 ≤ a → a ≤ 1 → 0 ≤ b → b ≤ 1 →
        0 ≤ L → L ≤ C * freq → 0 ≤ τ →
        ContDiff ℝ 1 (fun z => F (flatProjection z)) →
        ContDiff ℝ 1 (fun z => Q (flatProjection z)) →
        ContDiff ℝ 1 (fun z => W (flatProjection z)) →
        (∀ t v w, inner ℝ (Q t v) w = inner ℝ v (Q t w)) →
        (∀ t v, Q t (Q t v) = Q t v) →
        (∀ t v, Q t (F t v) = F t v) →
        (∀ x, ‖fderiv ℝ (fun z => F (flatProjection z)) x‖ ≤ L) →
        (∀ x, ‖fderiv ℝ (fun z => Q (flatProjection z)) x‖ ≤ C * L) →
        ‖W‖ ≤ C * a / freq →
        (∀ x, ‖fderiv ℝ (fun z => W (flatProjection z)) x‖ ≤ C * a) →
        (∀ x, ‖(Q (flatProjection x)).comp (fderiv ℝ (fun z => W (flatProjection z)) x)‖ ≤
          C * a * τ) →
        (∀ x, ‖fderiv ℝ (fun z => realTorusCutoff s (projectedWave Q W) (flatProjection z)) x -
          fderiv ℝ (fun z => projectedWave Q W (flatProjection z)) x‖ ≤ C * a * b) →
        let V := realTorusCutoff s (projectedWave Q W)
        ‖V‖ ≤ K * a / freq ∧
        (∀ x, ‖fderiv ℝ (fun z => V (flatProjection z)) x‖ ≤ K * a) ∧
        ∀ (x : Cover d) (metric : Cover d → Cover d → ℝ),
          (∀ v w, |inner ℝ (fderiv ℝ (fun z => W (flatProjection z)) x v)
            (fderiv ℝ (fun z => W (flatProjection z)) x w) - metric v w| ≤
              (C * a ^ 2 * b) * (‖v‖ * ‖w‖)) →
          ∀ v w,
            let D := fderiv ℝ (fun z => realTorusCutoff s (projectedWave Q W) (flatProjection z)) x
            let F₀ := F (flatProjection x)
            |inner ℝ ((F₀ + D) v) ((F₀ + D) w) - inner ℝ (F₀ v) (F₀ w) - metric v w| ≤
              (K * (a ^ 2 * b + a * L / freq + a ^ 2 * τ ^ 2)) * (‖v‖ * ‖w‖) := by
  let M₀ := torusCutoffMoment d 0
  let M₁ := torusCutoffMoment d 1
  have hM₀ : 0 ≤ M₀ := torusCutoffMoment_nonneg 0
  have hM₁ : 0 ≤ M₁ := torusCutoffMoment_nonneg 1
  let B := 3 * C + C ^ 3
  let J := (C + C ^ 3) * M₁ + C * M₀
  have hB : 0 ≤ B := by dsimp [B]; positivity
  have hJ : 0 ≤ J := by dsimp [J]; positivity
  let K := (B * C + C) + (2 * J + B * C ^ 2) + C ^ 2 + C * M₀ + B
  have hK : 0 ≤ K := by dsimp [K]; positivity
  refine ⟨K, hK, ?_⟩
  intro F Q W s freq a b L τ hfreq hfreqs ha ha₁ hb hb₁ hL hLfreq hτ hF hQ hW hsym hidem hfix
    hDF hDQ hW₀ hDW hangle hcut
  let P := projectedWave Q W
  let U := fun z : Cover d => fderiv ℝ (fun y => W (flatProjection y)) z
  let N := fun z : Cover d => (normalPart (Q (flatProjection z))).comp (U z)
  let dQ := fun z : Cover d => fderiv ℝ (fun y => Q (flatProjection y)) z
  let D := fun x : Cover d => fderiv ℝ (fun z => realTorusCutoff s P (flatProjection z)) x
  have hs : 0 < s := hfreq.trans_le hfreqs
  have hP := contDiff_projectedWave_lift Q W hQ hW
  let DP := torusDifferential P hP
  have hDP (z : Cover d) :
      HasFDerivAt (fun y => P (flatProjection y)) (DP (flatProjection z)) z := by
    rw [torusDifferential_apply]
    exact ((hP.differentiable one_ne_zero) z).hasFDerivAt
  have hDP_eq (z : Cover d) : DP (flatProjection z) =
      N z - (dQ z).flip (W (flatProjection z)) :=
    (hDP z).unique (hasFDerivAt_projectedWave
      ((hQ.differentiable one_ne_zero z).hasFDerivAt) ((hW.differentiable one_ne_zero z).hasFDerivAt))
  have hP₀ : ‖P‖ ≤ C * a / freq := by
    apply (ContinuousMap.norm_le _ (by positivity)).mpr
    intro t
    exact (norm_normalPart_apply_le (Q t) (hsym t) (hidem t) _).trans
      ((W.norm_coe_le_norm t).trans hW₀)
  have hN (z : Cover d) : ‖N z‖ ≤ C * a :=
    (norm_normalPart_comp_le (Q (flatProjection z)) (hsym _) (hidem _) _).trans (hDW z)
  have hQW (z : Cover d) : ‖(dQ z).flip (W (flatProjection z))‖ ≤ C ^ 2 * a * (L / freq) := by
    calc
      _ ≤ ‖dQ z‖ * ‖W (flatProjection z)‖ := by
        simpa only [opNorm_flip] using (le_opNorm (dQ z).flip (W (flatProjection z)))
      _ ≤ (C * L) * (C * a / freq) :=
        mul_le_mul (hDQ z) ((W.norm_coe_le_norm _).trans hW₀) (norm_nonneg _) (by positivity)
      _ = _ := by ring
  have hLratio : L / freq ≤ C := (div_le_iff₀ hfreq).mpr hLfreq
  have hDP₀ : ‖DP‖ ≤ (C + C ^ 3) * a := by
    apply (ContinuousMap.norm_le _ (by positivity)).mpr
    intro t
    obtain ⟨z, rfl⟩ := flatProjection_surjective t
    rw [hDP_eq]
    calc
      _ ≤ ‖N z‖ + ‖(dQ z).flip (W (flatProjection z))‖ := norm_sub_le _ _
      _ ≤ C * a + C ^ 2 * a * C := add_le_add (hN z)
        ((hQW z).trans (mul_le_mul_of_nonneg_left hLratio (by positivity)))
      _ = _ := by ring
  have hcut' (x : Cover d) : ‖D x - DP (flatProjection x)‖ ≤ C * a * b := by
    rw [torusDifferential_apply]
    exact hcut x
  have hD (x : Cover d) : ‖D x‖ ≤ (2 * C + C ^ 3) * a := by
    calc
      ‖D x‖ = ‖(D x - DP (flatProjection x)) + DP (flatProjection x)‖ := by rw [sub_add_cancel]
      _ ≤ ‖D x - DP (flatProjection x)‖ + ‖DP (flatProjection x)‖ := norm_add_le _ _
      _ ≤ C * a + (C + C ^ 3) * a := add_le_add
        ((hcut' x).trans (mul_le_of_le_one_right (mul_nonneg hC ha) hb₁))
        ((DP.norm_coe_le_norm _).trans hDP₀)
      _ = _ := by ring
  have hCM : C * M₀ ≤ K := by
    dsimp only [K]
    linarith [sq_nonneg C, mul_nonneg hB hC, mul_nonneg hB (sq_nonneg C)]
  have hBK : 2 * C + C ^ 3 ≤ K := by
    have hCB : 2 * C + C ^ 3 ≤ B := by dsimp only [B]; linarith
    exact hCB.trans (by
      dsimp only [K]
      linarith [sq_nonneg C, mul_nonneg hB hC, mul_nonneg hB (sq_nonneg C), mul_nonneg hC hM₀])
  refine ⟨?_, fun x => (hD x).trans (mul_le_mul_of_nonneg_right hBK ha), ?_⟩
  · calc
      ‖realTorusCutoff s P‖ ≤ ‖P‖ * M₀ := by
        simpa only [M₀, torusCutoffMoment, Real.rpow_zero, mul_one] using norm_realTorusCutoff_le hs P
      _ ≤ (C * a / freq) * M₀ := mul_le_mul_of_nonneg_right hP₀ hM₀
      _ = (C * M₀) * a / freq := by ring
      _ ≤ K * a / freq := by gcongr
  intro x metric hmetric v w
  have hDN : ‖D x - N x‖ ≤ C * a * b + C ^ 2 * a * (L / freq) := by
    calc
      _ = ‖(D x - DP (flatProjection x)) - (dQ x).flip (W (flatProjection x))‖ := by
        rw [hDP_eq]
        congr 1
        abel
      _ ≤ _ := (norm_sub_le _ _).trans (add_le_add (hcut' x) (hQW x))
  have hκ :
      (L * ‖DP‖) * (s⁻¹ * M₁) + (L * ‖P‖) * M₀ ≤ J * (a * L / freq) := by
    have hinv := inv_anti₀ hfreq hfreqs
    calc
      _ ≤ (L * ((C + C ^ 3) * a)) * (freq⁻¹ * M₁) + (L * (C * a / freq)) * M₀ := by
        apply add_le_add
        · exact mul_le_mul (mul_le_mul_of_nonneg_left hDP₀ hL)
            (mul_le_mul_of_nonneg_right hinv hM₁) (by positivity) (by positivity)
        · exact mul_le_mul_of_nonneg_right (mul_le_mul_of_nonneg_left hP₀ hL) hM₀
      _ = _ := by dsimp only [J]; ring
  have hnormal (t : UnitAddTorus d) (u : Cover d) : inner ℝ (F t u) (P t) = 0 := by
    change inner ℝ (F t u) (normalPart (Q t) (W t)) = 0
    simp only [normalPart, sub_apply, id_apply, inner_sub_right, ← hsym t (F t u) (W t),
      hfix, sub_self]
  have hcross (u w : Cover d) :
      |inner ℝ (F (flatProjection x) u) (D x w)| ≤ (J * (a * L / freq)) * (‖u‖ * ‖w‖) := by
    have hh := abs_inner_fderiv_realTorusCutoff_of_normal hs F
      (fderiv ℝ (fun z => F (flatProjection z))) (fun z => (hF.differentiable one_ne_zero z).hasFDerivAt)
      hDF P DP hDP hnormal x u w
    simp only [M₀, M₁, torusCutoffMoment, Real.rpow_zero, Real.rpow_one, mul_one] at hκ
    exact hh.trans (mul_le_mul_of_nonneg_right hκ (by positivity))
  change |inner ℝ ((F (flatProjection x) + D x) v) ((F (flatProjection x) + D x) w) -
    inner ℝ (F (flatProjection x) v) (F (flatProjection x) w) - metric v w| ≤ _
  refine (abs_gram_stage_le (F (flatProjection x)) (D x) (U x) (Q (flatProjection x))
    (hsym _) (hidem _) metric hcross hmetric v w).trans ?_
  change (2 * (J * (a * L / freq)) + ‖D x - N x‖ * (‖D x‖ + ‖N x‖) +
    ‖(Q (flatProjection x)).comp (U x)‖ ^ 2 + C * a ^ 2 * b) * _ ≤ _
  apply mul_le_mul_of_nonneg_right _ (by positivity)
  have hDD : ‖D x‖ + ‖N x‖ ≤ B * a := by
    refine (add_le_add (hD x) (hN x)).trans_eq ?_
    dsimp only [B]
    ring
  have ha₂ : a ^ 2 ≤ a := by simpa only [pow_two, mul_one] using mul_le_mul_of_nonneg_left ha₁ ha
  calc
    _ ≤ 2 * (J * (a * L / freq)) + (C * a * b + C ^ 2 * a * (L / freq)) * (B * a) +
        (C * a * τ) ^ 2 + C * a ^ 2 * b := by
      gcongr
      exact hangle x
    _ = (B * C + C) * (a ^ 2 * b) + 2 * J * (a * L / freq) +
        (B * C ^ 2) * (a ^ 2 * L / freq) + C ^ 2 * (a ^ 2 * τ ^ 2) := by ring
    _ ≤ (B * C + C) * (a ^ 2 * b) + 2 * J * (a * L / freq) +
        (B * C ^ 2) * (a * L / freq) + C ^ 2 * (a ^ 2 * τ ^ 2) := by
      gcongr
    _ = (B * C + C) * (a ^ 2 * b) + (2 * J + B * C ^ 2) * (a * L / freq) +
        C ^ 2 * (a ^ 2 * τ ^ 2) := by ring
    _ ≤ _ := by
      have hCM₀ := mul_nonneg hC hM₀
      have h₁ : B * C + C ≤ K := by dsimp only [K]; linarith [sq_nonneg C, mul_nonneg hB (sq_nonneg C)]
      have h₂ : 2 * J + B * C ^ 2 ≤ K := by dsimp only [K]; linarith [sq_nonneg C, mul_nonneg hB hC]
      have h₃ : C ^ 2 ≤ K := by dsimp only [K]; linarith [mul_nonneg hB hC, mul_nonneg hB (sq_nonneg C)]
      calc
        _ ≤ K * (a ^ 2 * b) + K * (a * L / freq) + K * (a ^ 2 * τ ^ 2) :=
          add_le_add (add_le_add (mul_le_mul_of_nonneg_right h₁ (by positivity))
            (mul_le_mul_of_nonneg_right h₂ (by positivity)))
            (mul_le_mul_of_nonneg_right h₃ (by positivity))
        _ = _ := by ring

end

end IsometricEmbeddingEndpoints

#print axioms IsometricEmbeddingEndpoints.exists_bound_gram_filtered_projection_stage
