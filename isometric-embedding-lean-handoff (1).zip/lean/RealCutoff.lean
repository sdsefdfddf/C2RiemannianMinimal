import CutoffApproximation
import FourierKernelScaling
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.Positivity

namespace IsometricEmbeddingEndpoints

open MeasureTheory
open scoped FourierTransform ComplexConjugate Topology

noncomputable section

variable {V : Type*} [NormedAddCommGroup V] [InnerProductSpace ℝ V] [FiniteDimensional ℝ V]
  [MeasurableSpace V] [BorelSpace V]

/-- The real kernel obtained from the normalized dilation of the unit Schwartz kernel. -/
def realCutoffKernel (scale : ℝ) (y : V) : ℝ :=
  (dilatedKernel scale (cutoffKernel unitCutoffSymbol) y).re

theorem ofReal_realCutoffKernel (scale : ℝ) (y : V) :
    (realCutoffKernel scale y : ℂ) = dilatedKernel scale (cutoffKernel unitCutoffSymbol) y := by
  apply Complex.conj_eq_iff_re.mp
  simp only [dilatedKernel, Complex.real_smul, map_mul, Complex.conj_ofReal, unitCutoffKernel_conj]

theorem norm_realCutoffKernel (scale : ℝ) (y : V) :
    ‖realCutoffKernel scale y‖ = ‖dilatedKernel scale (cutoffKernel unitCutoffSymbol) y‖ := by
  rw [← ofReal_realCutoffKernel, Complex.norm_real]

theorem continuous_realCutoffKernel (scale : ℝ) : Continuous (realCutoffKernel (V := V) scale) := by
  let K := cutoffKernel (unitCutoffSymbol (V := V))
  let c : ℝ := scale ^ Module.finrank ℝ V
  have h₁ : Continuous (fun y : V => K (scale • y)) :=
    K.continuous.comp (continuous_const_smul scale)
  have h : Continuous (fun y : V => c • K (scale • y)) :=
    (continuous_const : Continuous fun _ : V => c).smul h₁
  exact Complex.continuous_re.comp h

private theorem integrable_norm_rpow_mul_schwartz (K : SchwartzMap V ℂ) {r : ℝ}
    (hr : 0 ≤ r) (hr₂ : r ≤ 2) : Integrable (fun y => ‖K y‖ * ‖y‖ ^ r) := by
  have h0 : Integrable (fun y => ‖K y‖) := K.integrable.norm
  have h2 : Integrable (fun y => ‖y‖ ^ 2 * ‖K y‖) := K.integrable_pow_mul volume 2
  refine (h0.add h2).mono' (K.continuous.norm.mul
    ((Real.continuous_rpow_const hr).comp continuous_norm)).aestronglyMeasurable ?_
  filter_upwards with y
  have hy : ‖y‖ ^ r ≤ 1 + ‖y‖ ^ (2 : ℕ) := by
    by_cases h : ‖y‖ ≤ 1
    · exact (Real.rpow_le_one (norm_nonneg y) h hr).trans
        (le_add_of_nonneg_right (sq_nonneg _))
    · exact (Real.rpow_le_rpow_of_exponent_le (le_of_not_ge h) hr₂).trans
        (by rw [Real.rpow_two]; exact le_add_of_nonneg_left zero_le_one)
  simp only [Pi.add_apply, Real.norm_eq_abs]
  rw [abs_of_nonneg (mul_nonneg (norm_nonneg _) (Real.rpow_nonneg (norm_nonneg _) _))]
  calc
    ‖K y‖ * ‖y‖ ^ r ≤ ‖K y‖ * (1 + ‖y‖ ^ (2 : ℕ)) :=
      mul_le_mul_of_nonneg_left hy (norm_nonneg _)
    _ = _ := by ring

/-- The absolute moments of the real kernel through order two are integrable. -/
theorem integrable_norm_rpow_mul_realCutoffKernel {scale r : ℝ} (hscale : 0 < scale)
    (hr : 0 ≤ r) (hr₂ : r ≤ 2) :
    Integrable (fun y : V => ‖realCutoffKernel scale y‖ * ‖y‖ ^ r) := by
  let K := cutoffKernel (unitCutoffSymbol (V := V))
  let f : V → ℝ := fun y => ‖K y‖ * ‖y‖ ^ r
  have hf : Integrable f := integrable_norm_rpow_mul_schwartz K hr hr₂
  have hd := (hf.comp_smul hscale.ne').const_mul (scale ^ Module.finrank ℝ V * scale ^ (-r))
  refine hd.congr (Filter.Eventually.of_forall fun y => ?_)
  change _ = ‖realCutoffKernel scale y‖ * ‖y‖ ^ r
  rw [norm_realCutoffKernel]
  simp only [dilatedKernel, f, K, norm_smul, Real.norm_eq_abs,
    abs_of_nonneg (pow_nonneg hscale.le _), abs_of_pos hscale,
    Real.mul_rpow hscale.le (norm_nonneg y), Real.rpow_neg hscale.le]
  field_simp [(Real.rpow_pos_of_pos hscale r).ne']

theorem integrable_realCutoffKernel {scale : ℝ} (hscale : 0 < scale) :
    Integrable (realCutoffKernel (V := V) scale) := by
  have h := integrable_norm_rpow_mul_realCutoffKernel (V := V) hscale
    (r := 0) le_rfl (by norm_num)
  simp only [Real.rpow_zero, mul_one] at h
  exact (integrable_norm_iff (continuous_realCutoffKernel (V := V) scale).aestronglyMeasurable).mp h

theorem realCutoffKernel_mass {scale : ℝ} (hscale : 0 < scale) :
    (∫ y : V, realCutoffKernel scale y) = 1 := by
  have hm := dilated_cutoffKernel_modulated_mass (unitCutoffSymbol (V := V)) hscale 0
  rw [smul_zero, unitCutoffSymbol_one (by simp)] at hm
  have hcarrier (y : V) : negativeCarrier (0 : V) y = 1 := by
    simp [negativeCarrier]
  simp only [hcarrier, one_mul] at hm
  apply Complex.ofReal_injective
  calc
    Complex.ofReal (∫ y : V, realCutoffKernel scale y) =
        ∫ y : V, (realCutoffKernel scale y : ℂ) :=
      (integral_complex_ofReal (f := fun y : V => realCutoffKernel scale y)).symm
    _ = (1 : ℂ) := by simpa only [ofReal_realCutoffKernel]
    _ = ((1 : ℝ) : ℂ) := Complex.ofReal_one.symm

theorem integrable_realCutoffKernel_linear {scale : ℝ} (hscale : 0 < scale) :
    Integrable (fun y : V => realCutoffKernel scale y • y) := by
  have h := integrable_norm_rpow_mul_realCutoffKernel (V := V) hscale
    (r := 1) (by norm_num) (by norm_num)
  have hy : Integrable (fun y : V => ‖realCutoffKernel scale y • y‖) := by
    simpa only [Real.rpow_one, norm_smul] using h
  exact (integrable_norm_iff ((continuous_realCutoffKernel scale).smul
    continuous_id).aestronglyMeasurable).mp hy

/-- The real kernel has zero first vector moment. -/
theorem realCutoffKernel_firstMoment {scale : ℝ} (hscale : 0 < scale) :
    (∫ y : V, realCutoffKernel scale y • y) = 0 := by
  refine ext_inner_right ℝ fun w => ?_
  have hχ : (unitCutoffSymbol : V → ℂ) =ᶠ[𝓝 (scale⁻¹ • (0 : V))] fun _ => 1 := by
    rw [smul_zero]
    exact unitCutoffSymbol_eventually_one (by simp)
  have hm := dilated_cutoffKernel_modulated_firstMoment (unitCutoffSymbol (V := V)) hscale hχ w
  have hcarrier (y : V) : negativeCarrier (0 : V) y = 1 := by
    simp [negativeCarrier]
  simp only [hcarrier, one_mul] at hm
  change (innerSLFlip ℝ w) (∫ y : V, realCutoffKernel scale y • y) = inner ℝ (0 : V) w
  rw [← (innerSLFlip ℝ w).integral_comp_comm (integrable_realCutoffKernel_linear hscale),
    inner_zero_left]
  simp only [innerSLFlip_apply_apply ℝ, real_inner_smul_left]
  apply Complex.ofReal_injective
  calc
    Complex.ofReal (∫ y : V, realCutoffKernel scale y * inner ℝ y w) =
        ∫ y : V, ((realCutoffKernel scale y * inner ℝ y w : ℝ) : ℂ) :=
      (integral_complex_ofReal (f := fun y : V => realCutoffKernel scale y * inner ℝ y w)).symm
    _ = 0 := by simpa only [Complex.ofReal_mul, ofReal_realCutoffKernel, mul_comm] using hm
    _ = ((0 : ℝ) : ℂ) := Complex.ofReal_zero.symm

/-- Applying the two cancellations to a Taylor remainder gives the actual cutoff error. -/
theorem norm_realCutoff_error_of_remainder {H : Type*} [NormedAddCommGroup H] [NormedSpace ℝ H]
    [CompleteSpace H] {scale r C : ℝ} (hscale : 0 < scale) (hr : 0 ≤ r) (hr₂ : r ≤ 2)
    (A : V → H) (B : V →L[ℝ] H) (x : V)
    (hA : Integrable (fun y => realCutoffKernel scale y • A (x - y)))
    (hrem : ∀ y, ‖A (x - y) - A x + B y‖ ≤ C * ‖y‖ ^ r) :
    ‖(∫ y, realCutoffKernel scale y • A (x - y)) - A x‖ ≤
      C * (scale ^ (-r) * ∫ y : V, ‖cutoffKernel unitCutoffSymbol y‖ * ‖y‖ ^ r) := by
  have hK := integrable_realCutoffKernel_linear (V := V) hscale
  have hT : Integrable (fun y => realCutoffKernel scale y • B y) := by
    simpa only [B.map_smul] using B.integrable_comp hK
  have hzero := integral_weighted_linear_eq_zero (realCutoffKernel scale) id B hK
    (realCutoffKernel_firstMoment hscale)
  have h := norm_weighted_sub_mass_le (realCutoffKernel scale) (fun y => A (x - y)) B (A x)
    (fun y => ‖y‖ ^ r) (integrable_realCutoffKernel hscale) hA hT
    (realCutoffKernel_mass hscale) hzero
    (integrable_norm_rpow_mul_realCutoffKernel hscale hr hr₂)
    (Filter.Eventually.of_forall hrem)
  simp only [one_smul, norm_realCutoffKernel, integral_dilatedKernel_norm_rpow _ hscale r] at h
  exact h

end

end IsometricEmbeddingEndpoints

#print axioms IsometricEmbeddingEndpoints.realCutoffKernel_mass
#print axioms IsometricEmbeddingEndpoints.realCutoffKernel_firstMoment
#print axioms IsometricEmbeddingEndpoints.norm_realCutoff_error_of_remainder
