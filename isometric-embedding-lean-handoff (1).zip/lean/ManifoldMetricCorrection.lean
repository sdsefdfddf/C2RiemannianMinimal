import ManifoldMetricCharts
import CompactMetricMargin
import TorusGram
import Mathlib.Analysis.Calculus.ContDiff.Operations
import Mathlib.Geometry.Manifold.ContMDiff.NormedSpace

open scoped ContDiff Manifold Topology

namespace IsometricEmbeddingEndpoints

open ContinuousLinearMap
open Set

noncomputable section

variable {ι d M W : Type*} [Fintype ι] [Fintype d] [TopologicalSpace M]
  [ChartedSpace (Cover d) M] [NormedAddCommGroup W] [InnerProductSpace ℝ W] [CompleteSpace W]

local notation "𝕀" => 𝓘(ℝ, Cover d)
local instance : NormedAddCommGroup (MetricForm d) := inferInstance
local instance : NormedSpace ℝ (MetricForm d) := inferInstance

/-- The metric to reserve for the background embedding and the derivatives of
the square partition. The background embedding and the sphere radius will be
scaled by the same factor. -/
def metricCorrection (w : M → W) (a : ι → M → ℝ) (p : M) : MetricForm d :=
  differentialPairing (mvfderiv 𝕀 w p) (mvfderiv 𝕀 w p) +
    ∑ i, differentialPairing (mvfderiv 𝕀 (a i) p) (mvfderiv 𝕀 (a i) p)

set_option backward.isDefEq.respectTransparency false in
theorem metricCorrection_apply (w : M → W) (a : ι → M → ℝ) (p : M)
    (v z : TangentSpace 𝕀 p) :
    metricCorrection w a p v z =
      inner ℝ (mvfderiv 𝕀 w p v) (mvfderiv 𝕀 w p z) +
        ∑ i, mvfderiv 𝕀 (a i) p v * mvfderiv 𝕀 (a i) p z := by
  let D : Cover d →L[ℝ] W := mvfderiv 𝕀 w p
  let A (i : ι) : Cover d →L[ℝ] ℝ := mvfderiv 𝕀 (a i) p
  let ev : MetricForm d →L[ℝ] ℝ := (ContinuousLinearMap.apply (E' := Cover d) ℝ ℝ z).comp
    (ContinuousLinearMap.apply (E' := Cover d) ℝ (Cover d →L[ℝ] ℝ) v)
  change ev (differentialPairing D D + ∑ i, differentialPairing (A i) (A i)) = _
  rw [map_add, map_sum]
  change differentialPairing D D v z + (∑ i, differentialPairing (A i) (A i) v z) = _
  refine congrArg₂ (· + ·) (differentialPairing_apply D D v z) ?_
  exact Finset.sum_congr rfl fun i _ => by
    have hi := differentialPairing_apply (A i) (A i) v z
    rw [Real.inner_apply] at hi
    exact hi

/-- Pullback of the reserved metric by the inverse chart. -/
def metricCorrectionInChart (w : M → W) (a : ι → M → ℝ)
    (e : OpenPartialHomeomorph M (Cover d)) (x : Cover d) : MetricForm d :=
  pullbackMetricForm (metricCorrection w a (e.symm x)) (mfderiv 𝕀 𝕀 e.symm x)

theorem metricCorrectionInChart_pullback (w : M → W) (a : ι → M → ℝ)
    {e : OpenPartialHomeomorph M (Cover d)} (he : e.MDifferentiable 𝕀 𝕀) {p : M}
    (hp : p ∈ e.source) (v z : TangentSpace 𝕀 p) :
    metricCorrectionInChart w a e (e p) (mfderiv 𝕀 𝕀 e p v) (mfderiv 𝕀 𝕀 e p z) =
      metricCorrection w a p v z := by
  have hD (y : TangentSpace 𝕀 p) :
      mfderiv 𝕀 𝕀 e.symm (e p) (mfderiv 𝕀 𝕀 e p y) = y :=
    DFunLike.congr_fun (he.symm_comp_deriv hp) y
  change metricCorrection w a (e.symm (e p))
    (mfderiv 𝕀 𝕀 e.symm (e p) (mfderiv 𝕀 𝕀 e p v))
    (mfderiv 𝕀 𝕀 e.symm (e p) (mfderiv 𝕀 𝕀 e p z)) = _
  rw [hD, hD, e.left_inv hp]

/-- Remove the part of the metric contributed by the scaled background embedding
and the weights of the sphere-valued maps. -/
def RiemannianMetric.corrected (g : RiemannianMetric d M) (w : M → W)
    (a : ι → M → ℝ) (δ : ℝ)
    (hp : ∀ p v, v ≠ 0 → 0 < g.form p v v - δ * metricCorrection w a p v v) :
    RiemannianMetric d M where
  form p := by
    change MetricForm d
    let b : MetricForm d := g.form p
    exact b - δ • metricCorrection (d := d) w a p
  symmetric p v z := by
    have hs : (∑ i, mvfderiv 𝕀 (a i) p v * mvfderiv 𝕀 (a i) p z) =
        ∑ i, mvfderiv 𝕀 (a i) p z * mvfderiv 𝕀 (a i) p v :=
      Finset.sum_congr rfl fun _ _ => mul_comm _ _
    change g.form p v z - δ * metricCorrection w a p v z =
      g.form p z v - δ * metricCorrection w a p z v
    rw [g.symmetric p v z, metricCorrection_apply, metricCorrection_apply,
      real_inner_comm (mvfderiv 𝕀 w p v), hs]
  positive p v hv := hp p v hv

theorem RiemannianMetric.corrected_inChart (g : RiemannianMetric d M) (w : M → W)
    (a : ι → M → ℝ) (δ : ℝ) (hp)
    (e : OpenPartialHomeomorph M (Cover d)) (x : Cover d) :
    (g.corrected w a δ hp).inChart e x =
      g.inChart e x - δ • metricCorrectionInChart w a e x := by
  ext v z
  rfl

private def coordinateGram {F : Type*} [NormedAddCommGroup F] [InnerProductSpace ℝ F]
    [CompleteSpace F] (u : Cover d → F) (x : Cover d) : MetricForm d :=
  differentialPairing (fderiv ℝ u x) (fderiv ℝ u x)

private theorem coordinateGram_apply {F : Type*} [NormedAddCommGroup F] [InnerProductSpace ℝ F]
    [CompleteSpace F] (u : Cover d → F) (x v z : Cover d) :
    coordinateGram u x v z = inner ℝ (fderiv ℝ u x v) (fderiv ℝ u x z) :=
  differentialPairing_apply _ _ _ _

private theorem coordinateGram_contDiffAt_two {F : Type*} [NormedAddCommGroup F]
    [InnerProductSpace ℝ F] [CompleteSpace F] {u : Cover d → F} {x : Cover d}
    (hu : ContDiffAt ℝ ∞ u x) : ContDiffAt ℝ 2 (coordinateGram u) x := by
  have hD : ContDiffAt ℝ 2 (fderiv ℝ u) x := hu.fderiv_right (by norm_num)
  let P := differentialPairing (d := d) (H := F)
  have hP := ContinuousLinearMap.contDiff (𝕜 := ℝ) (n := 2)
    (E := Cover d →L[ℝ] F) (F := (Cover d →L[ℝ] F) →L[ℝ] MetricForm d) P
  exact (hP.contDiffAt.comp x hD).clm_apply hD

private theorem coordinate_fderiv_apply {F : Type*} [NormedAddCommGroup F] [NormedSpace ℝ F]
    {u : M → F} {e : OpenPartialHomeomorph M (Cover d)} {x : Cover d}
    (hu : ContMDiff 𝕀 𝓘(ℝ, F) ∞ u) (he : ContMDiffAt 𝕀 𝕀 ∞ e.symm x) (v : Cover d) :
    fderiv ℝ (u ∘ e.symm) x v = mvfderiv 𝕀 u (e.symm x) (mfderiv 𝕀 𝕀 e.symm x v) := by
  have hm := mvfderiv_comp_apply x (hu.contMDiffAt.mdifferentiableAt (by simp))
    (he.mdifferentiableAt (by simp)) v
  rw [mvfderiv_eq_fderiv] at hm
  exact hm

set_option maxHeartbeats 800000 in
theorem metricCorrectionInChart_contDiffAt_two
    {w : M → W} {a : ι → M → ℝ} {e : OpenPartialHomeomorph M (Cover d)} {x : Cover d}
    (hx : x ∈ e.target)
    (he : ∀ y ∈ e.target, ContMDiffAt 𝕀 𝕀 ∞ e.symm y)
    (hw : ContMDiff 𝕀 𝓘(ℝ, W) ∞ w) (ha : ∀ i, ContMDiff 𝕀 𝓘(ℝ) ∞ (a i)) :
    ContDiffAt ℝ 2 (metricCorrectionInChart w a e) x := by
  have hgram (u : M → W) (hu : ContMDiff 𝕀 𝓘(ℝ, W) ∞ u) :
      ContDiffAt ℝ 2 (coordinateGram (u ∘ e.symm)) x :=
    coordinateGram_contDiffAt_two ((hu.contMDiffAt.comp x (he x hx)).contDiffAt)
  have ha' (i : ι) : ContDiffAt ℝ 2 (coordinateGram ((a i) ∘ e.symm)) x :=
    coordinateGram_contDiffAt_two (((ha i).contMDiffAt.comp x (he x hx)).contDiffAt)
  have hs : ContDiffAt ℝ 2 (fun y => ∑ i, coordinateGram ((a i) ∘ e.symm) y) x :=
    ContDiffAt.sum fun i _ => ha' i
  apply ((hgram w hw).add hs).congr_of_eventuallyEq
  filter_upwards [e.open_target.mem_nhds hx] with y hy
  have hcompw := coordinate_fderiv_apply hw (he y hy)
  have hcompa (i : ι) := coordinate_fderiv_apply (ha i) (he y hy)
  ext v z
  change metricCorrection w a (e.symm y) (mfderiv 𝕀 𝕀 e.symm y v)
    (mfderiv 𝕀 𝕀 e.symm y z) =
      (coordinateGram (w ∘ e.symm) y + ∑ i, coordinateGram ((a i) ∘ e.symm) y) v z
  simp only [metricCorrection_apply, ContinuousLinearMap.add_apply, ContinuousLinearMap.sum_apply,
    coordinateGram_apply, hcompw, hcompa, Real.inner_apply]

/-- A single positive scale works on all the compact coordinate domains. -/
theorem exists_metric_correction_scale
    (g : RiemannianMetric d M) (w : M → W) (a : ι → M → ℝ)
    (e : ι → OpenPartialHomeomorph M (Cover d)) (K : ι → Set (Cover d))
    (hK : ∀ i, IsCompact (K i)) (hKt : ∀ i, K i ⊆ (e i).target)
    (he : ∀ i y, y ∈ (e i).target → ContMDiffAt 𝕀 𝕀 ∞ (e i).symm y)
    (he' : ∀ i y, y ∈ (e i).source → MDifferentiableAt 𝕀 𝕀 (e i) y)
    (hg : ∀ i, ContinuousOn (g.inChart (e i)) (K i))
    (hw : ContMDiff 𝕀 𝓘(ℝ, W) ∞ w) (ha : ∀ i, ContMDiff 𝕀 𝓘(ℝ) ∞ (a i)) :
    ∃ δ : ℝ, 0 < δ ∧ ∀ i x, x ∈ K i → ∀ v ≠ 0,
      0 < g.inChart (e i) x v v - δ * metricCorrectionInChart w a (e i) x v v := by
  classical
  have hm (i : ι) := exists_pos_metric_subtraction_on_compact (hK i)
    (g.inChart (e i)) (metricCorrectionInChart w a (e i)) (hg i)
    (fun x hx => (metricCorrectionInChart_contDiffAt_two (hKt i hx) (he i) hw ha).continuousAt.continuousWithinAt)
    (fun x hx v hv => g.inChart_positive
      (⟨fun y hy => (he' i y hy).mdifferentiableWithinAt, fun y hy =>
        ((he i y hy).mdifferentiableAt (by simp)).mdifferentiableWithinAt⟩) (hKt i hx) hv)
  choose ε hε hm using hm
  obtain ⟨δ, hδ, hδi⟩ := exists_pos_le_of_finite hε
  exact ⟨δ, hδ, fun i x hx v hv => hm i δ hδ.le (hδi i) x hx v hv⟩

end

end IsometricEmbeddingEndpoints

#print axioms IsometricEmbeddingEndpoints.metricCorrectionInChart_contDiffAt_two
#print axioms IsometricEmbeddingEndpoints.exists_metric_correction_scale
