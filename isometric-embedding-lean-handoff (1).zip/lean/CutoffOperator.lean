import Mathlib.Analysis.Normed.Module.FiniteDimension
import Mathlib.MeasureTheory.Integral.Bochner.ContinuousLinearMap
import Mathlib.Topology.ContinuousMap.Compact

namespace IsometricEmbeddingEndpoints

open MeasureTheory

noncomputable section

variable {V T : Type*} [TopologicalSpace V] [MeasurableSpace V] [BorelSpace V]
  [SecondCountableTopology V] [TopologicalSpace T] [CompactSpace T] [AddGroup T]
  [IsTopologicalAddGroup T]
  {ν : Measure V}

section Translation

variable {H : Type*}

/-- Translation of a continuous function on a compact additive group. -/
def shiftMap [TopologicalSpace H] (f : C(T, H)) (b : T) : C(T, H) :=
  ⟨fun x => f (x - b), f.continuous.comp (continuous_id.sub continuous_const)⟩

theorem norm_shiftMap_le [NormedAddCommGroup H] (f : C(T, H)) (b : T) : ‖shiftMap f b‖ ≤ ‖f‖ :=
  (ContinuousMap.norm_le _ (norm_nonneg _)).2 (fun x => f.norm_coe_le_norm (x - b))

omit [MeasurableSpace V] [BorelSpace V] [SecondCountableTopology V] [CompactSpace T] in
theorem continuous_shiftMap [TopologicalSpace H] (p : C(V, T)) (f : C(T, H)) :
    Continuous fun y => shiftMap f (p y) :=
  ContinuousMap.continuous_of_continuous_uncurry _ (f.continuous.comp
    (continuous_snd.sub (p.continuous.comp continuous_fst)))

variable {𝕜 : Type*} [NontriviallyNormedField 𝕜] [NormedAddCommGroup H] [NormedSpace 𝕜 H]

theorem integrable_weighted_shiftMap (p : C(V, T)) (k : V → 𝕜) (hk : Integrable k ν)
    (f : C(T, H)) : Integrable (fun y => k y • shiftMap f (p y)) ν := by
  refine (hk.norm.mul_const ‖f‖).mono'
    (hk.aestronglyMeasurable.smul (continuous_shiftMap p f).aestronglyMeasurable) ?_
  exact Filter.Eventually.of_forall (fun y => by
    rw [norm_smul]
    exact mul_le_mul_of_nonneg_left (norm_shiftMap_le f _) (norm_nonneg _))

omit [BorelSpace V] [SecondCountableTopology V] in
theorem norm_integral_weighted_shiftMap_le [NormedSpace ℝ H] (p : C(V, T)) (k : V → 𝕜)
    (hk : Integrable k ν) (f : C(T, H)) :
    ‖(∫ y, k y • shiftMap f (p y) ∂ν)‖ ≤ (∫ y, ‖k y‖ ∂ν) * ‖f‖ := by
  rw [← integral_mul_const]
  refine norm_integral_le_of_norm_le (hk.norm.mul_const ‖f‖) ?_
  exact Filter.Eventually.of_forall (fun y => by
    rw [norm_smul]
    exact mul_le_mul_of_nonneg_left (norm_shiftMap_le f _) (norm_nonneg _))

end Translation

/-- The cutoff convolution is a bounded operator in the uniform norm. The integral is taken
with values in continuous functions, so no pointwise continuity argument is needed afterwards. -/
def weightedShiftOperator (p : C(V, T)) (k : V → ℂ) (hk : Integrable k ν) :
    C(T, ℂ) →L[ℂ] C(T, ℂ) :=
  LinearMap.mkContinuous
    { toFun := fun f => ∫ y, k y • shiftMap f (p y) ∂ν
      map_add' := by
        intro f g
        have hs : ∀ y, shiftMap (f + g) (p y) = shiftMap f (p y) + shiftMap g (p y) :=
          fun y => ContinuousMap.ext (fun _ => rfl)
        simp only [hs, smul_add]
        exact integral_add (integrable_weighted_shiftMap p k hk f) (integrable_weighted_shiftMap p k hk g)
      map_smul' := by
        intro c f
        have hs : ∀ y, k y • shiftMap (c • f) (p y) = c • (k y • shiftMap f (p y)) := by
          intro y
          ext x
          change k y * (c * f (x - p y)) = c * (k y * f (x - p y))
          rw [mul_left_comm]
        simp only [hs, integral_smul, RingHom.id_apply] }
    (∫ y, ‖k y‖ ∂ν) (norm_integral_weighted_shiftMap_le (H := ℂ) p k hk)

theorem weightedShiftOperator_apply (p : C(V, T)) (k : V → ℂ) (hk : Integrable k ν)
    (f : C(T, ℂ)) (x : T) :
    weightedShiftOperator p k hk f x = ∫ y, k y * f (x - p y) ∂ν := by
  change (ContinuousMap.evalCLM ℂ x) (∫ y, k y • shiftMap f (p y) ∂ν) = _
  rw [← (ContinuousMap.evalCLM ℂ x).integral_comp_comm (integrable_weighted_shiftMap p k hk f)]
  rfl

theorem norm_weightedShiftOperator_apply_le (p : C(V, T)) (k : V → ℂ)
    (hk : Integrable k ν) (f : C(T, ℂ)) :
    ‖weightedShiftOperator p k hk f‖ ≤ (∫ y, ‖k y‖ ∂ν) * ‖f‖ :=
  norm_integral_weighted_shiftMap_le (H := ℂ) p k hk f

/-- A continuous cutoff lands in a finite-dimensional band as soon as it does on a dense
family of modes. This avoids proving a Fourier coefficient formula for every continuous input. -/
theorem mem_finite_span_of_dense_modes {E : Type*} [NormedAddCommGroup E] [NormedSpace ℂ E]
    {ι : Type*} (S : E →L[ℂ] E) (mode : ι → E) (band : Finset ι)
    (hdense : (Submodule.span ℂ (Set.range mode)).topologicalClosure = ⊤)
    (hmode : ∀ i, S (mode i) ∈ Submodule.span ℂ (mode '' (band : Set ι))) (f : E) :
    S f ∈ Submodule.span ℂ (mode '' (band : Set ι)) := by
  let B := Submodule.span ℂ (mode '' (band : Set ι))
  have : FiniteDimensional ℂ B := FiniteDimensional.span_of_finite ℂ (band.finite_toSet.image mode)
  have hpre : IsClosed ((B.comap S.toLinearMap : Submodule ℂ E) : Set E) :=
    (B.isClosed_of_finiteDimensional).preimage S.continuous
  have hspan : Submodule.span ℂ (Set.range mode) ≤ B.comap S.toLinearMap := by
    refine Submodule.span_le.2 ?_
    rintro _ ⟨i, rfl⟩
    exact hmode i
  have h := (Submodule.span ℂ (Set.range mode)).topologicalClosure_minimal hspan hpre
  rw [hdense] at h
  exact h (Submodule.mem_top (x := f))

end

end IsometricEmbeddingEndpoints

#print axioms IsometricEmbeddingEndpoints.weightedShiftOperator_apply
#print axioms IsometricEmbeddingEndpoints.mem_finite_span_of_dense_modes
