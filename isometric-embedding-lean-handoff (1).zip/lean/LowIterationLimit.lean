import LowLimit
import TorusGram
import TorusLifts

namespace IsometricEmbeddingEndpoints

open Filter Finset ContinuousLinearMap
open scoped Topology

noncomputable section

variable {d H : Type*} [Fintype d] [NormedAddCommGroup H] [InnerProductSpace ℝ H] [CompleteSpace H]

local instance : NormedAddCommGroup (MetricForm d) := inferInstance
local instance : NormedSpace ℝ (MetricForm d) := inferInstance

/-- The limit of smooth approximations whose Gram forms converge uniformly and whose
increments have the geometric bounds of the low-regularity iteration. -/
theorem exists_isometric_holder_limit_of_gram_approximations
    {L θ A A₀ : ℝ} (hL : 1 < L) (hθ : 0 < θ) (hθ₁ : θ < 1) (hA : 0 ≤ A) (hA₀ : 0 ≤ A₀)
    (u₀ : C(UnitAddTorus d, H)) (hu₀ : ContDiff ℝ 1 (fun x => u₀ (flatProjection x)))
    (hstart : ∀ x y : Cover d,
      ‖fderiv ℝ (fun z => u₀ (flatProjection z)) x - fderiv ℝ (fun z => u₀ (flatProjection z)) y‖ ≤
        A₀ * dist x y ^ θ)
    (v : ℕ → C(UnitAddTorus d, H)) (hv : ∀ j, ContDiff ℝ 1 (fun x => v j (flatProjection x)))
    (hsmall : ∀ j, ‖v j‖ ≤ A * (L ^ (-θ)) ^ j)
    (hgradient : ∀ j, ‖torusDifferential (v j) (hv j)‖ ≤ A * (L ^ (-θ)) ^ j)
    (hlip : ∀ j (x y : Cover d),
      ‖fderiv ℝ (fun z => v j (flatProjection z)) x - fderiv ℝ (fun z => v j (flatProjection z)) y‖ ≤
        A * (L ^ (1 - θ)) ^ j * dist x y)
    (g : TorusMetric d)
    (hmetric : Tendsto
      (fun n : ℕ => torusGram (torusDifferential u₀ hu₀ +
        ∑ j ∈ range n, torusDifferential (v j) (hv j))) atTop (𝓝 g.form)) :
    ∃ u : C(UnitAddTorus d, H), ContDiff ℝ 1 (fun x => u (flatProjection x)) ∧
      (∃ K : ℝ, 0 ≤ K ∧ ∀ x y : Cover d,
        ‖fderiv ℝ (fun z => u (flatProjection z)) x -
          fderiv ℝ (fun z => u (flatProjection z)) y‖ ≤ K * dist x y ^ θ) ∧
      g.HasIsometricDifferential u := by
  let D₀ := fderiv ℝ (fun z => u₀ (flatProjection z))
  let Dv := fun j => fderiv ℝ (fun z => v j (flatProjection z))
  have hvbound (j : ℕ) (x : Cover d) : ‖Dv j x‖ ≤ A * (L ^ (-θ)) ^ j := by
    dsimp only [Dv]
    rw [← torusDifferential_apply (v j) (hv j)]
    exact ((torusDifferential (v j) (hv j)).norm_coe_le_norm _).trans (hgradient j)
  have hpoint (x a b : Cover d) : Tendsto (fun n : ℕ =>
      inner ℝ ((D₀ x + ∑ j ∈ range n, Dv j x) a) ((D₀ x + ∑ j ∈ range n, Dv j x) b))
      atTop (𝓝 (g.form (flatProjection x) a b)) := by
    let ev := (ContinuousLinearMap.apply ℝ ℝ b).comp
      ((ContinuousLinearMap.apply ℝ (Cover d →L[ℝ] ℝ) a).comp
        (ContinuousMap.evalCLM ℝ (flatProjection x)))
    have h := (ev.continuous.continuousAt (x := g.form)).tendsto.comp hmetric
    change Tendsto (fun n : ℕ =>
      torusGram (torusDifferential u₀ hu₀ +
        ∑ j ∈ range n, torusDifferential (v j) (hv j)) (flatProjection x) a b)
      atTop (𝓝 (g.form (flatProjection x) a b)) at h
    simpa only [torusGram_apply, ContinuousMap.add_apply, ContinuousMap.coe_sum, Finset.sum_apply,
      torusDifferential_apply, D₀, Dv] using h
  obtain ⟨u, hu, hHolder, hIso⟩ := exists_isometric_holder_limit_of_torus_series hL hθ hθ₁ hA hA₀
    u₀ D₀ (fun x => (hu₀.differentiable one_ne_zero x).hasFDerivAt)
    (hu₀.continuous_fderiv one_ne_zero) hstart v Dv (fun j x => ((hv j).differentiable one_ne_zero x).hasFDerivAt)
    hsmall hvbound hlip (fun x a b => g.form (flatProjection x) a b) hpoint
  exact ⟨u, hu, hHolder, hu.differentiable one_ne_zero, hIso⟩

end

end IsometricEmbeddingEndpoints

#print axioms IsometricEmbeddingEndpoints.exists_isometric_holder_limit_of_gram_approximations
