import ContinuousTorusLimit
import LowIterationAssemble
import TorusInitialBlock

namespace IsometricEmbeddingEndpoints

open Filter Finset ContinuousLinearMap
open scoped Topology

noncomputable section

variable {d : Type*} [Fintype d] [DecidableEq d]

local instance : NormedAddCommGroup (MetricForm d) := inferInstance
local instance : NormedSpace ℝ (MetricForm d) := inferInstance
local instance : NormedAddCommGroup C(UnitAddTorus d, MetricForm d) := inferInstance

private theorem sum_geom_le_two {q : ℝ} (hq : 0 ≤ q) (hq₂ : q ≤ 1 / 2) (j : ℕ) :
    ∑ k ∈ range j, q ^ k ≤ 2 := by
  have hq₁ : q < 1 := by linarith
  calc
    _ ≤ ∑' k : ℕ, q ^ k :=
      (summable_geometric_of_lt_one hq hq₁).sum_le_tsum _ (fun k _ => pow_nonneg hq k)
    _ = (1 - q)⁻¹ := tsum_geometric_of_lt_one hq hq₁
    _ ≤ 2 := by rw [inv_eq_one_div, div_le_iff₀ (sub_pos.mpr hq₁)]; linarith

private theorem frequency_for_continuous_step (A Λ L K δ η : ℝ) (hη : 0 < η) :
    ∃ N : ℕ, 1 ≤ (N : ℝ) ∧ A * Λ ≤ (N : ℝ) ∧ L ≤ (N : ℝ) ∧
      K * (δ * (Λ / (N : ℝ)) ^ 2 + √δ * L / (N : ℝ)) ≤ η := by
  have hΛ := tendsto_const_div_atTop_nhds_zero_nat Λ
  have hL := tendsto_const_div_atTop_nhds_zero_nat (√δ * L)
  have hlim : Tendsto (fun N : ℕ => K * (δ * (Λ / (N : ℝ)) ^ 2 + √δ * L / (N : ℝ)))
      atTop (𝓝 0) := by
    simpa only [zero_pow (by decide : (2 : ℕ) ≠ 0), mul_zero, add_zero] using
      (((hΛ.pow 2).const_mul δ).add hL).const_mul K
  have hcast := tendsto_natCast_atTop_atTop (R := ℝ)
  have he : ∀ᶠ N : ℕ in atTop, 1 ≤ (N : ℝ) ∧ A * Λ ≤ (N : ℝ) ∧ L ≤ (N : ℝ) ∧
      K * (δ * (Λ / (N : ℝ)) ^ 2 + √δ * L / (N : ℝ)) ≤ η :=
    (hcast.eventually (eventually_ge_atTop 1)).and
      ((hcast.eventually (eventually_ge_atTop (A * Λ))).and
        ((hcast.eventually (eventually_ge_atTop L)).and (hlim.eventually (ge_mem_nhds hη))))
  exact he.exists

set_option maxHeartbeats 2500000 in
/-- A continuous positive metric on a torus admits a continuously differentiable isometric
immersion in finite-dimensional Euclidean space. The frequency is chosen at each step. -/
theorem TorusMetric.exists_euclideanImmersion_contDiff (g : TorusMetric d) :
    ∃ (N : ℕ) (u : C(UnitAddTorus d, EuclideanSpace ℝ (Fin N))),
      ContDiff ℝ 1 (fun x => u (flatProjection x)) ∧ g.HasIsometricDifferential u := by
  obtain ⟨n, δstart, σ, M, J, hδstart, hσ, hM, hstart⟩ :=
    g.exists_initialBlock (B := 1) (by decide)
  let H := InitialBlockSpace d n
  letI : NormedAddCommGroup C(UnitAddTorus d, H) := inferInstance
  letI : NormedAddCommGroup C(UnitAddTorus d, Cover d →L[ℝ] H) := inferInstance
  obtain ⟨ε, δmax, c, A, K, hε, hδmax, hc, hA, hK, hstep⟩ :=
    exists_lowIterationStep (d := d) (ι := Unit) (H := H)
      (show 0 < σ / 2 by positivity) (show 0 ≤ M + 1 by positivity)
  let q := min (1 / 2 : ℝ) (ε / 4)
  let e := min (1 : ℝ) (ε / 4)
  let η := e / 4
  have hq : 0 < q := lt_min (by positivity) (by positivity)
  have hq₂ : q ≤ 1 / 2 := min_le_left _ _
  have hq₁ : q < 1 := by linarith
  have he : 0 < e := lt_min (by positivity) (by positivity)
  have he₁ : e ≤ 1 := min_le_left _ _
  have hη : 0 < η := by positivity
  have hηsmall : η + 1 ≤ 2 := by dsimp [η]; linarith
  have hrel : e + (η + 1) * q ^ 2 ≤ ε := by
    have hqε : q ≤ ε / 4 := min_le_right _ _
    have heε : e ≤ ε / 4 := min_le_right _ _
    nlinarith [mul_le_mul_of_nonneg_right hηsmall (sq_nonneg q),
      mul_nonneg hq.le (show 0 ≤ 1 - q by linarith)]
  let s := min (√(min δstart δmax))
    (min (min 1 (σ / 2)) (√(η * q ^ 2 / (K + 1))) / (2 * K + 1))
  have hK₁ : 0 < K + 1 := by positivity
  have hKs : 0 < 2 * K + 1 := by positivity
  have hsmall : 0 < η * q ^ 2 / (K + 1) := by positivity
  have hs : 0 < s := by
    dsimp [s]
    exact lt_min (Real.sqrt_pos.2 (lt_min hδstart hδmax))
      (div_pos (lt_min (lt_min zero_lt_one (by positivity)) (Real.sqrt_pos.2 hsmall)) hKs)
  have hsδ : s ^ 2 ≤ min δstart δmax := by
    have h := pow_le_pow_left₀ hs.le (min_le_left (√(min δstart δmax)) _) 2
    rwa [Real.sq_sqrt (le_min hδstart.le hδmax.le)] at h
  let T := 2 * K * s
  have hT : 0 ≤ T := by positivity
  have hTbound : T ≤ min (min 1 (σ / 2)) (√(η * q ^ 2 / (K + 1))) := by
    calc
      T ≤ s * (2 * K + 1) := by dsimp only [T]; nlinarith
      _ ≤ _ := (le_div_iff₀ hKs).mp (min_le_right _ _)
  have hT₁ : T ≤ 1 := (hTbound.trans (min_le_left _ _)).trans (min_le_left _ _)
  have hTσ : T ≤ σ / 2 := (hTbound.trans (min_le_left _ _)).trans (min_le_right _ _)
  have hTη : K * T ^ 2 ≤ η * q ^ 2 := by
    have h := pow_le_pow_left₀ hT (hTbound.trans (min_le_right _ _)) 2
    rw [Real.sq_sqrt hsmall.le] at h
    have h' := (le_div_iff₀ hK₁).mp h
    nlinarith [sq_nonneg T]
  let a := fun j : ℕ => s * q ^ j
  let δ := fun j => (a j) ^ 2
  have ha (j) : 0 < a j := by dsimp [a]; positivity
  have hδ (j) : 0 < δ j := by dsimp only [δ]; positivity
  have hδj (j) : δ j ≤ δmax := by
    refine (pow_le_pow_left₀ (ha j).le ?_ 2).trans (hsδ.trans (min_le_right _ _))
    exact mul_le_of_le_one_right hs.le (pow_le_one₀ hq.le hq₁.le)
  have hδsucc (j) : δ (j + 1) = δ j * q ^ 2 := by
    simp only [δ, a, pow_succ]
    ring
  have hsqrt (j) : √(δ j) = a j := Real.sqrt_sq (ha j).le
  have hsum (j) : (∑ i ∈ range j, K * a i) ≤ T := by
    simp only [a, ← mul_assoc, ← Finset.mul_sum, T]
    convert mul_le_mul_of_nonneg_left (sum_geom_le_two hq.le hq₂ j) (mul_nonneg hK hs.le) using 1 <;>
      ring
  obtain ⟨s₀, w₀, hw₀, hs₀, _, hb₀, hF₀M, hF₀σ, hJ, hmetric₀⟩ :=
    hstart (δ 0) (e * δ 0) (hδ 0).le (by simpa [δ, a] using hsδ.trans (min_le_left _ _))
      (mul_pos he (hδ 0)) ((mul_le_of_le_one_left (hδ 0).le he₁).trans
        (by simpa [δ, a] using hsδ.trans (min_le_left _ _)))
  let u₀ : TorusCorrection d H := ⟨w₀, hw₀⟩
  let F₀ := u₀.differential
  have hF₀M' : ‖F₀‖ ≤ M := hF₀M
  let P := fun j (u : TorusCorrection d H) =>
    (∃ B : ℝ, 0 < B ∧ HasFourierSupport (latticeBall d B) u.differential) ∧
      ‖u.differential - F₀‖ ≤ ∑ i ∈ range j, K * a i ∧
      ‖torusGram u.differential - (g.form - δ j • flatMetric)‖ ≤ e * δ j
  have hP₀ : P 0 u₀ := by
    refine ⟨⟨2 * s₀, by positivity, hb₀.mono (torusCutoffBand_subset_latticeBall _)⟩, ?_, ?_⟩
    · change ‖F₀ - F₀‖ ≤ ∑ i ∈ range 0, K * a i
      rw [sub_self, norm_zero, range_zero, sum_empty]
    · change ‖torusGram F₀ - (g.form - δ 0 • flatMetric)‖ ≤ e * δ 0
      simpa only [F₀, u₀, TorusCorrection.differential, Nat.cast_one, one_smul] using hmetric₀.le
  have advance (j : ℕ) (u : {u // P j u}) :
      ∃ v : {u // P (j + 1) u}, dist u.val.value v.val.value ≤ K * a j ∧
        dist u.val.differential v.val.differential ≤ K * a j := by
    let D := u.val.differential
    obtain ⟨⟨B, hB, hband⟩, hdrift, hmetric⟩ := u.property
    have hdriftT : ‖D - F₀‖ ≤ T := hdrift.trans (hsum j)
    have hDM : ‖D‖ ≤ M + 1 := by
      calc
        ‖D‖ = ‖D - F₀ + F₀‖ := by rw [sub_add_cancel]
        _ ≤ ‖D - F₀‖ + ‖F₀‖ := norm_add_le _ _
        _ ≤ _ := add_le_add (hdriftT.trans hT₁) hF₀M' |>.trans_eq (add_comm _ _)
    have hDσ (t : UnitAddTorus d) (v : Cover d) : (σ / 2) * ‖v‖ ≤ ‖D t v‖ := by
      have hΔ : ‖(D - F₀) t v‖ ≤ T * ‖v‖ :=
        ((D - F₀) t).le_opNorm v |>.trans (mul_le_mul_of_nonneg_right
          (((D - F₀).norm_coe_le_norm t).trans hdriftT) (norm_nonneg _))
      have hΔ' : ‖F₀ t v‖ ≤ ‖D t v‖ + ‖(D - F₀) t v‖ := by
        simpa only [ContinuousMap.sub_apply, sub_apply, sub_sub_cancel, norm_sub_rev] using
          norm_sub_le (D t v) (D t v - F₀ t v)
      have hF : σ * ‖v‖ ≤ ‖F₀ t v‖ := hF₀σ t v
      linarith [mul_le_mul_of_nonneg_right hTσ (norm_nonneg v)]
    have hclose : ∀ᶠ Λ : ℝ in atTop,
        ‖realTorusCutoff Λ g.form - g.form‖ ≤ η * δ (j + 1) := by
      have ht := tendsto_iff_norm_sub_tendsto_zero.mp (tendsto_realTorusCutoff g.form)
      exact ht.eventually (ge_mem_nhds (mul_pos hη (hδ (j + 1))))
    obtain ⟨Λ, hΛB, hΛclose⟩ := ((eventually_ge_atTop B).and hclose).exists
    have hΛ : 0 < Λ := hB.trans_le hΛB
    let G := realTorusCutoff Λ g.form
    let F := fun _ : Unit => D
    have hGram : ∀ E : C(UnitAddTorus d, Cover d →L[ℝ] H),
        torusBlockGram (fun _ : Unit => E) = torusGram E := by
      intro E
      ext t x y
      rw [torusBlockGram_apply, torusGram_apply]
      simp
    have hGband : HasFourierSupport (latticeBall d (2 * Λ)) G :=
      (hasFourierSupport_realTorusCutoff hΛ g.form).mono (torusCutoffBand_subset_latticeBall _)
    have hEnorm : ‖normalizedDefect G (torusBlockGram F) (δ j) (δ (j + 1))‖ ≤ ε := by
      rw [show torusBlockGram F = torusGram D from hGram D]
      refine (norm_normalizedDefect_le g.form G (torusGram D) (hδ j) (hδ _).le hΛclose hmetric).trans ?_
      have heq : (η * δ (j + 1) + e * δ j + δ (j + 1)) / δ j =
          e + (η + 1) * q ^ 2 := by
        rw [hδsucc]
        field_simp [(hδ j).ne']
        ring
      rwa [heq]
    let L := (Λ * bernsteinConstant d) * ‖D‖
    have hbern : 0 ≤ bernsteinConstant d := MeasureTheory.integral_nonneg fun _ => norm_nonneg _
    have hL : 0 ≤ L := by dsimp only [L]; positivity
    have hDband := hband.mono (latticeBall_mono hΛB)
    have hDF (x : Cover d) : ‖fderiv ℝ (fun y => D (flatProjection y)) x‖ ≤ L := by
      have h := hDband.norm_iteratedFDeriv_lift_le_of_radius hΛ (fun _ hk => hk) x 1
      rwa [norm_iteratedFDeriv_one, pow_one] at h
    obtain ⟨N, hN₁, hΛN, hLN, herror⟩ :=
      frequency_for_continuous_step A Λ L K (δ j) (η * δ (j + 1)) (mul_pos hη (hδ _))
    have hN : 0 < N := by exact_mod_cast zero_lt_one.trans_le hN₁
    obtain ⟨V, hV, _, hDb, hV₀, hV₁, _, hVmetric⟩ := hstep g.form G F F₀ () J
      hN (hδ j) (hδj j) hΛ hΛN hL hLN hDM hDσ hJ (fun _ => hDband) hDF
      hGband (g.realTorusCutoff_symmetric hΛ) hEnorm
    let E := torusDifferential V hV
    let w : TorusCorrection d H := ⟨u.val.value + V, u.val.contDiff.add hV⟩
    have hDsum : w.differential = D + E := by
      ext t v
      obtain ⟨x, rfl⟩ := flatProjection_surjective t
      simp only [TorusCorrection.differential, D, E, ContinuousMap.add_apply, torusDifferential_apply]
      exact DFunLike.congr_fun (((u.val.contDiff.differentiable one_ne_zero x).hasFDerivAt.add
        ((hV.differentiable one_ne_zero x).hasFDerivAt)).fderiv) v
    have hV₀' : ‖V‖ ≤ K * a j := by
      refine hV₀.trans ?_
      rw [hsqrt]
      exact (div_le_iff₀ (zero_lt_one.trans_le hN₁)).mpr
        (le_mul_of_one_le_right (by positivity) hN₁)
    have hV₁' : ‖E‖ ≤ K * a j := by rwa [hsqrt] at hV₁
    have hWmetric : ‖torusGram w.differential - (g.form - δ (j + 1) • flatMetric)‖ ≤
        e * δ (j + 1) := by
      have hupdate : Function.update F () (D + E) = fun _ => D + E := by
        funext z
        cases z
        exact Function.update_self () _ _
      change ‖torusBlockGram (Function.update F () (D + E)) -
        (g.form - δ (j + 1) • flatMetric)‖ ≤ _ at hVmetric
      rw [hDsum]
      rw [hupdate, hGram] at hVmetric
      refine hVmetric.trans ?_
      have hdriftSq := pow_le_pow_left₀ (norm_nonneg _) hdriftT 2
      have hterm : K * (δ j * ‖D - F₀‖ ^ 2) ≤ η * δ (j + 1) := by
        rw [hδsucc]
        calc
          _ = δ j * (K * ‖D - F₀‖ ^ 2) := by ring
          _ ≤ δ j * (η * q ^ 2) :=
            mul_le_mul_of_nonneg_left ((mul_le_mul_of_nonneg_left hdriftSq hK).trans hTη) (hδ j).le
          _ = _ := by ring
      change K * (δ j * (Λ / (N : ℝ)) ^ 2 + √(δ j) * L / (N : ℝ) +
        δ j * ‖D - F₀‖ ^ 2) + ‖G - g.form‖ ≤ _
      rw [mul_add]
      have hηe : 3 * η ≤ e := by dsimp only [η]; linarith
      linarith [mul_le_mul_of_nonneg_right hηe (hδ (j + 1)).le]
    have hPw : P (j + 1) w := by
      refine ⟨⟨max Λ (c * (N : ℝ)), hΛ.trans_le (le_max_left _ _), ?_⟩, ?_, hWmetric⟩
      · rw [hDsum]
        exact (hDband.mono (latticeBall_mono (le_max_left _ _))).add
          (hDb.mono (latticeBall_mono (le_max_right _ _)))
      · rw [hDsum, sum_range_succ, add_sub_right_comm]
        exact (norm_add_le _ _).trans (add_le_add hdrift hV₁')
    refine ⟨⟨w, hPw⟩, ?_, ?_⟩
    · change dist u.val.value (u.val.value + V) ≤ _
      rwa [dist_comm, dist_eq_norm, add_sub_cancel_left]
    · change dist D w.differential ≤ _
      rw [dist_comm, dist_eq_norm, hDsum, add_sub_cancel_left]
      exact hV₁'
  choose next hnext using advance
  let u : (j : ℕ) → {u // P j u} :=
    Nat.rec (motive := fun j => {u // P j u}) ⟨u₀, hP₀⟩ next
  let U := fun j => (u j).val
  have hsteps (j) : dist (U j).value (U (j + 1)).value ≤ K * a j ∧
      dist (U j).differential (U (j + 1)).differential ≤ K * a j := hnext j (u j)
  have haSum : Summable (fun j => K * a j) := by
    simpa only [a, ← mul_assoc] using (summable_geometric_of_lt_one hq.le hq₁).mul_left (K * s)
  have hδlim : Tendsto δ atTop (𝓝 0) := by
    have hqpow := tendsto_pow_atTop_nhds_zero_of_lt_one hq.le hq₁
    simpa only [δ, a, mul_zero, zero_pow (by decide : (2 : ℕ) ≠ 0)] using (hqpow.const_mul s).pow 2
  have hmetriclim : Tendsto (fun j => torusGram (U j).differential) atTop (𝓝 g.form) := by
    refine tendsto_iff_norm_sub_tendsto_zero.2
      (squeeze_zero (fun _ => norm_nonneg _) (g := fun j => (e + 1) * δ j) (fun j => ?_) ?_)
    · have hh := (u j).property.2.2
      refine (norm_sub_le_norm_sub_add_norm_sub _ (g.form - δ j • flatMetric) _).trans ?_
      rw [add_mul, one_mul]
      apply add_le_add hh
      have heq : (g.form - δ j • flatMetric) - g.form = -(δ j • flatMetric) := by abel
      rw [heq, norm_neg, norm_smul, Real.norm_eq_abs, abs_of_pos (hδ j)]
      exact mul_le_of_le_one_right (hδ j).le norm_flatMetric_le_one
    · simpa using hδlim.const_mul (e + 1)
  obtain ⟨w, hw, hIso⟩ := exists_isometric_contDiff_limit g (fun j => (U j).value)
    (fun j => (U j).contDiff)
    (Summable.of_nonneg_of_le (fun _ => dist_nonneg) (fun j => (hsteps j).1) haSum)
    (Summable.of_nonneg_of_le (fun _ => dist_nonneg) (fun j => (hsteps j).2) haSum)
    hmetriclim
  let N := Module.finrank ℝ H
  let I : H →ₗᵢ[ℝ] EuclideanSpace ℝ (Fin N) := (stdOrthonormalBasis ℝ H).repr.toLinearIsometry
  let f : TorusCorrection d H := ⟨w, hw⟩
  let v := f.postcomp I.toContinuousLinearMap
  refine ⟨N, v.value, v.contDiff, v.contDiff.differentiable one_ne_zero, fun x a b => ?_⟩
  rw [← torusDifferential_apply v.value v.contDiff x]
  change inner ℝ (v.differential (flatProjection x) a) (v.differential (flatProjection x) b) = _
  have hpost := f.postcomp_differential I.toContinuousLinearMap (flatProjection x)
  change v.differential (flatProjection x) = _ at hpost
  rw [hpost,
    comp_apply, comp_apply, LinearIsometry.coe_toContinuousLinearMap, I.inner_map_map]
  simpa only [TorusCorrection.differential, f, torusDifferential_apply] using hIso.2 x a b

end

end IsometricEmbeddingEndpoints

#print axioms IsometricEmbeddingEndpoints.TorusMetric.exists_euclideanImmersion_contDiff
#check IsometricEmbeddingEndpoints.TorusMetric.exists_euclideanImmersion_contDiff
