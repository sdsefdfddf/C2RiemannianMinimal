import PeriodicHolder
import Mathlib.Analysis.Calculus.FDeriv.Bilinear

namespace IsometricEmbeddingEndpoints

open ContinuousLinearMap
open scoped ContDiff

noncomputable section

variable {d E F G : Type*} [Fintype d]
  [NormedAddCommGroup E] [NormedSpace ℝ E]
  [NormedAddCommGroup F] [NormedSpace ℝ F]
  [NormedAddCommGroup G] [NormedSpace ℝ G]

theorem hasHolderLift_torusDifferential_of_contDiff_two
    (u : C(UnitAddTorus d, E)) (hu : ContDiff ℝ 2 (fun x => u (flatProjection x)))
    (h₁ : ContDiff ℝ 1 (fun x => u (flatProjection x))) {a : ℝ} (ha : 0 ≤ a) (ha₁ : a ≤ 1) :
    HasHolderLift a (torusDifferential u h₁) := by
  apply hasHolderLift_of_contDiff _ _ ha ha₁
  simp only [torusDifferential_apply]
  exact hu.fderiv_right (show 1 + 1 ≤ (2 : WithTop ℕ∞) by norm_num)

theorem contDiff_bilinear_lift (B : E →L[ℝ] F →L[ℝ] G)
    {u : C(UnitAddTorus d, E)} {v : C(UnitAddTorus d, F)} {n : ℕ∞ω}
    (hu : ContDiff ℝ n (fun x => u (flatProjection x)))
    (hv : ContDiff ℝ n (fun x => v (flatProjection x))) :
    ContDiff ℝ n (fun x => B (u (flatProjection x)) (v (flatProjection x))) :=
  (B.contDiff.comp hu).clm_apply hv

/-- On a compact torus the product rule preserves Hölder control of the differential. -/
theorem hasHolderLift_torusDifferential_bilinear
    (B : E →L[ℝ] F →L[ℝ] G) (u : C(UnitAddTorus d, E)) (v : C(UnitAddTorus d, F))
    (hu : ContDiff ℝ 1 (fun x => u (flatProjection x)))
    (hv : ContDiff ℝ 1 (fun x => v (flatProjection x)))
    (hw : ContDiff ℝ 1 (fun x => B (u (flatProjection x)) (v (flatProjection x))))
    {a : ℝ} (ha : 0 ≤ a) (ha₁ : a ≤ 1)
    (hdu : HasHolderLift a (torusDifferential u hu))
    (hdv : HasHolderLift a (torusDifferential v hv)) :
    HasHolderLift a (torusDifferential
      ⟨fun t => B (u t) (v t), (B.continuous.comp u.continuous).clm_apply v.continuous⟩ hw) := by
  let D := Cover d
  let w : C(UnitAddTorus d, G) :=
    ⟨fun t => B (u t) (v t), (B.continuous.comp u.continuous).clm_apply v.continuous⟩
  let R := B.precompR D
  let L := B.precompL D
  let du := torusDifferential u hu
  let dv := torusDifferential v hv
  let A : C(UnitAddTorus d, D →L[ℝ] G) :=
    ⟨fun t => R (u t) (dv t), (R.continuous.comp u.continuous).clm_apply dv.continuous⟩
  let C : C(UnitAddTorus d, D →L[ℝ] G) :=
    ⟨fun t => L (du t) (v t), (L.continuous.comp du.continuous).clm_apply v.continuous⟩
  have hR : HasHolderLift a A := (hasHolderLift_of_contDiff u hu ha ha₁).bilinear R hdv
  have hL : HasHolderLift a C := hdu.bilinear L (hasHolderLift_of_contDiff v hv ha ha₁)
  have heq : torusDifferential w hw = A + C := by
    apply ContinuousMap.ext
    intro t
    obtain ⟨x, rfl⟩ := flatProjection_surjective t
    change torusDifferential w hw (flatProjection x) =
      R (u (flatProjection x)) (torusDifferential v hv (flatProjection x)) +
        L (torusDifferential u hu (flatProjection x)) (v (flatProjection x))
    simp only [torusDifferential_apply]
    exact (B.hasFDerivAt_of_bilinear ((hu.differentiable one_ne_zero x).hasFDerivAt)
      ((hv.differentiable one_ne_zero x).hasFDerivAt)).fderiv
  change HasHolderLift a (torusDifferential w hw)
  rw [heq]
  exact hR.add hL

/-- The chain rule for pulling back a locally defined (C^{1,a}) function by
a periodic map whose differential also has exponent (a). -/
theorem hasHolderLift_torusDifferential_comp {a C : ℝ} {s : Set E} (hs : IsOpen s)
    {f : E → F} (hf : ContDiffOn ℝ 1 f s)
    (ha : 0 ≤ a) (hC : 0 ≤ C)
    (hdf : ∀ x ∈ s, ∀ y ∈ s, ‖fderiv ℝ f x - fderiv ℝ f y‖ ≤ C * ‖x - y‖ ^ a)
    (u : C(UnitAddTorus d, E)) (hu : ContDiff ℝ 1 (fun x => u (flatProjection x)))
    (hus : ∀ t, u t ∈ s) (hdu : HasHolderLift a (torusDifferential u hu))
    (hfu : ContDiff ℝ 1 (fun x => f (u (flatProjection x)))) :
    HasHolderLift a (torusDifferential
      ⟨f ∘ u, hf.continuousOn.comp_continuous u.continuous hus⟩ hfu) := by
  let q : C(UnitAddTorus d, F) := ⟨f ∘ u, hf.continuousOn.comp_continuous u.continuous hus⟩
  have hdfc := hf.continuousOn_fderiv_of_isOpen hs le_rfl
  let V : C(UnitAddTorus d, E →L[ℝ] F) :=
    ⟨fderiv ℝ f ∘ u, hdfc.comp_continuous u.continuous hus⟩
  let W := torusDifferential u hu
  let L := compL ℝ (Cover d) E F
  let D : C(UnitAddTorus d, Cover d →L[ℝ] F) :=
    ⟨fun t => L (V t) (W t), (L.continuous.comp V.continuous).clm_apply W.continuous⟩
  have hV : HasHolderLift a V := HasHolderLift.of_comp hdfc hC ha hdf u hu hus
  have heq : torusDifferential q hfu = D := by
    apply ContinuousMap.ext
    intro t
    obtain ⟨x, rfl⟩ := flatProjection_surjective t
    change torusDifferential q hfu (flatProjection x) =
      (fderiv ℝ f (u (flatProjection x))).comp (torusDifferential u hu (flatProjection x))
    simp only [torusDifferential_apply]
    have h := (hf.contDiffAt (hs.mem_nhds (hus (flatProjection x)))).differentiableAt one_ne_zero
    exact (h.hasFDerivAt.comp x ((hu.differentiable one_ne_zero x).hasFDerivAt)).fderiv
  change HasHolderLift a (torusDifferential q hfu)
  rw [heq]
  exact hV.bilinear L hdu

theorem hasHolderLift_torusDifferential_postcomp {a : ℝ}
    (u : C(UnitAddTorus d, E)) (hu : ContDiff ℝ 1 (fun x => u (flatProjection x)))
    (T : E →L[ℝ] F) (hdu : HasHolderLift a (torusDifferential u hu))
    (hv : ContDiff ℝ 1 (fun x => T (u (flatProjection x)))) :
    HasHolderLift a (torusDifferential ⟨T ∘ u, T.continuous.comp u.continuous⟩ hv) := by
  let v : C(UnitAddTorus d, F) := ⟨T ∘ u, T.continuous.comp u.continuous⟩
  let L := compL ℝ (Cover d) E F T
  let D := torusDifferential u hu
  let V : C(UnitAddTorus d, Cover d →L[ℝ] F) := ⟨L ∘ D, L.continuous.comp D.continuous⟩
  have heq : torusDifferential v hv = V := by
    apply ContinuousMap.ext
    intro t
    obtain ⟨x, rfl⟩ := flatProjection_surjective t
    change torusDifferential v hv (flatProjection x) =
      T.comp (torusDifferential u hu (flatProjection x))
    simp only [torusDifferential_apply]
    exact (T.hasFDerivAt.comp x ((hu.differentiable one_ne_zero x).hasFDerivAt)).fderiv
  change HasHolderLift a (torusDifferential v hv)
  rw [heq]
  exact hdu.postcomp L

theorem hasHolderLift_torusDifferential_add {a : ℝ}
    (u v : C(UnitAddTorus d, F))
    (hu : ContDiff ℝ 1 (fun x => u (flatProjection x)))
    (hv : ContDiff ℝ 1 (fun x => v (flatProjection x)))
    (hdu : HasHolderLift a (torusDifferential u hu))
    (hdv : HasHolderLift a (torusDifferential v hv)) :
    HasHolderLift a (torusDifferential (u + v) (hu.add hv)) := by
  have heq : torusDifferential (u + v) (hu.add hv) =
      torusDifferential u hu + torusDifferential v hv := by
    apply ContinuousMap.ext
    intro t
    obtain ⟨x, rfl⟩ := flatProjection_surjective t
    simp only [ContinuousMap.add_apply, torusDifferential_apply]
    exact (((hu.differentiable one_ne_zero x).hasFDerivAt).add
      ((hv.differentiable one_ne_zero x).hasFDerivAt)).fderiv
  rw [heq]
  exact hdu.add hdv

end

end IsometricEmbeddingEndpoints

#print axioms IsometricEmbeddingEndpoints.hasHolderLift_torusDifferential_bilinear
#print axioms IsometricEmbeddingEndpoints.hasHolderLift_torusDifferential_comp
