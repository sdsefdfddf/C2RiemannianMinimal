import AmplitudeRegularity
import ProjectedCutoffStage

namespace IsometricEmbeddingEndpoints

open ContinuousLinearMap

noncomputable section

variable {d H : Type*} [Fintype d] [NormedAddCommGroup H] [InnerProductSpace ℝ H]

/-- Normal projection acts on the amplitude of each carrier without changing its frequency. -/
theorem projectedWave_sum_carriers {ι : Type*} (s : Finset ι)
    (n : ι → d → ℤ) (c : ι → ℂ) (A : ι → C(UnitAddTorus d, H))
    (Q : C(UnitAddTorus d, H →L[ℝ] H)) :
    projectedWave Q (∑ i ∈ s, fourierCarrier (n i) (c i) • A i) =
      ∑ i ∈ s, fourierCarrier (n i) (c i) • projectedWave Q (A i) := by
  ext x
  change normalPart (Q x)
    (ContinuousMap.evalCLM ℝ x (∑ i ∈ s, fourierCarrier (n i) (c i) • A i)) =
      ContinuousMap.evalCLM ℝ x (∑ i ∈ s, fourierCarrier (n i) (c i) • projectedWave Q (A i))
  rw [map_sum, map_sum, map_sum]
  apply Finset.sum_congr rfl
  intro i _
  change normalPart (Q x) (fourierCarrier (n i) (c i) x • A i x) =
    fourierCarrier (n i) (c i) x • normalPart (Q x) (A i x)
  exact map_smul _ _ _

variable [CompleteSpace H]

/-- A common low frequency scale for the amplitudes and normal projection gives
the corresponding differentiated cutoff bound for their entire projected wave. -/
theorem norm_fderiv_cutoff_projectedWave_sub_le_of_carriers {ι : Type*}
    {scale Λ M : ℝ} (hs : 0 < scale) (hΛ : 0 ≤ Λ) (hM : 0 ≤ M)
    (s : Finset ι) (n : ι → d → ℤ) (c : ι → ℂ) (C : ι → ℝ)
    (Q : C(UnitAddTorus d, H →L[ℝ] H)) (A : ι → C(UnitAddTorus d, H))
    (hband : ∀ i ∈ s, ‖scale⁻¹ • latticeVector (n i)‖ < 1)
    (hC : ∀ i ∈ s, 0 ≤ C i)
    (hQ : ContDiff ℝ 2 (fun z => normalPart (Q (flatProjection z))))
    (hA : ∀ i ∈ s, ContDiff ℝ 2 (fun z => A i (flatProjection z)))
    (hQ' : ∀ x j, j ≤ 2 →
      ‖iteratedFDeriv ℝ j (fun z => normalPart (Q (flatProjection z))) x‖ ≤ M * Λ ^ j)
    (hA' : ∀ i ∈ s, ∀ x j, j ≤ 2 →
      ‖iteratedFDeriv ℝ j (fun z => A i (flatProjection z)) x‖ ≤ C i * Λ ^ j)
    (x : Cover d) :
    let V := projectedWave Q (∑ i ∈ s, fourierCarrier (n i) (c i) • A i)
    ‖fderiv ℝ (fun z => realTorusCutoff scale V (flatProjection z)) x -
      fderiv ℝ (fun z => V (flatProjection z)) x‖ ≤
        4 * M * (∑ i ∈ s, C i * ‖c i‖) * Λ ^ 2 * scale⁻¹ *
          (torusCutoffMoment d 1 + (4 * Real.pi) * torusCutoffMoment d 2) := by
  dsimp only
  rw [projectedWave_sum_carriers]
  let B : (H →L[ℝ] H) →L[ℝ] H →L[ℝ] H := (ContinuousLinearMap.apply ℝ H).flip
  have hB : ‖B‖ ≤ 1 := by
    refine B.opNorm_le_bound₂ zero_le_one fun P w => ?_
    change ‖P w‖ ≤ 1 * ‖P‖ * ‖w‖
    simpa only [one_mul] using P.le_opNorm w
  let R := fun i => ‖B‖ * (4 * (M * C i * Λ ^ 2))
  have h (i) (hi : i ∈ s) (y : Cover d) :
      ‖iteratedFDeriv ℝ 2 (fun z => projectedWave Q (A i) (flatProjection z)) y‖ ≤ R i := by
    change ‖iteratedFDeriv ℝ 2 (fun z => B (normalPart (Q (flatProjection z))) (A i (flatProjection z))) y‖ ≤ _
    calc
      _ ≤ ‖B‖ * (2 ^ 2 * (M * C i * Λ ^ 2)) :=
        norm_iteratedFDeriv_bilinear_le_of_scaled_bounds B hQ (hA i hi) y hM hΛ
          (hQ' y) (hA' i hi y)
      _ = _ := by norm_num [R]
  have hsum : (∑ i ∈ s, R i * ‖c i‖) ≤ 4 * M * (∑ i ∈ s, C i * ‖c i‖) * Λ ^ 2 := by
    rw [Finset.mul_sum, Finset.sum_mul]
    apply Finset.sum_le_sum
    intro i hi
    have hCi := hC i hi
    calc
      _ ≤ (1 * (4 * (M * C i * Λ ^ 2))) * ‖c i‖ :=
        mul_le_mul_of_nonneg_right (mul_le_mul_of_nonneg_right hB (by positivity)) (norm_nonneg _)
      _ = _ := by ring
  have hb : 0 ≤ torusCutoffMoment d 1 + (4 * Real.pi) * torusCutoffMoment d 2 :=
    add_nonneg (torusCutoffMoment_nonneg 1)
      (mul_nonneg (by positivity) (torusCutoffMoment_nonneg 2))
  exact (norm_fderiv_realTorusCutoff_sub_le_of_carriers hs s n c
    (fun i => projectedWave Q (A i)) R hband (fun i hi => by
      have hCi := hC i hi
      dsimp only [R]
      positivity)
      (fun i hi => hQ.clm_apply (hA i hi)) h x).trans
      (mul_le_mul_of_nonneg_right (mul_le_mul_of_nonneg_right hsum (inv_nonneg.mpr hs.le)) hb)

end

end IsometricEmbeddingEndpoints

#print axioms IsometricEmbeddingEndpoints.norm_fderiv_cutoff_projectedWave_sub_le_of_carriers
