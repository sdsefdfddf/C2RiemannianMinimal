import Mathlib.Analysis.Calculus.ContDiff.Bounds
import Mathlib.Analysis.Normed.Group.Bounded

namespace IsometricEmbeddingEndpoints

variable {E F H : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E]
  [NormedAddCommGroup F] [NormedSpace ℝ F] [NormedAddCommGroup H] [NormedSpace ℝ H]

/-- The usual derivative bound for a composition applies when the outer function is smooth
in a neighborhood of each point in the range of the inner function. -/
theorem norm_iteratedFDeriv_comp_le_of_contDiffAt {f : E → F} {g : F → H}
    {n : ℕ} (hf : ContDiff ℝ n f) (hg : ∀ x, ContDiffAt ℝ n g (f x)) (x : E) {C D : ℝ}
    (hC : ∀ i, i ≤ n → ‖iteratedFDeriv ℝ i g (f x)‖ ≤ C)
    (hD : ∀ i, 1 ≤ i → i ≤ n → ‖iteratedFDeriv ℝ i f x‖ ≤ D ^ i) :
    ‖iteratedFDeriv ℝ n (g ∘ f) x‖ ≤ n.factorial * C * D ^ n := by
  let t := {y : F | ContDiffAt ℝ n g y}
  have ht : IsOpen t := isOpen_iff_mem_nhds.2 fun y hy =>
    (show ContDiffAt ℝ n g y from hy).eventually (by simp)
  have hft : Set.range f ⊆ t := by
    rintro _ ⟨z, rfl⟩
    exact hg z
  have hgt : ContDiffOn ℝ n g t := fun _ hy => hy.contDiffWithinAt
  apply norm_iteratedFDeriv_comp_le' hft ht.uniqueDiffOn hgt hf le_rfl x _ hD
  intro i hi
  rw [iteratedFDerivWithin_of_isOpen i ht (hft (Set.mem_range_self x))]
  exact hC i hi

/-- Derivative bounds for the outer function can be fixed in advance when the inner function
takes values in a fixed compact subset of its smoothness domain. -/
theorem exists_uniform_iteratedFDeriv_comp_le {g : F → H} {S : Set F} (hS : IsCompact S)
    (n : ℕ) (hg : ∀ y ∈ S, ContDiffAt ℝ n g y) :
    ∃ C : ℝ, 0 ≤ C ∧ ∀ (f : E → F) (D : ℝ), ContDiff ℝ n f → Set.range f ⊆ S →
      ∀ (x : E) (j : ℕ), j ≤ n →
        (∀ i, 1 ≤ i → i ≤ j → ‖iteratedFDeriv ℝ i f x‖ ≤ D ^ i) →
        ‖iteratedFDeriv ℝ j (g ∘ f) x‖ ≤ j.factorial * C * D ^ j := by
  have hbound (i : Fin (n + 1)) : ∃ A : ℝ, ∀ y ∈ S, ‖iteratedFDeriv ℝ (i : ℕ) g y‖ ≤ A := by
    apply hS.exists_bound_of_continuousOn
    intro y hy
    have hi : (i : ℕ) ≤ n := Nat.lt_succ_iff.mp i.isLt
    exact ((hg y hy).continuousAt_iteratedFDeriv (mod_cast hi)).continuousWithinAt
  choose A hA using hbound
  let C := ∑ i, max 0 (A i)
  have hC : 0 ≤ C := Finset.sum_nonneg fun _ _ => le_max_left _ _
  refine ⟨C, hC, fun f D hf hSf x j hj hD => ?_⟩
  have hj' : (j : WithTop ℕ∞) ≤ n := by exact_mod_cast hj
  apply norm_iteratedFDeriv_comp_le_of_contDiffAt (hf.of_le hj')
    (fun z => (hg _ (hSf (Set.mem_range_self z))).of_le hj') x _ hD
  intro i hi
  let a : Fin (n + 1) := ⟨i, Nat.lt_succ_of_le (hi.trans hj)⟩
  exact (hA a _ (hSf (Set.mem_range_self x))).trans
    ((le_max_right _ _).trans (Finset.single_le_sum (f := fun k => max 0 (A k))
      (fun k _ => le_max_left _ _) (Finset.mem_univ a)))

end IsometricEmbeddingEndpoints

#print axioms IsometricEmbeddingEndpoints.norm_iteratedFDeriv_comp_le_of_contDiffAt
#print axioms IsometricEmbeddingEndpoints.exists_uniform_iteratedFDeriv_comp_le
