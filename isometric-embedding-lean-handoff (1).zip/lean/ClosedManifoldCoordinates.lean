import ClosedManifoldStatement
import ManifoldLowStatement
import CenteredChartCover
import Mathlib.Geometry.Manifold.VectorBundle.Hom

open scoped ContDiff Manifold NNReal Topology
open Bundle Filter Function Set

namespace IsometricEmbeddingEndpoints

noncomputable section

variable {d N : ℕ} {M : Type*} [TopologicalSpace M] [ChartedSpace (Euclidean d) M]

local notation "𝓔" d:arg => 𝓘(ℝ, Euclidean d)
local notation "T" M:arg => TangentSpace (𝓔 d) (M := M)
local notation "Q" => MetricForm (Fin d)
local notation "K₀" r:arg => Metric.closedBall (0 : Euclidean d) r
local notation "φ" p:arg => extChartAt (𝓔 d) p
local notation "c" p:arg => centeredChart (d := Fin d) p

/-- The same metric viewed as the pointwise field used in the construction. -/
def metricField (g : Bundle.RiemannianMetric (T M)) : RiemannianMetric (Fin d) M :=
  ⟨g.inner, g.symm, g.pos⟩

variable [IsManifold (𝓔 d) ∞ M]

local instance : NormedAddCommGroup Q := inferInstance
local instance : NormedSpace ℝ Q := inferInstance

private def metricSection (g : Bundle.RiemannianMetric (T M)) (p q : M) : Q :=
  (trivializationAt Q
    (fun y : M => (T M) y →L[ℝ] (T M) y →L[ℝ] ℝ) p ⟨q, g.inner q⟩).2

set_option backward.isDefEq.respectTransparency false in
private theorem metricInChart_eq_section (g : Bundle.RiemannianMetric (T M))
    (p : M) {x : Euclidean d} (hx : x ∈ (φ p).target) :
    metricInChart g p x = metricSection g p ((φ p).symm x) := by
  let q := (φ p).symm x
  have hq : q ∈ (chartAt (Euclidean d) p).source := by
    rw [← extChartAt_source (𝓔 d)]
    exact (φ p).map_target hx
  have hb : q ∈ (trivializationAt (Euclidean d) (T M) p).baseSet := by
    simpa only [TangentBundle.trivializationAt_baseSet] using hq
  let A := (trivializationAt (Euclidean d) (T M) p).symmL ℝ q
  have hA : A = mfderiv (𝓔 d) (𝓔 d) (φ p).symm x := by
    dsimp [A]
    rw [TangentBundle.symmL_trivializationAt hq]
    change (mfderivWithin (𝓔 d) (𝓔 d) (φ p).symm (range (𝓔 d)) ((φ p) q) :
      Euclidean d →L[ℝ] Euclidean d) = _
    rw [show range (𝓔 d) = univ from range_id, mfderivWithin_univ]
    let D : Euclidean d → (Euclidean d →L[ℝ] Euclidean d) :=
      fun y => mfderiv (𝓔 d) (𝓔 d) (φ p).symm y
    exact congrArg D ((φ p).right_inv hx)
  ext u v
  have ev : metricInChart g p x u v = g.inner q (A u) (A v) := by
    rw [hA]
    rfl
  rw [ev]
  simp only [metricSection, hom_trivializationAt_apply]
  rw [inCoordinates_apply_eq₂ hb hb (mem_univ q)]
  simp only [Trivial.fiberBundle_trivializationAt', Trivial.linearMapAt_trivialization,
    LinearMap.id_coe, id_eq, A, Trivialization.symmL_apply _ hb]
  rfl

theorem metricInChart_continuousOn
    (g : Bundle.ContinuousRiemannianMetric (Euclidean d) (T M)) (p : M) :
    ContinuousOn (metricInChart g.toRiemannianMetric p) (φ p).target := by
  let b : M → TotalSpace Q (fun y : M => (T M) y →L[ℝ] (T M) y →L[ℝ] ℝ) :=
    fun y => ⟨y, g.inner y⟩
  let e := trivializationAt Q (fun y : M => (T M) y →L[ℝ] (T M) y →L[ℝ] ℝ) p
  have hb : Continuous b := g.continuous
  have hsrc : MapsTo b (φ p).source e.source := fun y hy => by
    have hbase : (trivializationAt ℝ (fun _ : M => ℝ) p).baseSet = univ := rfl
    rw [e.mem_source, hom_trivializationAt_baseSet, hom_trivializationAt_baseSet,
      TangentBundle.trivializationAt_baseSet, hbase, inter_univ, inter_self]
    simpa only [extChartAt_source] using hy
  have hsec : ContinuousOn (metricSection g.toRiemannianMetric p) (φ p).source :=
    continuous_snd.comp_continuousOn (e.continuousOn.comp hb.continuousOn hsrc)
  have hi : ContinuousOn (φ p).symm (φ p).target :=
    (contMDiffOn_extChartAt_symm (I := 𝓔 d) (n := ∞) (x := p)).continuousOn
  exact (hsec.comp hi (φ p).mapsTo_symm).congr
    fun _ hx => metricInChart_eq_section _ p hx

theorem metricInChart_contDiffAt
    (g : Bundle.ContMDiffRiemannianMetric (𝓔 d) 1 (Euclidean d) (T M)) (p : M) :
    ContDiffAt ℝ 1 (metricInChart g.toRiemannianMetric p) ((φ p) p) := by
  have hsec : ContMDiffAt (𝓔 d) 𝓘(ℝ, Q) 1
      (metricSection g.toRiemannianMetric p) p :=
    (Bundle.contMDiffAt_section_iff (F := Q) p).mp (g.contMDiff p)
  have hp : (φ p) p ∈ (φ p).target := mem_extChartAt_target p
  have hi := (contMDiffOn_extChartAt_symm (I := 𝓔 d) (n := 1) (x := p)).contMDiffAt
    ((isOpen_extChartAt_target (I := 𝓔 d) p).mem_nhds hp)
  have hp' : (φ p).symm ((φ p) p) = p :=
    (φ p).left_inv (mem_extChartAt_source p)
  have heq : metricInChart g.toRiemannianMetric p =ᶠ[𝓝 ((φ p) p)]
      metricSection g.toRiemannianMetric p ∘ (φ p).symm := by
    filter_upwards [(isOpen_extChartAt_target (I := 𝓔 d) p).mem_nhds hp] with x hx
    exact metricInChart_eq_section _ p hx
  have hsec' : ContMDiffAt (𝓔 d) 𝓘(ℝ, Q) 1 (metricSection g.toRiemannianMetric p)
      ((φ p).symm ((φ p) p)) := hp'.symm ▸ hsec
  exact (hsec'.comp _ hi).contDiffAt.congr_of_eventuallyEq heq

omit [IsManifold (𝓔 d) ∞ M] in
private theorem centeredChart_target_add {p : M} {x : Euclidean d} :
    x ∈ (c p).target ↔ x + (φ p) p ∈ (φ p).target := by
  rw [extChartAt_target, show range (𝓔 d) = univ from range_id, inter_univ]
  rfl

omit [IsManifold (𝓔 d) ∞ M] in
private theorem centeredChart_symm_add (p : M) (x : Euclidean d) :
    (c p).symm x = (φ p).symm (x + (φ p) p) := rfl

set_option backward.isDefEq.respectTransparency false in
private theorem metricField_centeredChart (g : Bundle.RiemannianMetric (T M))
    (p : M) {x : Euclidean d} (hx : x ∈ (c p).target) :
    (metricField g).inChart (c p) x = metricInChart g p (x + (φ p) p) := by
  let y := x + (φ p) p
  have hy : y ∈ (φ p).target := centeredChart_target_add.mp hx
  have hchart := ((contMDiffOn_extChartAt_symm (I := 𝓔 d) (n := ∞) (x := p)).contMDiffAt
    ((isOpen_extChartAt_target (I := 𝓔 d) p).mem_nhds hy)).mdifferentiableAt (by simp)
  have ha : HasFDerivAt (fun z : Euclidean d => z + (φ p) p)
      (ContinuousLinearMap.id ℝ (Euclidean d)) x := (hasFDerivAt_id x).add_const _
  have hD : mfderiv (𝓔 d) (𝓔 d) (c p).symm x =
      mfderiv (𝓔 d) (𝓔 d) (φ p).symm y := by
    rw [show ((c p).symm : Euclidean d → M) =
      ((φ p).symm : Euclidean d → M) ∘ (fun z => z + (φ p) p) from rfl]
    rw [mfderiv_comp x hchart ha.differentiableAt.mdifferentiableAt, mfderiv_eq_fderiv,
      ha.fderiv]
    rfl
  ext v w
  simp only [RiemannianMetric.inChart, metricInChart, pullbackMetricForm_apply,
    ContinuousLinearMap.bilinearComp_apply, centeredChart_symm_add, hD]
  rfl

omit [IsManifold (𝓔 d) ∞ M] in
private theorem smallCenteredBall (p : M) {s : Set (Euclidean d)}
    (hs : s ∈ 𝓝 ((φ p) p)) :
    ∃ r : ℝ, 0 < r ∧ K₀ r ⊆ (c p).target ∧
      MapsTo (fun x => x + (φ p) p) (K₀ r) s := by
  have htarget := (c p).open_target.mem_nhds (zero_mem_centeredChart_target p)
  have hcontinuous : Continuous (fun x : Euclidean d => x + (φ p) p) :=
    continuous_id.add continuous_const
  have hadd : Tendsto (fun x : Euclidean d => x + (φ p) p) (𝓝 0) (𝓝 ((φ p) p)) := by
    simpa only [zero_add] using hcontinuous.continuousAt.tendsto (x := (0 : Euclidean d))
  obtain ⟨r, hr, h⟩ := Metric.nhds_basis_closedBall.mem_iff.mp (inter_mem htarget (hadd hs))
  exact ⟨r, hr, h.trans inter_subset_left, h.trans inter_subset_right⟩

theorem metricField_holderInCharts (g : Bundle.ContinuousRiemannianMetric (Euclidean d) (T M))
    {a : ℝ≥0} (hg : HolderInCharts a (metricInChart g.toRiemannianMetric)) :
    (metricField g.toRiemannianMetric).holderInCharts (a : ℝ) := by
  intro p
  obtain ⟨C, s, hs, hH⟩ := hg p
  obtain ⟨r, hr, ht, hmap⟩ := smallCenteredBall p hs
  let F := metricInChart g.toRiemannianMetric p
  have hEq : EqOn ((metricField g.toRiemannianMetric).inChart (c p))
      (fun x => F (x + (φ p) p)) (c p).target :=
    fun _ hx => metricField_centeredChart _ p hx
  have hmapt : MapsTo (fun x => x + (φ p) p) (K₀ r) (φ p).target :=
    fun x hx => centeredChart_target_add.mp (ht hx)
  refine ⟨r, hr, ht, ?_, Or.inr ⟨C, C.coe_nonneg, ?_⟩⟩
  · exact ((metricInChart_continuousOn g p).comp (continuous_id.add continuous_const).continuousOn
      hmapt).congr (hEq.mono ht)
  · intro x hx y hy
    rw [hEq (ht hx), hEq (ht hy)]
    simpa [dist_eq_norm] using hH.dist_le (hmap hx) (hmap hy)

theorem metricField_holderDifferentialInCharts
    (g : Bundle.ContMDiffRiemannianMetric (𝓔 d) 1 (Euclidean d) (T M)) {a : ℝ≥0}
    (hg : HolderDifferentialInCharts a (metricInChart g.toRiemannianMetric)) :
    (metricField g.toRiemannianMetric).holderDifferentialInCharts (a : ℝ) := by
  intro p
  obtain ⟨C, s, hs, hH⟩ := hg p
  have hs' := inter_mem hs ((metricInChart_contDiffAt g p).eventually (by simp))
  obtain ⟨r, hr, ht, hmap⟩ := smallCenteredBall p hs'
  let F := metricInChart g.toRiemannianMetric p
  have hEq (x : Euclidean d) (hx : x ∈ K₀ r) :
      (metricField g.toRiemannianMetric).inChart (c p) =ᶠ[𝓝 x]
        fun y => F (y + (φ p) p) := by
    filter_upwards [(c p).open_target.mem_nhds (ht hx)] with y hy
    exact metricField_centeredChart _ p hy
  refine ⟨r, hr, ht, fun x hx => ?_, C, C.coe_nonneg, ?_⟩
  · have ht' : ContDiffAt ℝ 1 (fun y : Euclidean d => y + (φ p) p) x :=
      contDiffAt_id.add contDiffAt_const
    have hF : ContDiffAt ℝ 1 F (x + (φ p) p) := (hmap hx).2
    have hcomp := ContDiffAt.comp (g := F) x hF ht'
    exact hcomp.congr_of_eventuallyEq (hEq x hx)
  · intro x hx y hy
    rw [(hEq x hx).fderiv_eq, (hEq y hy).fderiv_eq, fderiv_comp_add_right, fderiv_comp_add_right]
    simpa [dist_eq_norm] using hH.dist_le (hmap hx).1 (hmap hy).1

omit [IsManifold (𝓔 d) ∞ M] in
theorem holderDifferentialInCharts_of_centered {a : ℝ≥0} {u : M → Euclidean N}
    (h : ∀ p, HasLocalHolderDifferentialAt (d := Fin d) a u p) :
    HolderDifferentialInCharts a (fun p => writtenInExtChartAt (𝓔 d) (𝓔 N) p u) := by
  intro p
  obtain ⟨r, hr, _, _, C, hC, hest⟩ := h p
  let q := (φ p) p
  have hx (x : Euclidean d) (hx : x ∈ Metric.closedBall q r) : x - q ∈ K₀ r := by
    simpa [dist_eq_norm] using hx
  have hEq : writtenInExtChartAt (𝓔 d) (𝓔 N) p u =
      (fun x => (u ∘ (c p).symm) (x - q)) := by
    funext x
    simp [writtenInExtChartAt, centeredChart_symm_add, q]
  refine ⟨⟨C, hC⟩, Metric.closedBall q r, Metric.closedBall_mem_nhds _ hr, ?_⟩
  intro x hxs y hys
  change edist (fderiv ℝ (writtenInExtChartAt (𝓔 d) (𝓔 N) p u) x)
    (fderiv ℝ (writtenInExtChartAt (𝓔 d) (𝓔 N) p u) y) ≤ _
  rw [hEq, fderiv_comp_sub, fderiv_comp_sub]
  have hn := hest _ (hx x hxs) _ (hx y hys)
  simp only [← dist_eq_norm, dist_sub_right] at hn
  simpa [edist_dist, ENNReal.ofReal_mul hC, ENNReal.ofReal_eq_coe_nnreal hC, NNReal.mk,
    ENNReal.ofReal_rpow_of_nonneg dist_nonneg a.coe_nonneg] using
    (ENNReal.ofReal_le_ofReal hn)

end

end IsometricEmbeddingEndpoints
