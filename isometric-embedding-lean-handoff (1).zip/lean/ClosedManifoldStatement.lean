module

public import Mathlib.Analysis.InnerProductSpace.PiL2
public import Mathlib.Geometry.Manifold.MFDeriv.NormedSpace
public import Mathlib.Geometry.Manifold.SmoothEmbedding
public import Mathlib.Geometry.Manifold.VectorBundle.Riemannian
public import Mathlib.Topology.MetricSpace.Holder

/-!
# Low-regularity isometric embeddings of closed manifolds

Public definitions for the two endpoint theorems.
-/

@[expose] public section

open scoped ContDiff Manifold NNReal Topology

namespace IsometricEmbeddingEndpoints

/-- Real Euclidean space of dimension `d`. -/
abbrev Euclidean (d : ℕ) := EuclideanSpace ℝ (Fin d)

local notation "𝓔" d:arg => 𝓘(ℝ, Euclidean d)

variable {d N : ℕ} {M : Type*} [TopologicalSpace M] [ChartedSpace (Euclidean d) M]

local notation "T" M:arg => TangentSpace (𝓔 d) (M := M)

set_option backward.isDefEq.respectTransparency false in
/-- The metric pulled back by the inverse of the chart at `p`. -/
noncomputable def metricInChart
    (g : Bundle.RiemannianMetric (T M)) (p : M) (x : Euclidean d) :
    Euclidean d →L[ℝ] Euclidean d →L[ℝ] ℝ :=
  let chartInv := (extChartAt (𝓔 d) p).symm
  let q := chartInv x
  let D := mfderiv (𝓔 d) (𝓔 d) chartInv x
  (g.inner q).bilinearComp D D

/-- The coordinate functions `f p` are `a`-Hölder near the image of `p` in its chart. -/
def HolderInCharts {F : Type*} [PseudoMetricSpace F]
    (a : ℝ≥0) (f : M → Euclidean d → F) : Prop :=
  ∀ p, ∃ C : ℝ≥0, ∃ s ∈ 𝓝 (extChartAt (𝓔 d) p p), HolderOnWith C a (f p) s

/-- The differentials of the coordinate functions `f p` are locally `a`-Hölder. -/
def HolderDifferentialInCharts {F : Type*} [NormedAddCommGroup F] [NormedSpace ℝ F]
    (a : ℝ≥0) (f : M → Euclidean d → F) : Prop :=
  HolderInCharts a (fun p => fderiv ℝ (f p))

/-- A `C¹` embedding which pulls back the Euclidean metric to `g`. -/
def IsC1IsometricEmbedding (g : Bundle.RiemannianMetric (T M)) (u : M → Euclidean N) : Prop :=
  Manifold.IsSmoothEmbedding (𝓔 d) (𝓔 N) 1 u ∧
    ∀ p v w,
      let D := mvfderiv (𝓔 d) u p
      inner ℝ (D v) (D w) = g.inner p v w

/-- A `C¹` isometric embedding whose differential is locally `a`-Hölder in charts. -/
def IsHolderIsometricEmbedding (g : Bundle.RiemannianMetric (T M))
    (a : ℝ≥0) (u : M → Euclidean N) : Prop :=
  IsC1IsometricEmbedding g u ∧
    HolderDifferentialInCharts a (fun p => writtenInExtChartAt (𝓔 d) (𝓔 N) p u)

end IsometricEmbeddingEndpoints
