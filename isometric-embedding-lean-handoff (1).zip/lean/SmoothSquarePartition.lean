import Mathlib.Geometry.Manifold.PartitionOfUnity
import Mathlib.Geometry.Manifold.Algebra.LieGroup
import Mathlib.Analysis.SpecialFunctions.Sqrt

namespace IsometricEmbeddingEndpoints

open Set Function
open scoped Manifold Topology ContDiff

noncomputable section

variable {ι E H M : Type*} [Fintype ι]
  [NormedAddCommGroup E] [NormedSpace ℝ E] [FiniteDimensional ℝ E]
  [TopologicalSpace H] {I : ModelWithCorners ℝ E H}
  [TopologicalSpace M] [T2Space M] [CompactSpace M] [ChartedSpace H M] [IsManifold I ∞ M]

/-- Normalize a finite smooth partition of unity so that the squares of its
weights sum to one. The topological supports remain subordinate to the cover. -/
theorem exists_smoothSquarePartition (U : ι → Set M) (hopen : ∀ i, IsOpen (U i))
    (hcover : (Set.univ : Set M) ⊆ ⋃ i, U i) :
    ∃ w : ι → M → ℝ,
      (∀ i, ContMDiff I 𝓘(ℝ) ∞ (w i)) ∧
      (∀ i, tsupport (w i) ⊆ U i) ∧
      ∀ x, ∑ i, w i x ^ 2 = 1 := by
  classical
  obtain ⟨p, hp⟩ := SmoothPartitionOfUnity.exists_isSubordinate (I := I) isClosed_univ U hopen hcover
  let Q := fun x : M => ∑ i, (p i x) ^ 2
  have hQ (x : M) : 0 < Q x := by
    obtain ⟨i, hi⟩ := p.exists_pos_of_mem (Set.mem_univ x)
    have h := Finset.single_le_sum (f := fun i => (p i x) ^ 2) (fun j _ => sq_nonneg (p j x))
      (Finset.mem_univ i)
    exact (sq_pos_of_pos hi).trans_le h
  have hQsmooth : ContMDiff I 𝓘(ℝ) ∞ Q :=
    contMDiff_finsetSum (fun i (_ : i ∈ Finset.univ) => (p i).contMDiff.pow 2)
  have hroot : ContMDiff I 𝓘(ℝ) ∞ (fun x => √(Q x)) := by
    intro x
    have hx : ContMDiffAt 𝓘(ℝ) 𝓘(ℝ) ∞ Real.sqrt (Q x) :=
      contMDiffAt_iff_contDiffAt.mpr (Real.contDiffAt_sqrt (hQ x).ne')
    exact hx.comp x hQsmooth.contMDiffAt
  let w := fun i x => p i x / √(Q x)
  refine ⟨w, ?_, ?_, ?_⟩
  · intro i
    exact (p i).contMDiff.div₀ hroot (fun x => (Real.sqrt_pos.2 (hQ x)).ne')
  · intro i
    apply (closure_mono ?_).trans (hp i)
    intro x hx
    intro hz
    exact hx (by simp [w, hz])
  · intro x
    change (∑ i, (p i x / √(Q x)) ^ 2) = 1
    simp_rw [div_pow, Real.sq_sqrt (hQ x).le, ← Finset.sum_div]
    exact div_self (hQ x).ne'

end

end IsometricEmbeddingEndpoints

#print axioms IsometricEmbeddingEndpoints.exists_smoothSquarePartition
