import PositiveFormApproximation

namespace IsometricEmbeddingEndpoints

open ContinuousLinearMap

noncomputable section

variable {d : Type*} [Fintype d]

local instance : NormedAddCommGroup (MetricForm d) := inferInstance
local instance : NormedSpace ℝ (MetricForm d) := inferInstance

set_option maxHeartbeats 470000 in
/-- Uniformly approximate a positive torus metric using finitely many lattice directions
and continuous amplitudes. The weights depend continuously on the metric values. -/
theorem TorusMetric.exists_latticeMetric_near (g : TorusMetric d) {ε : ℝ} (hε : 0 < ε) :
    ∃ (n : ℕ) (ξ : Fin n × Fin (Module.finrank ℝ (Cover d)) → d → ℤ)
      (a : Fin n × Fin (Module.finrank ℝ (Cover d)) → C(UnitAddTorus d, ℝ)),
      ‖torusLatticeMetric ξ a - g.form‖ < ε := by
  classical
  let r := ε / 3
  have hr : 0 < r := by dsimp only [r]; positivity
  let U := fun c : UnitAddTorus d => {t | ‖g.form t - g.form c‖ < r}
  have hU (c : UnitAddTorus d) : IsOpen (U c) :=
    isOpen_lt (g.form.continuous.sub continuous_const).norm continuous_const
  have hself (c : UnitAddTorus d) : c ∈ U c := by
    change ‖g.form c - g.form c‖ < r
    simpa only [sub_self, norm_zero] using hr
  obtain ⟨s, hs⟩ := isCompact_univ.elim_finite_subcover U hU
    (fun t _ => Set.mem_iUnion.2 ⟨t, hself t⟩)
  let n := Fintype.card s
  let e : s ≃ Fin n := Fintype.equivFin s
  let center := fun i : Fin n => (e.symm i).val
  have hcovers (t : UnitAddTorus d) : ∃ i, ‖g.form t - g.form (center i)‖ < r := by
    obtain ⟨c, hc⟩ := Set.mem_iUnion.1 (hs (Set.mem_univ t))
    obtain ⟨hcs, htc⟩ := Set.mem_iUnion.1 hc
    change ‖g.form t - g.form c‖ < r at htc
    refine ⟨e ⟨c, hcs⟩, ?_⟩
    simpa only [center, Equiv.symm_apply_apply] using htc
  choose ξ a ha using fun i : Fin n =>
    exists_latticeSum_near_positiveForm (g.form (center i)) (g.symmetric (center i))
      (g.positive (center i)) hr
  let R := fun i : Fin n => ∑ j, a i j ^ 2 • rankOneForm (latticeVector (ξ i j))
  let w := fun i t => max 0 (r - ‖g.form t - g.form (center i)‖)
  have hw (i : Fin n) : Continuous (w i) :=
    continuous_const.max (continuous_const.sub (g.form.continuous.sub continuous_const).norm)
  have hw₀ (i : Fin n) (t : UnitAddTorus d) : 0 ≤ w i t := le_max_left _ _
  let D := fun t => ∑ i, w i t
  have hD (t : UnitAddTorus d) : 0 < D t := by
    obtain ⟨i, hi⟩ := hcovers t
    have hpos : 0 < w i t := (sub_pos.mpr hi).trans_le (le_max_right _ _)
    exact hpos.trans_le (Finset.single_le_sum (f := fun j => w j t)
      (fun j _ => hw₀ j t) (Finset.mem_univ i))
  let p := fun i t => w i t / D t
  have hp (i : Fin n) : Continuous (p i) :=
    (hw i).div (continuous_finsetSum _ (fun j _ => hw j)) (fun t => (hD t).ne')
  have hp₀ (i : Fin n) (t : UnitAddTorus d) : 0 ≤ p i t := div_nonneg (hw₀ i t) (hD t).le
  have hp₁ (t : UnitAddTorus d) : (∑ i, p i t) = 1 := by
    simp only [p, ← Finset.sum_div]
    exact div_self (hD t).ne'
  let J := Fin n × Fin (Module.finrank ℝ (Cover d))
  let ζ := fun j : J => ξ j.1 j.2
  let b := fun j : J => (⟨fun t => √(p j.1 t) * a j.1 j.2,
    (Real.continuous_sqrt.comp (hp j.1)).mul continuous_const⟩ : C(UnitAddTorus d, ℝ))
  refine ⟨n, ζ, b, lt_of_le_of_lt ?_ (show 2 * r < ε by dsimp only [r]; linarith)⟩
  apply (ContinuousMap.norm_le _ (by positivity)).2
  intro t
  have hvalue : torusLatticeMetric ζ b t = ∑ i, p i t • R i := by
    ext u v
    rw [torusLatticeMetric_apply, Fintype.sum_prod_type, sum_apply, sum_apply]
    apply Finset.sum_congr rfl
    intro i _
    simp only [b, ζ, ContinuousMap.coe_mk, mul_pow, Real.sq_sqrt (hp₀ i t), smul_apply,
      smul_eq_mul, R, sum_apply, rankOneForm_apply, Finset.mul_sum]
    apply Finset.sum_congr rfl
    intro j _
    ring
  have hsub : (torusLatticeMetric ζ b - g.form) t = ∑ i, p i t • (R i - g.form t) := by
    simp only [ContinuousMap.sub_apply, hvalue, smul_sub, Finset.sum_sub_distrib,
      ← Finset.sum_smul, hp₁, one_smul]
  rw [hsub]
  calc
    _ ≤ ∑ i, ‖p i t • (R i - g.form t)‖ := norm_sum_le _ _
    _ ≤ ∑ i, p i t * (2 * r) := by
      apply Finset.sum_le_sum
      intro i _
      rw [norm_smul_of_nonneg (hp₀ i t)]
      by_cases hi : ‖g.form t - g.form (center i)‖ < r
      · apply mul_le_mul_of_nonneg_left _ (hp₀ i t)
        have hi' := norm_sub_le_norm_sub_add_norm_sub (R i) (g.form (center i)) (g.form t)
        rw [norm_sub_rev (g.form (center i)) (g.form t)] at hi'
        exact hi'.trans (by linarith [ha i])
      · have hz : p i t = 0 := by simp [p, w, max_eq_left (sub_nonpos.mpr (le_of_not_gt hi))]
        simp only [hz, zero_mul, le_refl]
    _ = 2 * r := by rw [← Finset.sum_mul, hp₁, one_mul]

end

end IsometricEmbeddingEndpoints

#print axioms IsometricEmbeddingEndpoints.TorusMetric.exists_latticeMetric_near
