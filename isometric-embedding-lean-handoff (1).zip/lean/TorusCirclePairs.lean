import RealTorusCutoff
import TorusBernstein

namespace IsometricEmbeddingEndpoints

noncomputable section

variable {d : Type*} [Fintype d]

omit [Fintype d] in
theorem latticeVector_mul_nat (N : ℕ) (ξ : d → ℤ) :
    latticeVector (fun i => (N : ℤ) * ξ i) = (N : ℝ) • latticeVector ξ := by
  ext i
  simp only [latticeVector, PiLp.toLp_apply, PiLp.smul_apply, Int.cast_mul, Int.cast_natCast,
    smul_eq_mul]

theorem mFourier_intMode_lift (N : ℕ) (ξ : d → ℤ) (x : Cover d) :
    UnitAddTorus.mFourier (fun i => (N : ℤ) * ξ i) (flatProjection x) =
      Complex.exp ((integerPhase N ξ x : ℂ) * Complex.I) := by
  rw [mFourier_flatProjection_eq_exp, latticeVector_mul_nat, integerPhase_eq_linear]
  congr 1
  change (2 * Real.pi * Complex.I : ℂ) *
    (inner ℝ ((N : ℝ) • latticeVector ξ) x : ℂ) =
      (↑(2 * Real.pi * (N : ℝ) * inner ℝ (latticeVector ξ) x) : ℂ) * Complex.I
  simp only [real_inner_smul_left, Complex.ofReal_mul, Complex.ofReal_ofNat]
  ring

theorem fourierCarrier_sin_lift (N : ℕ) (ξ : d → ℤ) (x : Cover d) :
    fourierCarrier (fun i => (N : ℤ) * ξ i) (-Complex.I) (flatProjection x) =
      Real.sin (integerPhase N ξ x) := by
  change (-Complex.I * UnitAddTorus.mFourier _ _).re = _
  rw [mFourier_intMode_lift]
  simp [Complex.mul_re, Complex.exp_ofReal_mul_I_im]

theorem fourierCarrier_cos_lift (N : ℕ) (ξ : d → ℤ) (x : Cover d) :
    fourierCarrier (fun i => (N : ℤ) * ξ i) 1 (flatProjection x) =
      Real.cos (integerPhase N ξ x) := by
  change (1 * UnitAddTorus.mFourier _ _).re = _
  rw [one_mul, mFourier_intMode_lift, Complex.exp_ofReal_mul_I_re]

variable {ι : Type*} [Fintype ι] [DecidableEq ι]

/-- The two unit vectors in the coordinate plane of a circle pair.
The Boolean index is true for the sine coordinate. -/
def circleCoordinate (k : ι × Bool) : PiLp 2 (fun _ : ι => CirclePair) :=
  PiLp.single 2 k.1 (WithLp.toLp 2 (if k.2 then ((1 : ℝ), (0 : ℝ)) else (0, 1)))

theorem norm_circleCoordinate (k : ι × Bool) : ‖circleCoordinate k‖ = 1 := by
  rw [circleCoordinate, PiLp.norm_single]
  cases k.2 <;> simp [WithLp.norm_toLp_fst, WithLp.norm_toLp_snd]

/-- The amplitudes of the circle pairs multiplied by their constant coordinate vectors. -/
def torusCircleAmplitude (a : ι → C(UnitAddTorus d, ℝ)) (k : ι × Bool) :
    C(UnitAddTorus d, PiLp 2 (fun _ : ι => CirclePair)) :=
  ⟨fun t => a k.1 t • circleCoordinate k, (a k.1).continuous.smul continuous_const⟩

/-- The ordinary circle pairs written as a sum of real Fourier carriers on the torus. -/
def torusCirclePairs (a : ι → C(UnitAddTorus d, ℝ)) (N : ℕ) (ξ : ι → d → ℤ) :
    C(UnitAddTorus d, PiLp 2 (fun _ : ι => CirclePair)) :=
  ∑ k : ι × Bool,
    fourierCarrier (fun i => (N : ℤ) * ξ k.1 i) (if k.2 then -Complex.I else 1) •
      torusCircleAmplitude a k

theorem torusCirclePairs_lift (a : ι → C(UnitAddTorus d, ℝ)) (N : ℕ) (ξ : ι → d → ℤ)
    (x : Cover d) :
    torusCirclePairs a N ξ (flatProjection x) =
      circlePairs (fun i z => a i (flatProjection z)) (fun i z => integerPhase N (ξ i) z) x := by
  let t := flatProjection x
  let V := fun k : ι × Bool =>
    fourierCarrier (fun i => (N : ℤ) * ξ k.1 i) (if k.2 then -Complex.I else 1) •
      torusCircleAmplitude a k
  apply WithLp.ofLp_injective 2
  funext j
  have hsum : (torusCirclePairs a N ξ t) j = ∑ k, (V k t) j := by
    change PiLp.projₗ (𝕜 := ℝ) 2 (β := fun _ : ι => CirclePair) j
      (ContinuousMap.evalCLM ℝ t (∑ k, V k)) = ∑ k, (V k t) j
    rw [map_sum, map_sum]
    rfl
  change (torusCirclePairs a N ξ t) j =
    circlePair (fun z => a j (flatProjection z)) (integerPhase N (ξ j)) x
  rw [hsum, Fintype.sum_prod_type, Finset.sum_eq_single j]
  · rw [Fintype.sum_bool]
    apply WithLp.ofLp_injective 2
    ext <;>
      simp [V, t, torusCircleAmplitude, circleCoordinate, circlePair, ContinuousMap.smul_apply',
        fourierCarrier_sin_lift, fourierCarrier_cos_lift] <;> ring
  · intro i _ hij
    apply Finset.sum_eq_zero fun k _ => ?_
    simp [V, torusCircleAmplitude, circleCoordinate, ContinuousMap.smul_apply', Ne.symm hij]
  · simp

/-- Normalize the amplitudes by the angular frequency of the circle pairs. -/
def scaledTorusCirclePairs (a : ι → C(UnitAddTorus d, ℝ)) (N : ℕ) (ξ : ι → d → ℤ) :
    C(UnitAddTorus d, PiLp 2 (fun _ : ι => CirclePair)) :=
  torusCirclePairs (fun i => (2 * Real.pi * (N : ℝ))⁻¹ • a i) N ξ

theorem scaledTorusCirclePairs_lift (a : ι → C(UnitAddTorus d, ℝ)) (N : ℕ)
    (ξ : ι → d → ℤ) :
    (fun x => scaledTorusCirclePairs a N ξ (flatProjection x)) =
      circlePairs
        (fun i x => (2 * Real.pi * (N : ℝ))⁻¹ * a i (flatProjection x))
        (fun i x => (2 * Real.pi * (N : ℝ)) * inner ℝ (latticeVector (ξ i)) x) := by
  funext x
  rw [scaledTorusCirclePairs, torusCirclePairs_lift]
  simp only [ContinuousMap.smul_apply, smul_eq_mul, integerPhase_eq_linear]

theorem norm_scaledTorusCirclePairs_sq (a : ι → C(UnitAddTorus d, ℝ)) (N : ℕ)
    (ξ : ι → d → ℤ) (x : Cover d) :
    ‖scaledTorusCirclePairs a N ξ (flatProjection x)‖ ^ 2 =
      ∑ i, ((2 * Real.pi * (N : ℝ))⁻¹ * a i (flatProjection x)) ^ 2 := by
  rw [congrFun (scaledTorusCirclePairs_lift a N ξ) x, norm_circlePairs_sq]

theorem norm_fderiv_scaledTorusCirclePairs_le (a : ι → C(UnitAddTorus d, ℝ)) {N : ℕ}
    (hN : 0 < N) (ξ : ι → d → ℤ) {x : Cover d} {A : ι → Cover d →L[ℝ] ℝ}
    (ha : ∀ i, HasFDerivAt (fun z => a i (flatProjection z)) (A i) x) :
    ‖fderiv ℝ (fun z => scaledTorusCirclePairs a N ξ (flatProjection z)) x‖ ≤
      Real.sqrt (∑ i, ((2 * Real.pi * (N : ℝ))⁻¹ ^ 2 * ‖A i‖ ^ 2 +
        a i (flatProjection x) ^ 2 * ‖latticeVector (ξ i)‖ ^ 2)) := by
  have hfreq : 2 * Real.pi * (N : ℝ) ≠ 0 := by positivity
  rw [scaledTorusCirclePairs_lift]
  simpa only [innerSL_apply_norm, innerSL_apply_apply ℝ] using
    norm_fderiv_scaledCirclePairs_le ha (fun i => innerSL ℝ (latticeVector (ξ i))) hfreq

theorem abs_gram_scaledTorusCirclePairs_error_le (a : ι → C(UnitAddTorus d, ℝ)) {N : ℕ}
    (hN : 0 < N) (ξ : ι → d → ℤ) {x : Cover d} {A : ι → Cover d →L[ℝ] ℝ}
    (ha : ∀ i, HasFDerivAt (fun z => a i (flatProjection z)) (A i) x) (v w : Cover d) :
    let D := fderiv ℝ (fun z => scaledTorusCirclePairs a N ξ (flatProjection z)) x
    |inner ℝ (D v) (D w) - ∑ i, a i (flatProjection x) ^ 2 *
      (inner ℝ (latticeVector (ξ i)) v * inner ℝ (latticeVector (ξ i)) w)| ≤
      (2 * Real.pi * (N : ℝ))⁻¹ ^ 2 * (∑ i, ‖A i‖ ^ 2) * (‖v‖ * ‖w‖) := by
  have hfreq : 2 * Real.pi * (N : ℝ) ≠ 0 := by positivity
  dsimp only
  rw [scaledTorusCirclePairs_lift]
  exact abs_gram_scaledCirclePairs_remainder_le ha (fun i => innerSL ℝ (latticeVector (ξ i))) hfreq v w

end

end IsometricEmbeddingEndpoints

#print axioms IsometricEmbeddingEndpoints.torusCirclePairs_lift
#print axioms IsometricEmbeddingEndpoints.abs_gram_scaledTorusCirclePairs_error_le
