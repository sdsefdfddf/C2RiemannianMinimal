import TorusCutoff
import Mathlib.Analysis.Calculus.ContDiff.Basic

namespace IsometricEmbeddingEndpoints

open Topology

noncomputable section

variable {d : Type*} [Fintype d]

omit [Fintype d] in
theorem flatProjection_add (x y : Cover d) :
    flatProjection (x + y) = flatProjection x + flatProjection y := by
  ext i
  exact AddCircle.coe_add (p := (1 : ℝ)) (x i) (y i)

omit [Fintype d] in
theorem flatProjection_isOpenQuotientMap :
    IsOpenQuotientMap (flatProjection (d := d)) := by
  let e := (PiLp.continuousLinearEquiv 2 ℝ (fun _ : d => ℝ)).toHomeomorph
  have he : IsOpenQuotientMap e := ⟨e.surjective, e.continuous, e.isOpenMap⟩
  have hq (i : d) : IsOpenQuotientMap (fun x : ℝ => (x : AddCircle (1 : ℝ))) :=
    QuotientAddGroup.isOpenQuotientMap_mk
  exact (IsOpenQuotientMap.piMap hq).comp he

variable {H : Type*}

/-- Descend a continuous function that is constant on the fibers of the torus cover. -/
def descendFlatProjection [TopologicalSpace H] (f : Cover d → H) (hf : Continuous f)
    (h : ∀ x y, flatProjection x = flatProjection y → f x = f y) :
    C(UnitAddTorus d, H) := by
  let s := Function.surjInv (flatProjection_surjective (d := d))
  have hs : Function.RightInverse s flatProjection :=
    Function.rightInverse_surjInv flatProjection_surjective
  have he : (f ∘ s) ∘ flatProjection = f :=
    funext fun x => h _ _ (hs (flatProjection x))
  exact ⟨f ∘ s, flatProjection_isOpenQuotientMap.continuous_comp_iff.mp (he.symm ▸ hf)⟩

omit [Fintype d] in
@[simp] theorem descendFlatProjection_apply [TopologicalSpace H] (f : Cover d → H)
    (hf : Continuous f) (h : ∀ x y, flatProjection x = flatProjection y → f x = f y) (x : Cover d) :
    descendFlatProjection f hf h (flatProjection x) = f x :=
  h _ _ (Function.rightInverse_surjInv flatProjection_surjective (flatProjection x))

variable [NormedAddCommGroup H] [NormedSpace ℝ H]

private theorem fderiv_flatProjection_fiber (f : C(UnitAddTorus d, H))
    (hf : Differentiable ℝ (fun z => f (flatProjection z))) {x y : Cover d}
    (hxy : flatProjection x = flatProjection y) :
    fderiv ℝ (fun z => f (flatProjection z)) x =
      fderiv ℝ (fun z => f (flatProjection z)) y := by
  let q := fun z : Cover d => f (flatProjection z)
  have hshift : flatProjection (y - x) = 0 := by
    rw [flatProjection_sub, hxy, sub_self]
  have he : (fun z => q (z + (y - x))) = q := by
    funext z
    dsimp only [q]
    rw [flatProjection_add, hshift, add_zero]
  have hxy' : x + (y - x) = y := by abel
  have hd' : HasFDerivAt q (fderiv ℝ q y) (x + (y - x)) :=
    hxy'.symm ▸ (hf y).hasFDerivAt
  have hd := hd'.comp x ((hasFDerivAt_id x).add_const (y - x))
  have hy : HasFDerivAt q (fderiv ℝ q y) x := by
    simpa only [Function.comp_def, id_eq, ContinuousLinearMap.comp_id, he] using hd
  exact ((hf x).hasFDerivAt.unique hy)

/-- The derivative of a continuously differentiable torus lift, as a torus function. -/
def torusDifferential (f : C(UnitAddTorus d, H))
    (hf : ContDiff ℝ 1 (fun z => f (flatProjection z))) :
    C(UnitAddTorus d, Cover d →L[ℝ] H) :=
  descendFlatProjection _ (hf.continuous_fderiv one_ne_zero)
    (fun _ _ => fderiv_flatProjection_fiber f (hf.differentiable one_ne_zero))

@[simp] theorem torusDifferential_apply (f : C(UnitAddTorus d, H))
    (hf : ContDiff ℝ 1 (fun z => f (flatProjection z))) (x : Cover d) :
    torusDifferential f hf (flatProjection x) = fderiv ℝ (fun z => f (flatProjection z)) x := by
  unfold torusDifferential
  exact descendFlatProjection_apply _ _ _ _

end

end IsometricEmbeddingEndpoints
