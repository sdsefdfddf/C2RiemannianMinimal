import Mathlib.Algebra.Field.GeomSum
import Mathlib.Analysis.Normed.Group.Basic
import Mathlib.Data.Nat.ModEq
import Mathlib.Tactic.Ring

namespace IsometricEmbeddingEndpoints

open Finset

/-- The steps before `j` at which block `b` was updated. -/
def earlierBlockSteps (B j b : ℕ) : Finset ℕ :=
  (range j).filter fun i => i % B = b

theorem add_blocks_succ {A : Type*} [AddCommMonoid A] (u : ℕ → A) (v : ℕ → A)
    (B j b : ℕ) :
    u b + (∑ i ∈ earlierBlockSteps B (j + 1) b, v i) =
      u b + (∑ i ∈ earlierBlockSteps B j b, v i) + if j % B = b then v j else 0 := by
  rw [earlierBlockSteps, earlierBlockSteps, sum_filter, sum_filter, sum_range_succ, add_assoc]

theorem add_le_of_mem_currentBlockSteps {B j i : ℕ}
    (hi : i ∈ earlierBlockSteps B j (j % B)) :
    i + B ≤ j := by
  obtain ⟨hij, hm⟩ := mem_filter.mp hi
  have hij' : i < j := mem_range.mp hij
  have hd : B ∣ j - i := (Nat.modEq_iff_dvd' hij'.le).mp hm
  have h := Nat.le_of_dvd (Nat.sub_pos_of_lt hij') hd
  omega

/-- At a given step, the contribution to the currently active block from all preceding
steps has a factor `q^(-B)` compared with an unrestricted geometric bound. -/
theorem sum_currentBlockSteps_pow_le {q : ℝ} (hq : 1 < q) (B j : ℕ) :
    (∑ i ∈ earlierBlockSteps B j (j % B), q ^ i) ≤
      (q / (q - 1)) * (q ^ j / q ^ B) := by
  have hq₀ : 0 < q := zero_lt_one.trans hq
  by_cases hBj : B ≤ j
  · have hsub : earlierBlockSteps B j (j % B) ⊆ range (j - B + 1) := by
      intro i hi
      have hh := add_le_of_mem_currentBlockSteps hi
      exact mem_range.mpr (by omega)
    have hp : q ^ j / q ^ B = q ^ (j - B) := by
      apply (div_eq_iff (pow_ne_zero _ hq₀.ne')).mpr
      rw [← pow_add, Nat.sub_add_cancel hBj]
    calc
      _ ≤ ∑ i ∈ range (j - B + 1), q ^ i :=
        sum_le_sum_of_subset_of_nonneg hsub fun i _ _ => pow_nonneg hq₀.le i
      _ ≤ q ^ (j - B + 1) / (q - 1) := by
        rw [geom_sum_eq (ne_of_gt hq)]
        exact div_le_div_of_nonneg_right (sub_le_self _ zero_le_one) (sub_nonneg.mpr hq.le)
      _ = _ := by rw [hp, pow_succ]; ring
  · have hz : earlierBlockSteps B j (j % B) = ∅ := by
      apply eq_empty_iff_forall_notMem.mpr
      intro i hi
      have hh := add_le_of_mem_currentBlockSteps hi
      omega
    rw [hz, sum_empty]
    exact mul_nonneg (div_nonneg hq₀.le (sub_nonneg.mpr hq.le))
      (div_nonneg (pow_nonneg hq₀.le _) (pow_nonneg hq₀.le _))

theorem norm_sum_currentBlockSteps_le {A : Type*} [NormedAddCommGroup A]
    (v : ℕ → A) {q C : ℝ} (hq : 1 < q) (hC : 0 ≤ C)
    (hv : ∀ i, ‖v i‖ ≤ C * q ^ i) (B j : ℕ) :
    ‖∑ i ∈ earlierBlockSteps B j (j % B), v i‖ ≤
      C * ((q / (q - 1)) * (q ^ j / q ^ B)) := by
  calc
    _ ≤ ∑ i ∈ earlierBlockSteps B j (j % B), ‖v i‖ := norm_sum_le _ _
    _ ≤ ∑ i ∈ earlierBlockSteps B j (j % B), C * q ^ i := sum_le_sum fun i _ => hv i
    _ = C * ∑ i ∈ earlierBlockSteps B j (j % B), q ^ i := (mul_sum _ _ _).symm
    _ ≤ _ := mul_le_mul_of_nonneg_left (sum_currentBlockSteps_pow_le hq B j) hC

end IsometricEmbeddingEndpoints

#print axioms IsometricEmbeddingEndpoints.sum_currentBlockSteps_pow_le
