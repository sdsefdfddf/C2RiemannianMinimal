import Mathlib.Analysis.Calculus.BumpFunction.InnerProduct
import Mathlib.Analysis.Distribution.SchwartzSpace.Fourier
import Mathlib.Tactic.NormNum

namespace IsometricEmbeddingEndpoints

open MeasureTheory
open scoped FourierTransform Topology

noncomputable section

variable {V : Type*} [NormedAddCommGroup V] [InnerProductSpace ℝ V]
  [FiniteDimensional ℝ V]

/-- The dilatable cutoff symbol with plateau radius one and support radius two. -/
def unitCutoffBump : ContDiffBump (0 : V) :=
  ⟨1, 2, zero_lt_one, one_lt_two⟩

/-- Regard the real, even bump as a complex Schwartz function. -/
def unitCutoffSymbol : SchwartzMap V ℂ := by
  let b := unitCutoffBump (V := V)
  have hs : HasCompactSupport (fun x => ((b x : ℝ) : ℂ)) :=
    b.hasCompactSupport.comp_left Complex.ofReal_zero
  exact hs.toSchwartzMap (Complex.ofRealCLM.contDiff.comp b.contDiff)

theorem unitCutoffSymbol_apply (x : V) :
    unitCutoffSymbol x = (((unitCutoffBump (V := V)) x : ℝ) : ℂ) := rfl

theorem unitCutoffSymbol_one {x : V} (hx : ‖x‖ ≤ 1) : unitCutoffSymbol x = 1 := by
  rw [unitCutoffSymbol_apply, unitCutoffBump.one_of_mem_closedBall]
  · simp
  · simpa [unitCutoffBump, Metric.mem_closedBall, dist_zero_right] using hx

theorem unitCutoffSymbol_zero {x : V} (hx : 2 ≤ ‖x‖) : unitCutoffSymbol x = 0 := by
  rw [unitCutoffSymbol_apply, unitCutoffBump.zero_of_le_dist]
  · simp
  · simpa [unitCutoffBump, dist_zero_right] using hx

theorem unitCutoffSymbol_even (x : V) : unitCutoffSymbol (-x) = unitCutoffSymbol x := by
  rw [unitCutoffSymbol_apply, unitCutoffSymbol_apply, ContDiffBump.neg]

theorem unitCutoffSymbol_eventually_one {x : V} (hx : ‖x‖ < 1) :
    (unitCutoffSymbol : V → ℂ) =ᶠ[𝓝 x] fun _ => 1 := by
  have hb : x ∈ Metric.ball (0 : V) (unitCutoffBump (V := V)).rIn := by
    simpa [Metric.mem_ball, dist_zero_right, unitCutoffBump] using hx
  filter_upwards [unitCutoffBump.eventuallyEq_one_of_mem_ball hb] with y hy
  simp [unitCutoffSymbol_apply, show (unitCutoffBump (V := V)) y = 1 from hy]

variable [MeasurableSpace V] [BorelSpace V]

/-- The inverse Fourier transform is taken in the Schwartz class. -/
def cutoffKernel (χ : SchwartzMap V ℂ) : SchwartzMap V ℂ := 𝓕⁻ χ

theorem fourier_cutoffKernel (χ : SchwartzMap V ℂ) :
    𝓕 (cutoffKernel χ) = χ := by
  simp [cutoffKernel]

/-- A carrier with the Fourier sign convention used in the kernel integral. -/
def negativeCarrier (ξ y : V) : ℂ := Real.fourierChar (-inner ℝ y ξ)

/-- The zeroth moment of the modulated kernel evaluates the multiplier at the carrier. -/
theorem cutoffKernel_modulated_mass (χ : SchwartzMap V ℂ) (ξ : V) :
    (∫ y, negativeCarrier ξ y * cutoffKernel χ y) = χ ξ := by
  have h := DFunLike.congr_fun (fourier_cutoffKernel χ) ξ
  simpa only [SchwartzMap.fourier_coe, Real.fourier_eq, Circle.smul_def, smul_eq_mul,
    negativeCarrier] using h

/-- At a plateau of the symbol the first moments of the modulated kernel vanish. -/
theorem cutoffKernel_modulated_firstMoment (χ : SchwartzMap V ℂ) {ξ : V}
    (hχ : (χ : V → ℂ) =ᶠ[𝓝 ξ] fun _ => 1) (w : V) :
    (∫ y, negativeCarrier ξ y * ((inner ℝ y w : ℂ) * cutoffKernel χ y)) = 0 := by
  let f := cutoffKernel χ
  let g : SchwartzMap V (V →L[ℝ] ℂ) := SchwartzMap.smulRightCLM ℂ ℂ (innerSL ℝ) f
  have hfg : SchwartzMap.fderivCLM ℂ V ℂ χ = 𝓕 ((-(2 * Real.pi * Complex.I) : ℂ) • g) := by
    have hd := SchwartzMap.fderivCLM_fourier_eq ℂ f
    rw [show 𝓕 f = χ from fourier_cutoffKernel χ] at hd
    exact hd
  have hzero : SchwartzMap.fderivCLM ℂ V ℂ χ ξ = 0 := by
    rw [SchwartzMap.fderivCLM_apply, hχ.fderiv_eq, fderiv_const_apply]
  rw [hfg, FourierTransform.fourier_smul] at hzero
  have hc : (-(2 * Real.pi * Complex.I) : ℂ) ≠ 0 := by
    exact neg_ne_zero.mpr
      (mul_ne_zero (mul_ne_zero (by norm_num) (Complex.ofReal_ne_zero.mpr Real.pi_ne_zero))
        Complex.I_ne_zero)
  have hfourier : 𝓕 g ξ = 0 := (smul_eq_zero.mp hzero).resolve_left hc
  have hx := DFunLike.congr_fun hfourier w
  rw [SchwartzMap.fourier_coe, Real.fourier_continuousLinearMap_apply g.integrable] at hx
  simpa only [Real.fourier_eq, Circle.smul_def, smul_eq_mul, negativeCarrier,
    f, g, SchwartzMap.smulRightCLM_apply_apply, ContinuousLinearMap.smulRight_apply,
    innerSL_apply_apply ℝ, Complex.real_smul, zero_apply] using hx

end

end IsometricEmbeddingEndpoints

#print axioms IsometricEmbeddingEndpoints.cutoffKernel_modulated_firstMoment
