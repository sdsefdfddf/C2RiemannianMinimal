import CenteredChartCover
import CompactMetricMargin
import HolderCoordinateOperations
import ManifoldDirectSum

open scoped Manifold Topology ContDiff

namespace IsometricEmbeddingEndpoints

open Filter Set

noncomputable section

variable {d M F G : Type*} [Fintype d] [TopologicalSpace M] [ChartedSpace (Cover d) M]
  [NormedAddCommGroup F] [NormedSpace ℝ F] [NormedAddCommGroup G] [NormedSpace ℝ G]

local notation "𝕀" => 𝓘(ℝ, Cover d)
local notation "K₀" r:arg => Metric.closedBall (0 : Cover d) r

private theorem centeredChart_symm_zero (p : M) : (centeredChart (d := d) p).symm 0 = p := by
  rw [← centeredChart_self (d := d) p]
  exact (centeredChart (d := d) p).left_inv (mem_centeredChart_source p)

private theorem small_ball_in_nhds {s : Set (Cover d)} (hs : s ∈ 𝓝 (0 : Cover d)) :
    ∃ r : ℝ, 0 < r ∧ Metric.ball (0 : Cover d) (2 * r) ⊆ s := by
  obtain ⟨r, hr, h⟩ := Metric.mem_nhds_iff.mp hs
  refine ⟨r / 2, by positivity, ?_⟩
  rwa [show 2 * (r / 2) = r by ring]

private theorem closedBall_subset_double_ball {r : ℝ} (hr : 0 < r) :
    K₀ r ⊆ Metric.ball (0 : Cover d) (2 * r) := fun x hx => by
  have h : dist x (0 : Cover d) ≤ r := Metric.mem_closedBall.mp hx
  exact Metric.mem_ball.mpr (h.trans_lt (by linarith))

private theorem chart_target_nhds (p : M) : (centeredChart (d := d) p).target ∈ 𝓝 (0 : Cover d) :=
  (centeredChart (d := d) p).open_target.mem_nhds (zero_mem_centeredChart_target p)

theorem HasLocalHolderDifferentialAt.congr_of_eventuallyEq {a : ℝ} {f g : M → F} {p : M}
    (hf : HasLocalHolderDifferentialAt (d := d) a f p) (he : g =ᶠ[𝓝 p] f) :
    HasLocalHolderDifferentialAt (d := d) a g p := by
  obtain ⟨r, hr, ht, hreg⟩ := hf
  let e := centeredChart (d := d) p
  have he0 : ContinuousAt e.symm 0 :=
    e.symm.continuousOn.continuousAt (chart_target_nhds p)
  have heq : g ∘ e.symm =ᶠ[𝓝 (0 : Cover d)] f ∘ e.symm :=
    he.comp_tendsto (by simpa only [e, centeredChart_symm_zero] using he0.tendsto)
  obtain ⟨s, hs, hsmall⟩ := small_ball_in_nhds
    (inter_mem (Metric.closedBall_mem_nhds _ hr) (show {x | (g ∘ e.symm) x = (f ∘ e.symm) x} ∈ 𝓝 0 from heq))
  have hle : K₀ s ⊆ K₀ r := fun x hx => (hsmall (closedBall_subset_double_ball hs hx)).1
  refine ⟨s, hs, hle.trans ht, (hreg.mono hle).congr_of_eventuallyEq fun x hx => ?_⟩
  filter_upwards [Metric.isOpen_ball.mem_nhds (closedBall_subset_double_ball hs hx)] with y hy
  exact (hsmall hy).2

theorem HasLocalHolderDifferentialAt.of_smooth [IsManifold 𝕀 ∞ M]
    {a : ℝ} {f : M → F} {p : M} (hf : ContMDiff 𝕀 𝓘(ℝ, F) ∞ f)
    (ha : 0 ≤ a) (ha₁ : a ≤ 1) : HasLocalHolderDifferentialAt (d := d) a f p := by
  obtain ⟨r, hr, h⟩ := small_ball_in_nhds (chart_target_nhds (d := d) p)
  have ht := (closedBall_subset_double_ball hr).trans h
  refine ⟨r, hr, ht, hasHolderDifferentialOn_of_contDiffAt_two
    (isCompact_closedBall _ _) (convex_closedBall _ _) ?_ ha ha₁⟩
  intro x hx
  exact ((hf.contMDiffAt.comp x (contMDiffAt_centeredChart_symm (ht hx))).contDiffAt).of_le (by simp)

/-- The local condition can be verified in any smooth chart containing the point. -/
theorem hasLocalHolderDifferentialAt_of_chart [IsManifold 𝕀 ∞ M]
    {a : ℝ} {u : Cover d → F} {e : OpenPartialHomeomorph M (Cover d)} {p : M} {s : Set (Cover d)}
    (hp : p ∈ e.source) (he : ∀ y ∈ e.source, ContMDiffAt 𝕀 𝕀 ∞ e y)
    (hs : e p ∈ interior s) (hu : HasHolderDifferentialOn a u s)
    (ha : 0 ≤ a) (ha₁ : a ≤ 1) : HasLocalHolderDifferentialAt (d := d) a (u ∘ e) p := by
  let c := centeredChart (d := d) p
  let T := e ∘ c.symm
  have hc0 : ContinuousAt c.symm 0 :=
    c.symm.continuousOn.continuousAt (chart_target_nhds p)
  have hc : Filter.Tendsto c.symm (𝓝 (0 : Cover d)) (𝓝 p) := by
    simpa only [c, centeredChart_symm_zero] using hc0.tendsto
  have hT : Filter.Tendsto T (𝓝 (0 : Cover d)) (𝓝 (e p)) :=
    (he p hp).continuousAt.tendsto.comp hc
  have hn := inter_mem (chart_target_nhds p) (inter_mem
    (hc.eventually (e.open_source.mem_nhds hp))
    (hT.eventually (mem_interior_iff_mem_nhds.mp hs)))
  obtain ⟨r, hr, h⟩ := small_ball_in_nhds hn
  have hsub := (closedBall_subset_double_ball hr).trans h
  have ht (x : Cover d) (hx : x ∈ K₀ r) : x ∈ c.target := (hsub hx).1
  have hT' (x : Cover d) (hx : x ∈ K₀ r) : ContDiffAt ℝ 2 T x :=
    (((he _ (hsub hx).2.1).comp x (contMDiffAt_centeredChart_symm (ht x hx))).contDiffAt).of_le
      (by simp)
  have hC : IsCompact (K₀ r) := isCompact_closedBall _ _
  have hconv : Convex ℝ (K₀ r) := convex_closedBall _ _
  have hmaps : Set.MapsTo T (K₀ r) s := fun _ hx => (hsub hx).2.2
  exact ⟨r, hr, ht, hu.comp (hasHolderDifferentialOn_of_contDiffAt_two hC hconv hT' ha ha₁)
    hmaps hC hconv ha⟩

theorem HasLocalHolderDifferentialAt.smooth_comp [FiniteDimensional ℝ F]
    {a : ℝ} {f : M → F} {p : M} (hf : HasLocalHolderDifferentialAt (d := d) a f p)
    {g : F → G} (hg : ContDiff ℝ 2 g) (ha : 0 ≤ a) (ha₁ : a ≤ 1) :
    HasLocalHolderDifferentialAt (d := d) a (g ∘ f) p := by
  obtain ⟨r, hr, ht, h⟩ := hf
  exact ⟨r, hr, ht, h.smooth_comp (isCompact_closedBall _ _) (convex_closedBall _ _) ha ha₁ hg⟩

theorem HasLocalHolderDifferentialAt.smul [FiniteDimensional ℝ F]
    {a : ℝ} {f : M → ℝ} {g : M → F} {p : M}
    (hf : HasLocalHolderDifferentialAt (d := d) a f p)
    (hg : HasLocalHolderDifferentialAt (d := d) a g p) (ha : 0 ≤ a) (ha₁ : a ≤ 1) :
    HasLocalHolderDifferentialAt (d := d) a (fun x => f x • g x) p := by
  obtain ⟨r, hr, ht, h⟩ := hf
  obtain ⟨s, hs, _, h'⟩ := hg
  let R := min r s
  have hr' : K₀ R ⊆ K₀ r := Metric.closedBall_subset_closedBall (min_le_left _ _)
  have hs' : K₀ R ⊆ K₀ s := Metric.closedBall_subset_closedBall (min_le_right _ _)
  exact ⟨R, lt_min hr hs, hr'.trans ht, (h.mono hr').smul (h'.mono hs')
    (isCompact_closedBall _ _) (convex_closedBall _ _) ha ha₁⟩

theorem hasLocalHolderDifferentialAt_directSumMap {ι : Type*} [Fintype ι]
    {V : ι → Type*} [∀ i, NormedAddCommGroup (V i)] [∀ i, InnerProductSpace ℝ (V i)]
    [∀ i, FiniteDimensional ℝ (V i)] {a : ℝ} {f : (i : ι) → M → V i} {p : M}
    (hf : ∀ i, HasLocalHolderDifferentialAt (d := d) a (f i) p)
    (ha : 0 ≤ a) (ha₁ : a ≤ 1) :
    HasLocalHolderDifferentialAt (d := d) a (directSumMap f) p := by
  choose r hr ht h using hf
  obtain ⟨R, hR, hRt⟩ := exists_pos_le_of_finite hr
  obtain ⟨s, hs, hst⟩ := small_ball_in_nhds (chart_target_nhds (d := d) p)
  let b := min R s
  have hbR : K₀ b ⊆ K₀ R := Metric.closedBall_subset_closedBall (min_le_left _ _)
  have hbs : K₀ b ⊆ K₀ s := Metric.closedBall_subset_closedBall (min_le_right _ _)
  refine ⟨b, lt_min hR hs, hbs.trans ((closedBall_subset_double_ball hs).trans hst), ?_⟩
  exact hasHolderDifferentialOn_piLp
    (fun i => (h i).mono (hbR.trans (Metric.closedBall_subset_closedBall (hRt i))))
    (isCompact_closedBall _ _) (convex_closedBall _ _) ha ha₁

end

end IsometricEmbeddingEndpoints

#print axioms IsometricEmbeddingEndpoints.hasLocalHolderDifferentialAt_of_chart
#print axioms IsometricEmbeddingEndpoints.hasLocalHolderDifferentialAt_directSumMap
